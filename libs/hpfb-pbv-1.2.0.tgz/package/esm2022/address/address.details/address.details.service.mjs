import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { CANADA, ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class AddressDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            address: [null, Validators.required],
            provText: '',
            provState: '',
            city: ['', [Validators.required]],
            country: ['', [Validators.required]],
            postal: ['', [Validators.required]]
        });
    }
    mapFormModelToDataModel(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = formValue['country'] ?
                this._converterService.findAndConverCodeToIdTextLabel(countryList, formValue['country'], lang) : null;
            if (addressModel.country) {
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    addressModel.province_text = '';
                    addressModel.province_lov = formValue['provState'] ?
                        this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
                }
                else {
                    addressModel.province_text = formValue['provText'];
                    addressModel.province_lov = null;
                }
            }
            else {
                addressModel.province_text = formValue['provText'];
            }
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapFormModelToDataModelCanadianAddress(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = this._converterService.findAndConverCodeToIdTextLabel(countryList, CANADA, lang);
            addressModel.province_text = '';
            addressModel.province_lov = formValue['provState'] ?
                this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapDataModelToFormModel(addressModel, formRecord) {
        if (addressModel) {
            formRecord.controls['address'].setValue(addressModel.street_address);
            formRecord.controls['city'].setValue(addressModel.city);
            formRecord.controls['postal'].setValue(addressModel.postal_code);
            if (addressModel.country) {
                formRecord.controls['country'].setValue(addressModel.country._id);
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    formRecord.controls['provState'].setValue(addressModel.province_lov._id);
                }
                else {
                    formRecord.controls['provText'].setValue(addressModel.province_text);
                }
            }
            else {
                formRecord.controls['country'].setValue(null);
            }
        }
    }
    setProvinceState(record, countryId, provinceList, stateList) {
        let listToReturn = [];
        if (this._utilsService.isCanadaOrUSA(countryId)) {
            this._utilsService.resetControlsValues(record.controls['provText']);
            record.controls['provList'].setValidators([Validators.required]);
            if (this._utilsService.isCanada(countryId)) {
                record.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
                listToReturn = provinceList;
            }
            else {
                record.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
                listToReturn = stateList;
            }
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        else {
            record.controls['provList'].setValidators([]);
            record.controls['provList'].setValue('');
            record.controls['postal'].setValidators([Validators.required]);
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        return listToReturn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLmRldGFpbHMvYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQXlCLFVBQVUsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxNQUFNLEVBQXlDLGlCQUFpQixFQUFFLE1BQU0sY0FBYyxDQUFDOzs7QUFJaEcsTUFBTSxPQUFPLHFCQUFxQjtJQUVoQyxZQUFvQixhQUEyQixFQUFVLGlCQUFtQztRQUF4RSxrQkFBYSxHQUFiLGFBQWEsQ0FBYztRQUFVLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBa0I7SUFBSSxDQUFDO0lBRWpHOzs7O09BSUc7SUFDSSxnQkFBZ0IsQ0FBQyxFQUFlO1FBQ3JDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUFBLE9BQU8sSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUN4QixPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUM7WUFDZCxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNwQyxRQUFRLEVBQUUsRUFBRTtZQUNaLFNBQVMsRUFBRSxFQUFFO1lBQ2IsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2pDLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNwQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDcEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFNBQWMsRUFBRSxZQUEwQixFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsb0JBQW9CO1FBQ2hILElBQUksU0FBUyxFQUFFLENBQUM7WUFDZCxZQUFZLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNuRCxZQUFZLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0QyxZQUFZLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN6QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBRTFHLElBQUksWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN6QixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDL0QsWUFBWSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLFlBQVksQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7d0JBQ2xELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyw4QkFBOEIsQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkgsQ0FBQztxQkFBSyxDQUFDO29CQUNMLFlBQVksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUNuRCxZQUFZLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDbkMsQ0FBQztZQUNMLENBQUM7aUJBQU0sQ0FBQztnQkFDTixZQUFZLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNyRCxDQUFDO1lBQ0QsWUFBWSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakQsQ0FBQztJQUNILENBQUM7SUFFTSxzQ0FBc0MsQ0FBQyxTQUFjLEVBQUUsWUFBMEIsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLG9CQUFvQjtRQUMvSCxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsWUFBWSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkQsWUFBWSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFdEMsWUFBWSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4RyxZQUFZLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUNoQyxZQUFZLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNwRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDakgsWUFBWSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakQsQ0FBQztJQUNILENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxZQUFZLEVBQUUsVUFBcUI7UUFDaEUsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUNqQixVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDckUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3hELFVBQVUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUVqRSxJQUFJLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekIsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFbEUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9ELFVBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzNFLENBQUM7cUJBQU0sQ0FBQztvQkFDTixVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3ZFLENBQUM7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEQsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsTUFBaUIsRUFBRSxTQUFpQixFQUFFLFlBQXFCLEVBQUUsU0FBa0I7UUFFckcsSUFBSSxZQUFZLEdBQVksRUFBRSxDQUFDO1FBRS9CLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUVoRCxJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtZQUNuRSxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ2pFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztnQkFDM0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztnQkFDeEcsWUFBWSxHQUFHLFlBQVksQ0FBQztZQUM5QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztnQkFDckcsWUFBWSxHQUFHLFNBQVMsQ0FBQztZQUMzQixDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUVyRCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDL0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUNyRCxDQUFDO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQzsrR0F6R1UscUJBQXFCO21IQUFyQixxQkFBcUI7OzRGQUFyQixxQkFBcUI7a0JBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7Rm9ybUJ1aWxkZXIsIEZvcm1Hcm91cCwgVmFsaWRhdG9yc30gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBDQU5BREEsIENvbnZlcnRlclNlcnZpY2UsIElDb2RlLCBVdGlsc1NlcnZpY2UsIFZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnQGhwZmIvc2RrL3VpJztcclxuaW1wb3J0IHsgSU5hbWVBZGRyZXNzIH0gZnJvbSAnLi4vLi4vbW9kZWwvZW50aXR5LWJhc2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQWRkcmVzc0RldGFpbHNTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfdXRpbHNTZXJ2aWNlOiBVdGlsc1NlcnZpY2UsIHByaXZhdGUgX2NvbnZlcnRlclNlcnZpY2U6IENvbnZlcnRlclNlcnZpY2UpIHsgfVxyXG4gIFxyXG4gIC8qKlxyXG4gICAqIEdldHMgdGhlIHJlYWN0aXZlIGZvcm1zIE1vZGVsIGZvciBhZGRyZXNzIGRldGFpbHNcclxuICAgKiBAcGFyYW0ge0Zvcm1CdWlsZGVyfSBmYlxyXG4gICAqIEByZXR1cm5zIHthbnl9XHJcbiAgICovXHJcbiAgcHVibGljIGdldFJlYWN0aXZlTW9kZWwoZmI6IEZvcm1CdWlsZGVyKSB7XHJcbiAgICBpZiAoIWZiKSB7cmV0dXJuIG51bGw7IH1cclxuICAgIHJldHVybiBmYi5ncm91cCh7XHJcbiAgICAgIGFkZHJlc3M6IFtudWxsLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgcHJvdlRleHQ6ICcnLFxyXG4gICAgICBwcm92U3RhdGU6ICcnLFxyXG4gICAgICBjaXR5OiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXV0sXHJcbiAgICAgIGNvdW50cnk6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdXSxcclxuICAgICAgcG9zdGFsOiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXV1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcEZvcm1Nb2RlbFRvRGF0YU1vZGVsKGZvcm1WYWx1ZTogYW55LCBhZGRyZXNzTW9kZWw6IElOYW1lQWRkcmVzcywgbGFuZywgY291bnRyeUxpc3QsIGNvbWJpbmVkUHJvdlN0YXRMaXN0KSB7XHJcbiAgICBpZiAoZm9ybVZhbHVlKSB7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5zdHJlZXRfYWRkcmVzcyA9IGZvcm1WYWx1ZVsnYWRkcmVzcyddO1xyXG4gICAgICBhZGRyZXNzTW9kZWwuY2l0eSA9IGZvcm1WYWx1ZVsnY2l0eSddO1xyXG5cclxuICAgICAgYWRkcmVzc01vZGVsLmNvdW50cnkgPSBmb3JtVmFsdWVbJ2NvdW50cnknXSA/IFxyXG4gICAgICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY291bnRyeUxpc3QsIGZvcm1WYWx1ZVsnY291bnRyeSddLCBsYW5nKSA6IG51bGw7XHJcblxyXG4gICAgICBpZiAoYWRkcmVzc01vZGVsLmNvdW50cnkpIHtcclxuICAgICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhT3JVU0EoYWRkcmVzc01vZGVsLmNvdW50cnkuX2lkKSkge1xyXG4gICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSAnJztcclxuICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YgPSBmb3JtVmFsdWVbJ3Byb3ZTdGF0ZSddID8gXHJcbiAgICAgICAgICAgIHRoaXMuX2NvbnZlcnRlclNlcnZpY2UuZmluZEFuZENvbnZlckNvZGVUb0lkVGV4dExhYmVsKGNvbWJpbmVkUHJvdlN0YXRMaXN0LCBmb3JtVmFsdWVbJ3Byb3ZTdGF0ZSddLCBsYW5nKSA6IG51bGw7XHJcbiAgICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV90ZXh0ID0gZm9ybVZhbHVlWydwcm92VGV4dCddO1xyXG4gICAgICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfbG92ID0gbnVsbDtcclxuICAgICAgICAgIH0gXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSBmb3JtVmFsdWVbJ3Byb3ZUZXh0J107XHJcbiAgICAgIH1cclxuICAgICAgYWRkcmVzc01vZGVsLnBvc3RhbF9jb2RlID0gZm9ybVZhbHVlWydwb3N0YWwnXTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHB1YmxpYyBtYXBGb3JtTW9kZWxUb0RhdGFNb2RlbENhbmFkaWFuQWRkcmVzcyhmb3JtVmFsdWU6IGFueSwgYWRkcmVzc01vZGVsOiBJTmFtZUFkZHJlc3MsIGxhbmcsIGNvdW50cnlMaXN0LCBjb21iaW5lZFByb3ZTdGF0TGlzdCkge1xyXG4gICAgaWYgKGZvcm1WYWx1ZSkge1xyXG4gICAgICBhZGRyZXNzTW9kZWwuc3RyZWV0X2FkZHJlc3MgPSBmb3JtVmFsdWVbJ2FkZHJlc3MnXTtcclxuICAgICAgYWRkcmVzc01vZGVsLmNpdHkgPSBmb3JtVmFsdWVbJ2NpdHknXTtcclxuXHJcbiAgICAgIGFkZHJlc3NNb2RlbC5jb3VudHJ5ID0gdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY291bnRyeUxpc3QsIENBTkFEQSwgbGFuZyk7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV90ZXh0ID0gJyc7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YgPSBmb3JtVmFsdWVbJ3Byb3ZTdGF0ZSddID8gXHJcbiAgICAgIHRoaXMuX2NvbnZlcnRlclNlcnZpY2UuZmluZEFuZENvbnZlckNvZGVUb0lkVGV4dExhYmVsKGNvbWJpbmVkUHJvdlN0YXRMaXN0LCBmb3JtVmFsdWVbJ3Byb3ZTdGF0ZSddLCBsYW5nKSA6IG51bGw7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5wb3N0YWxfY29kZSA9IGZvcm1WYWx1ZVsncG9zdGFsJ107XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbWFwRGF0YU1vZGVsVG9Gb3JtTW9kZWwoYWRkcmVzc01vZGVsLCBmb3JtUmVjb3JkOiBGb3JtR3JvdXApIHtcclxuICAgIGlmIChhZGRyZXNzTW9kZWwpIHtcclxuICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snYWRkcmVzcyddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5zdHJlZXRfYWRkcmVzcyk7XHJcbiAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2NpdHknXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwuY2l0eSk7XHJcbiAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5wb3N0YWxfY29kZSk7XHJcblxyXG4gICAgICBpZiAoYWRkcmVzc01vZGVsLmNvdW50cnkpIHtcclxuICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydjb3VudHJ5J10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLmNvdW50cnkuX2lkKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3V0aWxzU2VydmljZS5pc0NhbmFkYU9yVVNBKGFkZHJlc3NNb2RlbC5jb3VudHJ5Ll9pZCkpIHtcclxuICAgICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ3Byb3ZTdGF0ZSddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YuX2lkKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1sncHJvdlRleHQnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2NvdW50cnknXS5zZXRWYWx1ZShudWxsKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIHNldFByb3ZpbmNlU3RhdGUocmVjb3JkOiBGb3JtR3JvdXAsIGNvdW50cnlJZDogc3RyaW5nLCBwcm92aW5jZUxpc3Q6IElDb2RlW10sIHN0YXRlTGlzdDogSUNvZGVbXSk6IElDb2RlW10ge1xyXG5cclxuICAgIGxldCBsaXN0VG9SZXR1cm46IElDb2RlW10gPSBbXTtcclxuXHJcbiAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhT3JVU0EoY291bnRyeUlkKSkge1xyXG5cclxuICAgICAgdGhpcy5fdXRpbHNTZXJ2aWNlLnJlc2V0Q29udHJvbHNWYWx1ZXMocmVjb3JkLmNvbnRyb2xzWydwcm92VGV4dCddKVxyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZF0pO1xyXG4gICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhKGNvdW50cnlJZCkpIHtcclxuICAgICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLmNhbmFkYVBvc3RhbFZhbGlkYXRvcl0pO1xyXG4gICAgICAgIGxpc3RUb1JldHVybiA9IHByb3ZpbmNlTGlzdDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLnVzYVBvc3RhbFZhbGlkYXRvcl0pO1xyXG4gICAgICAgIGxpc3RUb1JldHVybiA9IHN0YXRlTGlzdDtcclxuICAgICAgfVxyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10uc2V0VmFsaWRhdG9ycyhbXSk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWx1ZSgnJyk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZF0pO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gbGlzdFRvUmV0dXJuO1xyXG4gIH1cclxuICBcclxufSJdfQ==