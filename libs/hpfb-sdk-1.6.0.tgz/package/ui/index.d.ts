import * as i0 from '@angular/core';
import { OnChanges, SimpleChanges, AfterViewInit, QueryList, EventEmitter, TemplateRef, ChangeDetectorRef, PipeTransform, OnInit, InjectionToken, ElementRef } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormControl, FormArray, AbstractControl, FormGroup, NgControl, FormBuilder } from '@angular/forms';
import * as i3 from '@angular/common';
import * as i5 from '@ngx-translate/core';
import { TranslateService } from '@ngx-translate/core';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import * as _angular_common_http from '@angular/common/http';
import { HttpClient, HttpErrorResponse, HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';
import { Router } from '@angular/router';

declare class LayoutComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutComponent, "lib-layout", never, {}, {}, never, ["[header]", "[body]"], true, never>;
}

interface IValidationService {
    getValidatorErrorMessage(key: string): string | null;
}

declare class ErrMessageService {
    private validationServices;
    constructor(validationServices: IValidationService[]);
    getValidatorErrorMessageKey(validatorName: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrMessageService>;
}

declare class ControlMessagesComponent implements OnChanges {
    private _errMessageService;
    /**
     *  The reactive form control that this message relates
     */
    control: FormControl;
    /**
     * When true, indicates to show the error, even if control was not touched
     * @type {boolean}
     */
    showError: boolean;
    /**
     * Label message key that is associated to the control. Used for the error summary
     */
    label: string;
    /**
     * The id of the control. Used for the error summary to create the anchor link
     */
    controlId: string;
    /**
     * The id of the parent of the control. For the error summary componnet, currently not used?
     */
    parentId: string;
    /**
     * The label message key of the parent of hte control . Used for the error summary component. Currently not used?
     */
    parentLabel: string;
    /**
     * The already translated label of the parent of hte control . Used for the error summary component.
     */
    translatedParentLabel: string;
    /***
     * Index of the error. Used to expand the expander for the error summaryt
     */
    index: Number;
    /**
     * For manually showing inline control message for disabled FormControl.
     */
    disabledError?: boolean;
    /**
    * Number of error from error summary
    */
    errorNumber: string;
    /**
     * Flag to indicate if error summary
     */
    errorSummaryFlag: boolean;
    /**
     * Current error type for the control
     * @type {string}
     */
    currentError: string;
    /**
     *  A reference the tabset control NgbTabset from Angular bootstrap
     * @type {null}
     */
    /**
     * Th id of the target tab, the tab containing the error
     * @type (string)
     */
    tabId: string;
    errorParams: {
        [key: string]: string;
    };
    /**
     * controls visiblity
     * @type boolean
     */
    private _errorVisible;
    constructor(_errMessageService: ErrMessageService);
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage(): string;
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible(): boolean;
    isCanadianPostalCode(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ControlMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ControlMessagesComponent, "control-messages", never, { "control": { "alias": "control"; "required": false; }; "showError": { "alias": "showError"; "required": false; }; "label": { "alias": "label"; "required": false; }; "controlId": { "alias": "controlId"; "required": false; }; "parentId": { "alias": "parentId"; "required": false; }; "parentLabel": { "alias": "parentLabel"; "required": false; }; "translatedParentLabel": { "alias": "translatedParentLabel"; "required": false; }; "index": { "alias": "index"; "required": false; }; "disabledError": { "alias": "disabledError"; "required": false; }; }, {}, never, never, false, never>;
}

declare abstract class BaseComponent implements AfterViewInit {
    protected msgList: QueryList<ControlMessagesComponent>;
    constructor();
    ngAfterViewInit(): void;
    protected _updateAndEmitErrors(errorObjs: any): void;
    protected _appendErrorsFromChild(errorsFromChild: ControlMessagesComponent[]): void;
    protected abstract emitErrors(errors: any[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseComponent, never, never, {}, {}, never, never, true, never>;
}

declare class ExpanderComponent implements OnChanges {
    accordionHeadingMsgKey: string;
    /**
     * Disable expand
     */
    disableExpand: boolean;
    /**
     * When set to true, disables collapse of a details section that is in error
     * @type {boolean}
     */
    /**
     * sets if the details form is valid. Controls collapses state
     * @type {boolean}
     */
    isValid: boolean;
    /**
     * The list of records to display in the expander component
     */
    itemsList: any;
    /**
     * Signal to indicate a record has been added
     * @type {number}
     */
    addRecord: number;
    /**
     * Expands a record when it has been added. Default is false
     */
    expandOnAdd: boolean;
    deleteRecord: number;
    collapseAll: number;
    loadFileIndicator: boolean;
    xmlStatus: any;
    expandedRow: EventEmitter<any>;
    private tableRowIndexCurrExpanded;
    private tableRowIndexPreExpanded;
    private _expandAdd;
    /**
     * for each table row, stores the state i.e. collapsed or expanded
     * @type {boolean[]}
     * @private
     */
    private _expanderTable;
    /**
     * an array of JSON objects to define the column labels, widths and bindings
     * @type {any[]}
     */
    columnDefinitions: any[];
    /**
     * The number of columns for this expander. Used to determine columnSpan
     * @type {number}
     */
    numberColSpan: number;
    dataItems: any[];
    private _expanderValid;
    constructor();
    ngOnInit(): void;
    /**
     * Looks for and reacts to changes in the expander component
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Adds an additional row to the expander UI state tracking array
     */
    updateDataRows(srcList: any): void;
    /**
     * For a given row denoted by a zero based index, returns if a row is collapsed or expanded
     * @param {number} index
     * @returns {boolean}
     */
    getExpandedState(index: number): boolean;
    /**
     *  Checks if a given zero based row denoted by index is expanded
     * @param {number} index
     * @returns {boolean}
     */
    isExpanded(index: number): boolean;
    /**
     *  Checks if a given zero based row denoted by index is collapsed
     * @param {number} index
     * @returns {boolean}
     */
    isCollapsed(index: number): boolean;
    broadcastExpandedRow(): void;
    getExpandedRow(): number;
    /**
     * Selects the table row to expand or collapse. If disable expand is enabled, will not collapse a row if it is in error
     * @param {number} index
     */
    selectTableRow(index: number): void;
    selectTableRowNoCheck(index: number): void;
    /**
     * Collapses all the table rows. Ignores any error states in the details.
     */
    collapseTableRows(): void;
    /**
     * Get the row title dynamic according to the expand/collapse status
     */
    getRowTitle(i: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpanderComponent, "lib-expander", never, { "accordionHeadingMsgKey": { "alias": "accordionHeadingMsgKey"; "required": false; }; "disableExpand": { "alias": "disableExpand"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "itemsList": { "alias": "group"; "required": false; }; "addRecord": { "alias": "addRecord"; "required": false; }; "expandOnAdd": { "alias": "expandOnAdd"; "required": false; }; "deleteRecord": { "alias": "deleteRecord"; "required": false; }; "collapseAll": { "alias": "collapseAll"; "required": false; }; "loadFileIndicator": { "alias": "loadFileIndicator"; "required": false; }; "xmlStatus": { "alias": "xmlStatus"; "required": false; }; "columnDefinitions": { "alias": "columnDefinitions"; "required": false; }; }, { "expandedRow": "expandedRow"; }, never, ["*"], false, never>;
}

declare class AccordionComponent {
    rowsFormArray: FormArray;
    accordionHeadingMsgKey: string;
    accordionHeadingSupp: any;
    rowClicked: EventEmitter<any>;
    tmplRef: TemplateRef<any>;
    accordionState: string;
    toggleExpand(index: number, expanded: boolean): void;
    constructor();
    getNestedFormValue(recordRow: any, keys: string[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionComponent, "lib-accordion", never, { "rowsFormArray": { "alias": "rowsFormArray"; "required": false; }; "accordionHeadingMsgKey": { "alias": "accordionHeadingMsgKey"; "required": false; }; "accordionHeadingSupp": { "alias": "accordionHeadingSupp"; "required": false; }; }, { "rowClicked": "rowClicked"; }, ["tmplRef"], never, false, never>;
}

declare class ExpanderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ExpanderModule, [typeof ExpanderComponent, typeof AccordionComponent], [typeof i3.CommonModule, typeof i1.ReactiveFormsModule, typeof i5.TranslateModule], [typeof ExpanderComponent, typeof AccordionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ExpanderModule>;
}

declare class ErrorSummaryComponent implements AfterViewInit {
    private cdr;
    private _errMessageService;
    headingPreamble: string;
    headingPreambleParams: any;
    errorList: any;
    hiddenSummary: any;
    compId: string;
    label: string;
    headingLevel: string;
    type: string;
    errors: {};
    componentId: string;
    tableId: string;
    hdingLevel: string;
    index: number;
    expander: ExpanderComponent;
    errorCount: number;
    errorNumberValue: string;
    constructor(cdr: ChangeDetectorRef, _errMessageService: ErrMessageService);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Creates an array of error elements based on the incoming error objects
     * Currently groups the errors by parent. Not doing anything with parent right now.
     * But could display errors groupded by the parent and parent label
     * @param errorList
     */
    processErrors(errorList: any): void;
    /**
     * Selects thje tab from an ngbTabset
     * @param error- the error object created by the summary component
     */
    processEvents(error: any): void;
    private resetErrorCount;
    getValidatorErrorMessageKey(error: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorSummaryComponent, "lib-error-summary", never, { "headingPreamble": { "alias": "headingPreamble"; "required": false; }; "headingPreambleParams": { "alias": "headingPreambleParams"; "required": false; }; "errorList": { "alias": "errorList"; "required": false; }; "hiddenSummary": { "alias": "hiddenSummary"; "required": false; }; "compId": { "alias": "compId"; "required": false; }; "label": { "alias": "label"; "required": false; }; "headingLevel": { "alias": "headingLevel"; "required": false; }; }, {}, never, never, false, never>;
}

declare class JsonKeysPipe implements PipeTransform {
    /**
     * Transforms a list of json objects into an array
     * Creates key value pairs
     * @param value
     * @param {string[]} args
     * @returns {any}
     */
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonKeysPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<JsonKeysPipe, "keys", false>;
}

declare class FormControlPipe implements PipeTransform {
    transform(value: AbstractControl): FormControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormControlPipe, "formControl", false>;
}

interface ICode {
    id: string;
    en: string;
    fr: string;
    sortPriority?: number;
}
interface ICodeDefinition extends ICode {
    defEn: string;
    defFr: string;
}
interface ICodeAria extends ICodeDefinition {
    ariaEn: string;
    ariaFr: string;
}
interface IParentChildren {
    parentId: string;
    children: ICodeDefinition[];
}
declare enum SortOn {
    ID = "id",
    ENGLISH = "en",
    FRENCH = "fr",
    PRIORITY = "sortPriority"
}
interface IKeyword {
    name: string;
    data: ICode[];
}

declare class TextTransformPipe implements PipeTransform {
    transform(value: ICode, lang: string): unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextTransformPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TextTransformPipe, "textTransform", false>;
}

declare class AriaTransformPipe implements PipeTransform {
    transform(value: ICodeAria, lang: string): unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<AriaTransformPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AriaTransformPipe, "ariaTransform", false>;
}

declare class PipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PipesModule, [typeof JsonKeysPipe, typeof FormControlPipe, typeof TextTransformPipe, typeof AriaTransformPipe], never, [typeof JsonKeysPipe, typeof FormControlPipe, typeof TextTransformPipe, typeof AriaTransformPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PipesModule>;
}

declare class ErrorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ErrorModule, [typeof ErrorSummaryComponent, typeof ControlMessagesComponent], [typeof i3.CommonModule, typeof PipesModule, typeof i5.TranslateModule], [typeof ErrorSummaryComponent, typeof ControlMessagesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ErrorModule>;
}

declare class ErrorNotificationService {
    private errorSummarySubject;
    errorSummaryChanged$: rxjs.Observable<{
        key: string;
        errSummaryMessage: ErrorSummaryComponent;
    }[]>;
    updateErrorSummary(key: string, errorMessage: ErrorSummaryComponent): void;
    removeErrorSummary(key: string): void;
    clearErrors(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorNotificationService>;
}

interface ErrorSummaryObject {
    index: number;
    label: string;
    controlId: string;
    error: string;
    type: string;
    tabId: number;
    componentId: string;
    tableId: string;
    expander: ExpanderComponent;
    compRef: any;
    errorNumber: string;
}
declare const ERR_TYPE_COMPONENT: string;
declare const ERR_TYPE_LEAST_ONE_REC: string;
/**
 * Creates a flat json object for the error summary component UI
 * @returns {object}
 */
declare function getEmptyErrorSummaryObj(): ErrorSummaryObject;

declare class DataLoaderService {
    private http;
    constructor(http: HttpClient);
    getData<T>(endpoint: string): Observable<T[]>;
    /**
     * @deprecated Will not be used in the future, use getSortedDataAccents() instead
     * @param endpoint
     * @param compareField
     * @returns
     */
    getSortedData<T extends ICode>(endpoint: string, compareField: SortOn): Observable<T[]>;
    private getCompareFunction;
    getSortedDataAccents<T extends ICode>(endpoint: string, compareFields: SortOn[]): Observable<T[]>;
    private getCompareFunctions;
    private getFieldValue;
    handleError(err: HttpErrorResponse): Observable<never>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DataLoaderService>;
}

interface IText {
    __text: string;
}
interface IIdText {
    _id: string;
    __text?: string;
}
interface IIdTextLabel {
    _id: string;
    __text?: string;
    _label_en: string;
    _label_fr: string;
}
interface ILabel {
    _label_en: string;
    _label_fr: string;
}
interface ITextLabel {
    __text?: string;
    _label_en: string;
    _label_fr: string;
}

declare class EntityBaseService {
    getEmptyIdTextLabel(): IIdTextLabel;
    getEmptyIIdText(): IIdText;
    getEmptyLabel(): ILabel;
    getEmptyITextLabel(): ITextLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityBaseService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntityBaseService>;
}

interface CheckboxOption {
    value: string;
    label: string;
    checked: boolean;
}

declare class UtilsService {
    isCanadaOrUSA(countryValue: any): boolean;
    /**
     * Checks of the value is canada or not. Checks for Json object vs single value
     * @param value the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isCanada(countryValue: any): boolean;
    /**
     * Checks if the value usa or not. Checks for Json object vs single value
     * @param value - the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isUsa(countryValue: any): boolean;
    static isFrench(lang: string): boolean;
    isFrench(lang: string): boolean;
    getFormattedDate(format: string): string;
    isFirstChange(changes: SimpleChanges): boolean;
    /**
     * find a code by its id in a code array
     * @param codeArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeById(codeArray: ICode[], id: string): ICode | undefined;
    filterCodesByIds(codeArray: ICode[], idsToFilter: string[]): ICode[];
    /**
     * find a codeDefinition by its id in a codeDefinition array
     * @param codeDefinitionArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeDefinitionById(codeDefinitionArray: ICodeDefinition[], id: string): ICodeDefinition | undefined;
    /**
     * get the id value from an IdTextLabel object
     * @param idTextLabelObj
     * @returns either id or undefined
     */
    getIdFromIdTextLabel(idTextLabelObj: IIdTextLabel): string;
    getIdsFromIdTextLabels(idTextLabelObjs: any): string[];
    getLabelFromIdTextLabelByLang(idTextLabelObj: IIdTextLabel, lang: string): string;
    isArrayOfIIdTextLabel(arr: any[]): arr is IIdTextLabel[];
    isIIdTextLabel(obj: any): obj is IIdTextLabel;
    filterParentChildrenArray(arr: IParentChildren[], pId: string): ICodeDefinition[];
    concat(...param: string[]): string;
    resetControlsValues(...controls: AbstractControl<any, any>[]): void;
    getCodeDefinitionByLang(codeDefinition: ICodeDefinition, lang: string): string;
    getCodeDefinitionByIdByLang(id: string, list: ICodeDefinition[], lang: string): string;
    toBoolean: (value: string | number | boolean) => boolean;
    isEmpty(value: any): boolean;
    flattenArrays<T>(arrays: T[]): T[];
    isArray1ElementInArray2(array1: any[], array2: any[]): boolean;
    copyFormGroupValues(source: FormGroup, destination: FormGroup): void;
    getControlName(control: AbstractControl): any;
    logFormControlState(form: AbstractControl, indent?: string): void;
    checkInputValidity(event: any, control: AbstractControl, errorMsgKey: string): void;
    checkComponentChanges(changes: SimpleChanges): any[];
    checkFormInvalidFields(FormGroup: FormGroup): void;
    findAndTranslateCode(codeArray: ICode[], lang: string, codeId: string): string;
    translateCode(code: ICode, lang: string): string;
    createIIdTextLabelObj(id: string, label_en: string, label_fr: string, text?: string): IIdTextLabel;
    sortCodeList(codeArray: ICode[], lang: string): ICode[];
    getEnumValueFromString<T>(enumType: T, value: string): T[keyof T] | undefined;
    formatAsSixDigitNumber(value: string): string;
    removeFirstAndLastChars(value: string): string;
    getCompareFields(sortOnPriority: boolean, lang: string): SortOn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UtilsService>;
}

declare class ConverterService {
    private _utilsService;
    constructor(_utilsService: UtilsService);
    convertCodeToIdTextLabel(codeObj: ICode, lang: string): IIdTextLabel;
    convertCodeToCheckboxOption(codeObj: ICode, lang: string): CheckboxOption;
    findAndConverCodeToIdTextLabel(codeList: ICode[], controlVal: string, lang: string): IIdTextLabel;
    findAndConverCodesToIdTextLabels(codeList: ICode[], controlVals: string[], lang: string): IIdTextLabel[];
    checkCheckboxes(loadedCodes: string[], optionList: CheckboxOption[], checkboxFormArray: FormArray): void;
    getCheckedCheckboxValues(optionList: CheckboxOption[], checkboxFormArray: FormArray): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ConverterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConverterService>;
}

declare class ConvertResults {
    messages: string[];
    data: any;
}

declare class FileConversionService {
    constructor();
    /***
     * Converts an incoming json string to a json object
     * @param data -the json string to convert
     * @param convertResult -the json object to store the data in
     */
    convertToJSONObjects(jsonData: any, convertResult: ConvertResults): void;
    /***
     *  Using xml2js to do the coversion from JSON to XML
     * @param data
     * @param convertResult
     */
    convertXMLToJSONObjects(data: any, convertResult: ConvertResults): any;
    /***
     * Converts a json object to XML. Assumes root tag is root of JSON object
     * @param jsonObj
     * @returns {any}
     */
    convertJSONObjectsToXML(jsonObj: any): any;
    saveJsonToFile(jsonObj: any, fileName: string, rootTag: string): void;
    /**
     * Saves the incoming JSON data as an xml file
     * @param jsonObj -the json object to write as XML
     * @param {string} fileName - the bsse filename to save the file as. the suffix is sdded
     * @param {boolean} addXsl
     * @param {string} xslName
     */
    saveXmlToFile(jsonObj: any, fileName: string, addXsl?: boolean, xslName?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileConversionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileConversionService>;
}

declare class FilereaderComponent implements OnInit {
    private translate;
    complete: EventEmitter<any>;
    rootTag: string;
    lang: string;
    versionTagPath?: string;
    startCheckSumVersion?: number;
    devEnv?: boolean;
    byPassCheckSum?: boolean;
    status: string;
    importSuccess: boolean;
    importedFileName: string;
    displayAlert: boolean;
    private rootId;
    constructor(translate: TranslateService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Attaches to the file browser, detecting the file selection change
     * @param $event
     */
    changeListener($event: any): void;
    /**
     * Determines if a file was selected. Sets a callback to process the file after load (asych)
     * @param inputValue
     */
    readSelectedFile(inputValue: any): void;
    /***
     * Processes the file data. Determines the type of file based on the filename suffix
     * @param name - the name of the file. Can include the path
     * @param result - the result of the file read i.e. file contents as text
     * @param rootId - the name of the rootTag. If null is ignored
     * @param {ConvertResults} convertResult -The results of the file read
     * @private
     */
    private static _readFile;
    private static checkRootTagMatch;
    refreshPage(): void;
    private static checkSumCheck;
    private static strictCheckSumCheck;
    private static doCheckSumCheck;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilereaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilereaderComponent, "lib-file-reader", never, { "rootTag": { "alias": "rootTag"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "versionTagPath": { "alias": "versionTagPath"; "required": false; }; "startCheckSumVersion": { "alias": "startCheckSumVersion"; "required": false; }; "devEnv": { "alias": "devEnv"; "required": false; }; "byPassCheckSum": { "alias": "byPassCheckSum"; "required": false; }; }, { "complete": "complete"; }, never, ["[fileUploadInstruction]"], false, never>;
}

declare class FileIoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileIoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FileIoModule, [typeof FilereaderComponent], [typeof i3.CommonModule, typeof i5.TranslateModule], [typeof FilereaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FileIoModule>;
}

declare const CANADA: string;
declare const USA: string;
declare const ENGLISH: string;
declare const FRENCH: string;
declare const YES: string;
declare const NO: string;
declare const FINAL: string;
declare const OTHER_EN: string;
declare const OTHER_FR: string;
declare const RECORD_ACTIONS: {
    SAVE: string;
    DISCARD: string;
    DELETE: string;
};

declare const CHECK_SUM_CONST = "check_sum";

declare class ValidationService implements IValidationService {
    constructor();
    getValidatorErrorMessage(validatorName: string): string | null;
    static emailValidator(control: any): {
        'error.msg.email': boolean;
    };
    static canadaPostalValidator(control: any): {
        'error.msg.postal': boolean;
    };
    static usaPostalValidator(control: any): {
        'error.mgs.zip': boolean;
    };
    static countryValidator(control: any): {
        required: boolean;
    };
    static phoneNumberValidator(control: any): {
        'error.msg.phone': boolean;
    };
    static faxNumberValidator(control: any): {
        'error.msg.fax': boolean;
    };
    static numberValidator(control: any): {
        'error.msg.number': boolean;
    };
    static companyIdValidator(control: any): {
        'error.mgs.company.id': boolean;
    };
    static numeric4Validator(control: any): {
        'error.mgs.4.numeric': boolean;
    };
    static numeric5Validator(control: any): {
        'error.mgs.5.numeric': boolean;
    };
    static numeric6Validator(control: any): {
        'error.mgs.6.numeric': boolean;
    };
    static numeric8Validator(control: any): {
        'error.mgs.8.numeric': boolean;
    };
    static dossierIdValidator(control: any): {
        'error.mgs.dossier.id': boolean;
    };
    static dossierContactIdValidator(control: any): {
        'error.mgs.contact.id': boolean;
    };
    static regulatoryContactIdValidator(control: any): {
        'error.mgs.regu.contact.id': boolean;
    };
    static licenceNumValidator(control: any): {
        'error.mgs.licence.number': boolean;
    };
    static appNumValidator(control: any): {
        'error.mgs.application.number': boolean;
    };
    static dinValidator(control: any): {
        'error.mgs.din': boolean;
    };
    static npnValidator(control: any): {
        'error.mgs.npn': boolean;
    };
    static checkboxRequiredValidator(control: any): {
        required: boolean;
    };
    static contactIdValidator(control: any): {
        'error.mgs.contact.id': boolean;
    };
    static primaryCompanyIdValidator(control: any): {
        'error.mgs.company.id': boolean;
    };
    static atLeastOneCheckboxSelected(formArray: FormArray): {
        required: boolean;
    };
    static masterFileNumberValidator(control: any): {
        'error.mgs.incorrectFormat': boolean;
    };
    static masterFileDossierIdValidator(control: any): {
        'error.mgs.dossier.id': boolean;
    };
    static accountNumberValidator(control: any): {
        'error.msg.account': boolean;
    };
    static businessNumberValidator(control: any): {
        'error.msg.business': boolean;
    };
    static limitValidation(control: any): {
        'error.msg.amount.limit': boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidationService>;
}

declare const VALIDATION_SERVICES: InjectionToken<IValidationService[]>;

declare class CheckSumService {
    constructor();
    checkHash(convertResultData: any): Boolean;
    createHash(result: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckSumService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckSumService>;
}

declare class NumbersOnlyDirective {
    private control;
    private el;
    constructor(control: NgControl, el: ElementRef);
    onInput(value: string): void;
    onPaste(event: ClipboardEvent): void;
    private filterValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumbersOnlyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NumbersOnlyDirective, "[data-only-digits]", never, {}, {}, never, never, true, never>;
}

declare class NumbersLettersDirective {
    private control;
    private el;
    constructor(control: NgControl, el: ElementRef);
    onInput(value: string): void;
    onPaste(event: ClipboardEvent): void;
    private filterValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumbersLettersDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NumbersLettersDirective, "[data-number-letter]", never, {}, {}, never, never, true, never>;
}

declare class CommonFormDendencyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonFormDendencyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonFormDendencyModule, never, never, [typeof i1.FormsModule, typeof i1.ReactiveFormsModule, typeof i5.TranslateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonFormDendencyModule>;
}

declare class CommonUiFeatureModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonUiFeatureModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonUiFeatureModule, never, [typeof i3.CommonModule, typeof i1.FormsModule, typeof i1.ReactiveFormsModule, typeof i5.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonUiFeatureModule>;
}

declare class NoCacheHeadersInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): rxjs.Observable<_angular_common_http.HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NoCacheHeadersInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NoCacheHeadersInterceptor>;
}

declare class VersionService {
    getApplicationVersion(appEnvironment: any): any;
    /**
     * get the major and minor version of the application concatenated with '.'
     * @param appVersion format is 1.0.0
     * @returns string
     */
    getApplicationMajorVersion(appVersion: string): string;
    /**
    * get the major and minor version of the application concatenated with '_'
    * @param appVersion format is 1.0.0
    * @returns string
    */
    getApplicationMajorVersionWithUnderscore(appVersion: string): string;
    /**
     * Extracts the major version number from a version string.
     *
     * @param versionStr - The version string in the format "major.minor.patch", e.g., "1.0.0".
     * @returns The major version number as an integer.
     */
    getMajorVersion(versionStr: string): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionService>;
}

declare class PrivacyStatementComponent {
    lang: any;
    purposeOfCollection?: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrivacyStatementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PrivacyStatementComponent, "lib-privacy-statement", never, { "lang": { "alias": "lang"; "required": false; }; "purposeOfCollection": { "alias": "purposeOfCollection"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SecurityDisclaimerComponent {
    lang: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurityDisclaimerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SecurityDisclaimerComponent, "lib-security-disclaimer", never, { "lang": { "alias": "lang"; "required": false; }; }, {}, never, never, true, never>;
}

declare class InstructionService {
    private helpTextIndx;
    constructor();
    /**
     * Sets the Help Text Index
     *
     * instructionHeadings should be a list
     * @deprecated Use `createtHelpTextIndex` instead
     */
    getHelpTextIndex(instructionHeadings: any): HelpIndex;
    createHelpSequence(prefix: string, suffix: string, instructionHeadings: string[]): HelpSequence;
    static ɵfac: i0.ɵɵFactoryDeclaration<InstructionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InstructionService>;
}
/**
 * @deprecated Use `HelpSequence` instead
 */
interface HelpIndex {
    [key: string]: number;
}
interface HelpSequence {
    [key: string]: [number, string, string];
}

declare class LoggerService {
    log(debugEnabled: boolean, className: string, methodName: string, ...messages: any[]): void;
    error(debugEnabled: boolean, className: string, methodName: string, ...messages: any[]): void;
    warn(debugEnabled: boolean, className: string, methodName: string, ...messages: any[]): void;
    private formatMessages;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}

declare class RoutingService {
    private router;
    constructor(router: Router);
    navigateTo(path: string): void;
    navigateToWithExtra(path: string, stateData: {
        [propertyKey: string]: any;
    }): void;
    getStateData<T>(propertyKey: string): T;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingService>;
}

interface RecordFormGroup extends OutputRecord, FormGroup {
    isNew: boolean;
    expandFlag: boolean;
    lastSavedState: any;
    recordInfo: FormGroup;
    recordId: number;
}
interface OutputRecord {
    id: number;
}

interface IBaseList<T extends OutputRecord> {
    recordList: T[];
    recordFormGroup: FormGroup;
    showErrors: boolean;
    errorSummaryChild: any;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    addRecord(): void;
    saveRecord(event: any): void;
    deleteRecord(index: number): void;
    revertRecord(event: any): void;
    handleRowClick(event: any): void;
    showError(errs: any): void;
    disableAddButton(): boolean;
    openPopup(): void;
    get recordFormArray(): FormArray;
    getRecordInfo(recordFormGroup: FormGroup): FormGroup;
    getRecordFormArrValues(): any;
}

interface IRecordService {
    createRecordFormGroup(fb: FormBuilder): FormGroup | null;
    setRecordsFormArrValue(val: any[]): void;
    getHeading(index: number, formGroup: FormGroup): void;
}

interface IListService {
    setList(list: FormGroup[]): void;
    getNextId(): number;
    setMaxId(value: number): void;
    getId(): number;
}

declare abstract class BaseListService implements IListService {
    protected list: FormGroup[];
    protected idCount: number;
    setList(list: FormGroup[]): void;
    getNextId(): number;
    setMaxId(value: number): void;
    getId(): number;
}

declare class RecordDiscardService {
    private discardConfirmedSubject;
    discardConfirmed$: rxjs.Observable<number>;
    confirmDiscard(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordDiscardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RecordDiscardService>;
}

declare class RecordDeleteService {
    private deleteConfirmedSubject;
    deleteConfirmed$: rxjs.Observable<number>;
    confirmDelete(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordDeleteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RecordDeleteService>;
}

declare abstract class BaseListComponent<T extends OutputRecord> extends BaseComponent implements IBaseList<T>, AfterViewInit {
    private _fb;
    protected listService: BaseListService;
    private _recordDiscardService;
    private _recordDeleteService;
    recordList: T[];
    showErrors: boolean;
    isInternal?: boolean;
    lang: string;
    recordFormGroup: FormGroup;
    errorSummaryChild: any;
    discardHeading: string;
    discardIndex: number;
    discardConfirmed: number;
    deleteHeading: string;
    deleteIndex: number;
    deleteConfirmed: number;
    abstract statusMessage: string;
    abstract statusMessageSave: string;
    abstract statusMessageDiscard: string;
    abstract statusMessageDelete: string;
    abstract focusField: string;
    abstract addButton: string;
    abstract records: string;
    abstract recordInfo: string;
    abstract recordService: IRecordService;
    abstract popupId: string;
    abstract discardPopupId: string;
    abstract deletePopupId: string;
    abstract errorList: [];
    constructor(_fb: FormBuilder, listService: BaseListService, _recordDiscardService: RecordDiscardService, _recordDeleteService: RecordDeleteService);
    ngOnChanges(changes: SimpleChanges): void;
    private _init;
    protected abstract _expandInvalidRecordUponLoading(): any;
    abstract expandAllInvalidRecords(): any;
    protected abstract _patchRecordInfoValue(group: any, outputModel: any): any;
    protected abstract _patchLastSavedStateValue(lastSavedStateFormControl: any, outputModel: any): any;
    addRecord(): void;
    saveRecord(event: any): void;
    protected _expandNextInvalidRecord(): void;
    deleteRecord(event: any): void;
    revertRecord(event: any): void;
    onDiscardConfirmed(index: number): void;
    onDeleteConfrmed(index: number): void;
    discardRecordConfirmation(event: any): void;
    deleteRecordConfirmation(event: any): void;
    onDiscardHandled(event: any): void;
    onDeleteHandled(event: any): void;
    handleRowClick(event: any): void;
    showError(errs: any): void;
    disableAddButton(): boolean;
    openPopup(): void;
    private _setStatusMessage;
    get recordFormArray(): FormArray;
    getRecordInfo(recordFormGroup: FormGroup): FormGroup;
    getRecordFormArrValues(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseListComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseListComponent<any>, "ng-component", never, { "recordList": { "alias": "recordList"; "required": false; }; "showErrors": { "alias": "showErrors"; "required": false; }; "isInternal": { "alias": "isInternal"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PopupComponent {
    message: string;
    title: string;
    id: string;
    close: string;
    closed: EventEmitter<void>;
    closePopup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PopupComponent, "lib-popup", never, { "message": { "alias": "message"; "required": false; }; "title": { "alias": "title"; "required": false; }; "id": { "alias": "id"; "required": false; }; "close": { "alias": "close"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}

declare class ConfirmationPopupComponent {
    message: string;
    title: string;
    id: string;
    cancel: string;
    confirm: string;
    heading: string;
    confirmed: EventEmitter<any>;
    closePopup(): void;
    onConfirm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationPopupComponent, "lib-confirmation-popup", never, { "message": { "alias": "message"; "required": false; }; "title": { "alias": "title"; "required": false; }; "id": { "alias": "id"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "confirm": { "alias": "confirm"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; }, { "confirmed": "confirmed"; }, never, never, true, never>;
}

export { AccordionComponent, AriaTransformPipe, BaseComponent, BaseListComponent, BaseListService, CANADA, CHECK_SUM_CONST, CheckSumService, CommonFormDendencyModule, CommonUiFeatureModule, ConfirmationPopupComponent, ControlMessagesComponent, ConvertResults, ConverterService, DataLoaderService, ENGLISH, ERR_TYPE_COMPONENT, ERR_TYPE_LEAST_ONE_REC, EntityBaseService, ErrorModule, ErrorNotificationService, ErrorSummaryComponent, ExpanderComponent, ExpanderModule, FINAL, FRENCH, FileConversionService, FileIoModule, FilereaderComponent, FormControlPipe, InstructionService, JsonKeysPipe, LayoutComponent, LoggerService, NO, NoCacheHeadersInterceptor, NumbersLettersDirective, NumbersOnlyDirective, OTHER_EN, OTHER_FR, PipesModule, PopupComponent, PrivacyStatementComponent, RECORD_ACTIONS, RecordDeleteService, RecordDiscardService, RoutingService, SecurityDisclaimerComponent, SortOn, TextTransformPipe, USA, UtilsService, VALIDATION_SERVICES, ValidationService, VersionService, YES, getEmptyErrorSummaryObj };
export type { CheckboxOption, ErrorSummaryObject, HelpIndex, HelpSequence, ICode, ICodeAria, ICodeDefinition, IIdText, IIdTextLabel, IKeyword, ILabel, IParentChildren, IRecordService, IText, ITextLabel, IValidationService, OutputRecord, RecordFormGroup };
