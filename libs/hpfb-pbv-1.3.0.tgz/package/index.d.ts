import * as i0 from '@angular/core';
import { OnInit, OnChanges, EventEmitter, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import * as i2 from '@angular/common';
import * as _angular_forms from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as i3 from '@ngx-translate/core';
import * as i5 from '@hpfb/sdk/ui';
import { IIdTextLabel, UtilsService, ConverterService, ICode, BaseComponent } from '@hpfb/sdk/ui';

declare class CommonPbvModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonPbvModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonPbvModule, never, [typeof i2.CommonModule, typeof _angular_forms.FormsModule, typeof _angular_forms.ReactiveFormsModule, typeof i3.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonPbvModule>;
}

declare class PbvService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PbvService>;
}

declare class PbvComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PbvComponent, "pb-lib-pbv", never, {}, {}, never, never, true, never>;
}

declare class PrivacyStatementComponent {
    lang: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrivacyStatementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PrivacyStatementComponent, "pb-lib-privacy-statement", never, { "lang": { "alias": "lang"; "required": false; }; }, {}, never, never, true, never>;
}

interface INameAddress {
    street_address: string;
    city: string;
    province_lov: IIdTextLabel;
    province_text: string;
    country: IIdTextLabel;
    postal_code: string;
}
interface IContact {
    given_name: string;
    initials: string;
    surname: string;
    job_title: string;
    language_correspondance: IIdTextLabel;
    phone_num: string;
    phone_ext: string;
    fax_num: string;
    email: string;
}

declare class AddressDetailsService {
    private _utilsService;
    private _converterService;
    constructor(_utilsService: UtilsService, _converterService: ConverterService);
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb: FormBuilder): FormGroup<{
        address: _angular_forms.FormControl<null>;
        provText: _angular_forms.FormControl<string>;
        provState: _angular_forms.FormControl<string>;
        city: _angular_forms.FormControl<string>;
        country: _angular_forms.FormControl<string>;
        postal: _angular_forms.FormControl<string>;
    }>;
    mapFormModelToDataModel(formValue: any, addressModel: INameAddress, lang: any, countryList: any, combinedProvStatList: any): void;
    mapFormModelToDataModelCanadianAddress(formValue: any, addressModel: INameAddress, lang: any, countryList: any, combinedProvStatList: any): void;
    mapDataModelToFormModel(addressModel: any, formRecord: FormGroup): void;
    setProvinceState(record: FormGroup, countryId: string, provinceList: ICode[], stateList: ICode[]): ICode[];
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddressDetailsService>;
}

declare class AddressDetailsComponent extends BaseComponent implements OnInit, OnChanges {
    private _fb;
    private cdr;
    private _detailsService;
    private _utilsService;
    showErrors: boolean;
    addressModel: any;
    lang: any;
    countryList: any;
    provinceList: any;
    stateList: any;
    canadaDefault: boolean;
    addrType: any;
    addrGroupLabelKey: any;
    errorList: EventEmitter<any>;
    formGroup?: FormGroup;
    recordId?: number | null;
    resetFormGroup?: number | null;
    addressForm: FormGroup;
    showFieldErrors: boolean;
    constructor(_fb: FormBuilder, cdr: ChangeDetectorRef, _detailsService: AddressDetailsService, _utilsService: UtilsService);
    ngOnInit(): void;
    protected emitErrors(errors: any[]): void;
    ngOnChanges(changes: SimpleChanges): void;
    onCountryChange(e: any): void;
    getFormValue(): any;
    private _resetControlValues;
    isCanadaOrUSA(): boolean;
    isCanada(): boolean;
    isUsa(): boolean;
    getCountryValue(): any;
    /**
     * Reactive funtion to return the provStateList based on selected country
     *
     * @returns ICode[] of either states or provinces or empty if neither Canada or USA is selected
     */
    provStateList(): ICode[];
    /**
     * Reactive function to return province label if country is Canada or USA
     * @returns Either "Province" or "State"
     */
    provinceLabel(): string;
    /**
     * Reactive function to return postal code label if country is Canada/USA/neither
     * @returns Either "Postal code"/"ZIP code"/"Postal/ZIP code"
     */
    postalLabel(): string;
    private _resetFormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddressDetailsComponent, "pbv-address-details", never, { "showErrors": { "alias": "showErrors"; "required": false; }; "addressModel": { "alias": "addressModel"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "countryList": { "alias": "countryList"; "required": false; }; "provinceList": { "alias": "provinceList"; "required": false; }; "stateList": { "alias": "stateList"; "required": false; }; "canadaDefault": { "alias": "canadaDefault"; "required": false; }; "addrType": { "alias": "addrType"; "required": false; }; "addrGroupLabelKey": { "alias": "addrGroupLabelKey"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "recordId": { "alias": "recordId"; "required": false; }; "resetFormGroup": { "alias": "resetFormGroup"; "required": false; }; }, { "errorList": "errorList"; }, never, never, false, never>;
}

declare class AddressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddressModule, [typeof AddressDetailsComponent], [typeof i2.CommonModule, typeof _angular_forms.ReactiveFormsModule, typeof _angular_forms.FormsModule, typeof i5.ErrorModule, typeof i5.PipesModule, typeof i3.TranslateModule, typeof i5.NumbersOnlyDirective, typeof i5.NumbersLettersDirective], [typeof AddressDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddressModule>;
}

declare class ContactDetailsService {
    private _utilsService;
    private _converterService;
    constructor(_utilsService: UtilsService, _converterService: ConverterService);
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb: FormBuilder): FormGroup<{
        firstName: _angular_forms.FormControl<null>;
        initials: _angular_forms.FormControl<any>;
        lastName: _angular_forms.FormControl<null>;
        fullName: _angular_forms.FormControl<string>;
        language: _angular_forms.FormControl<string>;
        jobTitle: _angular_forms.FormControl<null>;
        faxNumber: _angular_forms.FormControl<string>;
        phoneNumber: _angular_forms.FormControl<string>;
        phoneExtension: _angular_forms.FormControl<string>;
        email: _angular_forms.FormControl<null>;
    }>;
    private updateFullName;
    mapFormModelToDataModel(formValue: any, contactModel: IContact, lang: any, languageList: any): void;
    mapDataModelToFormModel(contactModel: IContact, formRecord: FormGroup): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContactDetailsService>;
}

declare class ContactDetailsComponent extends BaseComponent implements OnInit {
    private _contactDetailsService;
    private _fb;
    private _utilsService;
    showFieldErrors: boolean;
    contactDetailsForm: FormGroup;
    showErrors: boolean;
    contactDetailsModel: IContact;
    lang: any;
    languageList: any;
    contactType: any;
    contactGroupLabelKey: any;
    errorList: EventEmitter<any>;
    formGroup?: FormGroup;
    recordId?: number | null;
    resetFormGroup?: number | null;
    autocomplete: boolean;
    constructor(_contactDetailsService: ContactDetailsService, _fb: FormBuilder, _utilsService: UtilsService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    protected emitErrors(errors: any[]): void;
    getFormValue(): any;
    private _resetFormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContactDetailsComponent, "pbv-contact-details", never, { "showErrors": { "alias": "showErrors"; "required": false; }; "contactDetailsModel": { "alias": "contactDetailsModel"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "languageList": { "alias": "languageList"; "required": false; }; "contactType": { "alias": "contactType"; "required": false; }; "contactGroupLabelKey": { "alias": "contactGroupLabelKey"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "recordId": { "alias": "recordId"; "required": false; }; "resetFormGroup": { "alias": "resetFormGroup"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; }, { "errorList": "errorList"; }, never, never, false, never>;
}

declare class ContactModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ContactModule, [typeof ContactDetailsComponent], [typeof i2.CommonModule, typeof _angular_forms.ReactiveFormsModule, typeof _angular_forms.FormsModule, typeof i3.TranslateModule, typeof i5.ErrorModule, typeof i5.PipesModule, typeof i5.ExpanderModule, typeof i5.NumbersOnlyDirective, typeof i5.PopupComponent], [typeof ContactDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ContactModule>;
}

declare class EntityBasePbvService {
    getEmptyAddressDetailsModel(): INameAddress;
    getEmptyContactModel(): IContact;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityBasePbvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntityBasePbvService>;
}

declare class PbvValidationService {
    constructor();
    getValidatorErrorMessage(validatorName: string): string | null;
    static pharmabioDossierIdValidator(control: any): {
        'error.mgs.pbv.dossier.id': boolean;
    };
    static vetDossierIdValidator(control: any): {
        'error.mgs.pbv.dossier.id': boolean;
    };
    static dossierIdValidator(control: any): {
        'error.mgs.pbv.dossier.id': boolean;
    };
    static businessNumValidator(control: any): {
        'error.msg.business': boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PbvValidationService>;
}

export { AddressDetailsComponent, AddressDetailsService, AddressModule, CommonPbvModule, ContactDetailsComponent, ContactDetailsService, ContactModule, EntityBasePbvService, PbvComponent, PbvService, PbvValidationService, PrivacyStatementComponent };
export type { IContact, INameAddress };
