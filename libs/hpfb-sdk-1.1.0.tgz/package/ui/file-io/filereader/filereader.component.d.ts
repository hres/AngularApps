import { OnInit, EventEmitter, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class FilereaderComponent implements OnInit {
    private translate;
    complete: EventEmitter<any>;
    rootTag: string;
    lang: string;
    versionTagPath?: string;
    startCheckSumVersion?: number;
    devEnv?: boolean;
    byPassCheckSum?: boolean;
    status: string;
    importSuccess: boolean;
    importedFileName: string;
    showFileLoadStatus: boolean;
    private rootId;
    fileImported: boolean;
    constructor(translate: TranslateService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Attaches to the file browser, detecting the file selection change
     * @param $event
     */
    changeListener($event: any): void;
    /**
     * Determines if a file was selected. Sets a callback to process the file after load (asych)
     * @param inputValue
     */
    readSelectedFile(inputValue: any): void;
    /***
     * Processes the file data. Determines the type of file based on the filename suffix
     * @param name - the name of the file. Can include the path
     * @param result - the result of the file read i.e. file contents as text
     * @param rootId - the name of the rootTag. If null is ignored
     * @param {ConvertResults} convertResult -The results of the file read
     * @private
     */
    private static _readFile;
    private static checkRootTagMatch;
    refreshPage(): void;
    private static checkSumCheck;
    private static strictCheckSumCheck;
    private static doCheckSumCheck;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilereaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilereaderComponent, "lib-file-reader", never, { "rootTag": { "alias": "rootTag"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "versionTagPath": { "alias": "versionTagPath"; "required": false; }; "startCheckSumVersion": { "alias": "startCheckSumVersion"; "required": false; }; "devEnv": { "alias": "devEnv"; "required": false; }; "byPassCheckSum": { "alias": "byPassCheckSum"; "required": false; }; }, { "complete": "complete"; }, never, ["[fileUploadInstruction]"], false, never>;
}
