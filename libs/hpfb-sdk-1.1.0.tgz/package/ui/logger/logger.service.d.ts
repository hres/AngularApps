import * as i0 from "@angular/core";
export declare class LoggerService {
    log(className: string, methodName: string, ...messages: any[]): void;
    error(className: string, methodName: string, ...messages: any[]): void;
    warn(className: string, methodName: string, ...messages: any[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}
