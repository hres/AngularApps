import { AfterViewInit, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { ExpanderComponent } from '../../expander/expander.component';
import { ErrMessageService } from '../err.message.service';
import * as i0 from "@angular/core";
export declare class ErrorSummaryComponent implements AfterViewInit {
    private cdr;
    private _errMessageService;
    headingPreamble: string;
    headingPreambleParams: any;
    errorList: any;
    hiddenSummary: any;
    compId: string;
    label: string;
    headingLevel: string;
    type: string;
    errors: {};
    componentId: string;
    tableId: string;
    hdingLevel: string;
    index: number;
    expander: ExpanderComponent;
    errorCount: number;
    errorNumberValue: string;
    constructor(cdr: ChangeDetectorRef, _errMessageService: ErrMessageService);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Creates an array of error elements based on the incoming error objects
     * Currently groups the errors by parent. Not doing anything with parent right now.
     * But could display errors groupded by the parent and parent label
     * @param errorList
     */
    processErrors(errorList: any): void;
    /**
     * Selects thje tab from an ngbTabset
     * @param error- the error object created by the summary component
     */
    processEvents(error: any): void;
    private resetErrorCount;
    getValidatorErrorMessageKey(error: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorSummaryComponent, "lib-error-summary", never, { "headingPreamble": { "alias": "headingPreamble"; "required": false; }; "headingPreambleParams": { "alias": "headingPreambleParams"; "required": false; }; "errorList": { "alias": "errorList"; "required": false; }; "hiddenSummary": { "alias": "hiddenSummary"; "required": false; }; "compId": { "alias": "compId"; "required": false; }; "label": { "alias": "label"; "required": false; }; "headingLevel": { "alias": "headingLevel"; "required": false; }; }, {}, never, never, false, never>;
}
