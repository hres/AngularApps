import * as i0 from "@angular/core";
export declare class ErrMessageService {
    constructor();
    getValidatorErrorMessageKey(error: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrMessageService>;
}
