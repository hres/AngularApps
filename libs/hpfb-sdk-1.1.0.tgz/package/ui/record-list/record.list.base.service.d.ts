import { FormArray } from "@angular/forms";
import { UtilsService } from "../utils/utils.service";
export declare abstract class RecordListBaseService {
    /**
     * Used to create record ids
     * @type {number}
     * @private
     */
    private _indexValue;
    constructor();
    /**
     * Parses the current data and finds the largest ID
     * @public
     */
    initIndex(recordList: any): void;
    /**
     * Gets the next record id
     * @returns {number}
     */
    getNextIndex(): number;
    /**
     * Resets the index to the base value. Used for record ids
     */
    resetIndex(): void;
    /**
     * Gets the current id value to use for a record
     * @returns {number}
     */
    getCurrentIndex(): number;
    /**
     * Sets the record id to a value
     * @param {number} value
     */
    setIndex(value: number): void;
    updateFormRecordListSeqNumber(formRecordList: FormArray): void;
    /**
     * if formRecordIdToExpand is passed in, expand that record and collapse all other records;
     * otherwise, collapse all records
     *
     * @param formRecordList
     * @param formRecordIdToExpand optional
     */
    collapseFormRecordList(utilsService: UtilsService, formRecordList: FormArray, formRecordIdToExpand?: number): void;
}
