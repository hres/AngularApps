import { FormGroup } from '@angular/forms';
export interface RecordListServiceInterface {
    deleteModelRecord(id: number): any;
    getModelRecordList(): any;
    getModelRecord(id: any): any;
    saveRecord(record: FormGroup, lang: string, ...args: any[]): any;
    initIndex(recordList: any): any;
    getNextIndex(): any;
    resetIndex(): any;
    getCurrentIndex(): any;
    setIndex(value: number): any;
}
export interface IListService {
    setList(list: FormGroup[]): void;
    getNextId(): number;
}
