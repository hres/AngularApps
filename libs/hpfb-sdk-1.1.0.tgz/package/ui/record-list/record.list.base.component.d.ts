import { FormArray, FormGroup } from '@angular/forms';
import { ExpanderComponent } from '../expander/expander.component';
import { RecordListServiceInterface } from './record.list.service.interface';
import * as i0 from "@angular/core";
export declare abstract class RecordListBaseComponent {
    prevRow: number;
    protected showErrorSummary: boolean;
    newRecordIndicator: boolean;
    expander: ExpanderComponent;
    /**
     * Used to create address ids
     * @type {number}
     * @private
     */
    constructor();
    /**
     * Sets an ErrorSummary object (optional)
     * @param {ErrorSummaryComponent} errorSummaryInstance
     */
    /**
     * Sets a reference to an expander instance
     * @param {ExpanderComponent} expanderInstance
     */
    /**
     * Synchs the currently expanded row with the appropriate reactive form recortd
     * @param {FormArray} reactiveFormList -list of UI records
     * @returns {FormGroup} the record that matchs the currently open row
     */
    syncCurrentExpandedRow(reactiveFormList: FormArray): FormGroup;
    /**
     * Colllapses all the expander rows. Just a wrapper to the expander
     */
    private collapseExpanderRows;
    /**
     * Saves a record to the form model using the passed in service
     * @param {FormGroup} record
     * @param service
     * @returns {number}
     */
    saveRecord(record: FormGroup, service: RecordListServiceInterface, lang: string, ...args: any[]): number;
    /**
     * Adds a  new reoord. Exposes the new record ui
     * @param {FormGroup} formRecord
     * @param {FormArray} formList
     */
    addRecord(formRecord: FormGroup, formList: FormArray): void;
    /**
     * Deletes a form record of a given id
     * @param {number} id
     * @param {FormArray} recordList
     * @param service
     */
    deleteRecord(id: number, recordList: FormArray, service: RecordListServiceInterface): void;
    /**
     * Gets a recond of a given id, provided the list
     * @param {number} id
     * @param recordList
     * @returns {any}
     */
    getRecord(id: number, recordList: any): FormGroup<any>;
    getExpandedRow(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordListBaseComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RecordListBaseComponent, never, never, {}, {}, never, never, false, never>;
}
