import * as i0 from "@angular/core";
export declare class InstructionService {
    private helpTextIndx;
    constructor();
    /**
     * Sets the Help Text Index
     *
     * instructionHeadings should be a list
     */
    getHelpTextIndex(instructionHeadings: any): HelpIndex;
    static ɵfac: i0.ɵɵFactoryDeclaration<InstructionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InstructionService>;
}
export interface HelpIndex {
    [key: string]: number;
}
