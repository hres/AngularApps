import { FormArray } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ValidationService {
    constructor();
    static getValidatorErrorMessage(validatorName: string): any;
    static emailValidator(control: any): {
        'error.msg.email': boolean;
    };
    static canadaPostalValidator(control: any): {
        'error.msg.postal': boolean;
    };
    static usaPostalValidator(control: any): {
        'error.mgs.zip': boolean;
    };
    static countryValidator(control: any): {
        required: boolean;
    };
    static phoneNumberValidator(control: any): {
        'error.msg.phone': boolean;
    };
    static faxNumberValidator(control: any): {
        'error.msg.fax': boolean;
    };
    static numberValidator(control: any): {
        'error.msg.number': boolean;
    };
    static companyIdValidator(control: any): {
        'error.mgs.company.id': boolean;
    };
    static numeric5Validator(control: any): {
        'error.mgs.5.numeric': boolean;
    };
    static numeric6Validator(control: any): {
        'error.mgs.6.numeric': boolean;
    };
    static numeric8Validator(control: any): {
        'error.mgs.8.numeric': boolean;
    };
    static dossierIdValidator(control: any): {
        'error.mgs.dossier.id': boolean;
    };
    static dossierContactIdValidator(control: any): {
        'error.mgs.contact.id': boolean;
    };
    static regulatoryContactIdValidator(control: any): {
        'error.mgs.regu.contact.id': boolean;
    };
    static licenceNumValidator(control: any): {
        'error.mgs.licence.number': boolean;
    };
    static appNumValidator(control: any): {
        'error.mgs.application.number': boolean;
    };
    static dinValidator(control: any): {
        'error.mgs.din': boolean;
    };
    static npnValidator(control: any): {
        'error.mgs.npn': boolean;
    };
    static checkboxRequiredValidator(control: any): {
        required: boolean;
    };
    static contactIdValidator(control: any): {
        'error.mgs.contact.id': boolean;
    };
    static primaryCompanyIdValidator(control: any): {
        'error.mgs.company.id': boolean;
    };
    static atLeastOneCheckboxSelected(formArray: FormArray): {
        required: boolean;
    };
    static masterFileNumberValidator(control: any): {
        'error.mgs.incorrectFormat': boolean;
    };
    static masterFileDossierIdValidator(control: any): {
        'error.mgs.dossier.id': boolean;
    };
    static accountNumberValidator(control: any): {
        'error.msg.account': boolean;
    };
    static businessNumberValidator(control: any): {
        'error.msg.business': boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidationService>;
}
