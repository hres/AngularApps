import { EventEmitter, TemplateRef } from '@angular/core';
import { FormArray } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class AccordionComponent {
    rowsFormArray: FormArray;
    accordionHeadingMsgKey: string;
    accordionHeadingSupp: any;
    rowClicked: EventEmitter<any>;
    tmplRef: TemplateRef<any>;
    toggleExpand(index: number, expanded: boolean): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionComponent, "lib-accordion", never, { "rowsFormArray": { "alias": "rowsFormArray"; "required": false; }; "accordionHeadingMsgKey": { "alias": "accordionHeadingMsgKey"; "required": false; }; "accordionHeadingSupp": { "alias": "accordionHeadingSupp"; "required": false; }; }, { "rowClicked": "rowClicked"; }, ["tmplRef"], never, false, never>;
}
