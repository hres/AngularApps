import { Injectable } from '@angular/core';
import { map, throwError } from 'rxjs';
import { SortOn } from './data';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
export class DataLoaderService {
    constructor(http) {
        this.http = http;
    }
    // public getData<T>(filename: string): Observable<T[]> {
    //   return this.http.get<any>(GlobalsService.DATA_PATH + filename);
    // }
    getData(endpoint) {
        return this.http.get(endpoint).pipe();
    }
    /**
     * @deprecated Will not be used in the future, use getSortedDataAccents() instead
     * @param endpoint
     * @param compareField
     * @returns
     */
    getSortedData(endpoint, compareField) {
        const compareFn = this.getCompareFunction(compareField);
        return this.getData(endpoint).pipe(map(data => data.sort(compareFn)));
    }
    getCompareFunction(compareField) {
        return (a, b) => {
            const valA = this.getFieldValue(a, compareField);
            const valB = this.getFieldValue(b, compareField);
            return valA < valB ? -1 : valA > valB ? 1 : 0;
        };
    }
    getSortedDataAccents(endpoint, compareFields) {
        const compareFn = this.getCompareFunctions(compareFields);
        return this.getData(endpoint).pipe(map(data => data.sort(compareFn)));
    }
    getCompareFunctions(compareFields) {
        return (a, b) => {
            let valA = '';
            let valB = '';
            for (const field of compareFields) {
                valA += this.getFieldValue(a, field);
                valB += this.getFieldValue(b, field);
            }
            return valA.toString().localeCompare(valB.toString());
        };
    }
    getFieldValue(obj, field) {
        if (field === SortOn.PRIORITY && obj.sortPriority !== undefined) {
            // Pad leading 0's, assume the max # of digits in sortPriority is 2 
            const paddedValue = obj.sortPriority.toString().padStart(3, '0');
            return paddedValue;
        }
        return obj[field];
    }
    handleError(err) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        let errorMessage;
        if (err.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            errorMessage = `An error occurred: ${err.error.message}`;
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            errorMessage = `Backend returned code ${err.status}: ${err.message}`;
        }
        console.error(err);
        return throwError(() => errorMessage);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: DataLoaderService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: DataLoaderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: DataLoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YS1sb2FkZXIuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2RhdGEtbG9hZGVyL2RhdGEtbG9hZGVyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQWMsR0FBRyxFQUFPLFVBQVUsRUFBQyxNQUFNLE1BQU0sQ0FBQztBQUN2RCxPQUFPLEVBQVMsTUFBTSxFQUFFLE1BQU0sUUFBUSxDQUFDOzs7QUFLdkMsTUFBTSxPQUFPLGlCQUFpQjtJQUM1QixZQUFvQixJQUFnQjtRQUFoQixTQUFJLEdBQUosSUFBSSxDQUFZO0lBQUcsQ0FBQztJQUV4Qyx5REFBeUQ7SUFDekQsb0VBQW9FO0lBQ3BFLElBQUk7SUFDRyxPQUFPLENBQUksUUFBZ0I7UUFDaEMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBTSxRQUFRLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxhQUFhLENBQWtCLFFBQWdCLEVBQUUsWUFBb0I7UUFDMUUsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRXhELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBSSxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQ25DLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FDbEMsQ0FBQztJQUNKLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxZQUFvQjtRQUM3QyxPQUFPLENBQUMsQ0FBUSxFQUFFLENBQVEsRUFBRSxFQUFFO1lBQzVCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQ2pELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQ2pELE9BQU8sSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQztJQUNKLENBQUM7SUFFTSxvQkFBb0IsQ0FBa0IsUUFBZ0IsRUFBRSxhQUF1QjtRQUNwRixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFJLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FDbkMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUNsQyxDQUFDO0lBQ0osQ0FBQztJQUVPLG1CQUFtQixDQUFDLGFBQXVCO1FBQ2pELE9BQU8sQ0FBQyxDQUFRLEVBQUUsQ0FBUSxFQUFFLEVBQUU7WUFDNUIsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ2QsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ2QsS0FBSyxNQUFNLEtBQUssSUFBSSxhQUFhLEVBQUUsQ0FBQztnQkFDbEMsSUFBSSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkMsQ0FBQztZQUNELE9BQU8sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUM7SUFDSixDQUFDO0lBRU8sYUFBYSxDQUFDLEdBQVUsRUFBRSxLQUFhO1FBQzdDLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxRQUFRLElBQUksR0FBRyxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNoRSxvRUFBb0U7WUFDcEUsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ2pFLE9BQU8sV0FBVyxDQUFDO1FBQ3JCLENBQUM7UUFDRCxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQixDQUFDO0lBRU0sV0FBVyxDQUFDLEdBQXNCO1FBQ3ZDLG9GQUFvRjtRQUNwRiw0Q0FBNEM7UUFDNUMsSUFBSSxZQUFvQixDQUFDO1FBQ3pCLElBQUksR0FBRyxDQUFDLEtBQUssWUFBWSxVQUFVLEVBQUUsQ0FBQztZQUNwQyxrRUFBa0U7WUFDbEUsWUFBWSxHQUFHLHNCQUFzQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzNELENBQUM7YUFBTSxDQUFDO1lBQ04sc0RBQXNEO1lBQ3RELDZEQUE2RDtZQUM3RCxZQUFZLEdBQUcseUJBQXlCLEdBQUcsQ0FBQyxNQUFNLEtBQUssR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3ZFLENBQUM7UUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLE9BQU8sVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3hDLENBQUM7K0dBM0VVLGlCQUFpQjttSEFBakIsaUJBQWlCLGNBRmhCLE1BQU07OzRGQUVQLGlCQUFpQjtrQkFIN0IsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBtYXAsIHRhcCwgdGhyb3dFcnJvcn0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IElDb2RlLCBTb3J0T24gfSBmcm9tICcuL2RhdGEnOyBcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIERhdGFMb2FkZXJTZXJ2aWNlIHtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQpIHt9XHJcblxyXG4gIC8vIHB1YmxpYyBnZXREYXRhPFQ+KGZpbGVuYW1lOiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRbXT4ge1xyXG4gIC8vICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8YW55PihHbG9iYWxzU2VydmljZS5EQVRBX1BBVEggKyBmaWxlbmFtZSk7XHJcbiAgLy8gfVxyXG4gIHB1YmxpYyBnZXREYXRhPFQ+KGVuZHBvaW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRbXT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8YW55PihlbmRwb2ludCkucGlwZSgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQGRlcHJlY2F0ZWQgV2lsbCBub3QgYmUgdXNlZCBpbiB0aGUgZnV0dXJlLCB1c2UgZ2V0U29ydGVkRGF0YUFjY2VudHMoKSBpbnN0ZWFkXHJcbiAgICogQHBhcmFtIGVuZHBvaW50IFxyXG4gICAqIEBwYXJhbSBjb21wYXJlRmllbGQgXHJcbiAgICogQHJldHVybnMgXHJcbiAgICovXHJcbiAgcHVibGljIGdldFNvcnRlZERhdGE8VCBleHRlbmRzIElDb2RlPihlbmRwb2ludDogc3RyaW5nLCBjb21wYXJlRmllbGQ6IFNvcnRPbik6IE9ic2VydmFibGU8VFtdPiB7XHJcbiAgICBjb25zdCBjb21wYXJlRm4gPSB0aGlzLmdldENvbXBhcmVGdW5jdGlvbihjb21wYXJlRmllbGQpO1xyXG5cclxuICAgIHJldHVybiB0aGlzLmdldERhdGE8VD4oZW5kcG9pbnQpLnBpcGUoXHJcbiAgICAgIG1hcChkYXRhID0+IGRhdGEuc29ydChjb21wYXJlRm4pKVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0Q29tcGFyZUZ1bmN0aW9uKGNvbXBhcmVGaWVsZDogU29ydE9uKSB7XHJcbiAgICByZXR1cm4gKGE6IElDb2RlLCBiOiBJQ29kZSkgPT4ge1xyXG4gICAgICBjb25zdCB2YWxBID0gdGhpcy5nZXRGaWVsZFZhbHVlKGEsIGNvbXBhcmVGaWVsZCk7XHJcbiAgICAgIGNvbnN0IHZhbEIgPSB0aGlzLmdldEZpZWxkVmFsdWUoYiwgY29tcGFyZUZpZWxkKTtcclxuICAgICAgcmV0dXJuIHZhbEEgPCB2YWxCID8gLTEgOiB2YWxBID4gdmFsQiA/IDEgOiAwO1xyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBnZXRTb3J0ZWREYXRhQWNjZW50czxUIGV4dGVuZHMgSUNvZGU+KGVuZHBvaW50OiBzdHJpbmcsIGNvbXBhcmVGaWVsZHM6IFNvcnRPbltdKTogT2JzZXJ2YWJsZTxUW10+IHtcclxuICAgIGNvbnN0IGNvbXBhcmVGbiA9IHRoaXMuZ2V0Q29tcGFyZUZ1bmN0aW9ucyhjb21wYXJlRmllbGRzKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5nZXREYXRhPFQ+KGVuZHBvaW50KS5waXBlKFxyXG4gICAgICBtYXAoZGF0YSA9PiBkYXRhLnNvcnQoY29tcGFyZUZuKSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGdldENvbXBhcmVGdW5jdGlvbnMoY29tcGFyZUZpZWxkczogU29ydE9uW10pIHtcclxuICAgIHJldHVybiAoYTogSUNvZGUsIGI6IElDb2RlKSA9PiB7XHJcbiAgICAgIGxldCB2YWxBID0gJyc7XHJcbiAgICAgIGxldCB2YWxCID0gJyc7XHJcbiAgICAgIGZvciAoY29uc3QgZmllbGQgb2YgY29tcGFyZUZpZWxkcykge1xyXG4gICAgICAgIHZhbEEgKz0gdGhpcy5nZXRGaWVsZFZhbHVlKGEsIGZpZWxkKTtcclxuICAgICAgICB2YWxCICs9IHRoaXMuZ2V0RmllbGRWYWx1ZShiLCBmaWVsZCk7XHJcbiAgICAgIH0gXHJcbiAgICAgIHJldHVybiB2YWxBLnRvU3RyaW5nKCkubG9jYWxlQ29tcGFyZSh2YWxCLnRvU3RyaW5nKCkpO1xyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0RmllbGRWYWx1ZShvYmo6IElDb2RlLCBmaWVsZDogU29ydE9uKTogc3RyaW5nIHwgbnVtYmVyIHtcclxuICAgIGlmIChmaWVsZCA9PT0gU29ydE9uLlBSSU9SSVRZICYmIG9iai5zb3J0UHJpb3JpdHkgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAvLyBQYWQgbGVhZGluZyAwJ3MsIGFzc3VtZSB0aGUgbWF4ICMgb2YgZGlnaXRzIGluIHNvcnRQcmlvcml0eSBpcyAyIFxyXG4gICAgICBjb25zdCBwYWRkZWRWYWx1ZSA9IG9iai5zb3J0UHJpb3JpdHkudG9TdHJpbmcoKS5wYWRTdGFydCgzLCAnMCcpOyBcclxuICAgICAgcmV0dXJuIHBhZGRlZFZhbHVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG9ialtmaWVsZF07XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgaGFuZGxlRXJyb3IoZXJyOiBIdHRwRXJyb3JSZXNwb25zZSk6IE9ic2VydmFibGU8bmV2ZXI+IHtcclxuICAgIC8vIGluIGEgcmVhbCB3b3JsZCBhcHAsIHdlIG1heSBzZW5kIHRoZSBzZXJ2ZXIgdG8gc29tZSByZW1vdGUgbG9nZ2luZyBpbmZyYXN0cnVjdHVyZVxyXG4gICAgLy8gaW5zdGVhZCBvZiBqdXN0IGxvZ2dpbmcgaXQgdG8gdGhlIGNvbnNvbGVcclxuICAgIGxldCBlcnJvck1lc3NhZ2U6IHN0cmluZztcclxuICAgIGlmIChlcnIuZXJyb3IgaW5zdGFuY2VvZiBFcnJvckV2ZW50KSB7XHJcbiAgICAgIC8vIEEgY2xpZW50LXNpZGUgb3IgbmV0d29yayBlcnJvciBvY2N1cnJlZC4gSGFuZGxlIGl0IGFjY29yZGluZ2x5LlxyXG4gICAgICBlcnJvck1lc3NhZ2UgPSBgQW4gZXJyb3Igb2NjdXJyZWQ6ICR7ZXJyLmVycm9yLm1lc3NhZ2V9YDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIC8vIFRoZSBiYWNrZW5kIHJldHVybmVkIGFuIHVuc3VjY2Vzc2Z1bCByZXNwb25zZSBjb2RlLlxyXG4gICAgICAvLyBUaGUgcmVzcG9uc2UgYm9keSBtYXkgY29udGFpbiBjbHVlcyBhcyB0byB3aGF0IHdlbnQgd3JvbmcsXHJcbiAgICAgIGVycm9yTWVzc2FnZSA9IGBCYWNrZW5kIHJldHVybmVkIGNvZGUgJHtlcnIuc3RhdHVzfTogJHtlcnIubWVzc2FnZX1gO1xyXG4gICAgfVxyXG4gICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgcmV0dXJuIHRocm93RXJyb3IoKCkgPT4gZXJyb3JNZXNzYWdlKTtcclxuICB9XHJcbn1cclxuIl19