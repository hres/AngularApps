import { Pipe } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import * as i0 from "@angular/core";
// take an ICodeAria value and return either en or fr value based on lang
export class AriaTransformPipe {
    transform(value, lang) {
        return UtilsService.isFrench(lang) ? value.ariaFr : value.ariaEn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: AriaTransformPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: AriaTransformPipe, name: "ariaTransform" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: AriaTransformPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'ariaTransform'
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXJpYS10cmFuc2Zvcm0ucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3BpcGVzL3RleHQvYXJpYS10cmFuc2Zvcm0ucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUNwRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7O0FBR3pELHlFQUF5RTtBQUt6RSxNQUFNLE9BQU8saUJBQWlCO0lBRTVCLFNBQVMsQ0FBQyxLQUFnQixFQUFFLElBQVk7UUFDdEMsT0FBTyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0lBQ25FLENBQUM7OEdBSlUsaUJBQWlCOzRHQUFqQixpQkFBaUI7OzJGQUFqQixpQkFBaUI7a0JBSDdCLElBQUk7bUJBQUM7b0JBQ0osSUFBSSxFQUFFLGVBQWU7aUJBQ3RCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSwgUGlwZVRyYW5zZm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBVdGlsc1NlcnZpY2UgfSBmcm9tICcuLi8uLi91dGlscy91dGlscy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgSUNvZGVBcmlhIH0gZnJvbSAnLi4vLi4vZGF0YS1sb2FkZXIvZGF0YSc7XHJcblxyXG4vLyB0YWtlIGFuIElDb2RlQXJpYSB2YWx1ZSBhbmQgcmV0dXJuIGVpdGhlciBlbiBvciBmciB2YWx1ZSBiYXNlZCBvbiBsYW5nXHJcblxyXG5AUGlwZSh7XHJcbiAgbmFtZTogJ2FyaWFUcmFuc2Zvcm0nXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcmlhVHJhbnNmb3JtUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xyXG5cclxuICB0cmFuc2Zvcm0odmFsdWU6IElDb2RlQXJpYSwgbGFuZzogc3RyaW5nKTogdW5rbm93biB7XHJcbiAgICByZXR1cm4gVXRpbHNTZXJ2aWNlLmlzRnJlbmNoKGxhbmcpID8gdmFsdWUuYXJpYUZyIDogdmFsdWUuYXJpYUVuO1xyXG4gIH1cclxuXHJcbn1cclxuIl19