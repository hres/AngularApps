// ref: https://stackoverflow.com/questions/67834802/template-error-type-abstractcontrol-is-not-assignable-to-type-formcontrol
import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
export class FormControlPipe {
    transform(value) {
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: FormControlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.11", ngImport: i0, type: FormControlPipe, name: "formControl" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: FormControlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'formControl',
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1jb250cm9sLnBpcGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9waXBlcy9mb3JtL2Zvcm0tY29udHJvbC5waXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDhIQUE4SDtBQUU5SCxPQUFPLEVBQUMsSUFBSSxFQUFnQixNQUFNLGVBQWUsQ0FBQzs7QUFNbEQsTUFBTSxPQUFPLGVBQWU7SUFDeEIsU0FBUyxDQUFDLEtBQXNCO1FBQzVCLE9BQU8sS0FBb0IsQ0FBQztJQUNoQyxDQUFDOytHQUhRLGVBQWU7NkdBQWYsZUFBZTs7NEZBQWYsZUFBZTtrQkFIM0IsSUFBSTttQkFBQztvQkFDRixJQUFJLEVBQUUsYUFBYTtpQkFDdEIiLCJzb3VyY2VzQ29udGVudCI6WyIvLyByZWY6IGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzY3ODM0ODAyL3RlbXBsYXRlLWVycm9yLXR5cGUtYWJzdHJhY3Rjb250cm9sLWlzLW5vdC1hc3NpZ25hYmxlLXRvLXR5cGUtZm9ybWNvbnRyb2xcclxuXHJcbmltcG9ydCB7UGlwZSwgUGlwZVRyYW5zZm9ybX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7QWJzdHJhY3RDb250cm9sLCBGb3JtQ29udHJvbH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5cclxuQFBpcGUoe1xyXG4gICAgbmFtZTogJ2Zvcm1Db250cm9sJyxcclxufSlcclxuZXhwb3J0IGNsYXNzIEZvcm1Db250cm9sUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xyXG4gICAgdHJhbnNmb3JtKHZhbHVlOiBBYnN0cmFjdENvbnRyb2wpOiBGb3JtQ29udHJvbCB7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlIGFzIEZvcm1Db250cm9sO1xyXG4gICAgfVxyXG59Il19