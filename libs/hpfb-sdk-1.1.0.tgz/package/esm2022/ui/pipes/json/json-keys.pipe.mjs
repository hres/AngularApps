import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
export class JsonKeysPipe {
    /**
     * Transforms a list of json objects into an array
     * Creates key value pairs
     * @param value
     * @param {string[]} args
     * @returns {any}
     */
    transform(value) {
        const keys = [];
        for (const key in value) {
            keys.push({ key: key, value: value[key] });
        }
        return keys;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: JsonKeysPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.10", ngImport: i0, type: JsonKeysPipe, name: "keys" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: JsonKeysPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'keys'
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianNvbi1rZXlzLnBpcGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9waXBlcy9qc29uL2pzb24ta2V5cy5waXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxJQUFJLEVBQWdCLE1BQU0sZUFBZSxDQUFDOztBQUtsRCxNQUFNLE9BQU8sWUFBWTtJQUV2Qjs7Ozs7O09BTUc7SUFDSCxTQUFTLENBQUMsS0FBSztRQUNiLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNoQixLQUFLLE1BQU0sR0FBRyxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7K0dBZlUsWUFBWTs2R0FBWixZQUFZOzs0RkFBWixZQUFZO2tCQUh4QixJQUFJO21CQUFDO29CQUNKLElBQUksRUFBRSxNQUFNO2lCQUNiIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtQaXBlLCBQaXBlVHJhbnNmb3JtfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBQaXBlKHtcclxuICBuYW1lOiAna2V5cydcclxufSlcclxuZXhwb3J0IGNsYXNzIEpzb25LZXlzUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xyXG5cclxuICAvKipcclxuICAgKiBUcmFuc2Zvcm1zIGEgbGlzdCBvZiBqc29uIG9iamVjdHMgaW50byBhbiBhcnJheVxyXG4gICAqIENyZWF0ZXMga2V5IHZhbHVlIHBhaXJzXHJcbiAgICogQHBhcmFtIHZhbHVlXHJcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJnc1xyXG4gICAqIEByZXR1cm5zIHthbnl9XHJcbiAgICovXHJcbiAgdHJhbnNmb3JtKHZhbHVlKTogYW55IHtcclxuICAgIGNvbnN0IGtleXMgPSBbXTtcclxuICAgIGZvciAoY29uc3Qga2V5IGluIHZhbHVlKSB7XHJcbiAgICAgIGtleXMucHVzaCh7a2V5OiBrZXksIHZhbHVlOiB2YWx1ZVtrZXldfSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4ga2V5cztcclxuICB9XHJcblxyXG59XHJcbiJdfQ==