import { NgModule } from '@angular/core';
import { FormControlPipe } from './form/form-control.pipe';
import { JsonKeysPipe } from './json/json-keys.pipe';
import { TextTransformPipe } from './text/text-transform.pipe';
import { AriaTransformPipe } from './text/aria-transform.pipe';
import * as i0 from "@angular/core";
export class PipesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: PipesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.9", ngImport: i0, type: PipesModule, declarations: [JsonKeysPipe,
            FormControlPipe,
            TextTransformPipe,
            AriaTransformPipe], exports: [JsonKeysPipe,
            FormControlPipe,
            TextTransformPipe,
            AriaTransformPipe] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: PipesModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: PipesModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        JsonKeysPipe,
                        FormControlPipe,
                        TextTransformPipe,
                        AriaTransformPipe
                    ],
                    exports: [
                        JsonKeysPipe,
                        FormControlPipe,
                        TextTransformPipe,
                        AriaTransformPipe
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlwZXMubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvcGlwZXMvcGlwZXMubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFekMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQzNELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUNyRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7QUFnQi9ELE1BQU0sT0FBTyxXQUFXOzhHQUFYLFdBQVc7K0dBQVgsV0FBVyxpQkFacEIsWUFBWTtZQUNaLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsaUJBQWlCLGFBR2pCLFlBQVk7WUFDWixlQUFlO1lBQ2YsaUJBQWlCO1lBQ2pCLGlCQUFpQjsrR0FHUixXQUFXOzsyRkFBWCxXQUFXO2tCQWR2QixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWixZQUFZO3dCQUNaLGVBQWU7d0JBQ2YsaUJBQWlCO3dCQUNqQixpQkFBaUI7cUJBQ2xCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxZQUFZO3dCQUNaLGVBQWU7d0JBQ2YsaUJBQWlCO3dCQUNqQixpQkFBaUI7cUJBQ2xCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IEZvcm1Db250cm9sUGlwZSB9IGZyb20gJy4vZm9ybS9mb3JtLWNvbnRyb2wucGlwZSc7XHJcbmltcG9ydCB7IEpzb25LZXlzUGlwZSB9IGZyb20gJy4vanNvbi9qc29uLWtleXMucGlwZSc7XHJcbmltcG9ydCB7IFRleHRUcmFuc2Zvcm1QaXBlIH0gZnJvbSAnLi90ZXh0L3RleHQtdHJhbnNmb3JtLnBpcGUnO1xyXG5pbXBvcnQgeyBBcmlhVHJhbnNmb3JtUGlwZSB9IGZyb20gJy4vdGV4dC9hcmlhLXRyYW5zZm9ybS5waXBlJztcclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICBKc29uS2V5c1BpcGUsXHJcbiAgICBGb3JtQ29udHJvbFBpcGUsXHJcbiAgICBUZXh0VHJhbnNmb3JtUGlwZSxcclxuICAgIEFyaWFUcmFuc2Zvcm1QaXBlXHJcbiAgXSxcclxuICBleHBvcnRzOiBbXHJcbiAgICBKc29uS2V5c1BpcGUsXHJcbiAgICBGb3JtQ29udHJvbFBpcGUsXHJcbiAgICBUZXh0VHJhbnNmb3JtUGlwZSxcclxuICAgIEFyaWFUcmFuc2Zvcm1QaXBlXHJcbiAgXSxcclxufSlcclxuZXhwb3J0IGNsYXNzIFBpcGVzTW9kdWxlIHt9Il19