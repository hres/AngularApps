import { Component, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { DRAFT_FILE_TYPE, FILE_TYPE_ERROR, FINAL_FILE_TYPE, FORM_TYPE_ERROR, IMPORT_SUCCESS, CHECK_SUM_ERROR } from '../file-io-constants';
import { ConvertResults } from '../convert-results';
import { FileConversionService } from '../file-conversion.service';
import { CheckSumService } from '../../check-sum/check-sum.service';
import { CHECK_SUM_CONST } from '../../check-sum/check-sum-constants';
import * as i0 from "@angular/core";
import * as i1 from "@ngx-translate/core";
import * as i2 from "@angular/common";
export class FilereaderComponent {
    constructor(translate) {
        this.translate = translate;
        this.complete = new EventEmitter();
        this.rootTag = '';
        this.lang = '';
        this.status = IMPORT_SUCCESS;
        this.importSuccess = false;
        this.importedFileName = "";
        this.showFileLoadStatus = false;
        this.rootId = '';
        this.fileImported = false;
    }
    ngOnInit() {
        // console.log(this.rootTag);
    }
    ngOnChanges(changes) {
        if (changes['rootTag']) {
            this.rootId = changes['rootTag'].currentValue;
        }
    }
    /**
     * Attaches to the file browser, detecting the file selection change
     * @param $event
     */
    changeListener($event) {
        this.readSelectedFile($event.target);
    }
    /**
     * Determines if a file was selected. Sets a callback to process the file after load (asych)
     * @param inputValue
     */
    readSelectedFile(inputValue) {
        this.fileImported = true;
        let file = inputValue.files[0];
        let myReader = new FileReader();
        let self = this;
        myReader.onloadend = function (e) {
            // you can perform an action with data here callback for asynch load
            let convertResult = new ConvertResults();
            FilereaderComponent._readFile(file.name, myReader.result, self.rootId, convertResult, self.versionTagPath, self.startCheckSumVersion, self.devEnv, self.byPassCheckSum);
            if (convertResult.messages && convertResult.messages.length > 0) {
                self.status = convertResult.messages[0];
            }
            else {
                self.status = IMPORT_SUCCESS;
            }
            if (self.status === IMPORT_SUCCESS) {
                self.importSuccess = true;
            }
            self.importedFileName = file.name;
            self.showFileLoadStatus = true;
            self.complete.emit(convertResult);
        };
        if (file && file.name) {
            myReader.readAsText(file);
        }
    }
    /***
     * Processes the file data. Determines the type of file based on the filename suffix
     * @param name - the name of the file. Can include the path
     * @param result - the result of the file read i.e. file contents as text
     * @param rootId - the name of the rootTag. If null is ignored
     * @param {ConvertResults} convertResult -The results of the file read
     * @private
     */
    static _readFile(name, result, rootId, convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass) {
        let splitFile = name.split('.');
        let fileType = splitFile[splitFile.length - 1];
        let conversion = new FileConversionService();
        if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE || fileType.toLowerCase() === FINAL_FILE_TYPE) {
            if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE) {
                conversion.convertToJSONObjects(result, convertResult);
            }
            else {
                conversion.convertXMLToJSONObjects(result, convertResult);
            }
            // console.log(convertResult.data);
            if (convertResult.messages.length === 0) {
                FilereaderComponent.checkRootTagMatch(convertResult, rootId);
            }
            // MF-RT will start to use the strict checksum while other apps still keep their current behaviour
            if (fileType.toLowerCase() === FINAL_FILE_TYPE && convertResult.messages.length === 0) {
                if (this.doCheckSumCheck(convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass))
                    if (versionTagPath == null && startCheckSumVersion == null) {
                        this.checkSumCheck(convertResult, rootId);
                    }
                    else {
                        this.strictCheckSumCheck(convertResult, rootId);
                    }
            }
        }
        else {
            convertResult.data = null;
            convertResult.messages = []; //clear msessages
            convertResult.messages.push(FILE_TYPE_ERROR);
        }
    }
    static checkRootTagMatch(convertResult, rootName) {
        if (!rootName || !convertResult || !convertResult.data)
            return;
        if (!convertResult.data[rootName]) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(FORM_TYPE_ERROR);
        }
    }
    refreshPage() {
        location.reload();
    }
    static checkSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!convertResult.data[rootName][CHECK_SUM_CONST]) {
            return;
        }
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static strictCheckSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static doCheckSumCheck(convertResult, versionPath, startCheckSumVersion, devEnv, byPass) {
        if (versionPath != null && startCheckSumVersion != null) {
            var version = convertResult.data;
            versionPath.split(".").forEach(function (key) {
                version = version[key];
            });
            version = parseInt(version.split('.')[0], 10);
            if (version < startCheckSumVersion) {
                return false;
            }
        }
        if (devEnv && byPass) {
            console.warn("Bypassing Checksum Verification in Dev Mode!");
            return false;
        }
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FilereaderComponent, deps: [{ token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: FilereaderComponent, selector: "lib-file-reader", inputs: { rootTag: "rootTag", lang: "lang", versionTagPath: "versionTagPath", startCheckSumVersion: "startCheckSumVersion", devEnv: "devEnv", byPassCheckSum: "byPassCheckSum" }, outputs: { complete: "complete" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <div *ngIf=\"!importSuccess\">\r\n      <button id=\"fileLoadButton\" [attr.aria-labelledby]=\"fileImported ? 'fileName' : 'noFileChosen'\" onclick=\"document.getElementById('fileLoad').click()\" > {{ 'choose.file' | translate }} </button>\r\n      <input style=\"display:none\" type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n      <!-- FOR SCREEN READER : To read \"Select a file to load, no file chosen / (file name) button\" -->\r\n      <span hidden class=\"field-name\" *ngIf=\"!fileImported\" id=\"noFileChosen\"> {{ 'select.file'|translate }} {{ 'no.file.chosen' | translate }} </span>\r\n      <span hidden class=\"field-name\" *ngIf=\"fileImported\" id=\"fileName\"> {{ 'select.file'|translate }} {{importedFileName}} </span>\r\n      <!-- -->\r\n      <span class=\"field-name\" *ngIf=\"!fileImported\"> {{ 'no.file.chosen' | translate }} </span>\r\n      <span class=\"field-name\" *ngIf=\"fileImported\"> {{importedFileName}} </span>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div role=\"alert\" [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"showFileLoadStatus\">\r\n  <p>{{status | translate}}</p>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>", styles: [""], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FilereaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-file-reader', encapsulation: ViewEncapsulation.None, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <div *ngIf=\"!importSuccess\">\r\n      <button id=\"fileLoadButton\" [attr.aria-labelledby]=\"fileImported ? 'fileName' : 'noFileChosen'\" onclick=\"document.getElementById('fileLoad').click()\" > {{ 'choose.file' | translate }} </button>\r\n      <input style=\"display:none\" type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n      <!-- FOR SCREEN READER : To read \"Select a file to load, no file chosen / (file name) button\" -->\r\n      <span hidden class=\"field-name\" *ngIf=\"!fileImported\" id=\"noFileChosen\"> {{ 'select.file'|translate }} {{ 'no.file.chosen' | translate }} </span>\r\n      <span hidden class=\"field-name\" *ngIf=\"fileImported\" id=\"fileName\"> {{ 'select.file'|translate }} {{importedFileName}} </span>\r\n      <!-- -->\r\n      <span class=\"field-name\" *ngIf=\"!fileImported\"> {{ 'no.file.chosen' | translate }} </span>\r\n      <span class=\"field-name\" *ngIf=\"fileImported\"> {{importedFileName}} </span>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div role=\"alert\" [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"showFileLoadStatus\">\r\n  <p>{{status | translate}}</p>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>" }]
        }], ctorParameters: () => [{ type: i1.TranslateService }], propDecorators: { complete: [{
                type: Output
            }], rootTag: [{
                type: Input
            }], lang: [{
                type: Input
            }], versionTagPath: [{
                type: Input
            }], startCheckSumVersion: [{
                type: Input
            }], devEnv: [{
                type: Input
            }], byPassCheckSum: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZXJlYWRlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGVyZWFkZXIvZmlsZXJlYWRlci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGVyZWFkZXIvZmlsZXJlYWRlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsU0FBUyxFQUFVLFlBQVksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFpQixpQkFBaUIsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUMvRyxPQUFPLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFFLGNBQWMsRUFBRSxlQUFlLEVBQUMsTUFBTSxzQkFBc0IsQ0FBQztBQUUxSSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDcEQsT0FBTyxFQUFDLHFCQUFxQixFQUFDLE1BQU0sNEJBQTRCLENBQUM7QUFDakUsT0FBTyxFQUFDLGVBQWUsRUFBQyxNQUFNLG1DQUFtQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQzs7OztBQVN0RSxNQUFNLE9BQU8sbUJBQW1CO0lBaUI5QixZQUFvQixTQUEyQjtRQUEzQixjQUFTLEdBQVQsU0FBUyxDQUFrQjtRQWhCckMsYUFBUSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7UUFDL0IsWUFBTyxHQUFZLEVBQUUsQ0FBQztRQUN0QixTQUFJLEdBQVksRUFBRSxDQUFDO1FBT3JCLFdBQU0sR0FBRyxjQUFjLENBQUM7UUFDeEIsa0JBQWEsR0FBRyxLQUFLLENBQUM7UUFDdEIscUJBQWdCLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLHVCQUFrQixHQUFHLEtBQUssQ0FBQztRQUMxQixXQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2IsaUJBQVksR0FBRyxLQUFLLENBQUM7SUFHNUIsQ0FBQztJQUVELFFBQVE7UUFDTiw2QkFBNkI7SUFDL0IsQ0FBQztJQUdELFdBQVcsQ0FBQyxPQUFzQjtRQUNoQyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQztRQUNoRCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNILGNBQWMsQ0FBQyxNQUFXO1FBRXhCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFdkMsQ0FBQztJQUVEOzs7T0FHRztJQUNILGdCQUFnQixDQUFDLFVBQWU7UUFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDekIsSUFBSSxJQUFJLEdBQVMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyQyxJQUFJLFFBQVEsR0FBZSxJQUFJLFVBQVUsRUFBRSxDQUFDO1FBQzVDLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixRQUFRLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQztZQUM5QixvRUFBb0U7WUFDcEUsSUFBSSxhQUFhLEdBQUcsSUFBSSxjQUFjLEVBQUUsQ0FBQztZQUN6QyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3hLLElBQUksYUFBYSxDQUFDLFFBQVEsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDaEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsTUFBTSxHQUFHLGNBQWMsQ0FBQztZQUMvQixDQUFDO1lBRUQsSUFBRyxJQUFJLENBQUMsTUFBTSxLQUFLLGNBQWMsRUFBQyxDQUFDO2dCQUNqQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUM1QixDQUFDO1lBQ0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDbEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztZQUUvQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUM7UUFDRixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDdEIsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQVcsRUFBRSxNQUFNLEVBQUUsTUFBYSxFQUFFLGFBQTRCLEVBQUUsY0FBcUIsRUFBRSxvQkFBNEIsRUFBRSxNQUFjLEVBQUUsTUFBYztRQUM1SyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2hDLElBQUksUUFBUSxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQy9DLElBQUksVUFBVSxHQUF3QixJQUFJLHFCQUFxQixFQUFFLENBQUM7UUFFbEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLGVBQWUsSUFBSSxRQUFRLENBQUMsV0FBVyxFQUFFLEtBQUssZUFBZSxFQUFFLENBQUM7WUFDL0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLGVBQWUsRUFBRSxDQUFDO2dCQUNqRCxVQUFVLENBQUMsb0JBQW9CLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQ3pELENBQUM7aUJBQU0sQ0FBQztnQkFDTixVQUFVLENBQUMsdUJBQXVCLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzVELENBQUM7WUFDRCxtQ0FBbUM7WUFDbkMsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDeEMsbUJBQW1CLENBQUMsaUJBQWlCLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELENBQUM7WUFDRCxrR0FBa0c7WUFDbEcsSUFBRyxRQUFRLENBQUMsV0FBVyxFQUFFLEtBQUssZUFBZSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBQyxDQUFDO2dCQUNwRixJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxFQUFFLGNBQWMsRUFBRSxvQkFBb0IsRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDO29CQUMzRixJQUFJLGNBQWMsSUFBRyxJQUFJLElBQUksb0JBQW9CLElBQUksSUFBSSxFQUFFLENBQUM7d0JBQzFELElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUM1QyxDQUFDO3lCQUFNLENBQUM7d0JBQ04sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDbEQsQ0FBQztZQUNMLENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQzFCLGFBQWEsQ0FBQyxRQUFRLEdBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCO1lBQzVDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQy9DLENBQUM7SUFDSCxDQUFDO0lBQ08sTUFBTSxDQUFDLGlCQUFpQixDQUFDLGFBQTRCLEVBQUUsUUFBZTtRQUM1RSxJQUFJLENBQUMsUUFBUSxJQUFHLENBQUMsYUFBYSxJQUFHLENBQUMsYUFBYSxDQUFDLElBQUk7WUFBRSxPQUFPO1FBRTdELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7WUFDbEMsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDMUIsYUFBYSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7WUFDNUIsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFDTSxXQUFXO1FBQ2hCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRU8sTUFBTSxDQUFDLGFBQWEsQ0FBQyxhQUE0QixFQUFFLFFBQWU7UUFDeEUsTUFBTSxRQUFRLEdBQW9CLElBQUksZUFBZSxFQUFFLENBQUM7UUFFeEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQztZQUFBLE9BQU87UUFBQSxDQUFDO1FBRTdELElBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDO1lBQzFDLGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQzFCLGFBQWEsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQzVCLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQy9DLENBQUM7SUFDSCxDQUFDO0lBRU8sTUFBTSxDQUFDLG1CQUFtQixDQUFDLGFBQTRCLEVBQUUsUUFBZTtRQUM5RSxNQUFNLFFBQVEsR0FBb0IsSUFBSSxlQUFlLEVBQUUsQ0FBQztRQUV4RCxJQUFHLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQztZQUMxQyxhQUFhLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUMxQixhQUFhLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUM1QixhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUMvQyxDQUFDO0lBQ0gsQ0FBQztJQUVPLE1BQU0sQ0FBQyxlQUFlLENBQUMsYUFBNEIsRUFBRSxXQUFtQixFQUFFLG9CQUE0QixFQUFFLE1BQWUsRUFBRSxNQUFlO1FBQzlJLElBQUksV0FBVyxJQUFHLElBQUksSUFBSSxvQkFBb0IsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUN2RCxJQUFJLE9BQU8sR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDO1lBQ2pDLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVMsR0FBRztnQkFDekMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN6QixDQUFDLENBQUMsQ0FBQTtZQUNGLE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUM5QyxJQUFJLE9BQU8sR0FBRyxvQkFBb0IsRUFBRSxDQUFDO2dCQUNuQyxPQUFPLEtBQUssQ0FBQztZQUNmLENBQUM7UUFDSCxDQUFDO1FBQ0QsSUFBSSxNQUFNLElBQUksTUFBTSxFQUFFLENBQUM7WUFDckIsT0FBTyxDQUFDLElBQUksQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFBO1lBQzVELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQzs4R0FsS1UsbUJBQW1CO2tHQUFuQixtQkFBbUIsaVNDZmhDLCt2REF5QjBEOzsyRkRWN0MsbUJBQW1CO2tCQVAvQixTQUFTOytCQUNFLGlCQUFpQixpQkFHWixpQkFBaUIsQ0FBQyxJQUFJO3FGQUkzQixRQUFRO3NCQUFqQixNQUFNO2dCQUNFLE9BQU87c0JBQWYsS0FBSztnQkFDRyxJQUFJO3NCQUFaLEtBQUs7Z0JBQ0csY0FBYztzQkFBdEIsS0FBSztnQkFDRyxvQkFBb0I7c0JBQTVCLEtBQUs7Z0JBQ0csTUFBTTtzQkFBZCxLQUFLO2dCQUNHLGNBQWM7c0JBQXRCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0LCBFdmVudEVtaXR0ZXIsIE91dHB1dCwgSW5wdXQsIFNpbXBsZUNoYW5nZXMsIFZpZXdFbmNhcHN1bGF0aW9ufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRFJBRlRfRklMRV9UWVBFLCBGSUxFX1RZUEVfRVJST1IsIEZJTkFMX0ZJTEVfVFlQRSwgRk9STV9UWVBFX0VSUk9SLCBJTVBPUlRfU1VDQ0VTUywgQ0hFQ0tfU1VNX0VSUk9SfSBmcm9tICcuLi9maWxlLWlvLWNvbnN0YW50cyc7XHJcbmltcG9ydCB7VHJhbnNsYXRlU2VydmljZX0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XHJcbmltcG9ydCB7IENvbnZlcnRSZXN1bHRzIH0gZnJvbSAnLi4vY29udmVydC1yZXN1bHRzJztcclxuaW1wb3J0IHtGaWxlQ29udmVyc2lvblNlcnZpY2V9IGZyb20gJy4uL2ZpbGUtY29udmVyc2lvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHtDaGVja1N1bVNlcnZpY2V9IGZyb20gJy4uLy4uL2NoZWNrLXN1bS9jaGVjay1zdW0uc2VydmljZSc7XHJcbmltcG9ydCB7IENIRUNLX1NVTV9DT05TVCB9IGZyb20gJy4uLy4uL2NoZWNrLXN1bS9jaGVjay1zdW0tY29uc3RhbnRzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLWZpbGUtcmVhZGVyJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZmlsZXJlYWRlci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vZmlsZXJlYWRlci5jb21wb25lbnQuY3NzJ10sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBGaWxlcmVhZGVyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBAT3V0cHV0KCkgY29tcGxldGUgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgQElucHV0KCkgcm9vdFRhZyA6IHN0cmluZyA9ICcnO1xyXG4gIEBJbnB1dCgpIGxhbmcgOiBzdHJpbmcgPSAnJztcclxuICBASW5wdXQoKSB2ZXJzaW9uVGFnUGF0aD8gOiBzdHJpbmc7IC8vVGhlIHhtbCBwYXRoIG9mIHRoZSB2ZXJzaW9uIHRhZyBpbiBYTUwgc2VwZXJhdGVkIGJ5IFwiLlwiIGV4LiBcIlRSQU5TQUNUSU9OX0VOUk9MLnNvZnR3YXJlX3ZlcnNpb25cIlxyXG4gIEBJbnB1dCgpIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uPyA6IG51bWJlcjtcclxuICBASW5wdXQoKSBkZXZFbnY/IDogYm9vbGVhbjtcclxuICBASW5wdXQoKSBieVBhc3NDaGVja1N1bT8gOiBib29sZWFuO1xyXG5cclxuXHJcbiAgcHVibGljIHN0YXR1cyA9IElNUE9SVF9TVUNDRVNTO1xyXG4gIHB1YmxpYyBpbXBvcnRTdWNjZXNzID0gZmFsc2U7XHJcbiAgcHVibGljIGltcG9ydGVkRmlsZU5hbWUgPSBcIlwiO1xyXG4gIHB1YmxpYyBzaG93RmlsZUxvYWRTdGF0dXMgPSBmYWxzZTtcclxuICBwcml2YXRlIHJvb3RJZCA9ICcnO1xyXG4gIHB1YmxpYyBmaWxlSW1wb3J0ZWQgPSBmYWxzZTtcclxuICBcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHRyYW5zbGF0ZTogVHJhbnNsYXRlU2VydmljZSkge1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnJvb3RUYWcpO1xyXG4gIH1cclxuXHJcblxyXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuICAgIGlmIChjaGFuZ2VzWydyb290VGFnJ10pIHtcclxuICAgICAgdGhpcy5yb290SWQgPSBjaGFuZ2VzWydyb290VGFnJ10uY3VycmVudFZhbHVlO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQXR0YWNoZXMgdG8gdGhlIGZpbGUgYnJvd3NlciwgZGV0ZWN0aW5nIHRoZSBmaWxlIHNlbGVjdGlvbiBjaGFuZ2VcclxuICAgKiBAcGFyYW0gJGV2ZW50XHJcbiAgICovXHJcbiAgY2hhbmdlTGlzdGVuZXIoJGV2ZW50OiBhbnkpIHtcclxuXHJcbiAgICB0aGlzLnJlYWRTZWxlY3RlZEZpbGUoJGV2ZW50LnRhcmdldCk7XHJcblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGV0ZXJtaW5lcyBpZiBhIGZpbGUgd2FzIHNlbGVjdGVkLiBTZXRzIGEgY2FsbGJhY2sgdG8gcHJvY2VzcyB0aGUgZmlsZSBhZnRlciBsb2FkIChhc3ljaClcclxuICAgKiBAcGFyYW0gaW5wdXRWYWx1ZVxyXG4gICAqL1xyXG4gIHJlYWRTZWxlY3RlZEZpbGUoaW5wdXRWYWx1ZTogYW55KTogdm9pZCB7XHJcbiAgICB0aGlzLmZpbGVJbXBvcnRlZCA9IHRydWU7XHJcbiAgICBsZXQgZmlsZTogRmlsZSA9IGlucHV0VmFsdWUuZmlsZXNbMF07XHJcbiAgICBsZXQgbXlSZWFkZXI6IEZpbGVSZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgbGV0IHNlbGYgPSB0aGlzO1xyXG4gICAgbXlSZWFkZXIub25sb2FkZW5kID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgLy8geW91IGNhbiBwZXJmb3JtIGFuIGFjdGlvbiB3aXRoIGRhdGEgaGVyZSBjYWxsYmFjayBmb3IgYXN5bmNoIGxvYWRcclxuICAgICAgbGV0IGNvbnZlcnRSZXN1bHQgPSBuZXcgQ29udmVydFJlc3VsdHMoKTtcclxuICAgICAgRmlsZXJlYWRlckNvbXBvbmVudC5fcmVhZEZpbGUoZmlsZS5uYW1lLCBteVJlYWRlci5yZXN1bHQsIHNlbGYucm9vdElkLCBjb252ZXJ0UmVzdWx0LCBzZWxmLnZlcnNpb25UYWdQYXRoLCBzZWxmLnN0YXJ0Q2hlY2tTdW1WZXJzaW9uLCBzZWxmLmRldkVudiwgc2VsZi5ieVBhc3NDaGVja1N1bSk7XHJcbiAgICAgIGlmIChjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzICYmIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNlbGYuc3RhdHVzID0gY29udmVydFJlc3VsdC5tZXNzYWdlc1swXTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZWxmLnN0YXR1cyA9IElNUE9SVF9TVUNDRVNTO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZihzZWxmLnN0YXR1cyA9PT0gSU1QT1JUX1NVQ0NFU1Mpe1xyXG4gICAgICAgIHNlbGYuaW1wb3J0U3VjY2VzcyA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgICAgc2VsZi5pbXBvcnRlZEZpbGVOYW1lID0gZmlsZS5uYW1lO1xyXG4gICAgICBzZWxmLnNob3dGaWxlTG9hZFN0YXR1cyA9IHRydWU7XHJcbiAgICAgXHJcbiAgICAgIHNlbGYuY29tcGxldGUuZW1pdChjb252ZXJ0UmVzdWx0KTtcclxuICAgIH07XHJcbiAgICBpZiAoZmlsZSAmJiBmaWxlLm5hbWUpIHtcclxuICAgICAgbXlSZWFkZXIucmVhZEFzVGV4dChmaWxlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKipcclxuICAgKiBQcm9jZXNzZXMgdGhlIGZpbGUgZGF0YS4gRGV0ZXJtaW5lcyB0aGUgdHlwZSBvZiBmaWxlIGJhc2VkIG9uIHRoZSBmaWxlbmFtZSBzdWZmaXhcclxuICAgKiBAcGFyYW0gbmFtZSAtIHRoZSBuYW1lIG9mIHRoZSBmaWxlLiBDYW4gaW5jbHVkZSB0aGUgcGF0aFxyXG4gICAqIEBwYXJhbSByZXN1bHQgLSB0aGUgcmVzdWx0IG9mIHRoZSBmaWxlIHJlYWQgaS5lLiBmaWxlIGNvbnRlbnRzIGFzIHRleHRcclxuICAgKiBAcGFyYW0gcm9vdElkIC0gdGhlIG5hbWUgb2YgdGhlIHJvb3RUYWcuIElmIG51bGwgaXMgaWdub3JlZFxyXG4gICAqIEBwYXJhbSB7Q29udmVydFJlc3VsdHN9IGNvbnZlcnRSZXN1bHQgLVRoZSByZXN1bHRzIG9mIHRoZSBmaWxlIHJlYWRcclxuICAgKiBAcHJpdmF0ZVxyXG4gICAqL1xyXG4gIHByaXZhdGUgc3RhdGljIF9yZWFkRmlsZShuYW1lOnN0cmluZywgcmVzdWx0LCByb290SWQ6c3RyaW5nLCBjb252ZXJ0UmVzdWx0OkNvbnZlcnRSZXN1bHRzLCB2ZXJzaW9uVGFnUGF0aDpzdHJpbmcsIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uOiBudW1iZXIsIGRldkVudjpib29sZWFuLCBieVBhc3M6Ym9vbGVhbikge1xyXG4gICAgbGV0IHNwbGl0RmlsZSA9IG5hbWUuc3BsaXQoJy4nKTtcclxuICAgIGxldCBmaWxlVHlwZSA9IHNwbGl0RmlsZVtzcGxpdEZpbGUubGVuZ3RoIC0gMV07XHJcbiAgICBsZXQgY29udmVyc2lvbjpGaWxlQ29udmVyc2lvblNlcnZpY2UgPW5ldyBGaWxlQ29udmVyc2lvblNlcnZpY2UoKTtcclxuXHJcbiAgICBpZiAoKGZpbGVUeXBlLnRvTG93ZXJDYXNlKCkpID09PSBEUkFGVF9GSUxFX1RZUEUgfHwgZmlsZVR5cGUudG9Mb3dlckNhc2UoKSA9PT0gRklOQUxfRklMRV9UWVBFKSB7XHJcbiAgICAgIGlmICgoZmlsZVR5cGUudG9Mb3dlckNhc2UoKSkgPT09IERSQUZUX0ZJTEVfVFlQRSkge1xyXG4gICAgICAgIGNvbnZlcnNpb24uY29udmVydFRvSlNPTk9iamVjdHMocmVzdWx0LCBjb252ZXJ0UmVzdWx0KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb252ZXJzaW9uLmNvbnZlcnRYTUxUb0pTT05PYmplY3RzKHJlc3VsdCwgY29udmVydFJlc3VsdCk7XHJcbiAgICAgIH1cclxuICAgICAgLy8gY29uc29sZS5sb2coY29udmVydFJlc3VsdC5kYXRhKTtcclxuICAgICAgaWYgKGNvbnZlcnRSZXN1bHQubWVzc2FnZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgRmlsZXJlYWRlckNvbXBvbmVudC5jaGVja1Jvb3RUYWdNYXRjaChjb252ZXJ0UmVzdWx0LCByb290SWQpO1xyXG4gICAgICB9XHJcbiAgICAgIC8vIE1GLVJUIHdpbGwgc3RhcnQgdG8gdXNlIHRoZSBzdHJpY3QgY2hlY2tzdW0gd2hpbGUgb3RoZXIgYXBwcyBzdGlsbCBrZWVwIHRoZWlyIGN1cnJlbnQgYmVoYXZpb3VyXHJcbiAgICAgIGlmKGZpbGVUeXBlLnRvTG93ZXJDYXNlKCkgPT09IEZJTkFMX0ZJTEVfVFlQRSAmJiBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLmxlbmd0aCA9PT0gMCl7XHJcbiAgICAgICAgaWYgKHRoaXMuZG9DaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQsIHZlcnNpb25UYWdQYXRoLCBzdGFydENoZWNrU3VtVmVyc2lvbiwgZGV2RW52LCBieVBhc3MpKVxyXG4gICAgICAgICAgaWYgKHZlcnNpb25UYWdQYXRoID09bnVsbCAmJiBzdGFydENoZWNrU3VtVmVyc2lvbiA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2hlY2tTdW1DaGVjayhjb252ZXJ0UmVzdWx0LCByb290SWQpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5zdHJpY3RDaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQsIHJvb3RJZCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQuZGF0YSA9IG51bGw7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXM9W107IC8vY2xlYXIgbXNlc3NhZ2VzXHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMucHVzaChGSUxFX1RZUEVfRVJST1IpO1xyXG4gICAgfVxyXG4gIH1cclxuICBwcml2YXRlIHN0YXRpYyBjaGVja1Jvb3RUYWdNYXRjaChjb252ZXJ0UmVzdWx0OkNvbnZlcnRSZXN1bHRzLCByb290TmFtZTpzdHJpbmcpIHtcclxuICAgIGlmICghcm9vdE5hbWV8fCAhY29udmVydFJlc3VsdCB8fCFjb252ZXJ0UmVzdWx0LmRhdGEpIHJldHVybjtcclxuXHJcbiAgICBpZiAoIWNvbnZlcnRSZXN1bHQuZGF0YVtyb290TmFtZV0pIHtcclxuICAgICAgY29udmVydFJlc3VsdC5kYXRhID0gbnVsbDtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcyA9IFtdO1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLnB1c2goRk9STV9UWVBFX0VSUk9SKTtcclxuICAgIH1cclxuICB9XHJcbiAgcHVibGljIHJlZnJlc2hQYWdlKCl7XHJcbiAgICBsb2NhdGlvbi5yZWxvYWQoKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgc3RhdGljIGNoZWNrU3VtQ2hlY2soY29udmVydFJlc3VsdDpDb252ZXJ0UmVzdWx0cywgcm9vdE5hbWU6c3RyaW5nKSB7ICBcclxuICAgIGNvbnN0IGNoZWNrU3VtOiBDaGVja1N1bVNlcnZpY2UgPSBuZXcgQ2hlY2tTdW1TZXJ2aWNlKCk7XHJcblxyXG4gICAgaWYgKCFjb252ZXJ0UmVzdWx0LmRhdGFbcm9vdE5hbWVdW0NIRUNLX1NVTV9DT05TVF0pIHtyZXR1cm47fVxyXG5cclxuICAgIGlmKCFjaGVja1N1bS5jaGVja0hhc2goY29udmVydFJlc3VsdC5kYXRhKSl7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQuZGF0YSA9IG51bGw7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMgPSBbXTtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKENIRUNLX1NVTV9FUlJPUik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHN0YXRpYyBzdHJpY3RDaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQ6Q29udmVydFJlc3VsdHMsIHJvb3ROYW1lOnN0cmluZykge1xyXG4gICAgY29uc3QgY2hlY2tTdW06IENoZWNrU3VtU2VydmljZSA9IG5ldyBDaGVja1N1bVNlcnZpY2UoKTtcclxuXHJcbiAgICBpZighY2hlY2tTdW0uY2hlY2tIYXNoKGNvbnZlcnRSZXN1bHQuZGF0YSkpe1xyXG4gICAgICBjb252ZXJ0UmVzdWx0LmRhdGEgPSBudWxsO1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzID0gW107XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMucHVzaChDSEVDS19TVU1fRVJST1IpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzdGF0aWMgZG9DaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQ6Q29udmVydFJlc3VsdHMsIHZlcnNpb25QYXRoOiBzdHJpbmcsIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uOiBudW1iZXIsIGRldkVudjogYm9vbGVhbiwgYnlQYXNzOiBib29sZWFuKXtcclxuICAgIGlmICh2ZXJzaW9uUGF0aCAhPW51bGwgJiYgc3RhcnRDaGVja1N1bVZlcnNpb24gIT0gbnVsbCkge1xyXG4gICAgICB2YXIgdmVyc2lvbiA9IGNvbnZlcnRSZXN1bHQuZGF0YTtcclxuICAgICAgdmVyc2lvblBhdGguc3BsaXQoXCIuXCIpLmZvckVhY2goZnVuY3Rpb24oa2V5KXtcclxuICAgICAgICB2ZXJzaW9uID0gdmVyc2lvbltrZXldO1xyXG4gICAgICB9KVxyXG4gICAgICB2ZXJzaW9uID0gcGFyc2VJbnQodmVyc2lvbi5zcGxpdCgnLicpWzBdLCAxMCk7XHJcbiAgICAgIGlmICh2ZXJzaW9uIDwgc3RhcnRDaGVja1N1bVZlcnNpb24pIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gXHJcbiAgICBpZiAoZGV2RW52ICYmIGJ5UGFzcykge1xyXG4gICAgICBjb25zb2xlLndhcm4oXCJCeXBhc3NpbmcgQ2hlY2tzdW0gVmVyaWZpY2F0aW9uIGluIERldiBNb2RlIVwiKVxyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbn1cclxuXHJcbiIsIjxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICA8ZGl2ICpuZ0lmPVwiIWltcG9ydFN1Y2Nlc3NcIiBjbGFzcz1cImZvcm0tZ3JvdXAgY29sLWxnLTEyIGNvbC1tZC0xMiBjb2wtc20tMTIgY29sLXhzLTEyXCI+XHJcbiAgICA8bGFiZWwgZm9yPVwiZmlsZUxvYWRcIj5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJmaWVsZC1uYW1lXCI+e3sgJ3NlbGVjdC5maWxlJ3x0cmFuc2xhdGUgfX08L3NwYW4+XHJcbiAgICA8L2xhYmVsPlxyXG4gICAgPGRpdiAqbmdJZj1cIiFpbXBvcnRTdWNjZXNzXCI+XHJcbiAgICAgIDxidXR0b24gaWQ9XCJmaWxlTG9hZEJ1dHRvblwiIFthdHRyLmFyaWEtbGFiZWxsZWRieV09XCJmaWxlSW1wb3J0ZWQgPyAnZmlsZU5hbWUnIDogJ25vRmlsZUNob3NlbidcIiBvbmNsaWNrPVwiZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2ZpbGVMb2FkJykuY2xpY2soKVwiID4ge3sgJ2Nob29zZS5maWxlJyB8IHRyYW5zbGF0ZSB9fSA8L2J1dHRvbj5cclxuICAgICAgPGlucHV0IHN0eWxlPVwiZGlzcGxheTpub25lXCIgdHlwZT1cImZpbGVcIiBpZD1cImZpbGVMb2FkXCIgbmFtZT1cImZpbGVMb2FkXCIgYWNjZXB0PVwiLnhtbCwgLmhjc2NcIiAoY2hhbmdlKT1cImNoYW5nZUxpc3RlbmVyKCRldmVudClcIiAvPlxyXG4gICAgICA8IS0tIEZPUiBTQ1JFRU4gUkVBREVSIDogVG8gcmVhZCBcIlNlbGVjdCBhIGZpbGUgdG8gbG9hZCwgbm8gZmlsZSBjaG9zZW4gLyAoZmlsZSBuYW1lKSBidXR0b25cIiAtLT5cclxuICAgICAgPHNwYW4gaGlkZGVuIGNsYXNzPVwiZmllbGQtbmFtZVwiICpuZ0lmPVwiIWZpbGVJbXBvcnRlZFwiIGlkPVwibm9GaWxlQ2hvc2VuXCI+IHt7ICdzZWxlY3QuZmlsZSd8dHJhbnNsYXRlIH19IHt7ICduby5maWxlLmNob3NlbicgfCB0cmFuc2xhdGUgfX0gPC9zcGFuPlxyXG4gICAgICA8c3BhbiBoaWRkZW4gY2xhc3M9XCJmaWVsZC1uYW1lXCIgKm5nSWY9XCJmaWxlSW1wb3J0ZWRcIiBpZD1cImZpbGVOYW1lXCI+IHt7ICdzZWxlY3QuZmlsZSd8dHJhbnNsYXRlIH19IHt7aW1wb3J0ZWRGaWxlTmFtZX19IDwvc3Bhbj5cclxuICAgICAgPCEtLSAtLT5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJmaWVsZC1uYW1lXCIgKm5nSWY9XCIhZmlsZUltcG9ydGVkXCI+IHt7ICduby5maWxlLmNob3NlbicgfCB0cmFuc2xhdGUgfX0gPC9zcGFuPlxyXG4gICAgICA8c3BhbiBjbGFzcz1cImZpZWxkLW5hbWVcIiAqbmdJZj1cImZpbGVJbXBvcnRlZFwiPiB7e2ltcG9ydGVkRmlsZU5hbWV9fSA8L3NwYW4+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICA8ZGl2ICpuZ0lmPVwiaW1wb3J0U3VjY2Vzc1wiIGNsYXNzPVwiZm9ybS1ncm91cCBjb2wtbGctMTIgY29sLW1kLTEyIGNvbC1zbS0xMiBjb2wteHMtMTJcIj5cclxuICAgIDxidXR0b24gKGNsaWNrKT1cInJlZnJlc2hQYWdlKClcIj57eyAncmVmcmVzaC5maWxlLmlucHV0J3x0cmFuc2xhdGUgfX08L2J1dHRvbj5cclxuICAgIDxTdHJvbmc+IHt7aW1wb3J0ZWRGaWxlTmFtZX19PC9TdHJvbmc+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG48ZGl2IHJvbGU9XCJhbGVydFwiIFtuZ0NsYXNzXT1cInN0YXR1cyA9PSAnbXNnLnN1Y2Nlc3MubG9hZCcgPyAnYWxlcnQgYWxlcnQtc3VjY2VzcycgOiAnYWxlcnQgYWxlcnQtZGFuZ2VyJ1wiICpuZ0lmPVwic2hvd0ZpbGVMb2FkU3RhdHVzXCI+XHJcbiAgPHA+e3tzdGF0dXMgfCB0cmFuc2xhdGV9fTwvcD5cclxuPC9kaXY+XHJcblxyXG48bmctY29udGVudCBzZWxlY3Q9XCJbZmlsZVVwbG9hZEluc3RydWN0aW9uXVwiPjwvbmctY29udGVudD4iXX0=