import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';
import { DRAFT_FILE_TYPE, FINAL_FILE_TYPE, IMPORT_SUCCESS, PARSE_FAIL } from './file-io-constants';
import * as i0 from "@angular/core";
export class FileConversionService {
    constructor() {
    }
    /***
     * Converts an incoming json string to a json object
     * @param data -the json string to convert
     * @param convertResult -the json object to store the data in
     */
    convertToJSONObjects(jsonData, convertResult) {
        convertResult.messages = [];
        try {
            convertResult.data = JSON.parse(jsonData);
            convertResult.messages.push(IMPORT_SUCCESS);
        }
        catch (e) {
            convertResult.data = null;
            convertResult.messages.push(PARSE_FAIL);
        }
    }
    /***
     *  Using xml2js to do the coversion from JSON to XML
     * @param data
     * @param convertResult
     */
    convertXMLToJSONObjects(data, convertResult) {
        let xmlConfig = {
            escapeMode: true,
            emptyNodeForm: 'text',
            useDoubleQuotes: true
        };
        let jsonConverter = new X2JS(xmlConfig);
        convertResult.messages = [];
        // converts XML as a string to a json
        convertResult.data = jsonConverter.xml_str2json(data);
        if (convertResult.data == null) {
            convertResult.messages.push(PARSE_FAIL);
        }
        return (null);
        /* //see https://www.npmjs.com/package/xml2js for list of options
         let config = {
           attrkey: FileIoGlobalsService.attributeKey, //when there are attributes, this is the key, default $
           charkey: FileIoGlobalsService.innerTextKey, //when there are attributes, this what hte text value is of the tag
           trim: true,
           explicitArray: false, //Makes all the values an array
         };
         convertResult.messages = [];
         xml2js.parseString(data, config, function (err, result) {
           convertResult.data = result;
         });
         if (convertResult.data === null) {
           convertResult.messages.push(FileIoGlobalsService.parseFail);
         } else {
           convertResult.messages.push(FileIoGlobalsService.importSuccess);
           // console.log(convertResult);
         }*/
    }
    /***
     * Converts a json object to XML. Assumes root tag is root of JSON object
     * @param jsonObj
     * @returns {any}
     */
    convertJSONObjectsToXML(jsonObj) {
        if (!jsonObj)
            return null;
        /* let builder = new xml2js.Builder({
           headless: true,    //make headless for easier addition of xsl. Add header manualt
           attrkey: FileIoGlobalsService.attributeKey, //when there are attributes, this is the key, default $
           charkey: FileIoGlobalsService.innerTextKey, //when there are attributes, this what hte text value is of the tag
           explicitArray: false,
           explicitChildren: true
         });
         //making headless so easier to add the stylesheet info
         let xmlResult = builder.buildObject(jsonObj);*/
        let xmlConfig = {
            escapeMode: true,
            emptyNodeForm: 'text',
            useDoubleQuotes: true
        };
        let jsonConverter = new X2JS(xmlConfig);
        // converts XML as a string to a json
        let xmlResult = jsonConverter.json2xml_str(jsonObj);
        return xmlResult;
    }
    //let blob = new Blob([makeStrSave], {type: 'text/plain;charset=utf-8'});
    saveJsonToFile(jsonObj, fileName, rootTag) {
        if (!jsonObj)
            return;
        let makeStrSave = JSON.stringify(jsonObj);
        let blob = new Blob([makeStrSave], { type: 'text/plain;charset=utf-8' });
        // if (!fileName) {
        //   fileName = 'REPDraft.' + DRAFT_FILE_TYPE;
        // } else {
        fileName += '.' + DRAFT_FILE_TYPE;
        // }
        FileSaver.saveAs(blob, fileName);
    }
    /**
     * Saves the incoming JSON data as an xml file
     * @param jsonObj -the json object to write as XML
     * @param {string} fileName - the bsse filename to save the file as. the suffix is sdded
     * @param {boolean} addXsl
     * @param {string} xslName
     */
    saveXmlToFile(jsonObj, fileName, addXsl = true, xslName = null) {
        if (!jsonObj)
            return;
        let xmlResult = this.convertJSONObjectsToXML(jsonObj);
        if (addXsl) {
            // if (!xslName) {
            //   xmlResult = '<?xml version="1.0" encoding="UTF-8"?>' + '<?xml-stylesheet  type="text/xsl" href=' + defaultXSLName + '?>' + xmlResult;
            // } else {
            xmlResult = '<?xml version="1.0" encoding="UTF-8"?>' + '<?xml-stylesheet  type="text/xsl" href="' + xslName + '"?>' + xmlResult;
            // }
        }
        let blob = new Blob([xmlResult], { type: 'text/plain;charset=utf-8' });
        // if (!fileName) {
        //   fileName = 'REPFinal.' + FINAL_FILE_TYPE;
        // } else {
        fileName += '.' + FINAL_FILE_TYPE;
        // }
        FileSaver.saveAs(blob, fileName);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: FileConversionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: FileConversionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: FileConversionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1jb252ZXJzaW9uLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGUtY29udmVyc2lvbi5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxlQUFlLENBQUM7QUFHekMsT0FBTyxLQUFLLFNBQVMsTUFBTSxZQUFZLENBQUM7QUFDeEMsT0FBTyxFQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUUsY0FBYyxFQUFFLFVBQVUsRUFBRSxNQUFNLHFCQUFxQixDQUFDOztBQU1uRyxNQUFNLE9BQU8scUJBQXFCO0lBRWhDO0lBQ0EsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsYUFBNkI7UUFDMUQsYUFBYSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDO1lBQ0gsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzlDLENBQUM7UUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ1gsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDMUIsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDMUMsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsdUJBQXVCLENBQUMsSUFBSSxFQUFFLGFBQTZCO1FBRXpELElBQUksU0FBUyxHQUFHO1lBQ2QsVUFBVSxFQUFFLElBQUk7WUFDaEIsYUFBYSxFQUFFLE1BQU07WUFDckIsZUFBZSxFQUFFLElBQUk7U0FDdEIsQ0FBQztRQUNGLElBQUksYUFBYSxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3hDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQzVCLHFDQUFxQztRQUNyQyxhQUFhLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsSUFBSSxhQUFhLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1lBQy9CLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFZDs7Ozs7Ozs7Ozs7Ozs7OztZQWdCSTtJQUNOLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsdUJBQXVCLENBQUMsT0FBTztRQUM3QixJQUFJLENBQUMsT0FBTztZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQzNCOzs7Ozs7Ozt3REFRZ0Q7UUFDL0MsSUFBSSxTQUFTLEdBQUc7WUFDZCxVQUFVLEVBQUUsSUFBSTtZQUNoQixhQUFhLEVBQUUsTUFBTTtZQUNyQixlQUFlLEVBQUUsSUFBSTtTQUN0QixDQUFDO1FBQ0YsSUFBSSxhQUFhLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDeEMscUNBQXFDO1FBQ3JDLElBQUksU0FBUyxHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEQsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVELHlFQUF5RTtJQUNsRSxjQUFjLENBQUMsT0FBTyxFQUFFLFFBQWdCLEVBQUUsT0FBZTtRQUM5RCxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDckIsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMxQyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUMsSUFBSSxFQUFFLDBCQUEwQixFQUFDLENBQUMsQ0FBQztRQUN2RSxtQkFBbUI7UUFDbkIsOENBQThDO1FBQzlDLFdBQVc7UUFDVCxRQUFRLElBQUksR0FBRyxHQUFHLGVBQWUsQ0FBQztRQUNwQyxJQUFJO1FBQ0osU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGFBQWEsQ0FBQyxPQUFPLEVBQUUsUUFBZ0IsRUFBRSxTQUFrQixJQUFJLEVBQUUsVUFBa0IsSUFBSTtRQUM1RixJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDckIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRELElBQUksTUFBTSxFQUFFLENBQUM7WUFDWCxrQkFBa0I7WUFDbEIsMElBQTBJO1lBQzFJLFdBQVc7WUFDVCxTQUFTLEdBQUcsd0NBQXdDLEdBQUcsMENBQTBDLEdBQUcsT0FBTyxHQUFHLEtBQUssR0FBRyxTQUFTLENBQUM7WUFDbEksSUFBSTtRQUNOLENBQUM7UUFDRCxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUMsSUFBSSxFQUFFLDBCQUEwQixFQUFDLENBQUMsQ0FBQztRQUNyRSxtQkFBbUI7UUFDbkIsOENBQThDO1FBQzlDLFdBQVc7UUFDVCxRQUFRLElBQUksR0FBRyxHQUFHLGVBQWUsQ0FBQztRQUNwQyxJQUFJO1FBQ0osU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDbkMsQ0FBQzsrR0E5SFUscUJBQXFCO21IQUFyQixxQkFBcUI7OzRGQUFyQixxQkFBcUI7a0JBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0luamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vLyBpbXBvcnQgKiBhcyB4bWwyanMgZnJvbSAneG1sMmpzJztcclxuaW1wb3J0IHtDb252ZXJ0UmVzdWx0c30gZnJvbSAnLi9jb252ZXJ0LXJlc3VsdHMnO1xyXG5pbXBvcnQgKiBhcyBGaWxlU2F2ZXIgZnJvbSAnZmlsZS1zYXZlcic7XHJcbmltcG9ydCB7IERSQUZUX0ZJTEVfVFlQRSwgRklOQUxfRklMRV9UWVBFLCBJTVBPUlRfU1VDQ0VTUywgUEFSU0VfRkFJTCB9IGZyb20gJy4vZmlsZS1pby1jb25zdGFudHMnO1xyXG5cclxuZGVjbGFyZSB2YXIgWDJKUzogYW55O1xyXG5cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEZpbGVDb252ZXJzaW9uU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gIH1cclxuXHJcbiAgLyoqKlxyXG4gICAqIENvbnZlcnRzIGFuIGluY29taW5nIGpzb24gc3RyaW5nIHRvIGEganNvbiBvYmplY3RcclxuICAgKiBAcGFyYW0gZGF0YSAtdGhlIGpzb24gc3RyaW5nIHRvIGNvbnZlcnRcclxuICAgKiBAcGFyYW0gY29udmVydFJlc3VsdCAtdGhlIGpzb24gb2JqZWN0IHRvIHN0b3JlIHRoZSBkYXRhIGluXHJcbiAgICovXHJcbiAgY29udmVydFRvSlNPTk9iamVjdHMoanNvbkRhdGEsIGNvbnZlcnRSZXN1bHQ6IENvbnZlcnRSZXN1bHRzKSB7XHJcbiAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzID0gW107XHJcbiAgICB0cnkge1xyXG4gICAgICBjb252ZXJ0UmVzdWx0LmRhdGEgPSBKU09OLnBhcnNlKGpzb25EYXRhKTtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKElNUE9SVF9TVUNDRVNTKTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgY29udmVydFJlc3VsdC5kYXRhID0gbnVsbDtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKFBBUlNFX0ZBSUwpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqKlxyXG4gICAqICBVc2luZyB4bWwyanMgdG8gZG8gdGhlIGNvdmVyc2lvbiBmcm9tIEpTT04gdG8gWE1MXHJcbiAgICogQHBhcmFtIGRhdGFcclxuICAgKiBAcGFyYW0gY29udmVydFJlc3VsdFxyXG4gICAqL1xyXG4gIGNvbnZlcnRYTUxUb0pTT05PYmplY3RzKGRhdGEsIGNvbnZlcnRSZXN1bHQ6IENvbnZlcnRSZXN1bHRzKSB7XHJcblxyXG4gICAgbGV0IHhtbENvbmZpZyA9IHtcclxuICAgICAgZXNjYXBlTW9kZTogdHJ1ZSxcclxuICAgICAgZW1wdHlOb2RlRm9ybTogJ3RleHQnLFxyXG4gICAgICB1c2VEb3VibGVRdW90ZXM6IHRydWVcclxuICAgIH07XHJcbiAgICBsZXQganNvbkNvbnZlcnRlciA9IG5ldyBYMkpTKHhtbENvbmZpZyk7XHJcbiAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzID0gW107XHJcbiAgICAvLyBjb252ZXJ0cyBYTUwgYXMgYSBzdHJpbmcgdG8gYSBqc29uXHJcbiAgICBjb252ZXJ0UmVzdWx0LmRhdGEgPSBqc29uQ29udmVydGVyLnhtbF9zdHIyanNvbihkYXRhKTtcclxuICAgIGlmIChjb252ZXJ0UmVzdWx0LmRhdGEgPT0gbnVsbCkge1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLnB1c2goUEFSU0VfRkFJTCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKG51bGwpO1xyXG5cclxuICAgIC8qIC8vc2VlIGh0dHBzOi8vd3d3Lm5wbWpzLmNvbS9wYWNrYWdlL3htbDJqcyBmb3IgbGlzdCBvZiBvcHRpb25zXHJcbiAgICAgbGV0IGNvbmZpZyA9IHtcclxuICAgICAgIGF0dHJrZXk6IEZpbGVJb0dsb2JhbHNTZXJ2aWNlLmF0dHJpYnV0ZUtleSwgLy93aGVuIHRoZXJlIGFyZSBhdHRyaWJ1dGVzLCB0aGlzIGlzIHRoZSBrZXksIGRlZmF1bHQgJFxyXG4gICAgICAgY2hhcmtleTogRmlsZUlvR2xvYmFsc1NlcnZpY2UuaW5uZXJUZXh0S2V5LCAvL3doZW4gdGhlcmUgYXJlIGF0dHJpYnV0ZXMsIHRoaXMgd2hhdCBodGUgdGV4dCB2YWx1ZSBpcyBvZiB0aGUgdGFnXHJcbiAgICAgICB0cmltOiB0cnVlLFxyXG4gICAgICAgZXhwbGljaXRBcnJheTogZmFsc2UsIC8vTWFrZXMgYWxsIHRoZSB2YWx1ZXMgYW4gYXJyYXlcclxuICAgICB9O1xyXG4gICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMgPSBbXTtcclxuICAgICB4bWwyanMucGFyc2VTdHJpbmcoZGF0YSwgY29uZmlnLCBmdW5jdGlvbiAoZXJyLCByZXN1bHQpIHtcclxuICAgICAgIGNvbnZlcnRSZXN1bHQuZGF0YSA9IHJlc3VsdDtcclxuICAgICB9KTtcclxuICAgICBpZiAoY29udmVydFJlc3VsdC5kYXRhID09PSBudWxsKSB7XHJcbiAgICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLnB1c2goRmlsZUlvR2xvYmFsc1NlcnZpY2UucGFyc2VGYWlsKTtcclxuICAgICB9IGVsc2Uge1xyXG4gICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKEZpbGVJb0dsb2JhbHNTZXJ2aWNlLmltcG9ydFN1Y2Nlc3MpO1xyXG4gICAgICAgLy8gY29uc29sZS5sb2coY29udmVydFJlc3VsdCk7XHJcbiAgICAgfSovXHJcbiAgfVxyXG5cclxuICAvKioqXHJcbiAgICogQ29udmVydHMgYSBqc29uIG9iamVjdCB0byBYTUwuIEFzc3VtZXMgcm9vdCB0YWcgaXMgcm9vdCBvZiBKU09OIG9iamVjdFxyXG4gICAqIEBwYXJhbSBqc29uT2JqXHJcbiAgICogQHJldHVybnMge2FueX1cclxuICAgKi9cclxuICBjb252ZXJ0SlNPTk9iamVjdHNUb1hNTChqc29uT2JqKSB7XHJcbiAgICBpZiAoIWpzb25PYmopIHJldHVybiBudWxsO1xyXG4gICAvKiBsZXQgYnVpbGRlciA9IG5ldyB4bWwyanMuQnVpbGRlcih7XHJcbiAgICAgIGhlYWRsZXNzOiB0cnVlLCAgICAvL21ha2UgaGVhZGxlc3MgZm9yIGVhc2llciBhZGRpdGlvbiBvZiB4c2wuIEFkZCBoZWFkZXIgbWFudWFsdFxyXG4gICAgICBhdHRya2V5OiBGaWxlSW9HbG9iYWxzU2VydmljZS5hdHRyaWJ1dGVLZXksIC8vd2hlbiB0aGVyZSBhcmUgYXR0cmlidXRlcywgdGhpcyBpcyB0aGUga2V5LCBkZWZhdWx0ICRcclxuICAgICAgY2hhcmtleTogRmlsZUlvR2xvYmFsc1NlcnZpY2UuaW5uZXJUZXh0S2V5LCAvL3doZW4gdGhlcmUgYXJlIGF0dHJpYnV0ZXMsIHRoaXMgd2hhdCBodGUgdGV4dCB2YWx1ZSBpcyBvZiB0aGUgdGFnXHJcbiAgICAgIGV4cGxpY2l0QXJyYXk6IGZhbHNlLFxyXG4gICAgICBleHBsaWNpdENoaWxkcmVuOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIC8vbWFraW5nIGhlYWRsZXNzIHNvIGVhc2llciB0byBhZGQgdGhlIHN0eWxlc2hlZXQgaW5mb1xyXG4gICAgbGV0IHhtbFJlc3VsdCA9IGJ1aWxkZXIuYnVpbGRPYmplY3QoanNvbk9iaik7Ki9cclxuICAgIGxldCB4bWxDb25maWcgPSB7XHJcbiAgICAgIGVzY2FwZU1vZGU6IHRydWUsXHJcbiAgICAgIGVtcHR5Tm9kZUZvcm06ICd0ZXh0JyxcclxuICAgICAgdXNlRG91YmxlUXVvdGVzOiB0cnVlXHJcbiAgICB9O1xyXG4gICAgbGV0IGpzb25Db252ZXJ0ZXIgPSBuZXcgWDJKUyh4bWxDb25maWcpO1xyXG4gICAgLy8gY29udmVydHMgWE1MIGFzIGEgc3RyaW5nIHRvIGEganNvblxyXG4gICAgbGV0IHhtbFJlc3VsdCA9IGpzb25Db252ZXJ0ZXIuanNvbjJ4bWxfc3RyKGpzb25PYmopO1xyXG4gICAgcmV0dXJuIHhtbFJlc3VsdDtcclxuICB9XHJcblxyXG4gIC8vbGV0IGJsb2IgPSBuZXcgQmxvYihbbWFrZVN0clNhdmVdLCB7dHlwZTogJ3RleHQvcGxhaW47Y2hhcnNldD11dGYtOCd9KTtcclxuICBwdWJsaWMgc2F2ZUpzb25Ub0ZpbGUoanNvbk9iaiwgZmlsZU5hbWU6IHN0cmluZywgcm9vdFRhZzogc3RyaW5nKSB7XHJcbiAgICBpZiAoIWpzb25PYmopIHJldHVybjtcclxuICAgIGxldCBtYWtlU3RyU2F2ZSA9IEpTT04uc3RyaW5naWZ5KGpzb25PYmopO1xyXG4gICAgbGV0IGJsb2IgPSBuZXcgQmxvYihbbWFrZVN0clNhdmVdLCB7dHlwZTogJ3RleHQvcGxhaW47Y2hhcnNldD11dGYtOCd9KTtcclxuICAgIC8vIGlmICghZmlsZU5hbWUpIHtcclxuICAgIC8vICAgZmlsZU5hbWUgPSAnUkVQRHJhZnQuJyArIERSQUZUX0ZJTEVfVFlQRTtcclxuICAgIC8vIH0gZWxzZSB7XHJcbiAgICAgIGZpbGVOYW1lICs9ICcuJyArIERSQUZUX0ZJTEVfVFlQRTtcclxuICAgIC8vIH1cclxuICAgIEZpbGVTYXZlci5zYXZlQXMoYmxvYiwgZmlsZU5hbWUpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2F2ZXMgdGhlIGluY29taW5nIEpTT04gZGF0YSBhcyBhbiB4bWwgZmlsZVxyXG4gICAqIEBwYXJhbSBqc29uT2JqIC10aGUganNvbiBvYmplY3QgdG8gd3JpdGUgYXMgWE1MXHJcbiAgICogQHBhcmFtIHtzdHJpbmd9IGZpbGVOYW1lIC0gdGhlIGJzc2UgZmlsZW5hbWUgdG8gc2F2ZSB0aGUgZmlsZSBhcy4gdGhlIHN1ZmZpeCBpcyBzZGRlZFxyXG4gICAqIEBwYXJhbSB7Ym9vbGVhbn0gYWRkWHNsXHJcbiAgICogQHBhcmFtIHtzdHJpbmd9IHhzbE5hbWVcclxuICAgKi9cclxuICBwdWJsaWMgc2F2ZVhtbFRvRmlsZShqc29uT2JqLCBmaWxlTmFtZTogc3RyaW5nLCBhZGRYc2w6IGJvb2xlYW4gPSB0cnVlLCB4c2xOYW1lOiBzdHJpbmcgPSBudWxsKSB7XHJcbiAgICBpZiAoIWpzb25PYmopIHJldHVybjtcclxuICAgIGxldCB4bWxSZXN1bHQgPSB0aGlzLmNvbnZlcnRKU09OT2JqZWN0c1RvWE1MKGpzb25PYmopO1xyXG5cclxuICAgIGlmIChhZGRYc2wpIHtcclxuICAgICAgLy8gaWYgKCF4c2xOYW1lKSB7XHJcbiAgICAgIC8vICAgeG1sUmVzdWx0ID0gJzw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PicgKyAnPD94bWwtc3R5bGVzaGVldCAgdHlwZT1cInRleHQveHNsXCIgaHJlZj0nICsgZGVmYXVsdFhTTE5hbWUgKyAnPz4nICsgeG1sUmVzdWx0O1xyXG4gICAgICAvLyB9IGVsc2Uge1xyXG4gICAgICAgIHhtbFJlc3VsdCA9ICc8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz4nICsgJzw/eG1sLXN0eWxlc2hlZXQgIHR5cGU9XCJ0ZXh0L3hzbFwiIGhyZWY9XCInICsgeHNsTmFtZSArICdcIj8+JyArIHhtbFJlc3VsdDtcclxuICAgICAgLy8gfVxyXG4gICAgfVxyXG4gICAgbGV0IGJsb2IgPSBuZXcgQmxvYihbeG1sUmVzdWx0XSwge3R5cGU6ICd0ZXh0L3BsYWluO2NoYXJzZXQ9dXRmLTgnfSk7XHJcbiAgICAvLyBpZiAoIWZpbGVOYW1lKSB7XHJcbiAgICAvLyAgIGZpbGVOYW1lID0gJ1JFUEZpbmFsLicgKyBGSU5BTF9GSUxFX1RZUEU7XHJcbiAgICAvLyB9IGVsc2Uge1xyXG4gICAgICBmaWxlTmFtZSArPSAnLicgKyBGSU5BTF9GSUxFX1RZUEU7XHJcbiAgICAvLyB9XHJcbiAgICBGaWxlU2F2ZXIuc2F2ZUFzKGJsb2IsIGZpbGVOYW1lKTtcclxuICB9XHJcbn1cclxuIl19