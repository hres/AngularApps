import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class LoggerService {
    log(className, methodName, ...messages) {
        console.log(className + '-> ' + methodName + '->', messages.join(', '));
    }
    error(className, methodName, ...messages) {
        console.error(className + '-> ' + methodName + '->', messages.join(', '));
    }
    warn(className, methodName, ...messages) {
        console.warn(className + '-> ' + methodName + '->', messages.join(', '));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: LoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: LoggerService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nZ2VyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9sb2dnZXIvbG9nZ2VyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHM0MsTUFBTSxPQUFPLGFBQWE7SUFFeEIsR0FBRyxDQUFDLFNBQWlCLEVBQUUsVUFBa0IsRUFBRSxHQUFHLFFBQWU7UUFDM0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsS0FBSyxHQUFHLFVBQVUsR0FBRyxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzFFLENBQUM7SUFFRCxLQUFLLENBQUMsU0FBaUIsRUFBRSxVQUFrQixFQUFFLEdBQUcsUUFBZTtRQUM3RCxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxLQUFLLEdBQUcsVUFBVSxHQUFHLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVELElBQUksQ0FBQyxTQUFpQixFQUFFLFVBQWtCLEVBQUUsR0FBRyxRQUFlO1FBQzVELE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssR0FBRyxVQUFVLEdBQUcsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUMzRSxDQUFDOytHQVpVLGFBQWE7bUhBQWIsYUFBYTs7NEZBQWIsYUFBYTtrQkFEekIsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIExvZ2dlclNlcnZpY2Uge1xyXG4gIFxyXG4gIGxvZyhjbGFzc05hbWU6IHN0cmluZywgbWV0aG9kTmFtZTogc3RyaW5nLCAuLi5tZXNzYWdlczogYW55W10pIHtcclxuICAgIGNvbnNvbGUubG9nKGNsYXNzTmFtZSArICctPiAnICsgbWV0aG9kTmFtZSArICctPicsIG1lc3NhZ2VzLmpvaW4oJywgJykpO1xyXG4gIH1cclxuXHJcbiAgZXJyb3IoY2xhc3NOYW1lOiBzdHJpbmcsIG1ldGhvZE5hbWU6IHN0cmluZywgLi4ubWVzc2FnZXM6IGFueVtdKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGNsYXNzTmFtZSArICctPiAnICsgbWV0aG9kTmFtZSArICctPicsIG1lc3NhZ2VzLmpvaW4oJywgJykpO1xyXG4gIH1cclxuXHJcbiAgd2FybihjbGFzc05hbWU6IHN0cmluZywgbWV0aG9kTmFtZTogc3RyaW5nLCAuLi5tZXNzYWdlczogYW55W10pIHtcclxuICAgIGNvbnNvbGUud2FybihjbGFzc05hbWUgKyAnLT4gJyArIG1ldGhvZE5hbWUgKyAnLT4nLCBtZXNzYWdlcy5qb2luKCcsICcpKTtcclxuICB9XHJcbn1cclxuIl19