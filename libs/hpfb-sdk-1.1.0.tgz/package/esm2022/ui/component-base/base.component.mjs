import { Directive, ViewChildren } from "@angular/core";
import { ControlMessagesComponent } from "../error-msg/control-messages/control-messages.component";
import * as i0 from "@angular/core";
export class BaseComponent {
    constructor() { }
    ngAfterViewInit() {
        this.msgList.changes.subscribe(errorObjs => {
            this._updateAndEmitErrors(errorObjs);
        });
        this.msgList.notifyOnChanges();
    }
    _updateAndEmitErrors(errorObjs) {
        const temp = [];
        if (errorObjs) {
            errorObjs.forEach(error => {
                temp.push(error);
            });
        }
        this.emitErrors(temp);
    }
    // append errors from child component
    _appendErrorsFromChild(errorsFromChild) {
        const parentErrors = this.msgList.toArray();
        const combinedErrors = [...parentErrors, ...errorsFromChild];
        this.emitErrors(combinedErrors); // Call the abstract method
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: BaseComponent, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.10", type: BaseComponent, viewQueries: [{ propertyName: "msgList", predicate: ControlMessagesComponent, descendants: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: BaseComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { msgList: [{
                type: ViewChildren,
                args: [ControlMessagesComponent]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9jb21wb25lbnQtYmFzZS9iYXNlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQW9DLFNBQVMsRUFBYSxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDckcsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sMERBQTBELENBQUM7O0FBR3BHLE1BQU0sT0FBZ0IsYUFBYTtJQUlqQyxnQkFBZ0IsQ0FBQztJQUVqQixlQUFlO1FBQ2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2QyxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVTLG9CQUFvQixDQUFDLFNBQVM7UUFDdEMsTUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksU0FBUyxFQUFFLENBQUM7WUFDZCxTQUFTLENBQUMsT0FBTyxDQUNmLEtBQUssQ0FBQyxFQUFFO2dCQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkIsQ0FBQyxDQUNGLENBQUM7UUFDSixDQUFDO1FBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN4QixDQUFDO0lBRUQscUNBQXFDO0lBQzNCLHNCQUFzQixDQUFDLGVBQTJDO1FBQzFFLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDNUMsTUFBTSxjQUFjLEdBQUcsQ0FBQyxHQUFHLFlBQVksRUFBRSxHQUFHLGVBQWUsQ0FBQyxDQUFDO1FBQzdELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBRSwyQkFBMkI7SUFDL0QsQ0FBQzsrR0E5Qm1CLGFBQWE7bUdBQWIsYUFBYSxzREFFbkIsd0JBQXdCOzs0RkFGbEIsYUFBYTtrQkFEbEMsU0FBUzt3REFHMEMsT0FBTztzQkFBeEQsWUFBWTt1QkFBQyx3QkFBd0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBZnRlclZpZXdJbml0LCBDaGFuZ2VEZXRlY3RvclJlZiwgRGlyZWN0aXZlLCBRdWVyeUxpc3QsIFZpZXdDaGlsZHJlbiB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IENvbnRyb2xNZXNzYWdlc0NvbXBvbmVudCB9IGZyb20gXCIuLi9lcnJvci1tc2cvY29udHJvbC1tZXNzYWdlcy9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudFwiO1xyXG5cclxuQERpcmVjdGl2ZSgpXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgXHJcbiAgQFZpZXdDaGlsZHJlbihDb250cm9sTWVzc2FnZXNDb21wb25lbnQpIHByb3RlY3RlZCBtc2dMaXN0OiBRdWVyeUxpc3Q8Q29udHJvbE1lc3NhZ2VzQ29tcG9uZW50PjtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgdGhpcy5tc2dMaXN0LmNoYW5nZXMuc3Vic2NyaWJlKGVycm9yT2JqcyA9PiB7XHJcbiAgICAgIHRoaXMuX3VwZGF0ZUFuZEVtaXRFcnJvcnMoZXJyb3JPYmpzKTtcclxuICAgIH0pO1xyXG4gICAgdGhpcy5tc2dMaXN0Lm5vdGlmeU9uQ2hhbmdlcygpO1xyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF91cGRhdGVBbmRFbWl0RXJyb3JzKGVycm9yT2Jqcykge1xyXG4gICAgY29uc3QgdGVtcCA9IFtdO1xyXG4gICAgaWYgKGVycm9yT2Jqcykge1xyXG4gICAgICBlcnJvck9ianMuZm9yRWFjaChcclxuICAgICAgICBlcnJvciA9PiB7XHJcbiAgICAgICAgICB0ZW1wLnB1c2goZXJyb3IpO1xyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgIH1cclxuICAgIHRoaXMuZW1pdEVycm9ycyh0ZW1wKTtcclxuICB9XHJcblxyXG4gIC8vIGFwcGVuZCBlcnJvcnMgZnJvbSBjaGlsZCBjb21wb25lbnRcclxuICBwcm90ZWN0ZWQgX2FwcGVuZEVycm9yc0Zyb21DaGlsZChlcnJvcnNGcm9tQ2hpbGQ6IENvbnRyb2xNZXNzYWdlc0NvbXBvbmVudFtdKSB7XHJcbiAgICBjb25zdCBwYXJlbnRFcnJvcnMgPSB0aGlzLm1zZ0xpc3QudG9BcnJheSgpO1xyXG4gICAgY29uc3QgY29tYmluZWRFcnJvcnMgPSBbLi4ucGFyZW50RXJyb3JzLCAuLi5lcnJvcnNGcm9tQ2hpbGRdO1xyXG4gICAgdGhpcy5lbWl0RXJyb3JzKGNvbWJpbmVkRXJyb3JzKTsgIC8vIENhbGwgdGhlIGFic3RyYWN0IG1ldGhvZFxyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIGFic3RyYWN0IGVtaXRFcnJvcnMoZXJyb3JzOiBhbnlbXSk6IHZvaWQ7XHJcbn0iXX0=