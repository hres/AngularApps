import { Injectable } from '@angular/core';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import { CANADA, USA, FRENCH } from '../common.constants';
import { DatePipe } from '@angular/common';
import { SortOn } from '../data-loader/data';
import * as i0 from "@angular/core";
export class UtilsService {
    constructor() {
        // return true if the value is in the array of valid values
        this.toBoolean = (value) => [true, 'TRUE', 'T', '1', 1].includes(typeof value === 'string' ? value.toUpperCase() : value);
    }
    isCanadaOrUSA(countryValue) {
        return this.isCanada(countryValue) || this.isUsa(countryValue);
    }
    /**
     * Checks of the value is canada or not. Checks for Json object vs single value
     * @param value the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isCanada(countryValue) {
        return countryValue === CANADA;
    }
    /**
     * Checks if the value usa or not. Checks for Json object vs single value
     * @param value - the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isUsa(countryValue) {
        return countryValue === USA;
    }
    static isFrench(lang) {
        return lang === FRENCH;
    }
    isFrench(lang) {
        return lang === FRENCH;
    }
    getFormattedDate(format) {
        const today = new Date();
        const pipe = new DatePipe('en-US');
        return pipe.transform(today, format);
    }
    /*
    check if the component is first time loaded
    Object.values to retrieve all changes as an array
    Array.some to check whether any of the changes has isFirstChange set
    Beware: If no @Input is set at all, isFirstChange will be false because Array.some stops at the first true value.
    */
    isFirstChange(changes) {
        return Object.values(changes).some(c => c.isFirstChange());
    }
    /**
     * find a code by its id in a code array
     * @param codeArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeById(codeArray, id) {
        return this.isEmpty(id) ? undefined : codeArray.find(obj => obj.id === id);
    }
    /*
    * takes an array of ids,
    * uses the filter method to iterate through the codeArray and includes only those objects whose id is present in the idsToFilter array
    * the filtered array is then returned
    */
    filterCodesByIds(codeArray, idsToFilter) {
        return codeArray.filter((code) => idsToFilter.includes(code.id));
    }
    /**
     * find a codeDefinition by its id in a codeDefinition array
     * @param codeDefinitionArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeDefinitionById(codeDefinitionArray, id) {
        return this.isEmpty(id) ? undefined : codeDefinitionArray.find(obj => obj.id === id);
    }
    /**
     * get the id value from an IdTextLabel object
     * @param idTextLabelObj
     * @returns either id or undefined
     */
    getIdFromIdTextLabel(idTextLabelObj) {
        return !this.isEmpty(idTextLabelObj) ? idTextLabelObj._id : undefined;
    }
    getIdsFromIdTextLabels(idTextLabelObjs) {
        let ids = [];
        if (!this.isEmpty(idTextLabelObjs)) {
            if (Array.isArray(idTextLabelObjs) && this.isArrayOfIIdTextLabel(idTextLabelObjs)) {
                for (const temp of idTextLabelObjs) {
                    ids.push(this.getIdFromIdTextLabel(temp));
                }
            }
            else if (!Array.isArray(idTextLabelObjs) && this.isIIdTextLabel(idTextLabelObjs)) {
                ids.push(this.getIdFromIdTextLabel(idTextLabelObjs));
            }
        }
        return ids;
    }
    getLabelFromIdTextLabelByLang(idTextLabelObj, lang) {
        return !this.isEmpty(idTextLabelObj) ? (this.isFrench(lang) ? idTextLabelObj._label_fr : idTextLabelObj._label_en) : undefined;
    }
    isArrayOfIIdTextLabel(arr) {
        return arr.every(item => this.isIIdTextLabel(item));
    }
    isIIdTextLabel(obj) {
        return obj === null ? false : (typeof obj._id === 'string' &&
            (typeof obj.__text === 'undefined' || typeof obj.__text === 'string') &&
            typeof obj._label_en === 'string' &&
            typeof obj._label_fr === 'string');
    }
    // filter an IParentChildren array by parentId and return its children
    filterParentChildrenArray(arr, pId) {
        if (!pId) {
            return [];
        }
        const filteredArray = arr.filter((x) => x.parentId === pId);
        //    console.log(
        //      'filterParentChildrenArray ~ filteredArray',
        //      filteredArray
        // );
        // Check if filteredArray is not empty and return children
        if (filteredArray.length > 0) {
            return filteredArray[0]['children'];
        }
        // If no match found, return an empty array
        return [];
    }
    // return a concatated string, delimited by a space
    concat(...param) {
        // console.log(param.join(' ')) // [1,2]
        return param.join(' ');
    }
    // reset form controls' values
    resetControlsValues(...controls) {
        controls.forEach(c => {
            if (c instanceof FormArray) {
                // console.log("....FormArray")
                // If it's a FormArray, clear all existing form controls within it
                c.clear();
                c.markAsUntouched();
            }
            else if (c instanceof AbstractControl && 'setValue' in c) {
                // console.log("....FormControl")
                // If it's a FormControl, reset its value
                c.setValue(null);
                c.markAsUntouched();
            }
        });
    }
    getCodeDefinitionByLang(codeDefinition, lang) {
        if (codeDefinition) {
            if (this.isFrench(lang)) {
                return codeDefinition.defFr;
            }
            else {
                return codeDefinition.defEn;
            }
        }
        else {
            return null;
        }
    }
    // Function to find a match by id and return the appropriate definition based on lang
    getCodeDefinitionByIdByLang(id, list, lang) {
        // Find the ICodeDefinition object with the matching id
        const codeDefinition = list.find(item => item.id === id);
        // If no match is found, return undefined
        if (!codeDefinition) {
            return null;
        }
        return this.getCodeDefinitionByLang(codeDefinition, lang);
    }
    isEmpty(value) {
        return value === null || value === undefined || value === "";
    }
    flattenArrays(arrays) {
        return [].concat(...arrays);
    }
    // returns true if any item in array1 is in array2
    isArray1ElementInArray2(array1, array2) {
        for (const item1 of array1) {
            const found = array2.find(x => x === item1);
            if (found) {
                return true;
            }
        }
        return false;
    }
    // Function to copy values from source to destination
    copyFormGroupValues(source, destination) {
        Object.keys(source.controls).forEach(controlName => {
            if (destination.controls[controlName]) {
                destination.controls[controlName].setValue(source.controls[controlName].value);
            }
        });
    }
    getControlName(control) {
        var controlName = null;
        var parent = control["_parent"];
        // only such parent, which is FormGroup, has a dictionary 
        // with control-names as a key and a form-control as a value
        if (parent instanceof FormGroup) {
            // now we will iterate those keys (i.e. names of controls)
            Object.keys(parent.controls).forEach((name) => {
                // and compare the passed control and 
                // a child control of a parent - with provided name (we iterate them all)
                if (control === parent.controls[name]) {
                    // both are same: control passed to Validator
                    //  and this child - are the same references
                    controlName = name;
                }
            });
        }
        // we either found a name or simply return null
        return controlName;
    }
    logFormControlState(form, indent = '\t') {
        if (form) {
            console.log(`${indent}Pristine: ${form.pristine}`);
            console.log(`${indent}Dirty: ${form.dirty}`);
            console.log(`${indent}Touched: ${form.touched}`);
            console.log(`${indent}Untouched: ${form.untouched}`);
            console.log(`${indent}Valid: ${form.valid}`);
            console.log(`${indent}invalid: ${form.invalid}`);
            // ... other properties you might want to log
            if (form instanceof FormGroup) {
                Object.keys(form.controls).forEach((controlName) => {
                    const control = form.get(controlName);
                    if (control) {
                        console.log(`\t\t Control: ${controlName}`);
                        this.logFormControlState(control, '\t\t');
                    }
                });
            }
        }
    }
    checkInputValidity(event, control, errorMsgKey) {
        if (event.target.validity.badInput) {
            if (errorMsgKey == 'invalidDate') {
                control.setErrors({ 'error.msg.invalidDate': true });
            }
            // ...
        }
        else {
            // clear up previous errors
            control.setErrors(null);
            // Recalculates the value and validation status of the control, eg trigger "Validators.required" validation
            control.updateValueAndValidity();
        }
        // logFormControlState(control);
    }
    checkComponentChanges(changes) {
        let changesArray = [];
        for (const prop in changes) {
            if (changes.hasOwnProperty(prop)) {
                const change = changes[prop];
                const isFormGroup = change.currentValue instanceof FormGroup;
                const currentValue = isFormGroup ? change.currentValue.value : JSON.stringify(change.currentValue);
                const isFirstChange = change.isFirstChange();
                changesArray.push({ propertyName: prop, isFirstChange, currentValue });
            }
        }
        return changesArray;
    }
    checkFormInvalidFields(FormGroup) {
        let invalidFields = [];
        Object.keys(FormGroup.controls).forEach(key => {
            const control = FormGroup.get(key);
            if (control.invalid) {
                invalidFields.push(`Field '${key}' is invalid`);
            }
        });
    }
    findAndTranslateCode(codeArray, lang, codeId) {
        const bilingualCode = this.findCodeById(codeArray, codeId);
        if (bilingualCode) {
            return this.translateCode(bilingualCode, lang);
        }
        return null; // Return null if the word is not found
    }
    translateCode(code, lang) {
        // console.log("translateCode", "code", code, "lang", lang)
        return this.isFrench(lang) ? code.fr : code.en;
    }
    createIIdTextLabelObj(id, label_en, label_fr, text) {
        return {
            _id: id,
            __text: text,
            _label_en: label_en,
            _label_fr: label_fr
        };
    }
    //sort a list of ICode objects either by en or fr value based on the language
    sortCodeList(codeArray, lang) {
        return codeArray.sort((a, b) => this.isFrench(lang) ? a.fr.localeCompare(b.fr) : a.en.localeCompare(b.en));
    }
    // to get enum value from string
    getEnumValueFromString(enumType, value) {
        for (const key in enumType) {
            if (enumType[key] === value) {
                return enumType[key];
            }
        }
        return undefined;
    }
    formatAsSixDigitNumber(value) {
        const leadingZeros = '000000';
        return leadingZeros.substring(0, 6 - value.length) + value;
    }
    removeFirstAndLastChars(value) {
        if (value.length <= 2) {
            return '';
        }
        return value.substring(1, value.length - 1);
    }
    // get CompareFields to compare a list of Code objects
    // sort on sortPriority field first if required, and then en or fr field based on the form's language
    getCompareFields(sortOnPriority, lang) {
        let compareFields = [];
        if (sortOnPriority) {
            compareFields.push(SortOn.PRIORITY);
        }
        this.isFrench(lang) ? compareFields.push(SortOn.FRENCH) : compareFields.push(SortOn.ENGLISH);
        return compareFields;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: UtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: UtilsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: UtilsService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbHMuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3V0aWxzL3V0aWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBaUIsTUFBTSxlQUFlLENBQUM7QUFDMUQsT0FBTyxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQWUsU0FBUyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDcEYsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDMUQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzNDLE9BQU8sRUFBMkMsTUFBTSxFQUFFLE1BQU0scUJBQXFCLENBQUM7O0FBSXRGLE1BQU0sT0FBTyxZQUFZO0lBRHpCO1FBOExFLDJEQUEyRDtRQUMzRCxjQUFTLEdBQUcsQ0FBQyxLQUFnQyxFQUFXLEVBQUUsQ0FDeEQsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztLQW1Makc7SUFoWEMsYUFBYSxDQUFDLFlBQVk7UUFDeEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRLENBQUMsWUFBWTtRQUNuQixPQUFPLFlBQVksS0FBSyxNQUFNLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxLQUFLLENBQUMsWUFBWTtRQUNoQixPQUFPLFlBQVksS0FBSyxHQUFHLENBQUM7SUFDOUIsQ0FBQztJQUVELE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBWTtRQUMxQixPQUFPLElBQUksS0FBSyxNQUFNLENBQUM7SUFDekIsQ0FBQztJQUVELFFBQVEsQ0FBQyxJQUFZO1FBQ25CLE9BQU8sSUFBSSxLQUFLLE1BQU0sQ0FBQztJQUN6QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsTUFBYztRQUM3QixNQUFNLEtBQUssR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQ3pCLE1BQU0sSUFBSSxHQUFHLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOzs7OztNQUtFO0lBQ0YsYUFBYSxDQUFDLE9BQXNCO1FBQ2xDLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFZLENBQUMsU0FBa0IsRUFBRSxFQUFVO1FBQ3pDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQ7Ozs7TUFJRTtJQUNGLGdCQUFnQixDQUFDLFNBQWtCLEVBQUUsV0FBcUI7UUFDeEQsT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNELHNCQUFzQixDQUFDLG1CQUFzQyxFQUFFLEVBQVU7UUFDdkUsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFBLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDdEYsQ0FBQztJQUVIOzs7O09BSUc7SUFDSCxvQkFBb0IsQ0FBQyxjQUE0QjtRQUMvQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBQ3hFLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxlQUFvQjtRQUN6QyxJQUFJLEdBQUcsR0FBYSxFQUFFLENBQUM7UUFFdkIsSUFBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLEVBQUcsQ0FBQztZQUNyQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksSUFBSSxDQUFDLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUM7Z0JBQ2xGLEtBQUssTUFBTSxJQUFJLElBQUksZUFBZSxFQUFFLENBQUM7b0JBQ25DLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQzVDLENBQUM7WUFDSCxDQUFDO2lCQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLEVBQUMsQ0FBQztnQkFDbEYsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztZQUN2RCxDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sR0FBRyxDQUFDO0lBQ2IsQ0FBQztJQUVELDZCQUE2QixDQUFDLGNBQTRCLEVBQUUsSUFBWTtRQUN0RSxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztJQUNqSSxDQUFDO0lBRUQscUJBQXFCLENBQUMsR0FBVTtRQUM5QixPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVELGNBQWMsQ0FBQyxHQUFRO1FBQ3JCLE9BQU8sR0FBRyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUM3QixPQUFPLEdBQUcsQ0FBQyxHQUFHLEtBQUssUUFBUTtZQUMzQixDQUFDLE9BQU8sR0FBRyxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxHQUFHLENBQUMsTUFBTSxLQUFLLFFBQVEsQ0FBQztZQUNyRSxPQUFPLEdBQUcsQ0FBQyxTQUFTLEtBQUssUUFBUTtZQUNqQyxPQUFPLEdBQUcsQ0FBQyxTQUFTLEtBQUssUUFBUSxDQUNsQyxDQUFDO0lBQ0osQ0FBQztJQUVELHNFQUFzRTtJQUN0RSx5QkFBeUIsQ0FBQyxHQUFzQixFQUFFLEdBQVc7UUFDM0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ1QsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO1FBQ0QsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FDOUIsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssR0FBRyxDQUMxQixDQUFDO1FBQ0Ysa0JBQWtCO1FBQ2xCLG9EQUFvRDtRQUNwRCxxQkFBcUI7UUFDckIsS0FBSztRQUVMLDBEQUEwRDtRQUMxRCxJQUFJLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDN0IsT0FBTyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdEMsQ0FBQztRQUVELDJDQUEyQztRQUMzQyxPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRCxtREFBbUQ7SUFDbkQsTUFBTSxDQUFDLEdBQUcsS0FBZTtRQUN2Qix3Q0FBd0M7UUFDeEMsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFFRCw4QkFBOEI7SUFDOUIsbUJBQW1CLENBQUMsR0FBRyxRQUFxQztRQUMxRCxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ25CLElBQUksQ0FBQyxZQUFZLFNBQVMsRUFBRSxDQUFDO2dCQUMzQiwrQkFBK0I7Z0JBQy9CLGtFQUFrRTtnQkFDbEUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNWLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN0QixDQUFDO2lCQUFNLElBQUksQ0FBQyxZQUFZLGVBQWUsSUFBSSxVQUFVLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzNELGlDQUFpQztnQkFDakMseUNBQXlDO2dCQUN6QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNqQixDQUFDLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDdEIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHVCQUF1QixDQUFDLGNBQStCLEVBQUUsSUFBVztRQUNsRSxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ25CLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUN4QixPQUFPLGNBQWMsQ0FBQyxLQUFLLENBQUM7WUFDOUIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE9BQU8sY0FBYyxDQUFDLEtBQUssQ0FBQztZQUM5QixDQUFDO1FBQ0gsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7SUFDSCxDQUFDO0lBRUQscUZBQXFGO0lBQ3RGLDJCQUEyQixDQUFDLEVBQVUsRUFBRSxJQUF1QixFQUFFLElBQVk7UUFDMUUsdURBQXVEO1FBQ3ZELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBRXpELHlDQUF5QztRQUN6QyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDcEIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFNRCxPQUFPLENBQUMsS0FBVTtRQUNoQixPQUFPLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLEtBQUssRUFBRSxDQUFDO0lBQy9ELENBQUM7SUFFRCxhQUFhLENBQUksTUFBVztRQUMxQixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRUQsa0RBQWtEO0lBQ2xELHVCQUF1QixDQUFDLE1BQWEsRUFBRSxNQUFhO1FBQ2xELEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxFQUFFLENBQUM7WUFDM0IsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQztZQUM1QyxJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUNWLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxxREFBcUQ7SUFDckQsbUJBQW1CLENBQUMsTUFBaUIsRUFBRSxXQUFzQjtRQUMzRCxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxXQUFXLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3RDLFdBQVcsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDakYsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGNBQWMsQ0FBRSxPQUF3QjtRQUN0QyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFDdkIsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRWhDLDBEQUEwRDtRQUMxRCw0REFBNEQ7UUFDNUQsSUFBSSxNQUFNLFlBQVksU0FBUyxFQUMvQixDQUFDO1lBQ0csMERBQTBEO1lBQzFELE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO2dCQUUxQyxzQ0FBc0M7Z0JBQ3RDLHlFQUF5RTtnQkFDekUsSUFBSSxPQUFPLEtBQUssTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFDckMsQ0FBQztvQkFDRyw2Q0FBNkM7b0JBQzdDLDRDQUE0QztvQkFDNUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDdkIsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztRQUNELCtDQUErQztRQUMvQyxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQsbUJBQW1CLENBQUMsSUFBcUIsRUFBRSxTQUFpQixJQUFJO1FBQzlELElBQUksSUFBSSxFQUFFLENBQUM7WUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxhQUFhLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBQ25ELE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLFVBQVUsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDN0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sWUFBWSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxjQUFjLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1lBQ3JELE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLFVBQVUsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDN0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sWUFBWSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUNqRCw2Q0FBNkM7WUFFN0MsSUFBSSxJQUFJLFlBQVksU0FBUyxFQUFFLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFO29CQUNqRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN0QyxJQUFJLE9BQU8sRUFBRSxDQUFDO3dCQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFdBQVcsRUFBRSxDQUFDLENBQUM7d0JBQzVDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzNDLENBQUM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxrQkFBa0IsQ0FBQyxLQUFVLEVBQUUsT0FBd0IsRUFBRSxXQUFtQjtRQUMxRSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ25DLElBQUksV0FBVyxJQUFFLGFBQWEsRUFBRSxDQUFDO2dCQUMvQixPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUUsdUJBQXVCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN2RCxDQUFDO1lBQ0QsTUFBTTtRQUNSLENBQUM7YUFBTSxDQUFDO1lBQ04sMkJBQTJCO1lBQzNCLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDdkIsMkdBQTJHO1lBQzVHLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25DLENBQUM7UUFDRCxnQ0FBZ0M7SUFDbEMsQ0FBQztJQUVELHFCQUFxQixDQUFDLE9BQXNCO1FBQzFDLElBQUksWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUV0QixLQUFLLE1BQU0sSUFBSSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQzNCLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNqQyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzdCLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxZQUFZLFlBQVksU0FBUyxDQUFDO2dCQUM3RCxNQUFNLFlBQVksR0FBRyxXQUFXLENBQUEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDbEcsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUM3QyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQztZQUN6RSxDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxTQUFvQjtRQUN6QyxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUM7UUFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzVDLE1BQU0sT0FBTyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkMsSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3BCLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLGNBQWMsQ0FBQyxDQUFDO1lBQ2xELENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxvQkFBb0IsQ0FBQyxTQUFpQixFQUFFLElBQVcsRUFBRSxNQUFhO1FBQ2hFLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzNELElBQUksYUFBYSxFQUFFLENBQUM7WUFDbEIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRCxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsQ0FBQyx1Q0FBdUM7SUFDdEQsQ0FBQztJQUVELGFBQWEsQ0FBQyxJQUFVLEVBQUUsSUFBVztRQUNuQywyREFBMkQ7UUFDM0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0lBQ2pELENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxFQUFVLEVBQUUsUUFBZ0IsRUFBRSxRQUFnQixFQUFFLElBQWE7UUFDakYsT0FBTztZQUNMLEdBQUcsRUFBRSxFQUFFO1lBQ1AsTUFBTSxFQUFFLElBQUk7WUFDWixTQUFTLEVBQUUsUUFBUTtZQUNuQixTQUFTLEVBQUUsUUFBUTtTQUNwQixDQUFBO0lBQ0gsQ0FBQztJQUVELDZFQUE2RTtJQUM3RSxZQUFZLENBQUMsU0FBaUIsRUFBRSxJQUFXO1FBQ3pDLE9BQU8sU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDN0csQ0FBQztJQUVELGdDQUFnQztJQUNoQyxzQkFBc0IsQ0FBSSxRQUFXLEVBQUUsS0FBYTtRQUNsRCxLQUFLLE1BQU0sR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQzNCLElBQUksUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxDQUFDO2dCQUM1QixPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQWUsQ0FBQztZQUNyQyxDQUFDO1FBQ0gsQ0FBQztRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ25CLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxLQUFhO1FBQ2xDLE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQztRQUM5QixPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDO0lBQzdELENBQUM7SUFFRCx1QkFBdUIsQ0FBQyxLQUFhO1FBQ25DLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUN0QixPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFDRCxPQUFPLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELHNEQUFzRDtJQUN0RCxxR0FBcUc7SUFDckcsZ0JBQWdCLENBQUMsY0FBdUIsRUFBRSxJQUFZO1FBQ3BELElBQUksYUFBYSxHQUFjLEVBQUUsQ0FBQztRQUNsQyxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ25CLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RDLENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQSxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFNUYsT0FBTyxhQUFhLENBQUM7SUFDdkIsQ0FBQzs4R0FqWFUsWUFBWTtrSEFBWixZQUFZOzsyRkFBWixZQUFZO2tCQUR4QixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBYnN0cmFjdENvbnRyb2wsIEZvcm1BcnJheSwgRm9ybUNvbnRyb2wsIEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgQ0FOQURBLCBVU0EsIEZSRU5DSCB9IGZyb20gJy4uL2NvbW1vbi5jb25zdGFudHMnO1xyXG5pbXBvcnQgeyBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IElDb2RlLCBJQ29kZURlZmluaXRpb24sIElQYXJlbnRDaGlsZHJlbiwgU29ydE9uIH0gZnJvbSAnLi4vZGF0YS1sb2FkZXIvZGF0YSc7XHJcbmltcG9ydCB7IElJZFRleHRMYWJlbCB9IGZyb20gJy4uL21vZGVsL2VudGl0eS1iYXNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFV0aWxzU2VydmljZSB7XHJcblxyXG4gIGlzQ2FuYWRhT3JVU0EoY291bnRyeVZhbHVlKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gdGhpcy5pc0NhbmFkYShjb3VudHJ5VmFsdWUpIHx8IHRoaXMuaXNVc2EoY291bnRyeVZhbHVlKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoZWNrcyBvZiB0aGUgdmFsdWUgaXMgY2FuYWRhIG9yIG5vdC4gQ2hlY2tzIGZvciBKc29uIG9iamVjdCB2cyBzaW5nbGUgdmFsdWVcclxuICAgKiBAcGFyYW0gdmFsdWUgdGhlIHZhbHVlIHRvIGNoZWNrIGNhbiBiZSB0aGUganNvbiBvYmplY3Qgd2l0aCBhbiBpZCBpbmRleC5cclxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICAgKi9cclxuICBpc0NhbmFkYShjb3VudHJ5VmFsdWUpOiBib29sZWFuIHtcclxuICAgIHJldHVybiBjb3VudHJ5VmFsdWUgPT09IENBTkFEQTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoZWNrcyBpZiB0aGUgdmFsdWUgdXNhIG9yIG5vdC4gQ2hlY2tzIGZvciBKc29uIG9iamVjdCB2cyBzaW5nbGUgdmFsdWVcclxuICAgKiBAcGFyYW0gdmFsdWUgLSB0aGUgdmFsdWUgdG8gY2hlY2sgY2FuIGJlIHRoZSBqc29uIG9iamVjdCB3aXRoIGFuIGlkIGluZGV4LlxyXG4gICAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gICAqL1xyXG4gIGlzVXNhKGNvdW50cnlWYWx1ZSk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIGNvdW50cnlWYWx1ZSA9PT0gVVNBO1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIGlzRnJlbmNoKGxhbmc6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIGxhbmcgPT09IEZSRU5DSDtcclxuICB9XHJcblxyXG4gIGlzRnJlbmNoKGxhbmc6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIGxhbmcgPT09IEZSRU5DSDtcclxuICB9XHJcblxyXG4gIGdldEZvcm1hdHRlZERhdGUoZm9ybWF0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgcGlwZSA9IG5ldyBEYXRlUGlwZSgnZW4tVVMnKTtcclxuICAgIHJldHVybiBwaXBlLnRyYW5zZm9ybSh0b2RheSwgZm9ybWF0KTtcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgY2hlY2sgaWYgdGhlIGNvbXBvbmVudCBpcyBmaXJzdCB0aW1lIGxvYWRlZFxyXG4gIE9iamVjdC52YWx1ZXMgdG8gcmV0cmlldmUgYWxsIGNoYW5nZXMgYXMgYW4gYXJyYXlcclxuICBBcnJheS5zb21lIHRvIGNoZWNrIHdoZXRoZXIgYW55IG9mIHRoZSBjaGFuZ2VzIGhhcyBpc0ZpcnN0Q2hhbmdlIHNldFxyXG4gIEJld2FyZTogSWYgbm8gQElucHV0IGlzIHNldCBhdCBhbGwsIGlzRmlyc3RDaGFuZ2Ugd2lsbCBiZSBmYWxzZSBiZWNhdXNlIEFycmF5LnNvbWUgc3RvcHMgYXQgdGhlIGZpcnN0IHRydWUgdmFsdWUuXHJcbiAgKi9cclxuICBpc0ZpcnN0Q2hhbmdlKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiBib29sZWFue1xyXG4gICAgcmV0dXJuIE9iamVjdC52YWx1ZXMoY2hhbmdlcykuc29tZShjID0+IGMuaXNGaXJzdENoYW5nZSgpKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGZpbmQgYSBjb2RlIGJ5IGl0cyBpZCBpbiBhIGNvZGUgYXJyYXlcclxuICAgKiBAcGFyYW0gY29kZUFycmF5IFxyXG4gICAqIEBwYXJhbSBpZCBcclxuICAgKiBAcmV0dXJucyBlaXRoZXIgYSBjb2RlIG9yIHVuZGVmaW5lZFxyXG4gICAqL1xyXG4gIGZpbmRDb2RlQnlJZChjb2RlQXJyYXk6IElDb2RlW10sIGlkOiBzdHJpbmcpOiBJQ29kZSB8IHVuZGVmaW5lZCB7XHJcbiAgICByZXR1cm4gdGhpcy5pc0VtcHR5KGlkKT8gdW5kZWZpbmVkIDogY29kZUFycmF5LmZpbmQob2JqID0+IG9iai5pZCA9PT0gaWQpO1xyXG4gIH1cclxuXHJcbiAgLypcclxuICAqIHRha2VzIGFuIGFycmF5IG9mIGlkcywgXHJcbiAgKiB1c2VzIHRoZSBmaWx0ZXIgbWV0aG9kIHRvIGl0ZXJhdGUgdGhyb3VnaCB0aGUgY29kZUFycmF5IGFuZCBpbmNsdWRlcyBvbmx5IHRob3NlIG9iamVjdHMgd2hvc2UgaWQgaXMgcHJlc2VudCBpbiB0aGUgaWRzVG9GaWx0ZXIgYXJyYXlcclxuICAqIHRoZSBmaWx0ZXJlZCBhcnJheSBpcyB0aGVuIHJldHVybmVkXHJcbiAgKi9cclxuICBmaWx0ZXJDb2Rlc0J5SWRzKGNvZGVBcnJheTogSUNvZGVbXSwgaWRzVG9GaWx0ZXI6IHN0cmluZ1tdKTogSUNvZGVbXSB7XHJcbiAgICByZXR1cm4gY29kZUFycmF5LmZpbHRlcigoY29kZSkgPT4gaWRzVG9GaWx0ZXIuaW5jbHVkZXMoY29kZS5pZCkpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZmluZCBhIGNvZGVEZWZpbml0aW9uIGJ5IGl0cyBpZCBpbiBhIGNvZGVEZWZpbml0aW9uIGFycmF5XHJcbiAgICogQHBhcmFtIGNvZGVEZWZpbml0aW9uQXJyYXkgXHJcbiAgICogQHBhcmFtIGlkIFxyXG4gICAqIEByZXR1cm5zIGVpdGhlciBhIGNvZGUgb3IgdW5kZWZpbmVkXHJcbiAgICovXHJcbiAgICBmaW5kQ29kZURlZmluaXRpb25CeUlkKGNvZGVEZWZpbml0aW9uQXJyYXk6IElDb2RlRGVmaW5pdGlvbltdLCBpZDogc3RyaW5nKTogSUNvZGVEZWZpbml0aW9uIHwgdW5kZWZpbmVkIHtcclxuICAgICAgcmV0dXJuIHRoaXMuaXNFbXB0eShpZCk/IHVuZGVmaW5lZCA6IGNvZGVEZWZpbml0aW9uQXJyYXkuZmluZChvYmogPT4gb2JqLmlkID09PSBpZCk7XHJcbiAgICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldCB0aGUgaWQgdmFsdWUgZnJvbSBhbiBJZFRleHRMYWJlbCBvYmplY3RcclxuICAgKiBAcGFyYW0gaWRUZXh0TGFiZWxPYmogXHJcbiAgICogQHJldHVybnMgZWl0aGVyIGlkIG9yIHVuZGVmaW5lZFxyXG4gICAqL1xyXG4gIGdldElkRnJvbUlkVGV4dExhYmVsKGlkVGV4dExhYmVsT2JqOiBJSWRUZXh0TGFiZWwpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuICF0aGlzLmlzRW1wdHkoaWRUZXh0TGFiZWxPYmopID8gaWRUZXh0TGFiZWxPYmouX2lkIDogdW5kZWZpbmVkOyBcclxuICB9XHJcblxyXG4gIGdldElkc0Zyb21JZFRleHRMYWJlbHMoaWRUZXh0TGFiZWxPYmpzOiBhbnkpOiBzdHJpbmdbXSB7XHJcbiAgICBsZXQgaWRzOiBzdHJpbmdbXSA9IFtdO1xyXG5cclxuICAgIGlmICggIXRoaXMuaXNFbXB0eShpZFRleHRMYWJlbE9ianMpICkge1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShpZFRleHRMYWJlbE9ianMpICYmIHRoaXMuaXNBcnJheU9mSUlkVGV4dExhYmVsKGlkVGV4dExhYmVsT2JqcykpIHtcclxuICAgICAgICBmb3IgKGNvbnN0IHRlbXAgb2YgaWRUZXh0TGFiZWxPYmpzKSB7XHJcbiAgICAgICAgICBpZHMucHVzaCh0aGlzLmdldElkRnJvbUlkVGV4dExhYmVsKHRlbXApKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSBpZiAoIUFycmF5LmlzQXJyYXkoaWRUZXh0TGFiZWxPYmpzKSAmJiB0aGlzLmlzSUlkVGV4dExhYmVsKGlkVGV4dExhYmVsT2Jqcykpe1xyXG4gICAgICAgIGlkcy5wdXNoKHRoaXMuZ2V0SWRGcm9tSWRUZXh0TGFiZWwoaWRUZXh0TGFiZWxPYmpzKSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gaWRzO1xyXG4gIH1cclxuXHJcbiAgZ2V0TGFiZWxGcm9tSWRUZXh0TGFiZWxCeUxhbmcoaWRUZXh0TGFiZWxPYmo6IElJZFRleHRMYWJlbCwgbGFuZzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIHJldHVybiAhdGhpcy5pc0VtcHR5KGlkVGV4dExhYmVsT2JqKSA/ICh0aGlzLmlzRnJlbmNoKGxhbmcpID8gaWRUZXh0TGFiZWxPYmouX2xhYmVsX2ZyIDogaWRUZXh0TGFiZWxPYmouX2xhYmVsX2VuKSA6IHVuZGVmaW5lZDsgXHJcbiAgfVxyXG5cclxuICBpc0FycmF5T2ZJSWRUZXh0TGFiZWwoYXJyOiBhbnlbXSk6IGFyciBpcyBJSWRUZXh0TGFiZWxbXSB7XHJcbiAgICByZXR1cm4gYXJyLmV2ZXJ5KGl0ZW0gPT4gdGhpcy5pc0lJZFRleHRMYWJlbChpdGVtKSk7XHJcbiAgfVxyXG5cclxuICBpc0lJZFRleHRMYWJlbChvYmo6IGFueSk6IG9iaiBpcyBJSWRUZXh0TGFiZWwge1xyXG4gICAgcmV0dXJuIG9iaiA9PT0gbnVsbCA/ICBmYWxzZSA6IChcclxuICAgICAgdHlwZW9mIG9iai5faWQgPT09ICdzdHJpbmcnICYmXHJcbiAgICAgICh0eXBlb2Ygb2JqLl9fdGV4dCA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIG9iai5fX3RleHQgPT09ICdzdHJpbmcnKSAmJlxyXG4gICAgICB0eXBlb2Ygb2JqLl9sYWJlbF9lbiA9PT0gJ3N0cmluZycgJiZcclxuICAgICAgdHlwZW9mIG9iai5fbGFiZWxfZnIgPT09ICdzdHJpbmcnXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gZmlsdGVyIGFuIElQYXJlbnRDaGlsZHJlbiBhcnJheSBieSBwYXJlbnRJZCBhbmQgcmV0dXJuIGl0cyBjaGlsZHJlblxyXG4gIGZpbHRlclBhcmVudENoaWxkcmVuQXJyYXkoYXJyOiBJUGFyZW50Q2hpbGRyZW5bXSwgcElkOiBzdHJpbmcpIDogSUNvZGVEZWZpbml0aW9uW117XHJcbiAgICBpZiAoIXBJZCkge1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcbiAgICBjb25zdCBmaWx0ZXJlZEFycmF5ID0gYXJyLmZpbHRlcihcclxuICAgICAgKHgpID0+IHgucGFyZW50SWQgPT09IHBJZFxyXG4gICAgKTtcclxuICAgIC8vICAgIGNvbnNvbGUubG9nKFxyXG4gICAgLy8gICAgICAnZmlsdGVyUGFyZW50Q2hpbGRyZW5BcnJheSB+IGZpbHRlcmVkQXJyYXknLFxyXG4gICAgLy8gICAgICBmaWx0ZXJlZEFycmF5XHJcbiAgICAvLyApO1xyXG5cclxuICAgIC8vIENoZWNrIGlmIGZpbHRlcmVkQXJyYXkgaXMgbm90IGVtcHR5IGFuZCByZXR1cm4gY2hpbGRyZW5cclxuICAgIGlmIChmaWx0ZXJlZEFycmF5Lmxlbmd0aCA+IDApIHtcclxuICAgICAgcmV0dXJuIGZpbHRlcmVkQXJyYXlbMF1bJ2NoaWxkcmVuJ107XHJcbiAgICB9XHJcblxyXG4gICAgLy8gSWYgbm8gbWF0Y2ggZm91bmQsIHJldHVybiBhbiBlbXB0eSBhcnJheVxyXG4gICAgcmV0dXJuIFtdO1xyXG4gIH0gICAgXHJcblxyXG4gIC8vIHJldHVybiBhIGNvbmNhdGF0ZWQgc3RyaW5nLCBkZWxpbWl0ZWQgYnkgYSBzcGFjZVxyXG4gIGNvbmNhdCguLi5wYXJhbTogc3RyaW5nW10pOiBzdHJpbmd7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhwYXJhbS5qb2luKCcgJykpIC8vIFsxLDJdXHJcbiAgICByZXR1cm4gcGFyYW0uam9pbignICcpO1xyXG4gIH1cclxuXHJcbiAgLy8gcmVzZXQgZm9ybSBjb250cm9scycgdmFsdWVzXHJcbiAgcmVzZXRDb250cm9sc1ZhbHVlcyguLi5jb250cm9sczogQWJzdHJhY3RDb250cm9sPGFueSwgYW55PltdKTogdm9pZCB7XHJcbiAgICBjb250cm9scy5mb3JFYWNoKGMgPT4ge1xyXG4gICAgICBpZiAoYyBpbnN0YW5jZW9mIEZvcm1BcnJheSkge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLi4uLkZvcm1BcnJheVwiKVxyXG4gICAgICAgIC8vIElmIGl0J3MgYSBGb3JtQXJyYXksIGNsZWFyIGFsbCBleGlzdGluZyBmb3JtIGNvbnRyb2xzIHdpdGhpbiBpdFxyXG4gICAgICAgIGMuY2xlYXIoKTtcclxuICAgICAgICBjLm1hcmtBc1VudG91Y2hlZCgpO1xyXG4gICAgICB9IGVsc2UgaWYgKGMgaW5zdGFuY2VvZiBBYnN0cmFjdENvbnRyb2wgJiYgJ3NldFZhbHVlJyBpbiBjKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCIuLi4uRm9ybUNvbnRyb2xcIilcclxuICAgICAgICAvLyBJZiBpdCdzIGEgRm9ybUNvbnRyb2wsIHJlc2V0IGl0cyB2YWx1ZVxyXG4gICAgICAgIGMuc2V0VmFsdWUobnVsbCk7XHJcbiAgICAgICAgYy5tYXJrQXNVbnRvdWNoZWQoKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBnZXRDb2RlRGVmaW5pdGlvbkJ5TGFuZyhjb2RlRGVmaW5pdGlvbjogSUNvZGVEZWZpbml0aW9uLCBsYW5nOnN0cmluZyk6IHN0cmluZ3tcclxuICAgIGlmIChjb2RlRGVmaW5pdGlvbikge1xyXG4gICAgICBpZiAodGhpcy5pc0ZyZW5jaChsYW5nKSkge1xyXG4gICAgICAgIHJldHVybiBjb2RlRGVmaW5pdGlvbi5kZWZGcjtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gY29kZURlZmluaXRpb24uZGVmRW47XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH0gIFxyXG5cclxuICAvLyBGdW5jdGlvbiB0byBmaW5kIGEgbWF0Y2ggYnkgaWQgYW5kIHJldHVybiB0aGUgYXBwcm9wcmlhdGUgZGVmaW5pdGlvbiBiYXNlZCBvbiBsYW5nXHJcbiBnZXRDb2RlRGVmaW5pdGlvbkJ5SWRCeUxhbmcoaWQ6IHN0cmluZywgbGlzdDogSUNvZGVEZWZpbml0aW9uW10sIGxhbmc6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAvLyBGaW5kIHRoZSBJQ29kZURlZmluaXRpb24gb2JqZWN0IHdpdGggdGhlIG1hdGNoaW5nIGlkXHJcbiAgICBjb25zdCBjb2RlRGVmaW5pdGlvbiA9IGxpc3QuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IGlkKTtcclxuXHJcbiAgICAvLyBJZiBubyBtYXRjaCBpcyBmb3VuZCwgcmV0dXJuIHVuZGVmaW5lZFxyXG4gICAgaWYgKCFjb2RlRGVmaW5pdGlvbikge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb2RlRGVmaW5pdGlvbkJ5TGFuZyhjb2RlRGVmaW5pdGlvbiwgbGFuZyk7XHJcbiAgfSAgICBcclxuXHJcbiAgLy8gcmV0dXJuIHRydWUgaWYgdGhlIHZhbHVlIGlzIGluIHRoZSBhcnJheSBvZiB2YWxpZCB2YWx1ZXNcclxuICB0b0Jvb2xlYW4gPSAodmFsdWU6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4pOiBib29sZWFuID0+IFxyXG4gICAgW3RydWUsICdUUlVFJywgJ1QnLCAnMScsIDFdLmluY2x1ZGVzKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyB2YWx1ZS50b1VwcGVyQ2FzZSgpIDogdmFsdWUpO1xyXG5cclxuICBpc0VtcHR5KHZhbHVlOiBhbnkpOiBib29sZWFuIHtcclxuICAgIHJldHVybiB2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBcIlwiO1xyXG4gIH1cclxuXHJcbiAgZmxhdHRlbkFycmF5czxUPihhcnJheXM6IFRbXSk6IFRbXSB7XHJcbiAgICByZXR1cm4gW10uY29uY2F0KC4uLmFycmF5cyk7XHJcbiAgfVxyXG5cclxuICAvLyByZXR1cm5zIHRydWUgaWYgYW55IGl0ZW0gaW4gYXJyYXkxIGlzIGluIGFycmF5MlxyXG4gIGlzQXJyYXkxRWxlbWVudEluQXJyYXkyKGFycmF5MTogYW55W10sIGFycmF5MjogYW55W10pOiBib29sZWFue1xyXG4gICAgZm9yIChjb25zdCBpdGVtMSBvZiBhcnJheTEpIHtcclxuICAgICAgY29uc3QgZm91bmQgPSBhcnJheTIuZmluZCh4ID0+IHggPT09IGl0ZW0xKTtcclxuICAgICAgaWYgKGZvdW5kKSB7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgIH0gXHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG5cclxuICAvLyBGdW5jdGlvbiB0byBjb3B5IHZhbHVlcyBmcm9tIHNvdXJjZSB0byBkZXN0aW5hdGlvblxyXG4gIGNvcHlGb3JtR3JvdXBWYWx1ZXMoc291cmNlOiBGb3JtR3JvdXAsIGRlc3RpbmF0aW9uOiBGb3JtR3JvdXApOiB2b2lkIHtcclxuICAgIE9iamVjdC5rZXlzKHNvdXJjZS5jb250cm9scykuZm9yRWFjaChjb250cm9sTmFtZSA9PiB7XHJcbiAgICAgIGlmIChkZXN0aW5hdGlvbi5jb250cm9sc1tjb250cm9sTmFtZV0pIHtcclxuICAgICAgICBkZXN0aW5hdGlvbi5jb250cm9sc1tjb250cm9sTmFtZV0uc2V0VmFsdWUoc291cmNlLmNvbnRyb2xzW2NvbnRyb2xOYW1lXS52YWx1ZSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBcclxuICBnZXRDb250cm9sTmFtZSAoY29udHJvbDogQWJzdHJhY3RDb250cm9sKSB7XHJcbiAgICB2YXIgY29udHJvbE5hbWUgPSBudWxsO1xyXG4gICAgdmFyIHBhcmVudCA9IGNvbnRyb2xbXCJfcGFyZW50XCJdO1xyXG5cclxuICAgIC8vIG9ubHkgc3VjaCBwYXJlbnQsIHdoaWNoIGlzIEZvcm1Hcm91cCwgaGFzIGEgZGljdGlvbmFyeSBcclxuICAgIC8vIHdpdGggY29udHJvbC1uYW1lcyBhcyBhIGtleSBhbmQgYSBmb3JtLWNvbnRyb2wgYXMgYSB2YWx1ZVxyXG4gICAgaWYgKHBhcmVudCBpbnN0YW5jZW9mIEZvcm1Hcm91cClcclxuICAgIHtcclxuICAgICAgICAvLyBub3cgd2Ugd2lsbCBpdGVyYXRlIHRob3NlIGtleXMgKGkuZS4gbmFtZXMgb2YgY29udHJvbHMpXHJcbiAgICAgICAgT2JqZWN0LmtleXMocGFyZW50LmNvbnRyb2xzKS5mb3JFYWNoKChuYW1lKSA9PlxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgLy8gYW5kIGNvbXBhcmUgdGhlIHBhc3NlZCBjb250cm9sIGFuZCBcclxuICAgICAgICAgICAgLy8gYSBjaGlsZCBjb250cm9sIG9mIGEgcGFyZW50IC0gd2l0aCBwcm92aWRlZCBuYW1lICh3ZSBpdGVyYXRlIHRoZW0gYWxsKVxyXG4gICAgICAgICAgICBpZiAoY29udHJvbCA9PT0gcGFyZW50LmNvbnRyb2xzW25hbWVdKVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAvLyBib3RoIGFyZSBzYW1lOiBjb250cm9sIHBhc3NlZCB0byBWYWxpZGF0b3JcclxuICAgICAgICAgICAgICAgIC8vICBhbmQgdGhpcyBjaGlsZCAtIGFyZSB0aGUgc2FtZSByZWZlcmVuY2VzXHJcbiAgICAgICAgICAgICAgICBjb250cm9sTmFtZSA9IG5hbWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8vIHdlIGVpdGhlciBmb3VuZCBhIG5hbWUgb3Igc2ltcGx5IHJldHVybiBudWxsXHJcbiAgICByZXR1cm4gY29udHJvbE5hbWU7XHJcbiAgfVxyXG5cclxuICBsb2dGb3JtQ29udHJvbFN0YXRlKGZvcm06IEFic3RyYWN0Q29udHJvbCwgaW5kZW50OiBzdHJpbmcgPSAnXFx0Jyk6IHZvaWQge1xyXG4gICAgaWYgKGZvcm0pIHtcclxuICAgICAgY29uc29sZS5sb2coYCR7aW5kZW50fVByaXN0aW5lOiAke2Zvcm0ucHJpc3RpbmV9YCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGAke2luZGVudH1EaXJ0eTogJHtmb3JtLmRpcnR5fWApO1xyXG4gICAgICBjb25zb2xlLmxvZyhgJHtpbmRlbnR9VG91Y2hlZDogJHtmb3JtLnRvdWNoZWR9YCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGAke2luZGVudH1VbnRvdWNoZWQ6ICR7Zm9ybS51bnRvdWNoZWR9YCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGAke2luZGVudH1WYWxpZDogJHtmb3JtLnZhbGlkfWApO1xyXG4gICAgICBjb25zb2xlLmxvZyhgJHtpbmRlbnR9aW52YWxpZDogJHtmb3JtLmludmFsaWR9YCk7XHJcbiAgICAgIC8vIC4uLiBvdGhlciBwcm9wZXJ0aWVzIHlvdSBtaWdodCB3YW50IHRvIGxvZ1xyXG5cclxuICAgICAgaWYgKGZvcm0gaW5zdGFuY2VvZiBGb3JtR3JvdXApIHtcclxuICAgICAgICBPYmplY3Qua2V5cyhmb3JtLmNvbnRyb2xzKS5mb3JFYWNoKChjb250cm9sTmFtZSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY29udHJvbCA9IGZvcm0uZ2V0KGNvbnRyb2xOYW1lKTtcclxuICAgICAgICAgIGlmIChjb250cm9sKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBcXHRcXHQgQ29udHJvbDogJHtjb250cm9sTmFtZX1gKTtcclxuICAgICAgICAgICAgdGhpcy5sb2dGb3JtQ29udHJvbFN0YXRlKGNvbnRyb2wsJ1xcdFxcdCcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjaGVja0lucHV0VmFsaWRpdHkoZXZlbnQ6IGFueSwgY29udHJvbDogQWJzdHJhY3RDb250cm9sLCBlcnJvck1zZ0tleTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICBpZiAoZXZlbnQudGFyZ2V0LnZhbGlkaXR5LmJhZElucHV0KSB7XHJcbiAgICAgIGlmIChlcnJvck1zZ0tleT09J2ludmFsaWREYXRlJykge1xyXG4gICAgICAgIGNvbnRyb2wuc2V0RXJyb3JzKHsgJ2Vycm9yLm1zZy5pbnZhbGlkRGF0ZSc6IHRydWUgfSk7XHJcbiAgICAgIH1cclxuICAgICAgLy8gLi4uXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBjbGVhciB1cCBwcmV2aW91cyBlcnJvcnNcclxuICAgICAgY29udHJvbC5zZXRFcnJvcnMobnVsbCk7XHJcbiAgICAgICAvLyBSZWNhbGN1bGF0ZXMgdGhlIHZhbHVlIGFuZCB2YWxpZGF0aW9uIHN0YXR1cyBvZiB0aGUgY29udHJvbCwgZWcgdHJpZ2dlciBcIlZhbGlkYXRvcnMucmVxdWlyZWRcIiB2YWxpZGF0aW9uXHJcbiAgICAgIGNvbnRyb2wudXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgfVxyXG4gICAgLy8gbG9nRm9ybUNvbnRyb2xTdGF0ZShjb250cm9sKTtcclxuICB9ICBcclxuXHJcbiAgY2hlY2tDb21wb25lbnRDaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiBhbnlbXSB7XHJcbiAgICBsZXQgY2hhbmdlc0FycmF5ID0gW107XHJcblxyXG4gICAgZm9yIChjb25zdCBwcm9wIGluIGNoYW5nZXMpIHtcclxuICAgICAgaWYgKGNoYW5nZXMuaGFzT3duUHJvcGVydHkocHJvcCkpIHtcclxuICAgICAgICBjb25zdCBjaGFuZ2UgPSBjaGFuZ2VzW3Byb3BdO1xyXG4gICAgICAgIGNvbnN0IGlzRm9ybUdyb3VwID0gY2hhbmdlLmN1cnJlbnRWYWx1ZSBpbnN0YW5jZW9mIEZvcm1Hcm91cDtcclxuICAgICAgICBjb25zdCBjdXJyZW50VmFsdWUgPSBpc0Zvcm1Hcm91cD8gY2hhbmdlLmN1cnJlbnRWYWx1ZS52YWx1ZSA6IEpTT04uc3RyaW5naWZ5KGNoYW5nZS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIGNvbnN0IGlzRmlyc3RDaGFuZ2UgPSBjaGFuZ2UuaXNGaXJzdENoYW5nZSgpO1xyXG4gICAgICAgIGNoYW5nZXNBcnJheS5wdXNoKHsgcHJvcGVydHlOYW1lOiBwcm9wLCBpc0ZpcnN0Q2hhbmdlLCBjdXJyZW50VmFsdWUgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY2hhbmdlc0FycmF5O1xyXG4gIH1cclxuXHJcbiAgY2hlY2tGb3JtSW52YWxpZEZpZWxkcyhGb3JtR3JvdXA6IEZvcm1Hcm91cCkge1xyXG4gICAgbGV0IGludmFsaWRGaWVsZHMgPSBbXTtcclxuICAgIE9iamVjdC5rZXlzKEZvcm1Hcm91cC5jb250cm9scykuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICBjb25zdCBjb250cm9sID0gRm9ybUdyb3VwLmdldChrZXkpO1xyXG4gICAgICBpZiAoY29udHJvbC5pbnZhbGlkKSB7XHJcbiAgICAgICAgaW52YWxpZEZpZWxkcy5wdXNoKGBGaWVsZCAnJHtrZXl9JyBpcyBpbnZhbGlkYCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZmluZEFuZFRyYW5zbGF0ZUNvZGUoY29kZUFycmF5OklDb2RlW10sIGxhbmc6c3RyaW5nLCBjb2RlSWQ6c3RyaW5nKSB7XHJcbiAgICBjb25zdCBiaWxpbmd1YWxDb2RlID0gdGhpcy5maW5kQ29kZUJ5SWQoY29kZUFycmF5LCBjb2RlSWQpO1xyXG4gICAgaWYgKGJpbGluZ3VhbENvZGUpIHtcclxuICAgICAgcmV0dXJuIHRoaXMudHJhbnNsYXRlQ29kZShiaWxpbmd1YWxDb2RlLCBsYW5nKTtcclxuICAgIH1cclxuICAgIHJldHVybiBudWxsOyAvLyBSZXR1cm4gbnVsbCBpZiB0aGUgd29yZCBpcyBub3QgZm91bmRcclxuICB9XHJcblxyXG4gIHRyYW5zbGF0ZUNvZGUoY29kZTpJQ29kZSwgbGFuZzpzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgLy8gY29uc29sZS5sb2coXCJ0cmFuc2xhdGVDb2RlXCIsIFwiY29kZVwiLCBjb2RlLCBcImxhbmdcIiwgbGFuZylcclxuICAgIHJldHVybiB0aGlzLmlzRnJlbmNoKGxhbmcpID8gY29kZS5mciA6IGNvZGUuZW47XHJcbiAgfVxyXG5cclxuICBjcmVhdGVJSWRUZXh0TGFiZWxPYmooaWQ6IHN0cmluZywgbGFiZWxfZW46IHN0cmluZywgbGFiZWxfZnI6IHN0cmluZywgdGV4dD86IHN0cmluZykgOiBJSWRUZXh0TGFiZWwge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgX2lkOiBpZCxcclxuICAgICAgX190ZXh0OiB0ZXh0LFxyXG4gICAgICBfbGFiZWxfZW46IGxhYmVsX2VuLFxyXG4gICAgICBfbGFiZWxfZnI6IGxhYmVsX2ZyXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL3NvcnQgYSBsaXN0IG9mIElDb2RlIG9iamVjdHMgZWl0aGVyIGJ5IGVuIG9yIGZyIHZhbHVlIGJhc2VkIG9uIHRoZSBsYW5ndWFnZVxyXG4gIHNvcnRDb2RlTGlzdChjb2RlQXJyYXk6SUNvZGVbXSwgbGFuZzpzdHJpbmcpOiBJQ29kZVtde1xyXG4gICAgcmV0dXJuIGNvZGVBcnJheS5zb3J0KChhLCBiKSA9PiB0aGlzLmlzRnJlbmNoKGxhbmcpID8gYS5mci5sb2NhbGVDb21wYXJlKGIuZnIpIDogYS5lbi5sb2NhbGVDb21wYXJlKGIuZW4pKTtcclxuICB9XHJcblxyXG4gIC8vIHRvIGdldCBlbnVtIHZhbHVlIGZyb20gc3RyaW5nXHJcbiAgZ2V0RW51bVZhbHVlRnJvbVN0cmluZzxUPihlbnVtVHlwZTogVCwgdmFsdWU6IHN0cmluZyk6IFRba2V5b2YgVF0gfCB1bmRlZmluZWQge1xyXG4gICAgZm9yIChjb25zdCBrZXkgaW4gZW51bVR5cGUpIHtcclxuICAgICAgaWYgKGVudW1UeXBlW2tleV0gPT09IHZhbHVlKSB7XHJcbiAgICAgICAgcmV0dXJuIGVudW1UeXBlW2tleV0gYXMgVFtrZXlvZiBUXTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICB9XHJcblxyXG4gIGZvcm1hdEFzU2l4RGlnaXROdW1iZXIodmFsdWU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBsZWFkaW5nWmVyb3MgPSAnMDAwMDAwJztcclxuICAgIHJldHVybiBsZWFkaW5nWmVyb3Muc3Vic3RyaW5nKDAsIDYgLSB2YWx1ZS5sZW5ndGgpICsgdmFsdWU7XHJcbiAgfVxyXG5cclxuICByZW1vdmVGaXJzdEFuZExhc3RDaGFycyh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGlmICh2YWx1ZS5sZW5ndGggPD0gMikge1xyXG4gICAgICByZXR1cm4gJyc7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdmFsdWUuc3Vic3RyaW5nKDEsIHZhbHVlLmxlbmd0aCAtIDEpO1xyXG4gIH1cclxuXHJcbiAgLy8gZ2V0IENvbXBhcmVGaWVsZHMgdG8gY29tcGFyZSBhIGxpc3Qgb2YgQ29kZSBvYmplY3RzXHJcbiAgLy8gc29ydCBvbiBzb3J0UHJpb3JpdHkgZmllbGQgZmlyc3QgaWYgcmVxdWlyZWQsIGFuZCB0aGVuIGVuIG9yIGZyIGZpZWxkIGJhc2VkIG9uIHRoZSBmb3JtJ3MgbGFuZ3VhZ2VcclxuICBnZXRDb21wYXJlRmllbGRzKHNvcnRPblByaW9yaXR5OiBib29sZWFuLCBsYW5nOiBzdHJpbmcpOlNvcnRPbltde1xyXG4gICAgbGV0IGNvbXBhcmVGaWVsZHMgOiBTb3J0T25bXSA9IFtdO1xyXG4gICAgaWYgKHNvcnRPblByaW9yaXR5KSB7XHJcbiAgICAgIGNvbXBhcmVGaWVsZHMucHVzaChTb3J0T24uUFJJT1JJVFkpO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuaXNGcmVuY2gobGFuZykgPyBjb21wYXJlRmllbGRzLnB1c2goU29ydE9uLkZSRU5DSCk6IGNvbXBhcmVGaWVsZHMucHVzaChTb3J0T24uRU5HTElTSCk7XHJcblxyXG4gICAgcmV0dXJuIGNvbXBhcmVGaWVsZHM7XHJcbiAgfVxyXG59XHJcbiJdfQ==