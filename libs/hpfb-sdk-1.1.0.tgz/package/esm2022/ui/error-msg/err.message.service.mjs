import { Injectable } from '@angular/core';
import { ValidationService } from '../validation/validation.service';
import * as i0 from "@angular/core";
export class ErrMessageService {
    constructor() { }
    getValidatorErrorMessageKey(error) {
        // get the error message key in the en/fr.json for this error
        return ValidationService.getValidatorErrorMessage(error);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ErrMessageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ErrMessageService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ErrMessageService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyLm1lc3NhZ2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2Vycm9yLW1zZy9lcnIubWVzc2FnZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sa0NBQWtDLENBQUM7O0FBR3JFLE1BQU0sT0FBTyxpQkFBaUI7SUFFNUIsZ0JBQWMsQ0FBQztJQUVmLDJCQUEyQixDQUFDLEtBQWE7UUFDdkMsNkRBQTZEO1FBQzdELE9BQU8saUJBQWlCLENBQUMsd0JBQXdCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDM0QsQ0FBQzs4R0FQVSxpQkFBaUI7a0hBQWpCLGlCQUFpQjs7MkZBQWpCLGlCQUFpQjtrQkFEN0IsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgVmFsaWRhdGlvblNlcnZpY2UgfSBmcm9tICcuLi92YWxpZGF0aW9uL3ZhbGlkYXRpb24uc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBFcnJNZXNzYWdlU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCl7fVxyXG5cclxuICBnZXRWYWxpZGF0b3JFcnJvck1lc3NhZ2VLZXkoZXJyb3I6IHN0cmluZyl7XHJcbiAgICAvLyBnZXQgdGhlIGVycm9yIG1lc3NhZ2Uga2V5IGluIHRoZSBlbi9mci5qc29uIGZvciB0aGlzIGVycm9yXHJcbiAgICByZXR1cm4gVmFsaWRhdGlvblNlcnZpY2UuZ2V0VmFsaWRhdG9yRXJyb3JNZXNzYWdlKGVycm9yKTtcclxuICB9XHJcblxyXG59XHJcbiJdfQ==