import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorSummaryComponent } from './error-summary/error-summary.component';
import { ControlMessagesComponent } from './control-messages/control-messages.component';
import { TranslateModule } from '@ngx-translate/core';
import { PipesModule } from '../pipes/pipes.module';
import { ErrMessageService } from './err.message.service';
import { ErrorNotificationService } from './error.notification.service';
import * as i0 from "@angular/core";
export class ErrorModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: ErrorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.11", ngImport: i0, type: ErrorModule, declarations: [ErrorSummaryComponent,
            ControlMessagesComponent], imports: [CommonModule,
            PipesModule,
            TranslateModule], exports: [ErrorSummaryComponent,
            ControlMessagesComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: ErrorModule, providers: [ErrMessageService, ErrorNotificationService], imports: [CommonModule,
            PipesModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: ErrorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PipesModule,
                        TranslateModule,
                    ],
                    declarations: [
                        ErrorSummaryComponent,
                        ControlMessagesComponent
                    ],
                    exports: [
                        ErrorSummaryComponent,
                        ControlMessagesComponent
                    ],
                    providers: [ErrMessageService, ErrorNotificationService]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3ItdWkubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvZXJyb3ItbXNnL2Vycm9yLXVpLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSx5Q0FBeUMsQ0FBQztBQUNoRixPQUFPLEVBQUMsd0JBQXdCLEVBQUMsTUFBTSwrQ0FBK0MsQ0FBQztBQUN2RixPQUFPLEVBQUMsZUFBZSxFQUFDLE1BQU0scUJBQXFCLENBQUM7QUFDcEQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBRXBELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzFELE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDOztBQWtCeEUsTUFBTSxPQUFPLFdBQVc7K0dBQVgsV0FBVztnSEFBWCxXQUFXLGlCQVRwQixxQkFBcUI7WUFDckIsd0JBQXdCLGFBTnhCLFlBQVk7WUFDWixXQUFXO1lBQ1gsZUFBZSxhQU9mLHFCQUFxQjtZQUNyQix3QkFBd0I7Z0hBSWYsV0FBVyxhQUZaLENBQUMsaUJBQWlCLEVBQUUsd0JBQXdCLENBQUMsWUFackQsWUFBWTtZQUNaLFdBQVc7WUFDWCxlQUFlOzs0RkFZTixXQUFXO2tCQWhCdkIsUUFBUTttQkFBQztvQkFDUixPQUFPLEVBQUU7d0JBQ1AsWUFBWTt3QkFDWixXQUFXO3dCQUNYLGVBQWU7cUJBQ2hCO29CQUNELFlBQVksRUFBRTt3QkFDWixxQkFBcUI7d0JBQ3JCLHdCQUF3QjtxQkFDekI7b0JBQ0QsT0FBTyxFQUFDO3dCQUNOLHFCQUFxQjt3QkFDckIsd0JBQXdCO3FCQUN6QjtvQkFDRCxTQUFTLEVBQUMsQ0FBQyxpQkFBaUIsRUFBRSx3QkFBd0IsQ0FBQztpQkFDeEQiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBFcnJvclN1bW1hcnlDb21wb25lbnQgfSBmcm9tICcuL2Vycm9yLXN1bW1hcnkvZXJyb3Itc3VtbWFyeS5jb21wb25lbnQnO1xyXG5pbXBvcnQge0NvbnRyb2xNZXNzYWdlc0NvbXBvbmVudH0gZnJvbSAnLi9jb250cm9sLW1lc3NhZ2VzL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50JztcclxuaW1wb3J0IHtUcmFuc2xhdGVNb2R1bGV9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xyXG5pbXBvcnQgeyBQaXBlc01vZHVsZSB9IGZyb20gJy4uL3BpcGVzL3BpcGVzLm1vZHVsZSc7XHJcbmltcG9ydCB7IENvbW1vbkZvcm1EZW5kZW5jeU1vZHVsZSB9IGZyb20gJy4uL2NvbW1vbi5mb3JtLmRlbmRlbmN5Lm1vZHVsZSc7XHJcbmltcG9ydCB7IEVyck1lc3NhZ2VTZXJ2aWNlIH0gZnJvbSAnLi9lcnIubWVzc2FnZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgRXJyb3JOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9lcnJvci5ub3RpZmljYXRpb24uc2VydmljZSc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGltcG9ydHM6IFtcclxuICAgIENvbW1vbk1vZHVsZSxcclxuICAgIFBpcGVzTW9kdWxlLFxyXG4gICAgVHJhbnNsYXRlTW9kdWxlLFxyXG4gIF0sXHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICBFcnJvclN1bW1hcnlDb21wb25lbnQsXHJcbiAgICBDb250cm9sTWVzc2FnZXNDb21wb25lbnRcclxuICBdLFxyXG4gIGV4cG9ydHM6W1xyXG4gICAgRXJyb3JTdW1tYXJ5Q29tcG9uZW50LFxyXG4gICAgQ29udHJvbE1lc3NhZ2VzQ29tcG9uZW50XHJcbiAgXSxcclxuICBwcm92aWRlcnM6W0Vyck1lc3NhZ2VTZXJ2aWNlLCBFcnJvck5vdGlmaWNhdGlvblNlcnZpY2VdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBFcnJvck1vZHVsZSB7IH0gIl19