import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import * as i0 from "@angular/core";
export class ErrorNotificationService {
    constructor() {
        // error summaries change notification for all records in a list(eg. contact records) 
        this.errorSummarySubject = new BehaviorSubject([]);
        this.errorSummaryChanged$ = this.errorSummarySubject.asObservable();
    }
    updateErrorSummary(key, errorMessage) {
        const currentErrors = this.errorSummarySubject.value;
        // Check if the error key already exists, 
        // use == not === so comparison of the number 1 and the string "1" returns true 
        const existingErrorIndex = currentErrors.findIndex(error => error.key == key);
        if (existingErrorIndex !== -1) {
            // If the error key exists, update the error errSummaryMessage
            currentErrors[existingErrorIndex].errSummaryMessage = errorMessage;
        }
        else {
            // If the error key does not exist, add the new error
            currentErrors.push({ key, errSummaryMessage: errorMessage });
        }
        // Update the errorSummarySubject with the modified array of errors
        this.errorSummarySubject.next(currentErrors);
    }
    removeErrorSummary(key) {
        const currentErrors = this.errorSummarySubject.value;
        // Filter out the entry with the specified key
        // use == not === so comparison of the number 1 and the string "1" returns true 
        const updatedErrors = currentErrors.filter(error => error.key != key);
        // Update the errorSummarySubject with the filtered array of errors
        this.errorSummarySubject.next(updatedErrors);
    }
    clearErrors() {
        this.errorSummarySubject.next([]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: ErrorNotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: ErrorNotificationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.10", ngImport: i0, type: ErrorNotificationService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3Iubm90aWZpY2F0aW9uLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9lcnJvci1tc2cvZXJyb3Iubm90aWZpY2F0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsZUFBZSxFQUFXLE1BQU0sTUFBTSxDQUFDOztBQUloRCxNQUFNLE9BQU8sd0JBQXdCO0lBRHJDO1FBR0Usc0ZBQXNGO1FBQzlFLHdCQUFtQixHQUFHLElBQUksZUFBZSxDQUE4RCxFQUFFLENBQUMsQ0FBQztRQUNuSCx5QkFBb0IsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLENBQUM7S0ErQmhFO0lBN0JDLGtCQUFrQixDQUFDLEdBQVcsRUFBRSxZQUFtQztRQUNqRSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDO1FBQ3JELDBDQUEwQztRQUMxQyxnRkFBZ0Y7UUFDaEYsTUFBTSxrQkFBa0IsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUM5RSxJQUFJLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDOUIsOERBQThEO1lBQzlELGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLGlCQUFpQixHQUFHLFlBQVksQ0FBQztRQUNyRSxDQUFDO2FBQU0sQ0FBQztZQUNOLHFEQUFxRDtZQUNyRCxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLGlCQUFpQixFQUFFLFlBQVksRUFBRSxDQUFDLENBQUM7UUFDL0QsQ0FBQztRQUVELG1FQUFtRTtRQUNuRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxrQkFBa0IsQ0FBQyxHQUFXO1FBQzVCLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUM7UUFDckQsOENBQThDO1FBQzlDLGdGQUFnRjtRQUNoRixNQUFNLGFBQWEsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN0RSxtRUFBbUU7UUFDbkUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsV0FBVztRQUNULElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDcEMsQ0FBQzsrR0FsQ1Usd0JBQXdCO21IQUF4Qix3QkFBd0I7OzRGQUF4Qix3QkFBd0I7a0JBRHBDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBFcnJvclN1bW1hcnlDb21wb25lbnQgfSBmcm9tICcuL2Vycm9yLXN1bW1hcnkvZXJyb3Itc3VtbWFyeS5jb21wb25lbnQnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgRXJyb3JOb3RpZmljYXRpb25TZXJ2aWNlIHtcclxuXHJcbiAgLy8gZXJyb3Igc3VtbWFyaWVzIGNoYW5nZSBub3RpZmljYXRpb24gZm9yIGFsbCByZWNvcmRzIGluIGEgbGlzdChlZy4gY29udGFjdCByZWNvcmRzKSBcclxuICBwcml2YXRlIGVycm9yU3VtbWFyeVN1YmplY3QgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PHsga2V5OiBzdHJpbmcsIGVyclN1bW1hcnlNZXNzYWdlOiBFcnJvclN1bW1hcnlDb21wb25lbnQgfVtdPihbXSk7XHJcbiAgZXJyb3JTdW1tYXJ5Q2hhbmdlZCQgPSB0aGlzLmVycm9yU3VtbWFyeVN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcblxyXG4gIHVwZGF0ZUVycm9yU3VtbWFyeShrZXk6IHN0cmluZywgZXJyb3JNZXNzYWdlOiBFcnJvclN1bW1hcnlDb21wb25lbnQpIHtcclxuICAgIGNvbnN0IGN1cnJlbnRFcnJvcnMgPSB0aGlzLmVycm9yU3VtbWFyeVN1YmplY3QudmFsdWU7XHJcbiAgICAvLyBDaGVjayBpZiB0aGUgZXJyb3Iga2V5IGFscmVhZHkgZXhpc3RzLCBcclxuICAgIC8vIHVzZSA9PSBub3QgPT09IHNvIGNvbXBhcmlzb24gb2YgdGhlIG51bWJlciAxIGFuZCB0aGUgc3RyaW5nIFwiMVwiIHJldHVybnMgdHJ1ZSBcclxuICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JJbmRleCA9IGN1cnJlbnRFcnJvcnMuZmluZEluZGV4KGVycm9yID0+IGVycm9yLmtleSA9PSBrZXkpO1xyXG4gICAgaWYgKGV4aXN0aW5nRXJyb3JJbmRleCAhPT0gLTEpIHtcclxuICAgICAgLy8gSWYgdGhlIGVycm9yIGtleSBleGlzdHMsIHVwZGF0ZSB0aGUgZXJyb3IgZXJyU3VtbWFyeU1lc3NhZ2VcclxuICAgICAgY3VycmVudEVycm9yc1tleGlzdGluZ0Vycm9ySW5kZXhdLmVyclN1bW1hcnlNZXNzYWdlID0gZXJyb3JNZXNzYWdlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy8gSWYgdGhlIGVycm9yIGtleSBkb2VzIG5vdCBleGlzdCwgYWRkIHRoZSBuZXcgZXJyb3JcclxuICAgICAgY3VycmVudEVycm9ycy5wdXNoKHsga2V5LCBlcnJTdW1tYXJ5TWVzc2FnZTogZXJyb3JNZXNzYWdlIH0pO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBVcGRhdGUgdGhlIGVycm9yU3VtbWFyeVN1YmplY3Qgd2l0aCB0aGUgbW9kaWZpZWQgYXJyYXkgb2YgZXJyb3JzXHJcbiAgICB0aGlzLmVycm9yU3VtbWFyeVN1YmplY3QubmV4dChjdXJyZW50RXJyb3JzKTtcclxuICB9XHJcblxyXG4gIHJlbW92ZUVycm9yU3VtbWFyeShrZXk6IHN0cmluZykge1xyXG4gICAgY29uc3QgY3VycmVudEVycm9ycyA9IHRoaXMuZXJyb3JTdW1tYXJ5U3ViamVjdC52YWx1ZTtcclxuICAgIC8vIEZpbHRlciBvdXQgdGhlIGVudHJ5IHdpdGggdGhlIHNwZWNpZmllZCBrZXlcclxuICAgIC8vIHVzZSA9PSBub3QgPT09IHNvIGNvbXBhcmlzb24gb2YgdGhlIG51bWJlciAxIGFuZCB0aGUgc3RyaW5nIFwiMVwiIHJldHVybnMgdHJ1ZSBcclxuICAgIGNvbnN0IHVwZGF0ZWRFcnJvcnMgPSBjdXJyZW50RXJyb3JzLmZpbHRlcihlcnJvciA9PiBlcnJvci5rZXkgIT0ga2V5KTtcclxuICAgIC8vIFVwZGF0ZSB0aGUgZXJyb3JTdW1tYXJ5U3ViamVjdCB3aXRoIHRoZSBmaWx0ZXJlZCBhcnJheSBvZiBlcnJvcnNcclxuICAgIHRoaXMuZXJyb3JTdW1tYXJ5U3ViamVjdC5uZXh0KHVwZGF0ZWRFcnJvcnMpO1xyXG4gIH1cclxuXHJcbiAgY2xlYXJFcnJvcnMoKSB7XHJcbiAgICB0aGlzLmVycm9yU3VtbWFyeVN1YmplY3QubmV4dChbXSk7XHJcbiAgfVxyXG59XHJcbiJdfQ==