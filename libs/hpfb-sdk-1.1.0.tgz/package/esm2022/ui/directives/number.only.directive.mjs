/* tslint:disable:member-ordering */
import { Directive, HostListener } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
export class NumbersOnlyDirective {
    constructor(control, el) {
        this.control = control;
        this.el = el;
    }
    onInput(value) {
        this.filterValue(value);
    }
    onPaste(event) {
        const pastedText = event.clipboardData.getData('text/plain');
        this.filterValue(pastedText);
        event.preventDefault(); // Prevent default paste behavior
    }
    filterValue(value) {
        // Replace any non-numeric characters with an empty string
        var newValue = value.replace(/[^\d]/g, '');
        // Update the form control value with the cleaned value
        if (this.el.nativeElement.maxLength != null) {
            const pos = this.el.nativeElement.maxLength;
            newValue = newValue.substring(0, pos);
        }
        this.control.control.setValue(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: NumbersOnlyDirective, deps: [{ token: i1.NgControl }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.11", type: NumbersOnlyDirective, isStandalone: true, selector: "[data-only-digits]", host: { listeners: { "input": "onInput($event.target.value)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: NumbersOnlyDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[data-only-digits]'
                }]
        }], ctorParameters: () => [{ type: i1.NgControl }, { type: i0.ElementRef }], propDecorators: { onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnVtYmVyLm9ubHkuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvZGlyZWN0aXZlcy9udW1iZXIub25seS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsb0NBQW9DO0FBQ3BDLE9BQU8sRUFBRSxTQUFTLEVBQWMsWUFBWSxFQUFTLE1BQU0sZUFBZSxDQUFDOzs7QUFPM0UsTUFBTSxPQUFPLG9CQUFvQjtJQUUvQixZQUFvQixPQUFrQixFQUFVLEVBQWM7UUFBMUMsWUFBTyxHQUFQLE9BQU8sQ0FBVztRQUFVLE9BQUUsR0FBRixFQUFFLENBQVk7SUFBSSxDQUFDO0lBR25FLE9BQU8sQ0FBQyxLQUFhO1FBQ25CLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUdELE9BQU8sQ0FBQyxLQUFxQjtRQUMzQixNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzdCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLGlDQUFpQztJQUMzRCxDQUFDO0lBRU8sV0FBVyxDQUFDLEtBQWE7UUFDL0IsMERBQTBEO1FBQzFELElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzNDLHVEQUF1RDtRQUN2RCxJQUFJLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUM1QyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7WUFDNUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3hDLENBQUM7UUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUMsQ0FBQzsrR0F6QlUsb0JBQW9CO21HQUFwQixvQkFBb0I7OzRGQUFwQixvQkFBb0I7a0JBSmhDLFNBQVM7bUJBQUM7b0JBQ1QsVUFBVSxFQUFDLElBQUk7b0JBQ2YsUUFBUSxFQUFFLG9CQUFvQjtpQkFDL0I7dUdBTUMsT0FBTztzQkFETixZQUFZO3VCQUFDLE9BQU8sRUFBRSxDQUFDLHFCQUFxQixDQUFDO2dCQU05QyxPQUFPO3NCQUROLFlBQVk7dUJBQUMsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyogdHNsaW50OmRpc2FibGU6bWVtYmVyLW9yZGVyaW5nICovXHJcbmltcG9ydCB7IERpcmVjdGl2ZSwgRWxlbWVudFJlZiwgSG9zdExpc3RlbmVyLCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBOZ0NvbnRyb2wgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG5ARGlyZWN0aXZlKHtcclxuICBzdGFuZGFsb25lOnRydWUsXHJcbiAgc2VsZWN0b3I6ICdbZGF0YS1vbmx5LWRpZ2l0c10nXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBOdW1iZXJzT25seURpcmVjdGl2ZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY29udHJvbDogTmdDb250cm9sLCBwcml2YXRlIGVsOiBFbGVtZW50UmVmKSB7IH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignaW5wdXQnLCBbJyRldmVudC50YXJnZXQudmFsdWUnXSlcclxuICBvbklucHV0KHZhbHVlOiBzdHJpbmcpIHtcclxuICAgIHRoaXMuZmlsdGVyVmFsdWUodmFsdWUpO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcigncGFzdGUnLCBbJyRldmVudCddKVxyXG4gIG9uUGFzdGUoZXZlbnQ6IENsaXBib2FyZEV2ZW50KSB7XHJcbiAgICBjb25zdCBwYXN0ZWRUZXh0ID0gZXZlbnQuY2xpcGJvYXJkRGF0YS5nZXREYXRhKCd0ZXh0L3BsYWluJyk7XHJcbiAgICB0aGlzLmZpbHRlclZhbHVlKHBhc3RlZFRleHQpO1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTsgLy8gUHJldmVudCBkZWZhdWx0IHBhc3RlIGJlaGF2aW9yXHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGZpbHRlclZhbHVlKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgIC8vIFJlcGxhY2UgYW55IG5vbi1udW1lcmljIGNoYXJhY3RlcnMgd2l0aCBhbiBlbXB0eSBzdHJpbmdcclxuICAgIHZhciBuZXdWYWx1ZSA9IHZhbHVlLnJlcGxhY2UoL1teXFxkXS9nLCAnJyk7XHJcbiAgICAvLyBVcGRhdGUgdGhlIGZvcm0gY29udHJvbCB2YWx1ZSB3aXRoIHRoZSBjbGVhbmVkIHZhbHVlXHJcbiAgICBpZiAodGhpcy5lbC5uYXRpdmVFbGVtZW50Lm1heExlbmd0aCAhPSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IHBvcyA9IHRoaXMuZWwubmF0aXZlRWxlbWVudC5tYXhMZW5ndGg7XHJcbiAgICAgIG5ld1ZhbHVlID0gbmV3VmFsdWUuc3Vic3RyaW5nKDAsIHBvcyk7XHJcbiAgICB9ICBcclxuICAgIHRoaXMuY29udHJvbC5jb250cm9sLnNldFZhbHVlKG5ld1ZhbHVlKTtcclxuICB9XHJcblxyXG4gIC8vIHByaXZhdGUgcmVnZXg6IFJlZ0V4cCA9IG5ldyBSZWdFeHAoJ15bMC05XSokJyk7XHJcbiAgLy8gLy8gQWxsb3cga2V5IGNvZGVzIGZvciBzcGVjaWFsIGV2ZW50cy4gUmVmbGVjdCA6XHJcbiAgLy8gcHJpdmF0ZSBuYXZpZ2F0aW9uS2V5cyA9IFtcclxuICAvLyAgICdCYWNrc3BhY2UnLFxyXG4gIC8vICAgJ0RlbGV0ZScsXHJcbiAgLy8gICAnVGFiJyxcclxuICAvLyAgICdFc2NhcGUnLFxyXG4gIC8vICAgJ0VudGVyJyxcclxuICAvLyAgICdIb21lJyxcclxuICAvLyAgICdFbmQnLFxyXG4gIC8vICAgJ0Fycm93TGVmdCcsXHJcbiAgLy8gICAnQXJyb3dSaWdodCcsXHJcbiAgLy8gICAnQ2xlYXInLFxyXG4gIC8vICAgJ0NvcHknLFxyXG4gIC8vICAgJ1Bhc3RlJyxcclxuICAvLyBdO1xyXG4gIC8vIC8vIEJhY2tzcGFjZSwgdGFiLCBlbmQsIGhvbWVcclxuXHJcbiAgLy8gLy8gQElucHV0KCkgbWF4bGVuZ3RoOiBudW1iZXI7XHJcbiAgLy8gLy8gQElucHV0KCkgbWluOiBudW1iZXI7XHJcbiAgLy8gLy8gQElucHV0KCkgbWF4OiBudW1iZXI7XHJcblxyXG4gIC8vIGNvbnN0cnVjdG9yKHByaXZhdGUgZWw6IEVsZW1lbnRSZWYpIHtcclxuICAvLyB9XHJcbiAgLy8gQEhvc3RMaXN0ZW5lcigna2V5ZG93bicsIFsnJGV2ZW50J10pXHJcbiAgLy8gb25LZXlEb3duKGV2ZW50OiBLZXlib2FyZEV2ZW50KSB7XHJcbiAgLy8gICBsZXQgZSA9IDxLZXlib2FyZEV2ZW50PmV2ZW50O1xyXG5cclxuICAvLyBpZiAoXHJcbiAgLy8gICAgIHRoaXMubmF2aWdhdGlvbktleXMuaW5kZXhPZihlLmtleSkgPiAtMSB8fCAvLyBBbGxvdzogbmF2aWdhdGlvbiBrZXlzOiBiYWNrc3BhY2UsIGRlbGV0ZSwgYXJyb3dzIGV0Yy5cclxuICAvLyAgICAgKChlLmtleSA9PT0gJ2EnIHx8IGUuY29kZSA9PT0gJ0tleUEnKSAmJiBlLmN0cmxLZXkgPT09IHRydWUpIHx8IC8vIEFsbG93OiBDdHJsK0FcclxuICAvLyAgICAgKChlLmtleSA9PT0gJ2MnIHx8IGUuY29kZSA9PT0gJ0tleUMnKSAmJiBlLmN0cmxLZXkgPT09IHRydWUpIHx8IC8vIEFsbG93OiBDdHJsK0NcclxuICAvLyAgICAgKChlLmtleSA9PT0gJ3YnIHx8IGUuY29kZSA9PT0gJ0tleVYnKSAmJiBlLmN0cmxLZXkgPT09IHRydWUpIHx8IC8vIEFsbG93OiBDdHJsK1ZcclxuICAvLyAgICAgKChlLmtleSA9PT0gJ3gnIHx8IGUuY29kZSA9PT0gJ0tleVgnKSAmJiBlLmN0cmxLZXkgPT09IHRydWUpIHx8IC8vIEFsbG93OiBDdHJsK1hcclxuICAvLyAgICAgKChlLmtleSA9PT0gJ2EnIHx8IGUuY29kZSA9PT0gJ0tleUEnKSAmJiBlLm1ldGFLZXkgPT09IHRydWUpIHx8IC8vIEFsbG93OiBDbWQrQSAoTWFjKVxyXG4gIC8vICAgICAoKGUua2V5ID09PSAnYycgfHwgZS5jb2RlID09PSAnS2V5QycpICYmIGUubWV0YUtleSA9PT0gdHJ1ZSkgfHwgLy8gQWxsb3c6IENtZCtDIChNYWMpXHJcbiAgLy8gICAgICgoZS5rZXkgPT09ICd2JyB8fCBlLmNvZGUgPT09ICdLZXlWJykgJiYgZS5tZXRhS2V5ID09PSB0cnVlKSB8fCAvLyBBbGxvdzogQ21kK1YgKE1hYylcclxuICAvLyAgICAgKChlLmtleSA9PT0gJ3gnIHx8IGUuY29kZSA9PT0gJ0tleVgnKSAmJiBlLm1ldGFLZXkgPT09IHRydWUpIC8vIEFsbG93OiBDbWQrWCAoTWFjKVxyXG4gIC8vICAgKSB7XHJcbiAgLy8gICAgIC8vIGxldCBpdCBoYXBwZW4sIGRvbid0IGRvIGFueXRoaW5nXHJcblxyXG4gIC8vICAgICBjb25zb2xlLmxvZyhcIj09PT5cIiwgZS5rZXksIGUuY29kZSlcclxuXHJcbiAgLy8gICAgIHJldHVybjtcclxuICAvLyAgIH1cclxuICAvLyBpZiAoLy8gdG8gYWxsb3cgbnVtYmVyc1xyXG4gIC8vICAgZS5jb2RlLnN0YXJ0c1dpdGgoXCJEaWdpdFwiKSB8fFxyXG4gIC8vICAgLy8gdG8gYWxsb3cgbnVtcGFkIG51bWJlclxyXG4gIC8vICAgZS5jb2RlLnN0YXJ0c1dpdGgoXCJOdW1wYWRcIikgKSB7XHJcbiAgLy8gICB9IGVsc2Uge1xyXG4gIC8vICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIGxldCBjdXJyZW50OiBzdHJpbmcgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQudmFsdWU7XHJcblxyXG4gIC8vICAgbGV0IG5leHQ6IHN0cmluZyA9IGN1cnJlbnQuY29uY2F0KGV2ZW50LmtleSk7XHJcbiAgLy8gICBpZiAobmV4dCAmJiAhU3RyaW5nKG5leHQpLm1hdGNoKHRoaXMucmVnZXgpICkge1xyXG4gIC8vICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyB9XHJcbn1cclxuIl19