import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class VersionService {
    getApplicationVersion(appEnvironment) {
        return appEnvironment.appVersion;
    }
    /**
     * get the major and minor version of the application concatenated with '.'
     * @param appVersion format is 1.0.0
     * @returns string
     */
    getApplicationMajorVersion(appVersion) {
        const majorVersion = appVersion.split('.', 2).join('.');
        return majorVersion;
    }
    /**
    * get the major and minor version of the application concatenated with '_'
    * @param appVersion format is 1.0.0
    * @returns string
    */
    getApplicationMajorVersionWithUnderscore(appVersion) {
        const majorVersion = appVersion.split('.', 2).join('_');
        return majorVersion;
    }
    /**
     * Extracts the major version number from a version string.
     *
     * @param versionStr - The version string in the format "major.minor.patch", e.g., "1.0.0".
     * @returns The major version number as an integer.
     */
    getMajorVersion(versionStr) {
        return parseInt(versionStr.split('.')[0], 10);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: VersionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: VersionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: VersionService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVyc2lvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvdmVyc2lvbi92ZXJzaW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHM0MsTUFBTSxPQUFPLGNBQWM7SUFDbEIscUJBQXFCLENBQUMsY0FBYztRQUN6QyxPQUFPLGNBQWMsQ0FBQyxVQUFVLENBQUM7SUFDbkMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCwwQkFBMEIsQ0FBQyxVQUFrQjtRQUMzQyxNQUFNLFlBQVksR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDeEQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVBOzs7O01BSUU7SUFDSCx3Q0FBd0MsQ0FBQyxVQUFrQjtRQUN6RCxNQUFNLFlBQVksR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDeEQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVIOzs7OztPQUtHO0lBQ0QsZUFBZSxDQUFDLFVBQWtCO1FBQ2hDLE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDaEQsQ0FBQzs4R0FqQ1UsY0FBYztrSEFBZCxjQUFjOzsyRkFBZCxjQUFjO2tCQUQxQixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgVmVyc2lvblNlcnZpY2Uge1xyXG4gIHB1YmxpYyBnZXRBcHBsaWNhdGlvblZlcnNpb24oYXBwRW52aXJvbm1lbnQpIHtcclxuICAgIHJldHVybiBhcHBFbnZpcm9ubWVudC5hcHBWZXJzaW9uO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZ2V0IHRoZSBtYWpvciBhbmQgbWlub3IgdmVyc2lvbiBvZiB0aGUgYXBwbGljYXRpb24gY29uY2F0ZW5hdGVkIHdpdGggJy4nXHJcbiAgICogQHBhcmFtIGFwcFZlcnNpb24gZm9ybWF0IGlzIDEuMC4wXHJcbiAgICogQHJldHVybnMgc3RyaW5nXHJcbiAgICovXHJcbiAgZ2V0QXBwbGljYXRpb25NYWpvclZlcnNpb24oYXBwVmVyc2lvbjogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IG1ham9yVmVyc2lvbiA9IGFwcFZlcnNpb24uc3BsaXQoJy4nLCAyKS5qb2luKCcuJyk7XHJcbiAgICByZXR1cm4gbWFqb3JWZXJzaW9uO1xyXG4gIH1cclxuXHJcbiAgIC8qKlxyXG4gICAqIGdldCB0aGUgbWFqb3IgYW5kIG1pbm9yIHZlcnNpb24gb2YgdGhlIGFwcGxpY2F0aW9uIGNvbmNhdGVuYXRlZCB3aXRoICdfJ1xyXG4gICAqIEBwYXJhbSBhcHBWZXJzaW9uIGZvcm1hdCBpcyAxLjAuMFxyXG4gICAqIEByZXR1cm5zIHN0cmluZ1xyXG4gICAqL1xyXG4gIGdldEFwcGxpY2F0aW9uTWFqb3JWZXJzaW9uV2l0aFVuZGVyc2NvcmUoYXBwVmVyc2lvbjogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IG1ham9yVmVyc2lvbiA9IGFwcFZlcnNpb24uc3BsaXQoJy4nLCAyKS5qb2luKCdfJyk7XHJcbiAgICByZXR1cm4gbWFqb3JWZXJzaW9uO1xyXG4gIH1cclxuXHJcbi8qKlxyXG4gKiBFeHRyYWN0cyB0aGUgbWFqb3IgdmVyc2lvbiBudW1iZXIgZnJvbSBhIHZlcnNpb24gc3RyaW5nLlxyXG4gKlxyXG4gKiBAcGFyYW0gdmVyc2lvblN0ciAtIFRoZSB2ZXJzaW9uIHN0cmluZyBpbiB0aGUgZm9ybWF0IFwibWFqb3IubWlub3IucGF0Y2hcIiwgZS5nLiwgXCIxLjAuMFwiLlxyXG4gKiBAcmV0dXJucyBUaGUgbWFqb3IgdmVyc2lvbiBudW1iZXIgYXMgYW4gaW50ZWdlci5cclxuICovXHJcbiAgZ2V0TWFqb3JWZXJzaW9uKHZlcnNpb25TdHI6IHN0cmluZyk6IG51bWJlciB7XHJcbiAgICByZXR1cm4gcGFyc2VJbnQodmVyc2lvblN0ci5zcGxpdCgnLicpWzBdLCAxMCk7XHJcbiAgfVxyXG59XHJcbiJdfQ==