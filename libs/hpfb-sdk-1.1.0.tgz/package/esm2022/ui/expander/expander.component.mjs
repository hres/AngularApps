import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
import { FINAL } from '../common.constants';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@ngx-translate/core";
export class ExpanderComponent {
    constructor() {
        /**
         * Disable expand
         */
        this.disableExpand = false;
        /**
         * Expands a record when it has been added. Default is false
         */
        this.expandOnAdd = false;
        this.expandedRow = new EventEmitter();
        this.tableRowIndexCurrExpanded = -1;
        this.tableRowIndexPreExpanded = -1;
        /**
         * for each table row, stores the state i.e. collapsed or expanded
         * @type {boolean[]}
         * @private
         */
        this._expanderTable = [];
        /**
         * an array of JSON objects to define the column labels, widths and bindings
         * @type {any[]}
         */
        this.columnDefinitions = [];
        /**
         * The number of columns for this expander. Used to determine columnSpan
         * @type {number}
         */
        this.numberColSpan = 1;
        this.dataItems = [];
        this._expanderValid = true;
        this._expandAdd = false;
    }
    ngOnInit() {
    }
    /**
     * Looks for and reacts to changes in the expander component
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['columnDefinitions']) {
            this.numberColSpan = (changes['columnDefinitions'].currentValue).length + 1;
        }
        if (changes['expandOnAdd']) {
            this._expandAdd = changes['expandOnAdd'].currentValue;
        }
        if (changes['itemsList']) {
            this.updateDataRows(changes['itemsList'].currentValue);
            this.dataItems = changes['itemsList'].currentValue;
            if (!Array.isArray(this.dataItems)) {
                this.dataItems = [];
            }
            else if (this.dataItems.length > 0 && this.loadFileIndicator) {
                this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
                this.tableRowIndexCurrExpanded = 0;
            }
        }
        if (changes['isValid']) {
            this._expanderValid = changes['isValid'].currentValue;
        }
        if (changes['addRecord'] && !changes['addRecord'].firstChange) {
            this.collapseTableRows();
            this.updateDataRows(this.itemsList);
            if (this._expandAdd) {
                // expands the table on the additon of a new record
                this.selectTableRowNoCheck(this._expanderTable.length - 1);
            }
            else if (!this.isValid) {
                if (this.tableRowIndexPreExpanded + 1 < this._expanderTable.length) {
                    this.tableRowIndexCurrExpanded = this.tableRowIndexPreExpanded + 1;
                }
                else {
                    this.tableRowIndexCurrExpanded = 0;
                }
                this.selectTableRowNoCheck(this.tableRowIndexCurrExpanded);
            }
        }
        if (changes['deleteRecord']) {
            this.updateDataRows(this.itemsList);
        }
        if (changes['collapseAll']) {
            this.collapseTableRows();
        }
        if (changes['xmlStatus']) {
            if (changes['xmlStatus'].currentValue === FINAL) {
                this.collapseTableRows();
            }
        }
    }
    /**
     * Adds an additional row to the expander UI state tracking array
     */
    updateDataRows(srcList) {
        if (!srcList) {
            return;
        }
        if (srcList.length !== this._expanderTable.length) {
            this._expanderTable = new Array(srcList.length);
        }
    }
    /**
     * For a given row denoted by a zero based index, returns if a row is collapsed or expanded
     * @param {number} index
     * @returns {boolean}
     */
    getExpandedState(index) {
        return (this._expanderTable)[index];
    }
    /**
     *  Checks if a given zero based row denoted by index is expanded
     * @param {number} index
     * @returns {boolean}
     */
    isExpanded(index) {
        if (this.tableRowIndexCurrExpanded < 0)
            return false;
        this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
        return this.tableRowIndexCurrExpanded === index;
    }
    ;
    /**
     *  Checks if a given zero based row denoted by index is collapsed
     * @param {number} index
     * @returns {boolean}
     */
    isCollapsed(index) {
        return !this.isExpanded(index);
    }
    broadcastExpandedRow() {
        // return this.tableRowIndexCurrExpanded;
        this.expandedRow.emit(this.tableRowIndexCurrExpanded);
    }
    getExpandedRow() {
        return this.tableRowIndexCurrExpanded;
    }
    /**
     * Selects the table row to expand or collapse. If disable expand is enabled, will not collapse a row if it is in error
     * @param {number} index
     */
    selectTableRow(index) {
        // if (!this._expanderValid) {
        //    console.warn('select table row did not meet conditions');
        //   return;
        // }
        if (!this.disableExpand) { // && this.isValid
            this.selectTableRowNoCheck(index);
        }
    }
    selectTableRowNoCheck(index) {
        if (this._expanderTable.length > index) {
            const temp = this._expanderTable[index];
            this.collapseTableRows();
            this._expanderTable[index] = !temp;
            this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
            if (this._expanderTable[index]) {
                this.tableRowIndexCurrExpanded = index;
            }
            else {
                this.tableRowIndexCurrExpanded = -1;
            }
        }
        else {
            console.warn('The index is greater than the table length ' + index + ' ' + this._expanderTable.length);
        }
    }
    /**
     * Collapses all the table rows. Ignores any error states in the details.
     */
    collapseTableRows() {
        for (let rec of this._expanderTable) {
            rec = false;
        }
        this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
        this.tableRowIndexCurrExpanded = -1;
    }
    /**
     * Get the row title dynamic according to the expand/collapse status
     */
    getRowTitle(i) {
        if (this.isCollapsed(i)) {
            return 'Expand Row ' + (i + 1);
        }
        else if (this.isExpanded(i)) {
            return 'Collapse Row ' + (i + 1);
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ExpanderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ExpanderComponent, selector: "lib-expander", inputs: { accordionHeadingMsgKey: "accordionHeadingMsgKey", disableExpand: "disableExpand", isValid: "isValid", itemsList: ["group", "itemsList"], addRecord: "addRecord", expandOnAdd: "expandOnAdd", deleteRecord: "deleteRecord", collapseAll: "collapseAll", loadFileIndicator: "loadFileIndicator", xmlStatus: "xmlStatus", columnDefinitions: "columnDefinitions" }, outputs: { expandedRow: "expandedRow" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngFor=\"let record of dataItems; index as i;\">\r\n  <div role=\"button\" >\r\n    <h4 id=\"tr-expand-row-{{i}}\" class=\"clickableRow\" [ngClass]=\"{'selected':isExpanded(i)}\"\r\n      [attr.aria-expanded]=\"getExpandedState(i)\" i18n-title=\"@@expander.rowTitle\" [title]=\"getRowTitle(i)\"\r\n      (click)=\"selectTableRow(i)\">\r\n      <span class=\"fa fa-lg fa-fw\" [ngClass]=\"{'fa-caret-right':isCollapsed(i), 'fa-caret-down':isExpanded(i) }\"></span>\r\n      {{accordionHeadingMsgKey | translate}}&nbsp; {{ +record['id']+1 }}\r\n    </h4>\r\n  </div>\r\n\r\n  <div class=\"table-override\" *ngIf=\"isExpanded(i)\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n</ng-container>", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i2.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ExpanderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-expander', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngFor=\"let record of dataItems; index as i;\">\r\n  <div role=\"button\" >\r\n    <h4 id=\"tr-expand-row-{{i}}\" class=\"clickableRow\" [ngClass]=\"{'selected':isExpanded(i)}\"\r\n      [attr.aria-expanded]=\"getExpandedState(i)\" i18n-title=\"@@expander.rowTitle\" [title]=\"getRowTitle(i)\"\r\n      (click)=\"selectTableRow(i)\">\r\n      <span class=\"fa fa-lg fa-fw\" [ngClass]=\"{'fa-caret-right':isCollapsed(i), 'fa-caret-down':isExpanded(i) }\"></span>\r\n      {{accordionHeadingMsgKey | translate}}&nbsp; {{ +record['id']+1 }}\r\n    </h4>\r\n  </div>\r\n\r\n  <div class=\"table-override\" *ngIf=\"isExpanded(i)\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n</ng-container>" }]
        }], ctorParameters: () => [], propDecorators: { accordionHeadingMsgKey: [{
                type: Input
            }], disableExpand: [{
                type: Input
            }], isValid: [{
                type: Input
            }], itemsList: [{
                type: Input,
                args: ['group']
            }], addRecord: [{
                type: Input
            }], expandOnAdd: [{
                type: Input
            }], deleteRecord: [{
                type: Input
            }], collapseAll: [{
                type: Input
            }], loadFileIndicator: [{
                type: Input
            }], xmlStatus: [{
                type: Input
            }], expandedRow: [{
                type: Output
            }], columnDefinitions: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhwYW5kZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvZXhwYW5kZXIvZXhwYW5kZXIuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvZXhwYW5kZXIvZXhwYW5kZXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFhLE1BQU0sRUFBaUIsaUJBQWlCLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDcEgsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDOzs7O0FBUTVDLE1BQU0sT0FBTyxpQkFBaUI7SUFpRTVCO1FBOURBOztXQUVHO1FBQ00sa0JBQWEsR0FBRyxLQUFLLENBQUM7UUF1Qi9COztXQUVHO1FBQ00sZ0JBQVcsR0FBRyxLQUFLLENBQUM7UUFNbkIsZ0JBQVcsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBRW5DLDhCQUF5QixHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQy9CLDZCQUF3QixHQUFHLENBQUMsQ0FBQyxDQUFDO1FBR3RDOzs7O1dBSUc7UUFDSyxtQkFBYyxHQUFjLEVBQUUsQ0FBQztRQUV2Qzs7O1dBR0c7UUFDTSxzQkFBaUIsR0FBRyxFQUFFLENBQUM7UUFFaEM7OztXQUdHO1FBQ0gsa0JBQWEsR0FBRyxDQUFDLENBQUM7UUFDWCxjQUFTLEdBQUcsRUFBRSxDQUFDO1FBSXBCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFFRCxRQUFRO0lBQ1IsQ0FBQztJQUVEOzs7T0FHRztJQUNILFdBQVcsQ0FBQyxPQUFzQjtRQUNoQyxJQUFJLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDOUUsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3hELENBQUM7UUFFRCxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQztZQUNuRCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7WUFDdEIsQ0FBQztpQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztnQkFDL0QsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDL0QsSUFBSSxDQUFDLHlCQUF5QixHQUFHLENBQUMsQ0FBQztZQUNyQyxDQUFDO1FBQ0gsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3hELENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM5RCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwQyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDcEIsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDN0QsQ0FBQztpQkFBTSxJQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRyxDQUFDO2dCQUMzQixJQUFLLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUcsQ0FBQztvQkFDckUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxDQUFDLENBQUM7Z0JBQ3JFLENBQUM7cUJBQU0sQ0FBQztvQkFDTixJQUFJLENBQUMseUJBQXlCLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELElBQUksQ0FBQyxxQkFBcUIsQ0FBRSxJQUFJLENBQUMseUJBQXlCLENBQUUsQ0FBQztZQUMvRCxDQUFDO1FBQ0gsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdEMsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDM0IsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7WUFDekIsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxLQUFLLEtBQUssRUFBRSxDQUFDO2dCQUNoRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUMzQixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNJLGNBQWMsQ0FBQyxPQUFPO1FBQzNCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNiLE9BQU87UUFDVCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLEtBQUssQ0FBVSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0QsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksZ0JBQWdCLENBQUMsS0FBYTtRQUNuQyxPQUFnQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFVBQVUsQ0FBQyxLQUFhO1FBQzdCLElBQUksSUFBSSxDQUFDLHlCQUF5QixHQUFHLENBQUM7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUNyRCxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1FBQy9ELE9BQU8sSUFBSSxDQUFDLHlCQUF5QixLQUFLLEtBQUssQ0FBQztJQUNsRCxDQUFDO0lBQUEsQ0FBQztJQUVGOzs7O09BSUc7SUFDSSxXQUFXLENBQUMsS0FBYTtRQUM5QixPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBR00sb0JBQW9CO1FBQ3pCLHlDQUF5QztRQUN6QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ00sY0FBYztRQUNuQixPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksY0FBYyxDQUFDLEtBQWE7UUFDakMsOEJBQThCO1FBQzlCLCtEQUErRDtRQUMvRCxZQUFZO1FBQ1osSUFBSTtRQUNKLElBQUssQ0FBRSxJQUFJLENBQUMsYUFBYSxFQUFHLENBQUMsQ0FBQyxrQkFBa0I7WUFDOUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLENBQUM7SUFDSCxDQUFDO0lBR00scUJBQXFCLENBQUMsS0FBYTtRQUN4QyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLEtBQUssRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDeEMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNuQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1lBQy9ELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUMvQixJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO1lBQ3pDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMseUJBQXlCLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDdEMsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxDQUFDLElBQUksQ0FBQyw2Q0FBNkMsR0FBRyxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDekcsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNJLGlCQUFpQjtRQUN0QixLQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNyQyxHQUFHLEdBQUcsS0FBSyxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUM7UUFDL0QsSUFBSSxDQUFDLHlCQUF5QixHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7T0FFRztJQUNHLFdBQVcsQ0FBQyxDQUFDO1FBQ2xCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ3hCLE9BQU8sYUFBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUM5QixPQUFPLGVBQWUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDYixDQUFDOzhHQXBPVSxpQkFBaUI7a0dBQWpCLGlCQUFpQiw2ZENUOUIsbXNCQWFlOzsyRkRKRixpQkFBaUI7a0JBTjdCLFNBQVM7K0JBQ0UsY0FBYyxpQkFFVCxpQkFBaUIsQ0FBQyxJQUFJO3dEQUs1QixzQkFBc0I7c0JBQTlCLEtBQUs7Z0JBSUcsYUFBYTtzQkFBckIsS0FBSztnQkFXRyxPQUFPO3NCQUFmLEtBQUs7Z0JBS1UsU0FBUztzQkFBeEIsS0FBSzt1QkFBQyxPQUFPO2dCQU1MLFNBQVM7c0JBQWpCLEtBQUs7Z0JBSUcsV0FBVztzQkFBbkIsS0FBSztnQkFDRyxZQUFZO3NCQUFwQixLQUFLO2dCQUNHLFdBQVc7c0JBQW5CLEtBQUs7Z0JBQ0csaUJBQWlCO3NCQUF6QixLQUFLO2dCQUNHLFNBQVM7c0JBQWpCLEtBQUs7Z0JBRUksV0FBVztzQkFBcEIsTUFBTTtnQkFpQkUsaUJBQWlCO3NCQUF6QixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkNoYW5nZXMsIE91dHB1dCwgU2ltcGxlQ2hhbmdlcywgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRklOQUwgfSBmcm9tICcuLi9jb21tb24uY29uc3RhbnRzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLWV4cGFuZGVyJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZXhwYW5kZXIuY29tcG9uZW50Lmh0bWwnLFxyXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBFeHBhbmRlckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XHJcblxyXG4gIEBJbnB1dCgpIGFjY29yZGlvbkhlYWRpbmdNc2dLZXk6IHN0cmluZztcclxuICAvKipcclxuICAgKiBEaXNhYmxlIGV4cGFuZFxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGRpc2FibGVFeHBhbmQgPSBmYWxzZTtcclxuXHJcbiAgLyoqXHJcbiAgICogV2hlbiBzZXQgdG8gdHJ1ZSwgZGlzYWJsZXMgY29sbGFwc2Ugb2YgYSBkZXRhaWxzIHNlY3Rpb24gdGhhdCBpcyBpbiBlcnJvclxyXG4gICAqIEB0eXBlIHtib29sZWFufVxyXG4gICAqL1xyXG4gLy8gQElucHV0KCkgZGlzYWJsZUNvbGxhcHNlID0gdHJ1ZTtcclxuICAvKipcclxuICAgKiBzZXRzIGlmIHRoZSBkZXRhaWxzIGZvcm0gaXMgdmFsaWQuIENvbnRyb2xzIGNvbGxhcHNlcyBzdGF0ZVxyXG4gICAqIEB0eXBlIHtib29sZWFufVxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGlzVmFsaWQ6IGJvb2xlYW47XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoZSBsaXN0IG9mIHJlY29yZHMgdG8gZGlzcGxheSBpbiB0aGUgZXhwYW5kZXIgY29tcG9uZW50XHJcbiAgICovXHJcbiAgQElucHV0KCdncm91cCcpIGl0ZW1zTGlzdDtcclxuXHJcbiAgLyoqXHJcbiAgICogU2lnbmFsIHRvIGluZGljYXRlIGEgcmVjb3JkIGhhcyBiZWVuIGFkZGVkXHJcbiAgICogQHR5cGUge251bWJlcn1cclxuICAgKi9cclxuICBASW5wdXQoKSBhZGRSZWNvcmQ6IG51bWJlcjtcclxuICAvKipcclxuICAgKiBFeHBhbmRzIGEgcmVjb3JkIHdoZW4gaXQgaGFzIGJlZW4gYWRkZWQuIERlZmF1bHQgaXMgZmFsc2VcclxuICAgKi9cclxuICBASW5wdXQoKSBleHBhbmRPbkFkZCA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIGRlbGV0ZVJlY29yZDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIGNvbGxhcHNlQWxsOiBudW1iZXI7XHJcbiAgQElucHV0KCkgbG9hZEZpbGVJbmRpY2F0b3I6IGJvb2xlYW47XHJcbiAgQElucHV0KCkgeG1sU3RhdHVzO1xyXG5cclxuICBAT3V0cHV0KCkgZXhwYW5kZWRSb3cgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gIHByaXZhdGUgdGFibGVSb3dJbmRleEN1cnJFeHBhbmRlZCA9IC0xO1xyXG4gIHByaXZhdGUgdGFibGVSb3dJbmRleFByZUV4cGFuZGVkID0gLTE7XHJcbiAgcHJpdmF0ZSBfZXhwYW5kQWRkOiBib29sZWFuO1xyXG5cclxuICAvKipcclxuICAgKiBmb3IgZWFjaCB0YWJsZSByb3csIHN0b3JlcyB0aGUgc3RhdGUgaS5lLiBjb2xsYXBzZWQgb3IgZXhwYW5kZWRcclxuICAgKiBAdHlwZSB7Ym9vbGVhbltdfVxyXG4gICAqIEBwcml2YXRlXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBfZXhwYW5kZXJUYWJsZTogYm9vbGVhbltdID0gW107XHJcblxyXG4gIC8qKlxyXG4gICAqIGFuIGFycmF5IG9mIEpTT04gb2JqZWN0cyB0byBkZWZpbmUgdGhlIGNvbHVtbiBsYWJlbHMsIHdpZHRocyBhbmQgYmluZGluZ3NcclxuICAgKiBAdHlwZSB7YW55W119XHJcbiAgICovXHJcbiAgQElucHV0KCkgY29sdW1uRGVmaW5pdGlvbnMgPSBbXTtcclxuXHJcbiAgLyoqXHJcbiAgICogVGhlIG51bWJlciBvZiBjb2x1bW5zIGZvciB0aGlzIGV4cGFuZGVyLiBVc2VkIHRvIGRldGVybWluZSBjb2x1bW5TcGFuXHJcbiAgICogQHR5cGUge251bWJlcn1cclxuICAgKi9cclxuICBudW1iZXJDb2xTcGFuID0gMTtcclxuICBwdWJsaWMgZGF0YUl0ZW1zID0gW107XHJcbiAgcHJpdmF0ZSBfZXhwYW5kZXJWYWxpZDogYm9vbGVhbjtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLl9leHBhbmRlclZhbGlkID0gdHJ1ZTtcclxuICAgIHRoaXMuX2V4cGFuZEFkZCA9IGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBMb29rcyBmb3IgYW5kIHJlYWN0cyB0byBjaGFuZ2VzIGluIHRoZSBleHBhbmRlciBjb21wb25lbnRcclxuICAgKiBAcGFyYW0ge1NpbXBsZUNoYW5nZXN9IGNoYW5nZXNcclxuICAgKi9cclxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcbiAgICBpZiAoY2hhbmdlc1snY29sdW1uRGVmaW5pdGlvbnMnXSkge1xyXG4gICAgICB0aGlzLm51bWJlckNvbFNwYW4gPSAoY2hhbmdlc1snY29sdW1uRGVmaW5pdGlvbnMnXS5jdXJyZW50VmFsdWUpLmxlbmd0aCArIDE7XHJcbiAgICB9XHJcbiAgICBpZiAoY2hhbmdlc1snZXhwYW5kT25BZGQnXSkge1xyXG4gICAgICB0aGlzLl9leHBhbmRBZGQgPSBjaGFuZ2VzWydleHBhbmRPbkFkZCddLmN1cnJlbnRWYWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoY2hhbmdlc1snaXRlbXNMaXN0J10pIHtcclxuICAgICAgdGhpcy51cGRhdGVEYXRhUm93cyhjaGFuZ2VzWydpdGVtc0xpc3QnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICB0aGlzLmRhdGFJdGVtcyA9IGNoYW5nZXNbJ2l0ZW1zTGlzdCddLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHRoaXMuZGF0YUl0ZW1zKSkge1xyXG4gICAgICAgIHRoaXMuZGF0YUl0ZW1zID0gW107XHJcbiAgICAgIH0gZWxzZSBpZiAodGhpcy5kYXRhSXRlbXMubGVuZ3RoID4gMCAmJiB0aGlzLmxvYWRGaWxlSW5kaWNhdG9yKSB7XHJcbiAgICAgICAgdGhpcy50YWJsZVJvd0luZGV4UHJlRXhwYW5kZWQgPSB0aGlzLnRhYmxlUm93SW5kZXhDdXJyRXhwYW5kZWQ7XHJcbiAgICAgICAgdGhpcy50YWJsZVJvd0luZGV4Q3VyckV4cGFuZGVkID0gMDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKGNoYW5nZXNbJ2lzVmFsaWQnXSkge1xyXG4gICAgICB0aGlzLl9leHBhbmRlclZhbGlkID0gY2hhbmdlc1snaXNWYWxpZCddLmN1cnJlbnRWYWx1ZTtcclxuICAgIH1cclxuICAgIGlmIChjaGFuZ2VzWydhZGRSZWNvcmQnXSAmJiAhY2hhbmdlc1snYWRkUmVjb3JkJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgdGhpcy5jb2xsYXBzZVRhYmxlUm93cygpO1xyXG4gICAgICB0aGlzLnVwZGF0ZURhdGFSb3dzKHRoaXMuaXRlbXNMaXN0KTtcclxuICAgICAgaWYgKHRoaXMuX2V4cGFuZEFkZCkge1xyXG4gICAgICAgIC8vIGV4cGFuZHMgdGhlIHRhYmxlIG9uIHRoZSBhZGRpdG9uIG9mIGEgbmV3IHJlY29yZFxyXG4gICAgICAgIHRoaXMuc2VsZWN0VGFibGVSb3dOb0NoZWNrKHRoaXMuX2V4cGFuZGVyVGFibGUubGVuZ3RoIC0gMSk7XHJcbiAgICAgIH0gZWxzZSBpZiAoICF0aGlzLmlzVmFsaWQgKSB7XHJcbiAgICAgICAgaWYgKCB0aGlzLnRhYmxlUm93SW5kZXhQcmVFeHBhbmRlZCArIDEgPCB0aGlzLl9leHBhbmRlclRhYmxlLmxlbmd0aCApIHtcclxuICAgICAgICAgIHRoaXMudGFibGVSb3dJbmRleEN1cnJFeHBhbmRlZCA9IHRoaXMudGFibGVSb3dJbmRleFByZUV4cGFuZGVkICsgMTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy50YWJsZVJvd0luZGV4Q3VyckV4cGFuZGVkID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zZWxlY3RUYWJsZVJvd05vQ2hlY2soIHRoaXMudGFibGVSb3dJbmRleEN1cnJFeHBhbmRlZCApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoY2hhbmdlc1snZGVsZXRlUmVjb3JkJ10pIHtcclxuICAgICAgdGhpcy51cGRhdGVEYXRhUm93cyh0aGlzLml0ZW1zTGlzdCk7XHJcbiAgICB9XHJcbiAgICBpZiAoY2hhbmdlc1snY29sbGFwc2VBbGwnXSkge1xyXG4gICAgICB0aGlzLmNvbGxhcHNlVGFibGVSb3dzKCk7XHJcbiAgICB9XHJcbiAgICBpZiAoY2hhbmdlc1sneG1sU3RhdHVzJ10pIHtcclxuICAgICAgaWYgKGNoYW5nZXNbJ3htbFN0YXR1cyddLmN1cnJlbnRWYWx1ZSA9PT0gRklOQUwpIHtcclxuICAgICAgICB0aGlzLmNvbGxhcHNlVGFibGVSb3dzKCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEFkZHMgYW4gYWRkaXRpb25hbCByb3cgdG8gdGhlIGV4cGFuZGVyIFVJIHN0YXRlIHRyYWNraW5nIGFycmF5XHJcbiAgICovXHJcbiAgcHVibGljIHVwZGF0ZURhdGFSb3dzKHNyY0xpc3QpIHtcclxuICAgIGlmICghc3JjTGlzdCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoc3JjTGlzdC5sZW5ndGggIT09IHRoaXMuX2V4cGFuZGVyVGFibGUubGVuZ3RoKSB7XHJcbiAgICAgIHRoaXMuX2V4cGFuZGVyVGFibGUgPSBuZXcgQXJyYXk8Ym9vbGVhbj4oc3JjTGlzdC5sZW5ndGgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRm9yIGEgZ2l2ZW4gcm93IGRlbm90ZWQgYnkgYSB6ZXJvIGJhc2VkIGluZGV4LCByZXR1cm5zIGlmIGEgcm93IGlzIGNvbGxhcHNlZCBvciBleHBhbmRlZFxyXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxyXG4gICAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRFeHBhbmRlZFN0YXRlKGluZGV4OiBudW1iZXIpIHtcclxuICAgIHJldHVybiA8Ym9vbGVhbj4odGhpcy5fZXhwYW5kZXJUYWJsZSlbaW5kZXhdO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogIENoZWNrcyBpZiBhIGdpdmVuIHplcm8gYmFzZWQgcm93IGRlbm90ZWQgYnkgaW5kZXggaXMgZXhwYW5kZWRcclxuICAgKiBAcGFyYW0ge251bWJlcn0gaW5kZXhcclxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICAgKi9cclxuICBwdWJsaWMgaXNFeHBhbmRlZChpbmRleDogbnVtYmVyKSB7XHJcbiAgICBpZiAodGhpcy50YWJsZVJvd0luZGV4Q3VyckV4cGFuZGVkIDwgMCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgdGhpcy50YWJsZVJvd0luZGV4UHJlRXhwYW5kZWQgPSB0aGlzLnRhYmxlUm93SW5kZXhDdXJyRXhwYW5kZWQ7XHJcbiAgICByZXR1cm4gdGhpcy50YWJsZVJvd0luZGV4Q3VyckV4cGFuZGVkID09PSBpbmRleDtcclxuICB9O1xyXG5cclxuICAvKipcclxuICAgKiAgQ2hlY2tzIGlmIGEgZ2l2ZW4gemVybyBiYXNlZCByb3cgZGVub3RlZCBieSBpbmRleCBpcyBjb2xsYXBzZWRcclxuICAgKiBAcGFyYW0ge251bWJlcn0gaW5kZXhcclxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICAgKi9cclxuICBwdWJsaWMgaXNDb2xsYXBzZWQoaW5kZXg6IG51bWJlcikge1xyXG4gICAgcmV0dXJuICF0aGlzLmlzRXhwYW5kZWQoaW5kZXgpO1xyXG4gIH1cclxuXHJcblxyXG4gIHB1YmxpYyBicm9hZGNhc3RFeHBhbmRlZFJvdygpIHtcclxuICAgIC8vIHJldHVybiB0aGlzLnRhYmxlUm93SW5kZXhDdXJyRXhwYW5kZWQ7XHJcbiAgICB0aGlzLmV4cGFuZGVkUm93LmVtaXQodGhpcy50YWJsZVJvd0luZGV4Q3VyckV4cGFuZGVkKTtcclxuICB9XHJcbiAgcHVibGljIGdldEV4cGFuZGVkUm93KCkge1xyXG4gICAgcmV0dXJuIHRoaXMudGFibGVSb3dJbmRleEN1cnJFeHBhbmRlZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNlbGVjdHMgdGhlIHRhYmxlIHJvdyB0byBleHBhbmQgb3IgY29sbGFwc2UuIElmIGRpc2FibGUgZXhwYW5kIGlzIGVuYWJsZWQsIHdpbGwgbm90IGNvbGxhcHNlIGEgcm93IGlmIGl0IGlzIGluIGVycm9yXHJcbiAgICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XHJcbiAgICovXHJcbiAgcHVibGljIHNlbGVjdFRhYmxlUm93KGluZGV4OiBudW1iZXIpIHtcclxuICAgIC8vIGlmICghdGhpcy5fZXhwYW5kZXJWYWxpZCkge1xyXG4gICAgLy8gICAgY29uc29sZS53YXJuKCdzZWxlY3QgdGFibGUgcm93IGRpZCBub3QgbWVldCBjb25kaXRpb25zJyk7XHJcbiAgICAvLyAgIHJldHVybjtcclxuICAgIC8vIH1cclxuICAgIGlmICggISB0aGlzLmRpc2FibGVFeHBhbmQgKSB7IC8vICYmIHRoaXMuaXNWYWxpZFxyXG4gICAgICB0aGlzLnNlbGVjdFRhYmxlUm93Tm9DaGVjayhpbmRleCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbiAgcHVibGljIHNlbGVjdFRhYmxlUm93Tm9DaGVjayhpbmRleDogbnVtYmVyKSB7XHJcbiAgICBpZiAodGhpcy5fZXhwYW5kZXJUYWJsZS5sZW5ndGggPiBpbmRleCkge1xyXG4gICAgICBjb25zdCB0ZW1wID0gdGhpcy5fZXhwYW5kZXJUYWJsZVtpbmRleF07XHJcbiAgICAgIHRoaXMuY29sbGFwc2VUYWJsZVJvd3MoKTtcclxuICAgICAgdGhpcy5fZXhwYW5kZXJUYWJsZVtpbmRleF0gPSAhdGVtcDtcclxuICAgICAgdGhpcy50YWJsZVJvd0luZGV4UHJlRXhwYW5kZWQgPSB0aGlzLnRhYmxlUm93SW5kZXhDdXJyRXhwYW5kZWQ7XHJcbiAgICAgIGlmICh0aGlzLl9leHBhbmRlclRhYmxlW2luZGV4XSkge1xyXG4gICAgICAgIHRoaXMudGFibGVSb3dJbmRleEN1cnJFeHBhbmRlZCA9IGluZGV4O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMudGFibGVSb3dJbmRleEN1cnJFeHBhbmRlZCA9IC0xO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLndhcm4oJ1RoZSBpbmRleCBpcyBncmVhdGVyIHRoYW4gdGhlIHRhYmxlIGxlbmd0aCAnICsgaW5kZXggKyAnICcgKyB0aGlzLl9leHBhbmRlclRhYmxlLmxlbmd0aCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb2xsYXBzZXMgYWxsIHRoZSB0YWJsZSByb3dzLiBJZ25vcmVzIGFueSBlcnJvciBzdGF0ZXMgaW4gdGhlIGRldGFpbHMuXHJcbiAgICovXHJcbiAgcHVibGljIGNvbGxhcHNlVGFibGVSb3dzKCkge1xyXG4gICAgZm9yICggbGV0IHJlYyBvZiB0aGlzLl9leHBhbmRlclRhYmxlKSB7XHJcbiAgICAgIHJlYyA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgdGhpcy50YWJsZVJvd0luZGV4UHJlRXhwYW5kZWQgPSB0aGlzLnRhYmxlUm93SW5kZXhDdXJyRXhwYW5kZWQ7XHJcbiAgICB0aGlzLnRhYmxlUm93SW5kZXhDdXJyRXhwYW5kZWQgPSAtMTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldCB0aGUgcm93IHRpdGxlIGR5bmFtaWMgYWNjb3JkaW5nIHRvIHRoZSBleHBhbmQvY29sbGFwc2Ugc3RhdHVzXHJcbiAgICovXHJcbiBwdWJsaWMgZ2V0Um93VGl0bGUoaSkge1xyXG4gICBpZiAodGhpcy5pc0NvbGxhcHNlZChpKSkge1xyXG4gICAgIHJldHVybiAnRXhwYW5kIFJvdyAnICsgKGkgKyAxKTtcclxuICAgfSBlbHNlIGlmICh0aGlzLmlzRXhwYW5kZWQoaSkpIHtcclxuICAgICByZXR1cm4gJ0NvbGxhcHNlIFJvdyAnICsgKGkgKyAxKTtcclxuICAgfVxyXG4gICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbiIsIjxuZy1jb250YWluZXIgKm5nRm9yPVwibGV0IHJlY29yZCBvZiBkYXRhSXRlbXM7IGluZGV4IGFzIGk7XCI+XHJcbiAgPGRpdiByb2xlPVwiYnV0dG9uXCIgPlxyXG4gICAgPGg0IGlkPVwidHItZXhwYW5kLXJvdy17e2l9fVwiIGNsYXNzPVwiY2xpY2thYmxlUm93XCIgW25nQ2xhc3NdPVwieydzZWxlY3RlZCc6aXNFeHBhbmRlZChpKX1cIlxyXG4gICAgICBbYXR0ci5hcmlhLWV4cGFuZGVkXT1cImdldEV4cGFuZGVkU3RhdGUoaSlcIiBpMThuLXRpdGxlPVwiQEBleHBhbmRlci5yb3dUaXRsZVwiIFt0aXRsZV09XCJnZXRSb3dUaXRsZShpKVwiXHJcbiAgICAgIChjbGljayk9XCJzZWxlY3RUYWJsZVJvdyhpKVwiPlxyXG4gICAgICA8c3BhbiBjbGFzcz1cImZhIGZhLWxnIGZhLWZ3XCIgW25nQ2xhc3NdPVwieydmYS1jYXJldC1yaWdodCc6aXNDb2xsYXBzZWQoaSksICdmYS1jYXJldC1kb3duJzppc0V4cGFuZGVkKGkpIH1cIj48L3NwYW4+XHJcbiAgICAgIHt7YWNjb3JkaW9uSGVhZGluZ01zZ0tleSB8IHRyYW5zbGF0ZX19Jm5ic3A7IHt7ICtyZWNvcmRbJ2lkJ10rMSB9fVxyXG4gICAgPC9oND5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzcz1cInRhYmxlLW92ZXJyaWRlXCIgKm5nSWY9XCJpc0V4cGFuZGVkKGkpXCI+XHJcbiAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XHJcbiAgPC9kaXY+XHJcbjwvbmctY29udGFpbmVyPiJdfQ==