import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../utils/utils.service";
/**
 * form data/output data converter/mapper
 */
export class ConverterService {
    constructor(_utilsService) {
        this._utilsService = _utilsService;
    }
    convertCodeToIdTextLabel(codeObj, lang) {
        if (codeObj === undefined || codeObj === null) {
            return null;
        }
        else {
            const idTextLabelObj = {};
            idTextLabelObj.__text = this._utilsService.isFrench(lang) ? codeObj.fr : codeObj.en;
            idTextLabelObj._id = codeObj.id;
            idTextLabelObj._label_en = codeObj.en;
            idTextLabelObj._label_fr = codeObj.fr;
            return idTextLabelObj;
        }
    }
    convertCodeToCheckboxOption(codeObj, lang) {
        if (codeObj === undefined || codeObj === null) {
            return null;
        }
        else {
            const checkboxOption = {};
            checkboxOption.value = codeObj.id;
            checkboxOption.label = this._utilsService.isFrench(lang) ? codeObj.fr : codeObj.en;
            checkboxOption.checked = false;
            return checkboxOption;
        }
    }
    // find a ICode in a ICodeList and convert it to an IdTextLabel object
    findAndConverCodeToIdTextLabel(codeList, controlVal, lang) {
        // filter a CodeList by a form control value
        const codeVal = this._utilsService.findCodeById(codeList, controlVal);
        // if found, convert the Code value to an IIdTextLabel object and return it, otherwise return null
        return codeVal ? this.convertCodeToIdTextLabel(codeVal, lang) : null;
    }
    // loop through the controlVals and find it's each and every value in a ICodeList and convert it to an IdTextLabel object 
    // return an IdTextLabel[]
    findAndConverCodesToIdTextLabels(codeList, controlVals, lang) {
        let idTextLabels = [];
        for (const controlVal of controlVals) {
            const temp = this.findAndConverCodeToIdTextLabel(codeList, controlVal, lang);
            if (temp) {
                idTextLabels.push(temp);
            }
            else {
                console.error("ConverterService", "findAndConverCodesToIdTextLabels", `couldn't find '${controlVal}' in codeList`);
                return null;
            }
        }
        return idTextLabels;
    }
    // takes an array of codes and iterates through it, 
    // for each codes, finds the index of the corresponding option in optionList,
    // it the option is found, sets the values of the corresponding checkbox in checkboxFormArray to true
    checkCheckboxes(loadedCodes, optionList, checkboxFormArray) {
        loadedCodes.forEach(id => {
            const index = optionList.findIndex(option => option.value === id);
            if (index !== -1) {
                checkboxFormArray.controls[index].setValue(true);
            }
        });
    }
    getCheckedCheckboxValues(optionList, checkboxFormArray) {
        return optionList
            .filter((item, idx) => checkboxFormArray.controls.some((control, controlIdx) => idx === controlIdx && control.value))
            .map(item => item.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ConverterService, deps: [{ token: i1.UtilsService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ConverterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ConverterService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udmVydGVyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9jb252ZXJ0ZXIvY29udmVydGVyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7O0FBUTNDOztHQUVHO0FBQ0gsTUFBTSxPQUFPLGdCQUFnQjtJQUUzQixZQUFvQixhQUEyQjtRQUEzQixrQkFBYSxHQUFiLGFBQWEsQ0FBYztJQUFFLENBQUM7SUFFbEQsd0JBQXdCLENBQUMsT0FBYyxFQUFFLElBQVk7UUFDbkQsSUFBSSxPQUFPLEtBQUssU0FBUyxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUM5QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxjQUFjLEdBQUcsRUFBa0IsQ0FBQztZQUMxQyxjQUFjLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ3BGLGNBQWMsQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNoQyxjQUFjLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDdEMsY0FBYyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sY0FBYyxDQUFDO1FBQ3hCLENBQUM7SUFDSCxDQUFDO0lBRUQsMkJBQTJCLENBQUMsT0FBYyxFQUFFLElBQVk7UUFDdEQsSUFBSSxPQUFPLEtBQUssU0FBUyxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUM5QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxjQUFjLEdBQUcsRUFBb0IsQ0FBQztZQUM1QyxjQUFjLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDbEMsY0FBYyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNuRixjQUFjLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztZQUMvQixPQUFPLGNBQWMsQ0FBQztRQUN4QixDQUFDO0lBQ0gsQ0FBQztJQUVELHNFQUFzRTtJQUN0RSw4QkFBOEIsQ0FBQyxRQUFpQixFQUFFLFVBQWtCLEVBQUUsSUFBWTtRQUNoRiw0Q0FBNEM7UUFDNUMsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ3RFLGtHQUFrRztRQUNsRyxPQUFPLE9BQU8sQ0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ3RFLENBQUM7SUFFRCwwSEFBMEg7SUFDMUgsMEJBQTBCO0lBQzFCLGdDQUFnQyxDQUFDLFFBQWlCLEVBQUUsV0FBcUIsRUFBRSxJQUFZO1FBQ3JGLElBQUksWUFBWSxHQUFtQixFQUFFLENBQUM7UUFDdEMsS0FBSyxNQUFNLFVBQVUsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNyQyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsUUFBUSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM3RSxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUNULFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDMUIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0JBQWtCLEVBQUUsa0NBQWtDLEVBQUUsa0JBQWtCLFVBQVUsZUFBZSxDQUFDLENBQUM7Z0JBQ25ILE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRUQsb0RBQW9EO0lBQ3BELDZFQUE2RTtJQUM3RSxxR0FBcUc7SUFDckcsZUFBZSxDQUFDLFdBQXFCLEVBQUUsVUFBNEIsRUFBRSxpQkFBNEI7UUFDL0YsV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUN2QixNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxFQUFFLENBQUMsQ0FBQztZQUNsRSxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNqQixpQkFBaUIsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ25ELENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCx3QkFBd0IsQ0FBQyxVQUE0QixFQUFFLGlCQUE0QjtRQUNqRixPQUFPLFVBQVU7YUFDZCxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxFQUFFLENBQUMsR0FBRyxLQUFLLFVBQVUsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDcEgsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzdCLENBQUM7OEdBckVVLGdCQUFnQjtrSEFBaEIsZ0JBQWdCOzsyRkFBaEIsZ0JBQWdCO2tCQUo1QixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJQ29kZSB9IGZyb20gJy4uL2RhdGEtbG9hZGVyL2RhdGEnO1xyXG5pbXBvcnQgeyBJSWRUZXh0TGFiZWwgfSBmcm9tICcuLi9tb2RlbC9lbnRpdHktYmFzZSc7XHJcbmltcG9ydCB7IFV0aWxzU2VydmljZSB9IGZyb20gJy4uL3V0aWxzL3V0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDaGVja2JveE9wdGlvbiB9IGZyb20gJy4uL21vZGVsL2Zvcm0tbW9kZWwnO1xyXG5pbXBvcnQgeyBGb3JtQXJyYXksIEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuLyoqXHJcbiAqIGZvcm0gZGF0YS9vdXRwdXQgZGF0YSBjb252ZXJ0ZXIvbWFwcGVyXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgQ29udmVydGVyU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX3V0aWxzU2VydmljZTogVXRpbHNTZXJ2aWNlKXt9XHJcblxyXG4gIGNvbnZlcnRDb2RlVG9JZFRleHRMYWJlbChjb2RlT2JqOiBJQ29kZSwgbGFuZzogc3RyaW5nKTogSUlkVGV4dExhYmVsIHtcclxuICAgIGlmIChjb2RlT2JqID09PSB1bmRlZmluZWQgfHwgY29kZU9iaiA9PT0gbnVsbCkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IGlkVGV4dExhYmVsT2JqID0ge30gYXMgSUlkVGV4dExhYmVsO1xyXG4gICAgICBpZFRleHRMYWJlbE9iai5fX3RleHQgPSB0aGlzLl91dGlsc1NlcnZpY2UuaXNGcmVuY2gobGFuZykgPyBjb2RlT2JqLmZyIDogY29kZU9iai5lbjtcclxuICAgICAgaWRUZXh0TGFiZWxPYmouX2lkID0gY29kZU9iai5pZDtcclxuICAgICAgaWRUZXh0TGFiZWxPYmouX2xhYmVsX2VuID0gY29kZU9iai5lbjtcclxuICAgICAgaWRUZXh0TGFiZWxPYmouX2xhYmVsX2ZyID0gY29kZU9iai5mcjtcclxuICAgICAgcmV0dXJuIGlkVGV4dExhYmVsT2JqO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29udmVydENvZGVUb0NoZWNrYm94T3B0aW9uKGNvZGVPYmo6IElDb2RlLCBsYW5nOiBzdHJpbmcpOiBDaGVja2JveE9wdGlvbiB7XHJcbiAgICBpZiAoY29kZU9iaiA9PT0gdW5kZWZpbmVkIHx8IGNvZGVPYmogPT09IG51bGwpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBjaGVja2JveE9wdGlvbiA9IHt9IGFzIENoZWNrYm94T3B0aW9uO1xyXG4gICAgICBjaGVja2JveE9wdGlvbi52YWx1ZSA9IGNvZGVPYmouaWQ7XHJcbiAgICAgIGNoZWNrYm94T3B0aW9uLmxhYmVsID0gdGhpcy5fdXRpbHNTZXJ2aWNlLmlzRnJlbmNoKGxhbmcpID8gY29kZU9iai5mciA6IGNvZGVPYmouZW47XHJcbiAgICAgIGNoZWNrYm94T3B0aW9uLmNoZWNrZWQgPSBmYWxzZTtcclxuICAgICAgcmV0dXJuIGNoZWNrYm94T3B0aW9uO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gZmluZCBhIElDb2RlIGluIGEgSUNvZGVMaXN0IGFuZCBjb252ZXJ0IGl0IHRvIGFuIElkVGV4dExhYmVsIG9iamVjdFxyXG4gIGZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChjb2RlTGlzdDogSUNvZGVbXSwgY29udHJvbFZhbDogc3RyaW5nLCBsYW5nOiBzdHJpbmcpOiBJSWRUZXh0TGFiZWwge1xyXG4gICAgLy8gZmlsdGVyIGEgQ29kZUxpc3QgYnkgYSBmb3JtIGNvbnRyb2wgdmFsdWVcclxuICAgIGNvbnN0IGNvZGVWYWwgPSB0aGlzLl91dGlsc1NlcnZpY2UuZmluZENvZGVCeUlkKGNvZGVMaXN0LCBjb250cm9sVmFsKTtcclxuICAgIC8vIGlmIGZvdW5kLCBjb252ZXJ0IHRoZSBDb2RlIHZhbHVlIHRvIGFuIElJZFRleHRMYWJlbCBvYmplY3QgYW5kIHJldHVybiBpdCwgb3RoZXJ3aXNlIHJldHVybiBudWxsXHJcbiAgICByZXR1cm4gY29kZVZhbD8gdGhpcy5jb252ZXJ0Q29kZVRvSWRUZXh0TGFiZWwoY29kZVZhbCwgbGFuZykgOiBudWxsO1xyXG4gIH1cclxuXHJcbiAgLy8gbG9vcCB0aHJvdWdoIHRoZSBjb250cm9sVmFscyBhbmQgZmluZCBpdCdzIGVhY2ggYW5kIGV2ZXJ5IHZhbHVlIGluIGEgSUNvZGVMaXN0IGFuZCBjb252ZXJ0IGl0IHRvIGFuIElkVGV4dExhYmVsIG9iamVjdCBcclxuICAvLyByZXR1cm4gYW4gSWRUZXh0TGFiZWxbXVxyXG4gIGZpbmRBbmRDb252ZXJDb2Rlc1RvSWRUZXh0TGFiZWxzKGNvZGVMaXN0OiBJQ29kZVtdLCBjb250cm9sVmFsczogc3RyaW5nW10sIGxhbmc6IHN0cmluZyk6IElJZFRleHRMYWJlbFtdIHtcclxuICAgIGxldCBpZFRleHRMYWJlbHM6IElJZFRleHRMYWJlbFtdID0gW107XHJcbiAgICBmb3IgKGNvbnN0IGNvbnRyb2xWYWwgb2YgY29udHJvbFZhbHMpIHtcclxuICAgICAgY29uc3QgdGVtcCA9IHRoaXMuZmluZEFuZENvbnZlckNvZGVUb0lkVGV4dExhYmVsKGNvZGVMaXN0LCBjb250cm9sVmFsLCBsYW5nKTtcclxuICAgICAgaWYgKHRlbXApIHtcclxuICAgICAgICBpZFRleHRMYWJlbHMucHVzaCh0ZW1wKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ29udmVydGVyU2VydmljZVwiLCBcImZpbmRBbmRDb252ZXJDb2Rlc1RvSWRUZXh0TGFiZWxzXCIsIGBjb3VsZG4ndCBmaW5kICcke2NvbnRyb2xWYWx9JyBpbiBjb2RlTGlzdGApO1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9XHJcbiAgICB9IFxyXG4gICAgcmV0dXJuIGlkVGV4dExhYmVscztcclxuICB9XHJcblxyXG4gIC8vIHRha2VzIGFuIGFycmF5IG9mIGNvZGVzIGFuZCBpdGVyYXRlcyB0aHJvdWdoIGl0LCBcclxuICAvLyBmb3IgZWFjaCBjb2RlcywgZmluZHMgdGhlIGluZGV4IG9mIHRoZSBjb3JyZXNwb25kaW5nIG9wdGlvbiBpbiBvcHRpb25MaXN0LFxyXG4gIC8vIGl0IHRoZSBvcHRpb24gaXMgZm91bmQsIHNldHMgdGhlIHZhbHVlcyBvZiB0aGUgY29ycmVzcG9uZGluZyBjaGVja2JveCBpbiBjaGVja2JveEZvcm1BcnJheSB0byB0cnVlXHJcbiAgY2hlY2tDaGVja2JveGVzKGxvYWRlZENvZGVzOiBzdHJpbmdbXSwgb3B0aW9uTGlzdDogQ2hlY2tib3hPcHRpb25bXSwgY2hlY2tib3hGb3JtQXJyYXk6IEZvcm1BcnJheSkgOiB2b2lkIHtcclxuICAgIGxvYWRlZENvZGVzLmZvckVhY2goaWQgPT4ge1xyXG4gICAgICBjb25zdCBpbmRleCA9IG9wdGlvbkxpc3QuZmluZEluZGV4KG9wdGlvbiA9PiBvcHRpb24udmFsdWUgPT09IGlkKTtcclxuICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xyXG4gICAgICAgIGNoZWNrYm94Rm9ybUFycmF5LmNvbnRyb2xzW2luZGV4XS5zZXRWYWx1ZSh0cnVlKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBnZXRDaGVja2VkQ2hlY2tib3hWYWx1ZXMob3B0aW9uTGlzdDogQ2hlY2tib3hPcHRpb25bXSwgY2hlY2tib3hGb3JtQXJyYXk6IEZvcm1BcnJheSkgOiBzdHJpbmdbXXtcclxuICAgIHJldHVybiBvcHRpb25MaXN0XHJcbiAgICAgIC5maWx0ZXIoKGl0ZW0sIGlkeCkgPT4gY2hlY2tib3hGb3JtQXJyYXkuY29udHJvbHMuc29tZSgoY29udHJvbCwgY29udHJvbElkeCkgPT4gaWR4ID09PSBjb250cm9sSWR4ICYmIGNvbnRyb2wudmFsdWUpKVxyXG4gICAgICAubWFwKGl0ZW0gPT4gaXRlbS52YWx1ZSk7XHJcbiAgfVxyXG5cclxufSJdfQ==