import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class NoCacheHeadersInterceptor {
    intercept(req, next) {
        const httpRequest = req.clone({
            headers: req.headers
                .set('Cache-Control', 'no-cache')
                .set('Pragma', 'no-cache')
                .set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT')
        });
        // console.log(httpRequest.headers);
        return next.handle(httpRequest);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: NoCacheHeadersInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: NoCacheHeadersInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: NoCacheHeadersInterceptor, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUuaW50ZXJjZXB0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9pbnRlcmNlcHRvci9jYWNoZS5pbnRlcmNlcHRvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUczQyxNQUFNLE9BQU8seUJBQXlCO0lBQ3RDLFNBQVMsQ0FBQyxHQUFxQixFQUFFLElBQWlCO1FBQzlDLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7WUFDNUIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxPQUFPO2lCQUNqQixHQUFHLENBQUMsZUFBZSxFQUFFLFVBQVUsQ0FBQztpQkFDaEMsR0FBRyxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUM7aUJBQ3pCLEdBQUcsQ0FBQyxTQUFTLEVBQUUsK0JBQStCLENBQUM7U0FDbkQsQ0FBQyxDQUFBO1FBQ0Ysb0NBQW9DO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNsQyxDQUFDOytHQVZVLHlCQUF5QjttSEFBekIseUJBQXlCOzs0RkFBekIseUJBQXlCO2tCQURyQyxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSHR0cEhhbmRsZXIsIEh0dHBIZWFkZXJzLCBIdHRwSW50ZXJjZXB0b3IsIEh0dHBSZXF1ZXN0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBOb0NhY2hlSGVhZGVyc0ludGVyY2VwdG9yIGltcGxlbWVudHMgSHR0cEludGVyY2VwdG9yIHtcclxuaW50ZXJjZXB0KHJlcTogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpIHtcclxuICAgIGNvbnN0IGh0dHBSZXF1ZXN0ID0gcmVxLmNsb25lKHtcclxuICAgICAgaGVhZGVyczogcmVxLmhlYWRlcnNcclxuICAgICAgICAuc2V0KCdDYWNoZS1Db250cm9sJywgJ25vLWNhY2hlJylcclxuICAgICAgICAuc2V0KCdQcmFnbWEnLCAnbm8tY2FjaGUnKVxyXG4gICAgICAgIC5zZXQoJ0V4cGlyZXMnLCAnU2F0LCAwMSBKYW4gMjAwMCAwMDowMDowMCBHTVQnKVxyXG4gICAgfSlcclxuICAgIC8vIGNvbnNvbGUubG9nKGh0dHBSZXF1ZXN0LmhlYWRlcnMpO1xyXG4gICAgcmV0dXJuIG5leHQuaGFuZGxlKGh0dHBSZXF1ZXN0KTtcclxuICB9XHJcbn0iXX0=