import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
export class RoutingService {
    constructor(router) {
        this.router = router;
    }
    navigateTo(path) {
        this.router.navigate([path]);
    }
    navigateToWithExtra(path, stateData) {
        this.router.navigate([path], { state: stateData });
    }
    getStateData(propertyKey) {
        const currentNavigation = this.router.getCurrentNavigation();
        if (currentNavigation && currentNavigation.extras.state) {
            return currentNavigation.extras.state[propertyKey];
        }
        console.info(`Property '${propertyKey}' not found in state.`);
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: RoutingService, deps: [{ token: i1.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: RoutingService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: RoutingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.Router }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGluZy5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvcm91dGluZy9yb3V0aW5nLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7O0FBTTNDLE1BQU0sT0FBTyxjQUFjO0lBRXpCLFlBQW9CLE1BQWM7UUFBZCxXQUFNLEdBQU4sTUFBTSxDQUFRO0lBQUksQ0FBQztJQUV2QyxVQUFVLENBQUMsSUFBWTtRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELG1CQUFtQixDQUFDLElBQVksRUFBRSxTQUF1QztRQUN2RSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVELFlBQVksQ0FBSSxXQUFtQjtRQUNqQyxNQUFNLGlCQUFpQixHQUFzQixJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDaEYsSUFBSSxpQkFBaUIsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDeEQsT0FBTyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBTSxDQUFDO1FBQzFELENBQUM7UUFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsV0FBVyx1QkFBdUIsQ0FBQyxDQUFDO1FBQzlELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQzs4R0FuQlUsY0FBYztrSEFBZCxjQUFjLGNBRmIsTUFBTTs7MkZBRVAsY0FBYztrQkFIMUIsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE5hdmlnYXRpb24sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBSb3V0aW5nU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGVyOiBSb3V0ZXIpIHsgfVxyXG5cclxuICBuYXZpZ2F0ZVRvKHBhdGg6IHN0cmluZykge1xyXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW3BhdGhdKTtcclxuICB9XHJcblxyXG4gIG5hdmlnYXRlVG9XaXRoRXh0cmEocGF0aDogc3RyaW5nLCBzdGF0ZURhdGE6IHtbcHJvcGVydHlLZXk6IHN0cmluZ106IGFueX0pIHtcclxuICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFtwYXRoXSwgeyBzdGF0ZTogc3RhdGVEYXRhIH0pO1xyXG4gIH1cclxuXHJcbiAgZ2V0U3RhdGVEYXRhPFQ+KHByb3BlcnR5S2V5OiBzdHJpbmcpOiBUIHtcclxuICAgIGNvbnN0IGN1cnJlbnROYXZpZ2F0aW9uOiBOYXZpZ2F0aW9uIHwgbnVsbCA9IHRoaXMucm91dGVyLmdldEN1cnJlbnROYXZpZ2F0aW9uKCk7XHJcbiAgICBpZiAoY3VycmVudE5hdmlnYXRpb24gJiYgY3VycmVudE5hdmlnYXRpb24uZXh0cmFzLnN0YXRlKSB7XHJcbiAgICAgIHJldHVybiBjdXJyZW50TmF2aWdhdGlvbi5leHRyYXMuc3RhdGVbcHJvcGVydHlLZXldIGFzIFQ7XHJcbiAgICB9XHJcbiAgICBjb25zb2xlLmluZm8oYFByb3BlcnR5ICcke3Byb3BlcnR5S2V5fScgbm90IGZvdW5kIGluIHN0YXRlLmApO1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG59XHJcbiJdfQ==