import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { FileConversionService } from '../file-io/file-conversion.service';
import { ConvertResults } from '../file-io/convert-results';
import { CHECK_SUM_CONST } from './check-sum-constants';
import * as i0 from "@angular/core";
export class CheckSumService {
    constructor() { }
    checkHash(convertResultData) {
        for (const key in convertResultData) {
            if (convertResultData.hasOwnProperty(key)) {
                for (const seckey in convertResultData[key]) {
                    if (convertResultData[key].hasOwnProperty(seckey)) {
                        if (seckey === CHECK_SUM_CONST) {
                            let hashFromFile = convertResultData[key][seckey];
                            convertResultData[key][seckey] = "";
                            let hash = CryptoJS.MD5(JSON.stringify(convertResultData));
                            if (hash.toString(CryptoJS.enc.MD5) === hashFromFile) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
    createHash(result) {
        let fileConversion = new FileConversionService();
        let xResult = fileConversion.convertJSONObjectsToXML(result);
        let cr = new ConvertResults();
        fileConversion.convertXMLToJSONObjects(xResult, cr);
        result = cr.data;
        const hash = CryptoJS.MD5(JSON.stringify(result));
        return hash.toString(CryptoJS.enc.MD5);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: CheckSumService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: CheckSumService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: CheckSumService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2stc3VtLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9jaGVjay1zdW0vY2hlY2stc3VtLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFRLEtBQUssUUFBUSxNQUFNLFdBQVcsQ0FBQztBQUN2QyxPQUFPLEVBQUMscUJBQXFCLEVBQUMsTUFBTSxvQ0FBb0MsQ0FBQztBQUN6RSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDNUQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHVCQUF1QixDQUFDOztBQU14RCxNQUFNLE9BQU8sZUFBZTtJQUUxQixnQkFBZSxDQUFDO0lBRWhCLFNBQVMsQ0FBQyxpQkFBc0I7UUFFOUIsS0FBSSxNQUFNLEdBQUcsSUFBSSxpQkFBaUIsRUFBQyxDQUFDO1lBRWxDLElBQUcsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUM7Z0JBRXhDLEtBQUksTUFBTSxNQUFNLElBQUksaUJBQWlCLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQztvQkFFMUMsSUFBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQzt3QkFFaEQsSUFBRyxNQUFNLEtBQUssZUFBZSxFQUFDLENBQUM7NEJBQzdCLElBQUksWUFBWSxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUNsRCxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUM7NEJBQ3BDLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7NEJBRTNELElBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFlBQVksRUFBQyxDQUFDO2dDQUNuRCxPQUFPLElBQUksQ0FBQzs0QkFDZCxDQUFDO3dCQUNILENBQUM7b0JBQ0gsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxVQUFVLENBQUMsTUFBVztRQUVwQixJQUFJLGNBQWMsR0FBRyxJQUFJLHFCQUFxQixFQUFFLENBQUM7UUFDakQsSUFBSSxPQUFPLEdBQUcsY0FBYyxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzdELElBQUksRUFBRSxHQUFtQixJQUFJLGNBQWMsRUFBRSxDQUFDO1FBRTlDLGNBQWMsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDcEQsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFFakIsTUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbEQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFFekMsQ0FBQzsrR0ExQ1UsZUFBZTttSEFBZixlQUFlLGNBSGQsTUFBTTs7NEZBR1AsZUFBZTtrQkFKM0IsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCAgKiBhcyBDcnlwdG9KUyBmcm9tICdjcnlwdG8tanMnO1xyXG5pbXBvcnQge0ZpbGVDb252ZXJzaW9uU2VydmljZX0gZnJvbSAnLi4vZmlsZS1pby9maWxlLWNvbnZlcnNpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IENvbnZlcnRSZXN1bHRzIH0gZnJvbSAnLi4vZmlsZS1pby9jb252ZXJ0LXJlc3VsdHMnO1xyXG5pbXBvcnQgeyBDSEVDS19TVU1fQ09OU1QgfSBmcm9tICcuL2NoZWNrLXN1bS1jb25zdGFudHMnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIENoZWNrU3VtU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge31cclxuXHJcbiAgY2hlY2tIYXNoKGNvbnZlcnRSZXN1bHREYXRhOiBhbnkpOiBCb29sZWFuIHtcclxuICAgIFxyXG4gICAgZm9yKGNvbnN0IGtleSBpbiBjb252ZXJ0UmVzdWx0RGF0YSl7XHJcblxyXG4gICAgICBpZihjb252ZXJ0UmVzdWx0RGF0YS5oYXNPd25Qcm9wZXJ0eShrZXkpKXtcclxuXHJcbiAgICAgICAgZm9yKGNvbnN0IHNlY2tleSBpbiBjb252ZXJ0UmVzdWx0RGF0YVtrZXldKXtcclxuXHJcbiAgICAgICAgICBpZihjb252ZXJ0UmVzdWx0RGF0YVtrZXldLmhhc093blByb3BlcnR5KHNlY2tleSkpe1xyXG5cclxuICAgICAgICAgICAgaWYoc2Vja2V5ID09PSBDSEVDS19TVU1fQ09OU1Qpe1xyXG4gICAgICAgICAgICAgIGxldCBoYXNoRnJvbUZpbGUgPSBjb252ZXJ0UmVzdWx0RGF0YVtrZXldW3NlY2tleV07XHJcbiAgICAgICAgICAgICAgY29udmVydFJlc3VsdERhdGFba2V5XVtzZWNrZXldID0gXCJcIjtcclxuICAgICAgICAgICAgICBsZXQgaGFzaCA9IENyeXB0b0pTLk1ENShKU09OLnN0cmluZ2lmeShjb252ZXJ0UmVzdWx0RGF0YSkpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgICBpZihoYXNoLnRvU3RyaW5nKENyeXB0b0pTLmVuYy5NRDUpID09PSBoYXNoRnJvbUZpbGUpe1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG5cclxuICBjcmVhdGVIYXNoKHJlc3VsdDogYW55KTogc3RyaW5ne1xyXG5cclxuICAgIGxldCBmaWxlQ29udmVyc2lvbiA9IG5ldyBGaWxlQ29udmVyc2lvblNlcnZpY2UoKTtcclxuICAgIGxldCB4UmVzdWx0ID0gZmlsZUNvbnZlcnNpb24uY29udmVydEpTT05PYmplY3RzVG9YTUwocmVzdWx0KTtcclxuICAgIGxldCBjcjogQ29udmVydFJlc3VsdHMgPSBuZXcgQ29udmVydFJlc3VsdHMoKTtcclxuXHJcbiAgICBmaWxlQ29udmVyc2lvbi5jb252ZXJ0WE1MVG9KU09OT2JqZWN0cyh4UmVzdWx0LCBjcik7XHJcbiAgICByZXN1bHQgPSBjci5kYXRhO1xyXG5cclxuICAgIGNvbnN0IGhhc2ggPSBDcnlwdG9KUy5NRDUoSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XHJcbiAgICByZXR1cm4gaGFzaC50b1N0cmluZyhDcnlwdG9KUy5lbmMuTUQ1KTtcclxuXHJcbiAgfVxyXG5cclxufSJdfQ==