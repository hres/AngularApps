import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export class CommonFormDendencyModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: CommonFormDendencyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: CommonFormDendencyModule, exports: [FormsModule, ReactiveFormsModule, TranslateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: CommonFormDendencyModule, imports: [FormsModule, ReactiveFormsModule, TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: CommonFormDendencyModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    exports: [FormsModule, ReactiveFormsModule, TranslateModule],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmZvcm0uZGVuZGVuY3kubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvY29tbW9uLmZvcm0uZGVuZGVuY3kubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFekMsT0FBTyxFQUFFLFdBQVcsRUFBRSxtQkFBbUIsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQzs7QUFNdEQsTUFBTSxPQUFPLHdCQUF3Qjs4R0FBeEIsd0JBQXdCOytHQUF4Qix3QkFBd0IsWUFGekIsV0FBVyxFQUFFLG1CQUFtQixFQUFFLGVBQWU7K0dBRWhELHdCQUF3QixZQUZ6QixXQUFXLEVBQUUsbUJBQW1CLEVBQUUsZUFBZTs7MkZBRWhELHdCQUF3QjtrQkFKcEMsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUUsRUFBRTtvQkFDaEIsT0FBTyxFQUFFLENBQUMsV0FBVyxFQUFFLG1CQUFtQixFQUFFLGVBQWUsQ0FBQztpQkFDN0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgVHJhbnNsYXRlTW9kdWxlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGRlY2xhcmF0aW9uczogW10sXHJcbiAgZXhwb3J0czogW0Zvcm1zTW9kdWxlLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBUcmFuc2xhdGVNb2R1bGVdLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgQ29tbW9uRm9ybURlbmRlbmN5TW9kdWxlIHt9XHJcblxyXG4vLyB0aGlzIGNsYXNzIGNvbnRhaW5zIGFsbCByZXF1aXJlZCBsaWJyYXJpZXMgdG8gYnVpbGQgcmVhY3RpdmUgZm9ybXMgd2l0aCBsYW5ndWFnZSB0cmFuc2xhdGlvbnMiXX0=