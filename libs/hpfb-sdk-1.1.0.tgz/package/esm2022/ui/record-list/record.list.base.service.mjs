export class RecordListBaseService {
    constructor() {
        /**
         * Used to create record ids
         * @type {number}
         * @private
         */
        this._indexValue = -1;
    }
    /**
     * Parses the current data and finds the largest ID
     * @public
     */
    initIndex(recordList) {
        this.resetIndex();
        for (let record of recordList) {
            if (record.id > this._indexValue) {
                this._indexValue = record.id;
            }
        }
        // console.log("The index value "+  this._indexValue)
    }
    /**
     * Gets the next record id
     * @returns {number}
     */
    getNextIndex() {
        this._indexValue++;
        // console.log("In list service get id "+ this._indexValue);
        return this._indexValue;
    }
    /**
     * Resets the index to the base value. Used for record ids
     */
    resetIndex() {
        this._indexValue = -1;
    }
    /**
     * Gets the current id value to use for a record
     * @returns {number}
     */
    getCurrentIndex() {
        return this._indexValue;
    }
    /**
     * Sets the record id to a value
     * @param {number} value
     */
    setIndex(value) {
        this._indexValue = value;
    }
    updateFormRecordListSeqNumber(formRecordList) {
        let seq = 0;
        formRecordList.controls.forEach((element) => {
            // console.log(element);
            element.controls['seqNumber'].setValue(seq + 1);
            seq++;
        });
    }
    /**
     * if formRecordIdToExpand is passed in, expand that record and collapse all other records;
     * otherwise, collapse all records
     *
     * @param formRecordList
     * @param formRecordIdToExpand optional
     */
    collapseFormRecordList(utilsService, formRecordList, formRecordIdToExpand) {
        formRecordList.controls.forEach((element) => {
            // console.log(element);
            if (!utilsService.isEmpty(formRecordIdToExpand) && (Number(element.controls['id'].value) === formRecordIdToExpand)) {
                element.controls['expandFlag'].setValue(true);
            }
            else {
                element.controls['expandFlag'].setValue(false);
            }
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb3JkLmxpc3QuYmFzZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvcmVjb3JkLWxpc3QvcmVjb3JkLmxpc3QuYmFzZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBLE1BQU0sT0FBZ0IscUJBQXFCO0lBU3pDO1FBUEE7Ozs7V0FJRztRQUNLLGdCQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFJekIsQ0FBQztJQUVEOzs7T0FHRztJQUNJLFNBQVMsQ0FBQyxVQUFVO1FBQ3pCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixLQUFLLElBQUksTUFBTSxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBQzlCLElBQUksTUFBTSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUMvQixDQUFDO1FBQ0gsQ0FBQztRQUNELHFEQUFxRDtJQUN2RCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsWUFBWTtRQUNWLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQiw0REFBNEQ7UUFDNUQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFFRDs7T0FFRztJQUNJLFVBQVU7UUFDZixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxlQUFlO1FBRWIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFFRDs7O09BR0c7SUFDSSxRQUFRLENBQUMsS0FBYTtRQUMzQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztJQUMzQixDQUFDO0lBRU0sNkJBQTZCLENBQUMsY0FBeUI7UUFDNUQsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ1osY0FBYyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUUsQ0FBQyxPQUFrQixFQUFFLEVBQUU7WUFDdEQsd0JBQXdCO1lBQ3hCLE9BQU8sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNoRCxHQUFHLEVBQUcsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLHNCQUFzQixDQUFDLFlBQTBCLEVBQUUsY0FBeUIsRUFBRSxvQkFBNkI7UUFDaEgsY0FBYyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUUsQ0FBQyxPQUFrQixFQUFFLEVBQUU7WUFDdEQsd0JBQXdCO1lBQ3hCLElBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxvQkFBb0IsQ0FBQyxFQUFHLENBQUM7Z0JBQ3JILE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2hELENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNqRCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBRUYiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGb3JtQXJyYXksIEZvcm1Hcm91cCB9IGZyb20gXCJAYW5ndWxhci9mb3Jtc1wiO1xyXG5pbXBvcnQgeyBVdGlsc1NlcnZpY2UgfSBmcm9tIFwiLi4vdXRpbHMvdXRpbHMuc2VydmljZVwiO1xyXG5cclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIFJlY29yZExpc3RCYXNlU2VydmljZSB7XHJcblxyXG4gIC8qKlxyXG4gICAqIFVzZWQgdG8gY3JlYXRlIHJlY29yZCBpZHNcclxuICAgKiBAdHlwZSB7bnVtYmVyfVxyXG4gICAqIEBwcml2YXRlXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBfaW5kZXhWYWx1ZSA9IC0xO1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBQYXJzZXMgdGhlIGN1cnJlbnQgZGF0YSBhbmQgZmluZHMgdGhlIGxhcmdlc3QgSURcclxuICAgKiBAcHVibGljXHJcbiAgICovXHJcbiAgcHVibGljIGluaXRJbmRleChyZWNvcmRMaXN0KSB7XHJcbiAgICB0aGlzLnJlc2V0SW5kZXgoKTtcclxuICAgIGZvciAobGV0IHJlY29yZCBvZiByZWNvcmRMaXN0KSB7XHJcbiAgICAgIGlmIChyZWNvcmQuaWQgPiB0aGlzLl9pbmRleFZhbHVlKSB7XHJcbiAgICAgICAgdGhpcy5faW5kZXhWYWx1ZSA9IHJlY29yZC5pZDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8gY29uc29sZS5sb2coXCJUaGUgaW5kZXggdmFsdWUgXCIrICB0aGlzLl9pbmRleFZhbHVlKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyB0aGUgbmV4dCByZWNvcmQgaWQgXHJcbiAgICogQHJldHVybnMge251bWJlcn1cclxuICAgKi9cclxuICBnZXROZXh0SW5kZXgoKSB7XHJcbiAgICB0aGlzLl9pbmRleFZhbHVlKys7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhcIkluIGxpc3Qgc2VydmljZSBnZXQgaWQgXCIrIHRoaXMuX2luZGV4VmFsdWUpO1xyXG4gICAgcmV0dXJuIHRoaXMuX2luZGV4VmFsdWU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXNldHMgdGhlIGluZGV4IHRvIHRoZSBiYXNlIHZhbHVlLiBVc2VkIGZvciByZWNvcmQgaWRzXHJcbiAgICovXHJcbiAgcHVibGljIHJlc2V0SW5kZXgoKSB7XHJcbiAgICB0aGlzLl9pbmRleFZhbHVlID0gLTE7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXRzIHRoZSBjdXJyZW50IGlkIHZhbHVlIHRvIHVzZSBmb3IgYSByZWNvcmRcclxuICAgKiBAcmV0dXJucyB7bnVtYmVyfVxyXG4gICAqL1xyXG4gIGdldEN1cnJlbnRJbmRleCgpIHtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5faW5kZXhWYWx1ZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNldHMgdGhlIHJlY29yZCBpZCB0byBhIHZhbHVlXHJcbiAgICogQHBhcmFtIHtudW1iZXJ9IHZhbHVlXHJcbiAgICovXHJcbiAgcHVibGljIHNldEluZGV4KHZhbHVlOiBudW1iZXIpIHtcclxuICAgIHRoaXMuX2luZGV4VmFsdWUgPSB2YWx1ZTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyB1cGRhdGVGb3JtUmVjb3JkTGlzdFNlcU51bWJlcihmb3JtUmVjb3JkTGlzdDogRm9ybUFycmF5KXtcclxuICAgIGxldCBzZXEgPSAwO1xyXG4gICAgZm9ybVJlY29yZExpc3QuY29udHJvbHMuZm9yRWFjaCggKGVsZW1lbnQ6IEZvcm1Hcm91cCkgPT4ge1xyXG4gICAgICAvLyBjb25zb2xlLmxvZyhlbGVtZW50KTtcclxuICAgICAgZWxlbWVudC5jb250cm9sc1snc2VxTnVtYmVyJ10uc2V0VmFsdWUoc2VxICsgMSk7XHJcbiAgICAgIHNlcSArKztcclxuICAgIH0pOyAgXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBpZiBmb3JtUmVjb3JkSWRUb0V4cGFuZCBpcyBwYXNzZWQgaW4sIGV4cGFuZCB0aGF0IHJlY29yZCBhbmQgY29sbGFwc2UgYWxsIG90aGVyIHJlY29yZHM7XHJcbiAgICogb3RoZXJ3aXNlLCBjb2xsYXBzZSBhbGwgcmVjb3Jkc1xyXG4gICAqIFxyXG4gICAqIEBwYXJhbSBmb3JtUmVjb3JkTGlzdCBcclxuICAgKiBAcGFyYW0gZm9ybVJlY29yZElkVG9FeHBhbmQgb3B0aW9uYWxcclxuICAgKi9cclxuICBwdWJsaWMgY29sbGFwc2VGb3JtUmVjb3JkTGlzdCh1dGlsc1NlcnZpY2U6IFV0aWxzU2VydmljZSwgZm9ybVJlY29yZExpc3Q6IEZvcm1BcnJheSwgZm9ybVJlY29yZElkVG9FeHBhbmQ/OiBudW1iZXIpe1xyXG4gICAgZm9ybVJlY29yZExpc3QuY29udHJvbHMuZm9yRWFjaCggKGVsZW1lbnQ6IEZvcm1Hcm91cCkgPT4ge1xyXG4gICAgICAvLyBjb25zb2xlLmxvZyhlbGVtZW50KTtcclxuICAgICAgaWYgKCAhdXRpbHNTZXJ2aWNlLmlzRW1wdHkoZm9ybVJlY29yZElkVG9FeHBhbmQpICYmIChOdW1iZXIoZWxlbWVudC5jb250cm9sc1snaWQnXS52YWx1ZSkgPT09IGZvcm1SZWNvcmRJZFRvRXhwYW5kKSApIHtcclxuICAgICAgICBlbGVtZW50LmNvbnRyb2xzWydleHBhbmRGbGFnJ10uc2V0VmFsdWUodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZWxlbWVudC5jb250cm9sc1snZXhwYW5kRmxhZyddLnNldFZhbHVlKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSk7ICBcclxuICB9XHJcblxyXG59XHJcblxyXG4iXX0=