import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { UtilsService } from './utils/utils.service';
import { VersionService } from './version/version.service';
import { LoggerService } from './logger/logger.service';
import { ConverterService } from './converter/converter.service';
import { EntityBaseService } from './model/entity-base.service';
import * as i0 from "@angular/core";
// import { BrowserModule } from '@angular/platform-browser';
export class CommonUiFeatureModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CommonUiFeatureModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.9", ngImport: i0, type: CommonUiFeatureModule, imports: [CommonModule,
            // BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            TranslateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CommonUiFeatureModule, providers: [
            UtilsService,
            VersionService,
            LoggerService,
            ConverterService,
            EntityBaseService,
        ], imports: [CommonModule,
            // BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CommonUiFeatureModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        FormsModule,
                        ReactiveFormsModule,
                        TranslateModule,
                    ],
                    providers: [
                        UtilsService,
                        VersionService,
                        LoggerService,
                        ConverterService,
                        EntityBaseService,
                    ],
                    exports: [],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLnVpLmZlYXR1cmUubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvY29tbW9uLnVpLmZlYXR1cmUubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxXQUFXLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNsRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDdEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDeEQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDakUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sNkJBQTZCLENBQUM7O0FBQ2hFLDZEQUE2RDtBQXVCN0QsTUFBTSxPQUFPLHFCQUFxQjs4R0FBckIscUJBQXFCOytHQUFyQixxQkFBcUIsWUFqQjlCLFlBQVk7WUFDWixpQkFBaUI7WUFDakIsV0FBVztZQUNYLG1CQUFtQjtZQUNuQixlQUFlOytHQWFOLHFCQUFxQixhQVhyQjtZQUNULFlBQVk7WUFDWixjQUFjO1lBQ2QsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQixpQkFBaUI7U0FDbEIsWUFaQyxZQUFZO1lBQ1osaUJBQWlCO1lBQ2pCLFdBQVc7WUFDWCxtQkFBbUI7WUFDbkIsZUFBZTs7MkZBYU4scUJBQXFCO2tCQXJCakMsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUUsRUFDYjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsWUFBWTt3QkFDWixpQkFBaUI7d0JBQ2pCLFdBQVc7d0JBQ1gsbUJBQW1CO3dCQUNuQixlQUFlO3FCQUNoQjtvQkFDRCxTQUFTLEVBQUU7d0JBQ1QsWUFBWTt3QkFDWixjQUFjO3dCQUNkLGFBQWE7d0JBQ2IsZ0JBQWdCO3dCQUNoQixpQkFBaUI7cUJBQ2xCO29CQUNELE9BQU8sRUFBRSxFQUVSO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgRm9ybXNNb2R1bGUsIFJlYWN0aXZlRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IFRyYW5zbGF0ZU1vZHVsZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xyXG5pbXBvcnQgeyBVdGlsc1NlcnZpY2UgfSBmcm9tICcuL3V0aWxzL3V0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBWZXJzaW9uU2VydmljZSB9IGZyb20gJy4vdmVyc2lvbi92ZXJzaW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMb2dnZXJTZXJ2aWNlIH0gZnJvbSAnLi9sb2dnZXIvbG9nZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDb252ZXJ0ZXJTZXJ2aWNlIH0gZnJvbSAnLi9jb252ZXJ0ZXIvY29udmVydGVyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBFbnRpdHlCYXNlU2VydmljZSB9IGZyb20gJy4vbW9kZWwvZW50aXR5LWJhc2Uuc2VydmljZSc7XHJcbi8vIGltcG9ydCB7IEJyb3dzZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgXSxcclxuICBpbXBvcnRzOiBbXHJcbiAgICBDb21tb25Nb2R1bGUsXHJcbiAgICAvLyBCcm93c2VyTW9kdWxlLFxyXG4gICAgRm9ybXNNb2R1bGUsXHJcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gICAgVHJhbnNsYXRlTW9kdWxlLFxyXG4gIF0sXHJcbiAgcHJvdmlkZXJzOiBbXHJcbiAgICBVdGlsc1NlcnZpY2UsXHJcbiAgICBWZXJzaW9uU2VydmljZSxcclxuICAgIExvZ2dlclNlcnZpY2UsXHJcbiAgICBDb252ZXJ0ZXJTZXJ2aWNlLFxyXG4gICAgRW50aXR5QmFzZVNlcnZpY2UsXHJcbiAgXSxcclxuICBleHBvcnRzOiBbXHJcblxyXG4gIF0sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDb21tb25VaUZlYXR1cmVNb2R1bGUge31cclxuIl19