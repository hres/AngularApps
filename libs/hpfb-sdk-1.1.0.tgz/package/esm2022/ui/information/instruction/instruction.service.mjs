import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class InstructionService {
    constructor() {
        this.helpTextIndx = {};
    }
    /**
     * Sets the Help Text Index
     *
     * instructionHeadings should be a list
     * @deprecated Use `createtHelpTextIndex` instead
     */
    getHelpTextIndex(instructionHeadings) {
        for (let i = 0; i < instructionHeadings.length; i++) {
            this.helpTextIndx[instructionHeadings[i]] = i + 1;
        }
        // console.log(this.helpTextIndx);
        return this.helpTextIndx;
    }
    createHelpSequence(prefix, suffix, instructionHeadings) {
        return instructionHeadings.reduce((acc, heading, index) => {
            const sequence = index + 1;
            acc[heading] = [
                sequence, // Help text sequence
                `${prefix}${sequence}`, // Definition description (dd) id, eg tr1
                `${prefix}${sequence}${suffix}` // Superscript (sup) id, eg tr1-rf
            ];
            return acc;
        }, {});
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: InstructionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: InstructionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: InstructionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5zdHJ1Y3Rpb24uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2luZm9ybWF0aW9uL2luc3RydWN0aW9uL2luc3RydWN0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHM0MsTUFBTSxPQUFPLGtCQUFrQjtJQUU3QjtRQURRLGlCQUFZLEdBQWMsRUFBRSxDQUFDO0lBRXJDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGdCQUFnQixDQUFDLG1CQUF5QjtRQUV4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDcEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEQsQ0FBQztRQUNELGtDQUFrQztRQUNsQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDM0IsQ0FBQztJQUVELGtCQUFrQixDQUFDLE1BQWMsRUFBRSxNQUFjLEVBQUUsbUJBQTZCO1FBQzlFLE9BQU8sbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUN4RCxNQUFNLFFBQVEsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1lBQzNCLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRztnQkFDYixRQUFRLEVBQXNCLHFCQUFxQjtnQkFDbkQsR0FBRyxNQUFNLEdBQUcsUUFBUSxFQUFFLEVBQVEseUNBQXlDO2dCQUN2RSxHQUFHLE1BQU0sR0FBRyxRQUFRLEdBQUcsTUFBTSxFQUFFLENBQUMsa0NBQWtDO2FBQ25FLENBQUM7WUFDRixPQUFPLEdBQUcsQ0FBQztRQUNiLENBQUMsRUFBRSxFQUFrQixDQUFDLENBQUM7SUFDekIsQ0FBQzs4R0E5QlUsa0JBQWtCO2tIQUFsQixrQkFBa0I7OzJGQUFsQixrQkFBa0I7a0JBRDlCLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBJbnN0cnVjdGlvblNlcnZpY2Uge1xyXG4gIHByaXZhdGUgaGVscFRleHRJbmR4OiBIZWxwSW5kZXggPSB7fTtcclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNldHMgdGhlIEhlbHAgVGV4dCBJbmRleFxyXG4gICAqXHJcbiAgICogaW5zdHJ1Y3Rpb25IZWFkaW5ncyBzaG91bGQgYmUgYSBsaXN0XHJcbiAgICogQGRlcHJlY2F0ZWQgVXNlIGBjcmVhdGV0SGVscFRleHRJbmRleGAgaW5zdGVhZFxyXG4gICAqL1xyXG4gIGdldEhlbHBUZXh0SW5kZXgoaW5zdHJ1Y3Rpb25IZWFkaW5ncyA6IGFueSkgeyBcclxuXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluc3RydWN0aW9uSGVhZGluZ3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgdGhpcy5oZWxwVGV4dEluZHhbaW5zdHJ1Y3Rpb25IZWFkaW5nc1tpXV0gPSBpICsgMTtcclxuICAgIH1cclxuICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuaGVscFRleHRJbmR4KTtcclxuICAgIHJldHVybiB0aGlzLmhlbHBUZXh0SW5keDtcclxuICB9XHJcblxyXG4gIGNyZWF0ZUhlbHBTZXF1ZW5jZShwcmVmaXg6IHN0cmluZywgc3VmZml4OiBzdHJpbmcsIGluc3RydWN0aW9uSGVhZGluZ3M6IHN0cmluZ1tdKTogSGVscFNlcXVlbmNlIHtcclxuICAgIHJldHVybiBpbnN0cnVjdGlvbkhlYWRpbmdzLnJlZHVjZSgoYWNjLCBoZWFkaW5nLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBzZXF1ZW5jZSA9IGluZGV4ICsgMTtcclxuICAgICAgYWNjW2hlYWRpbmddID0gW1xyXG4gICAgICAgIHNlcXVlbmNlLCAgICAgICAgICAgICAgICAgICAgIC8vIEhlbHAgdGV4dCBzZXF1ZW5jZVxyXG4gICAgICAgIGAke3ByZWZpeH0ke3NlcXVlbmNlfWAsICAgICAgIC8vIERlZmluaXRpb24gZGVzY3JpcHRpb24gKGRkKSBpZCwgZWcgdHIxXHJcbiAgICAgICAgYCR7cHJlZml4fSR7c2VxdWVuY2V9JHtzdWZmaXh9YCAvLyBTdXBlcnNjcmlwdCAoc3VwKSBpZCwgZWcgdHIxLXJmXHJcbiAgICAgIF07XHJcbiAgICAgIHJldHVybiBhY2M7XHJcbiAgICB9LCB7fSBhcyBIZWxwU2VxdWVuY2UpO1xyXG4gIH1cclxuXHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAZGVwcmVjYXRlZCBVc2UgYEhlbHBTZXF1ZW5jZWAgaW5zdGVhZFxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBIZWxwSW5kZXgge1xyXG4gIFtrZXk6IHN0cmluZ106IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBIZWxwU2VxdWVuY2Uge1xyXG4gIFtrZXk6IHN0cmluZ106IFtudW1iZXIsIHN0cmluZywgc3RyaW5nXTsgLy8gaGVscCB0ZXh0IHNlcXVlbmNlIGF0IGluZGV4IDAsIGRlZmluaXRpb24gZGVzY3JpcHRpb24gKGRkKSBpZCBhdCBpbmRleCAxIGFuZCBzdXBlcnNjcmlwdChzdXApIGlkIGF0IGluZGV4IDJcclxufVxyXG4iXX0=