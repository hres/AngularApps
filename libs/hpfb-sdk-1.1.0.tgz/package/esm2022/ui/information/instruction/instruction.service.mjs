import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class InstructionService {
    constructor() {
        this.helpTextIndx = {};
    }
    /**
     * Sets the Help Text Index
     *
     * instructionHeadings should be a list
     */
    getHelpTextIndex(instructionHeadings) {
        for (let i = 0; i < instructionHeadings.length; i++) {
            this.helpTextIndx[instructionHeadings[i]] = i + 1;
        }
        // console.log(this.helpTextIndx);
        return this.helpTextIndx;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InstructionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InstructionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InstructionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5zdHJ1Y3Rpb24uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2luZm9ybWF0aW9uL2luc3RydWN0aW9uL2luc3RydWN0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHM0MsTUFBTSxPQUFPLGtCQUFrQjtJQUU3QjtRQURRLGlCQUFZLEdBQWMsRUFBRSxDQUFDO0lBRXJDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZ0JBQWdCLENBQUMsbUJBQXlCO1FBRXhDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwRCxDQUFDO1FBQ0Qsa0NBQWtDO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUczQixDQUFDOzhHQW5CVSxrQkFBa0I7a0hBQWxCLGtCQUFrQjs7MkZBQWxCLGtCQUFrQjtrQkFEOUIsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEluc3RydWN0aW9uU2VydmljZSB7XHJcbiAgcHJpdmF0ZSBoZWxwVGV4dEluZHg6IEhlbHBJbmRleCA9IHt9O1xyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2V0cyB0aGUgSGVscCBUZXh0IEluZGV4XHJcbiAgICpcclxuICAgKiBpbnN0cnVjdGlvbkhlYWRpbmdzIHNob3VsZCBiZSBhIGxpc3RcclxuICAgKi9cclxuICBnZXRIZWxwVGV4dEluZGV4KGluc3RydWN0aW9uSGVhZGluZ3MgOiBhbnkpIHsgXHJcblxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnN0cnVjdGlvbkhlYWRpbmdzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHRoaXMuaGVscFRleHRJbmR4W2luc3RydWN0aW9uSGVhZGluZ3NbaV1dID0gaSArIDE7XHJcbiAgICB9XHJcbiAgICAvLyBjb25zb2xlLmxvZyh0aGlzLmhlbHBUZXh0SW5keCk7XHJcbiAgICByZXR1cm4gdGhpcy5oZWxwVGV4dEluZHg7XHJcbiAgICBcclxuXHJcbiAgfVxyXG5cclxuIFxyXG59XHJcblxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBIZWxwSW5kZXgge1xyXG4gIFtrZXk6IHN0cmluZ106IG51bWJlcjtcclxufSJdfQ==