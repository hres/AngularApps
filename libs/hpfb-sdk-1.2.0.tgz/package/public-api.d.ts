export declare const MY_COMP_UI_SDK = "@mycomp/ui-sdk";
