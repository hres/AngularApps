import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class LoggerService {
    log(debugEnabled, className, methodName, ...messages) {
        if (debugEnabled) {
            console.log(`${className} -> ${methodName} ->`, ...this.formatMessages(messages));
        }
    }
    error(debugEnabled, className, methodName, ...messages) {
        if (debugEnabled) {
            console.error(`${className} -> ${methodName} ->`, ...this.formatMessages(messages));
        }
    }
    warn(debugEnabled, className, methodName, ...messages) {
        if (debugEnabled) {
            console.warn(`${className} -> ${methodName} ->`, ...this.formatMessages(messages));
        }
    }
    formatMessages(messages) {
        return messages.map(msg => typeof msg === 'object' ? JSON.stringify(msg, null, 2) : msg);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LoggerService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nZ2VyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9sb2dnZXIvbG9nZ2VyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHM0MsTUFBTSxPQUFPLGFBQWE7SUFFeEIsR0FBRyxDQUFDLFlBQXFCLEVBQUUsU0FBaUIsRUFBRSxVQUFrQixFQUFFLEdBQUcsUUFBZTtRQUNsRixJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLE9BQU8sVUFBVSxLQUFLLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDcEYsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsWUFBcUIsRUFBRSxTQUFpQixFQUFFLFVBQWtCLEVBQUUsR0FBRyxRQUFlO1FBQ3BGLElBQUksWUFBWSxFQUFFLENBQUM7WUFDakIsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLFNBQVMsT0FBTyxVQUFVLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUN0RixDQUFDO0lBQ0gsQ0FBQztJQUVELElBQUksQ0FBQyxZQUFxQixFQUFFLFNBQWlCLEVBQUUsVUFBa0IsRUFBRSxHQUFHLFFBQWU7UUFDbkYsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUNqQixPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsU0FBUyxPQUFPLFVBQVUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ3JGLENBQUM7SUFDSCxDQUFDO0lBRU8sY0FBYyxDQUFDLFFBQWU7UUFDcEMsT0FBTyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQ3hCLE9BQU8sR0FBRyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQzdELENBQUM7SUFDSixDQUFDOytHQXhCVSxhQUFhO21IQUFiLGFBQWE7OzRGQUFiLGFBQWE7a0JBRHpCLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBMb2dnZXJTZXJ2aWNlIHtcclxuXHJcbiAgbG9nKGRlYnVnRW5hYmxlZDogYm9vbGVhbiwgY2xhc3NOYW1lOiBzdHJpbmcsIG1ldGhvZE5hbWU6IHN0cmluZywgLi4ubWVzc2FnZXM6IGFueVtdKSB7XHJcbiAgICBpZiAoZGVidWdFbmFibGVkKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGAke2NsYXNzTmFtZX0gLT4gJHttZXRob2ROYW1lfSAtPmAsIC4uLnRoaXMuZm9ybWF0TWVzc2FnZXMobWVzc2FnZXMpKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGVycm9yKGRlYnVnRW5hYmxlZDogYm9vbGVhbiwgY2xhc3NOYW1lOiBzdHJpbmcsIG1ldGhvZE5hbWU6IHN0cmluZywgLi4ubWVzc2FnZXM6IGFueVtdKSB7XHJcbiAgICBpZiAoZGVidWdFbmFibGVkKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoYCR7Y2xhc3NOYW1lfSAtPiAke21ldGhvZE5hbWV9IC0+YCwgLi4udGhpcy5mb3JtYXRNZXNzYWdlcyhtZXNzYWdlcykpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgd2FybihkZWJ1Z0VuYWJsZWQ6IGJvb2xlYW4sIGNsYXNzTmFtZTogc3RyaW5nLCBtZXRob2ROYW1lOiBzdHJpbmcsIC4uLm1lc3NhZ2VzOiBhbnlbXSkge1xyXG4gICAgaWYgKGRlYnVnRW5hYmxlZCkge1xyXG4gICAgICBjb25zb2xlLndhcm4oYCR7Y2xhc3NOYW1lfSAtPiAke21ldGhvZE5hbWV9IC0+YCwgLi4udGhpcy5mb3JtYXRNZXNzYWdlcyhtZXNzYWdlcykpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBmb3JtYXRNZXNzYWdlcyhtZXNzYWdlczogYW55W10pOiBhbnlbXSB7XHJcbiAgICByZXR1cm4gbWVzc2FnZXMubWFwKG1zZyA9PiBcclxuICAgICAgdHlwZW9mIG1zZyA9PT0gJ29iamVjdCcgPyBKU09OLnN0cmluZ2lmeShtc2csIG51bGwsIDIpIDogbXNnXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG4iXX0=