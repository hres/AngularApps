import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class EntityBaseService {
    getEmptyIdTextLabel() {
        return {
            __text: '',
            _id: '',
            _label_en: '',
            _label_fr: '',
        };
    }
    getEmptyIIdText() {
        return {
            __text: '',
            _id: '',
        };
    }
    getEmptyLabel() {
        return {
            _label_en: '',
            _label_fr: '',
        };
    }
    getEmptyITextLabel() {
        return {
            __text: '',
            _label_en: '',
            _label_fr: ''
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBaseService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBaseService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBaseService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW50aXR5LWJhc2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL21vZGVsL2VudGl0eS1iYXNlLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFJM0MsTUFBTSxPQUFPLGlCQUFpQjtJQUM1QixtQkFBbUI7UUFDakIsT0FBTztZQUNMLE1BQU0sRUFBRSxFQUFFO1lBQ1YsR0FBRyxFQUFFLEVBQUU7WUFDUCxTQUFTLEVBQUUsRUFBRTtZQUNiLFNBQVMsRUFBRSxFQUFFO1NBQ2QsQ0FBQztJQUNKLENBQUM7SUFFRCxlQUFlO1FBQ2IsT0FBTztZQUNMLE1BQU0sRUFBRSxFQUFFO1lBQ1YsR0FBRyxFQUFFLEVBQUU7U0FDUixDQUFDO0lBQ0osQ0FBQztJQUVELGFBQWE7UUFDWCxPQUFPO1lBQ0wsU0FBUyxFQUFFLEVBQUU7WUFDYixTQUFTLEVBQUUsRUFBRTtTQUNkLENBQUM7SUFDSixDQUFDO0lBRUQsa0JBQWtCO1FBQ2hCLE9BQU87WUFDTCxNQUFNLEVBQUUsRUFBRTtZQUNWLFNBQVMsRUFBRSxFQUFFO1lBQ2IsU0FBUyxFQUFFLEVBQUU7U0FDZCxDQUFBO0lBQ0gsQ0FBQzsrR0E5QlUsaUJBQWlCO21IQUFqQixpQkFBaUI7OzRGQUFqQixpQkFBaUI7a0JBRDdCLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElJZFRleHQsIElJZFRleHRMYWJlbCwgSUxhYmVsLCBJVGV4dExhYmVsIH0gZnJvbSAnLi9lbnRpdHktYmFzZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBFbnRpdHlCYXNlU2VydmljZSB7XHJcbiAgZ2V0RW1wdHlJZFRleHRMYWJlbCgpOiBJSWRUZXh0TGFiZWwge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgX190ZXh0OiAnJyxcclxuICAgICAgX2lkOiAnJyxcclxuICAgICAgX2xhYmVsX2VuOiAnJyxcclxuICAgICAgX2xhYmVsX2ZyOiAnJyxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBnZXRFbXB0eUlJZFRleHQoKTogSUlkVGV4dCB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBfX3RleHQ6ICcnLFxyXG4gICAgICBfaWQ6ICcnLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIGdldEVtcHR5TGFiZWwoKTogSUxhYmVsIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIF9sYWJlbF9lbjogJycsXHJcbiAgICAgIF9sYWJlbF9mcjogJycsXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgZ2V0RW1wdHlJVGV4dExhYmVsKCk6IElUZXh0TGFiZWwge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgX190ZXh0OiAnJyxcclxuICAgICAgX2xhYmVsX2VuOiAnJyxcclxuICAgICAgX2xhYmVsX2ZyOiAnJ1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbn1cclxuIl19