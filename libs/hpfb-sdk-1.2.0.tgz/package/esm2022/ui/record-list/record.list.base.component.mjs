import { ExpanderComponent } from '../expander/expander.component';
import { Directive, ViewChild } from '@angular/core';
import * as i0 from "@angular/core";
export class RecordListBaseComponent {
    // private errorSummary: ErrorSummaryComponent;
    /**
     * Used to create address ids
     * @type {number}
     * @private
     */
    constructor() {
        this.prevRow = -1;
        this.showErrorSummary = false;
        this.newRecordIndicator = false;
    }
    /**
     * Sets an ErrorSummary object (optional)
     * @param {ErrorSummaryComponent} errorSummaryInstance
     */
    // public setErrorSummary(errorSummaryInstance: ErrorSummaryComponent) {
    //   this.errorSummary = errorSummaryInstance; // TODO dont think this does anything
    // }
    /**
     * Sets a reference to an expander instance
     * @param {ExpanderComponent} expanderInstance
     */
    /* public setExpander(expanderInstance: ExpanderComponent) {
       this.expander = expanderInstance;
     }
   */
    /**
     * Synchs the currently expanded row with the appropriate reactive form recortd
     * @param {FormArray} reactiveFormList -list of UI records
     * @returns {FormGroup} the record that matchs the currently open row
     */
    syncCurrentExpandedRow(reactiveFormList) {
        if (!this.expander) {
            console.warn('RecordListBaseComponent-syncCurrentExpandedRow: There is no expander');
            return null;
        }
        const rowNum = this.expander.getExpandedRow();
        // used to sync the expander with the details
        if (rowNum > -1 && this.prevRow !== rowNum) {
            this.prevRow = rowNum;
            // console.log('Prev control does not equal current row');
            return reactiveFormList.controls[rowNum];
        }
        else {
            // do nothing?
            return null;
        }
    }
    /**
     * Colllapses all the expander rows. Just a wrapper to the expander
     */
    collapseExpanderRows() {
        if (this.expander) {
            this.expander.collapseTableRows();
        }
    }
    /**
     * Saves a record to the form model using the passed in service
     * @param {FormGroup} record
     * @param service
     * @returns {number}
     */
    saveRecord(record, service, lang, ...args) {
        //  Case 1 no record, just show error summary, shoud never happen
        if (!record) {
            this.showErrorSummary = true;
            return -1;
        }
        // console.log(record);
        let recordId = service.saveRecord(record, lang, ...args);
        this.showErrorSummary = false;
        this.newRecordIndicator = false; // in case this was a new record
        // this.collapseExpanderRows();
        return recordId;
    }
    /**
     * Adds a  new reoord. Exposes the new record ui
     * @param {FormGroup} formRecord
     * @param {FormArray} formList
     */
    addRecord(formRecord, formList) {
        // this.collapseExpanderRows(); // if you don't do this view will not look right
        formList.push(formRecord);
        // console.log(formList);
        this.newRecordIndicator = true; // TODO why does superclass variable not update
    }
    /**
     * Deletes a form record of a given id
     * @param {number} id
     * @param {FormArray} recordList
     * @param service
     */
    deleteRecord(id, recordList, service) {
        const serviceResult = service.deleteModelRecord(id);
        for (let i = 0; i < recordList.controls.length; i++) {
            const temp = recordList.controls[i];
            if (temp.controls['id'].value === id) {
                recordList.removeAt(i);
                if (id === service.getCurrentIndex()) {
                    service.setIndex(id - 1);
                }
                break;
            }
        }
        // this.collapseExpanderRows();
        this.newRecordIndicator = false;
        // this.prevRow = -1;
    }
    /**
     * Gets a recond of a given id, provided the list
     * @param {number} id
     * @param recordList
     * @returns {any}
     */
    getRecord(id, recordList) {
        for (let i = 0; i < recordList.controls.length; i++) {
            let temp = recordList.controls[i];
            if (temp.controls['id'].value === id) {
                return temp;
            }
        }
        return null;
    }
    getExpandedRow() {
        return this.expander.getExpandedRow();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RecordListBaseComponent, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: RecordListBaseComponent, viewQueries: [{ propertyName: "expander", first: true, predicate: ExpanderComponent, descendants: true, static: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RecordListBaseComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { expander: [{
                type: ViewChild,
                args: [ExpanderComponent, { static: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb3JkLmxpc3QuYmFzZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9yZWNvcmQtbGlzdC9yZWNvcmQubGlzdC5iYXNlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUVuRSxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxNQUFNLGVBQWUsQ0FBQzs7QUFJcEQsTUFBTSxPQUFnQix1QkFBdUI7SUFPM0MsK0NBQStDO0lBRS9DOzs7O09BSUc7SUFFSDtRQUNFLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztRQUM5QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO0lBQ2xDLENBQUM7SUFHRDs7O09BR0c7SUFDSCx3RUFBd0U7SUFDeEUsb0ZBQW9GO0lBQ3BGLElBQUk7SUFFSjs7O09BR0c7SUFDSjs7O0tBR0M7SUFDQTs7OztPQUlHO0lBQ0ksc0JBQXNCLENBQUMsZ0JBQTJCO1FBRXZELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbkIsT0FBTyxDQUFDLElBQUksQ0FBQyxzRUFBc0UsQ0FBQyxDQUFDO1lBQ3JGLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDOUMsNkNBQTZDO1FBQzdDLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssTUFBTSxFQUFFLENBQUM7WUFDM0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7WUFDdEIsMERBQTBEO1lBQzFELE9BQW1CLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN2RCxDQUFDO2FBQU0sQ0FBQztZQUNOLGNBQWM7WUFDZCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxvQkFBb0I7UUFDMUIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3BDLENBQUM7SUFFSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxVQUFVLENBQUMsTUFBaUIsRUFBRSxPQUFtQyxFQUFFLElBQVcsRUFBRSxHQUFHLElBQVc7UUFDbkcsaUVBQWlFO1FBQ2pFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNaLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7WUFDN0IsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNaLENBQUM7UUFDRCx1QkFBdUI7UUFDdkIsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztRQUM5QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDLENBQUMsZ0NBQWdDO1FBQ2pFLCtCQUErQjtRQUMvQixPQUFPLFFBQVEsQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFNBQVMsQ0FBQyxVQUFxQixFQUFFLFFBQW1CO1FBQ3pELGdGQUFnRjtRQUNoRixRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzFCLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLENBQUMsK0NBQStDO0lBQ2pGLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFlBQVksQ0FBQyxFQUFVLEVBQUUsVUFBcUIsRUFBRSxPQUFtQztRQUN4RixNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDcEQsTUFBTSxJQUFJLEdBQWUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoRCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUNyQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2QixJQUFJLEVBQUUsS0FBSyxPQUFPLENBQUMsZUFBZSxFQUFFLEVBQUUsQ0FBQztvQkFDckMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzNCLENBQUM7Z0JBQ0QsTUFBTTtZQUNSLENBQUM7UUFDSCxDQUFDO1FBQ0QsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7UUFDaEMscUJBQXFCO0lBQ3ZCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFNBQVMsQ0FBQyxFQUFVLEVBQUUsVUFBVTtRQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxJQUFJLElBQUksR0FBZSxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzlDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQ3JDLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFTSxjQUFjO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUV6QyxDQUFDOytHQWpKbUIsdUJBQXVCO21HQUF2Qix1QkFBdUIsb0VBTWhDLGlCQUFpQjs7NEZBTlIsdUJBQXVCO2tCQUQ1QyxTQUFTO3dEQU9zQyxRQUFRO3NCQUFyRCxTQUFTO3VCQUFDLGlCQUFpQixFQUFFLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Rm9ybUFycmF5LCBGb3JtR3JvdXB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgRXhwYW5kZXJDb21wb25lbnQgfSBmcm9tICcuLi9leHBhbmRlci9leHBhbmRlci5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBFcnJvclN1bW1hcnlDb21wb25lbnQgfSBmcm9tICcuLi9lcnJvci1tc2cvZXJyb3Itc3VtbWFyeS9lcnJvci1zdW1tYXJ5LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IERpcmVjdGl2ZSwgVmlld0NoaWxkfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtSZWNvcmRMaXN0U2VydmljZUludGVyZmFjZX0gZnJvbSAnLi9yZWNvcmQubGlzdC5zZXJ2aWNlLmludGVyZmFjZSc7XHJcblxyXG5ARGlyZWN0aXZlKClcclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIFJlY29yZExpc3RCYXNlQ29tcG9uZW50IHtcclxuXHJcbiAgcHVibGljIHByZXZSb3c6IG51bWJlcjtcclxuICBwcm90ZWN0ZWQgc2hvd0Vycm9yU3VtbWFyeTogYm9vbGVhbjtcclxuICBwdWJsaWMgbmV3UmVjb3JkSW5kaWNhdG9yOiBib29sZWFuO1xyXG5cclxuICBAVmlld0NoaWxkKEV4cGFuZGVyQ29tcG9uZW50LCB7c3RhdGljOiB0cnVlfSkgZXhwYW5kZXI6IEV4cGFuZGVyQ29tcG9uZW50O1xyXG4gIC8vIHByaXZhdGUgZXJyb3JTdW1tYXJ5OiBFcnJvclN1bW1hcnlDb21wb25lbnQ7XHJcblxyXG4gIC8qKlxyXG4gICAqIFVzZWQgdG8gY3JlYXRlIGFkZHJlc3MgaWRzXHJcbiAgICogQHR5cGUge251bWJlcn1cclxuICAgKiBAcHJpdmF0ZVxyXG4gICAqL1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMucHJldlJvdyA9IC0xO1xyXG4gICAgdGhpcy5zaG93RXJyb3JTdW1tYXJ5ID0gZmFsc2U7XHJcbiAgICB0aGlzLm5ld1JlY29yZEluZGljYXRvciA9IGZhbHNlO1xyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIFNldHMgYW4gRXJyb3JTdW1tYXJ5IG9iamVjdCAob3B0aW9uYWwpXHJcbiAgICogQHBhcmFtIHtFcnJvclN1bW1hcnlDb21wb25lbnR9IGVycm9yU3VtbWFyeUluc3RhbmNlXHJcbiAgICovXHJcbiAgLy8gcHVibGljIHNldEVycm9yU3VtbWFyeShlcnJvclN1bW1hcnlJbnN0YW5jZTogRXJyb3JTdW1tYXJ5Q29tcG9uZW50KSB7XHJcbiAgLy8gICB0aGlzLmVycm9yU3VtbWFyeSA9IGVycm9yU3VtbWFyeUluc3RhbmNlOyAvLyBUT0RPIGRvbnQgdGhpbmsgdGhpcyBkb2VzIGFueXRoaW5nXHJcbiAgLy8gfVxyXG5cclxuICAvKipcclxuICAgKiBTZXRzIGEgcmVmZXJlbmNlIHRvIGFuIGV4cGFuZGVyIGluc3RhbmNlXHJcbiAgICogQHBhcmFtIHtFeHBhbmRlckNvbXBvbmVudH0gZXhwYW5kZXJJbnN0YW5jZVxyXG4gICAqL1xyXG4gLyogcHVibGljIHNldEV4cGFuZGVyKGV4cGFuZGVySW5zdGFuY2U6IEV4cGFuZGVyQ29tcG9uZW50KSB7XHJcbiAgICB0aGlzLmV4cGFuZGVyID0gZXhwYW5kZXJJbnN0YW5jZTtcclxuICB9XHJcbiovXHJcbiAgLyoqXHJcbiAgICogU3luY2hzIHRoZSBjdXJyZW50bHkgZXhwYW5kZWQgcm93IHdpdGggdGhlIGFwcHJvcHJpYXRlIHJlYWN0aXZlIGZvcm0gcmVjb3J0ZFxyXG4gICAqIEBwYXJhbSB7Rm9ybUFycmF5fSByZWFjdGl2ZUZvcm1MaXN0IC1saXN0IG9mIFVJIHJlY29yZHNcclxuICAgKiBAcmV0dXJucyB7Rm9ybUdyb3VwfSB0aGUgcmVjb3JkIHRoYXQgbWF0Y2hzIHRoZSBjdXJyZW50bHkgb3BlbiByb3dcclxuICAgKi9cclxuICBwdWJsaWMgc3luY0N1cnJlbnRFeHBhbmRlZFJvdyhyZWFjdGl2ZUZvcm1MaXN0OiBGb3JtQXJyYXkpOiBGb3JtR3JvdXAge1xyXG5cclxuICAgIGlmICghdGhpcy5leHBhbmRlcikge1xyXG4gICAgICBjb25zb2xlLndhcm4oJ1JlY29yZExpc3RCYXNlQ29tcG9uZW50LXN5bmNDdXJyZW50RXhwYW5kZWRSb3c6IFRoZXJlIGlzIG5vIGV4cGFuZGVyJyk7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgcm93TnVtID0gdGhpcy5leHBhbmRlci5nZXRFeHBhbmRlZFJvdygpO1xyXG4gICAgLy8gdXNlZCB0byBzeW5jIHRoZSBleHBhbmRlciB3aXRoIHRoZSBkZXRhaWxzXHJcbiAgICBpZiAocm93TnVtID4gLTEgJiYgdGhpcy5wcmV2Um93ICE9PSByb3dOdW0pIHtcclxuICAgICAgdGhpcy5wcmV2Um93ID0gcm93TnVtO1xyXG4gICAgICAvLyBjb25zb2xlLmxvZygnUHJldiBjb250cm9sIGRvZXMgbm90IGVxdWFsIGN1cnJlbnQgcm93Jyk7XHJcbiAgICAgIHJldHVybiA8Rm9ybUdyb3VwPiByZWFjdGl2ZUZvcm1MaXN0LmNvbnRyb2xzW3Jvd051bV07XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBkbyBub3RoaW5nP1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbGxsYXBzZXMgYWxsIHRoZSBleHBhbmRlciByb3dzLiBKdXN0IGEgd3JhcHBlciB0byB0aGUgZXhwYW5kZXJcclxuICAgKi9cclxuICBwcml2YXRlIGNvbGxhcHNlRXhwYW5kZXJSb3dzKCkge1xyXG4gICAgaWYgKHRoaXMuZXhwYW5kZXIpIHtcclxuICAgICAgdGhpcy5leHBhbmRlci5jb2xsYXBzZVRhYmxlUm93cygpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNhdmVzIGEgcmVjb3JkIHRvIHRoZSBmb3JtIG1vZGVsIHVzaW5nIHRoZSBwYXNzZWQgaW4gc2VydmljZVxyXG4gICAqIEBwYXJhbSB7Rm9ybUdyb3VwfSByZWNvcmRcclxuICAgKiBAcGFyYW0gc2VydmljZVxyXG4gICAqIEByZXR1cm5zIHtudW1iZXJ9XHJcbiAgICovXHJcbiAgcHVibGljIHNhdmVSZWNvcmQocmVjb3JkOiBGb3JtR3JvdXAsIHNlcnZpY2U6IFJlY29yZExpc3RTZXJ2aWNlSW50ZXJmYWNlLCBsYW5nOnN0cmluZywgLi4uYXJnczogYW55W10pOiBudW1iZXIge1xyXG4gICAgLy8gIENhc2UgMSBubyByZWNvcmQsIGp1c3Qgc2hvdyBlcnJvciBzdW1tYXJ5LCBzaG91ZCBuZXZlciBoYXBwZW5cclxuICAgIGlmICghcmVjb3JkKSB7XHJcbiAgICAgIHRoaXMuc2hvd0Vycm9yU3VtbWFyeSA9IHRydWU7XHJcbiAgICAgIHJldHVybiAtMTtcclxuICAgIH1cclxuICAgIC8vIGNvbnNvbGUubG9nKHJlY29yZCk7XHJcbiAgICBsZXQgcmVjb3JkSWQgPSBzZXJ2aWNlLnNhdmVSZWNvcmQocmVjb3JkLCBsYW5nLCAuLi5hcmdzKTtcclxuICAgIHRoaXMuc2hvd0Vycm9yU3VtbWFyeSA9IGZhbHNlO1xyXG4gICAgdGhpcy5uZXdSZWNvcmRJbmRpY2F0b3IgPSBmYWxzZTsgLy8gaW4gY2FzZSB0aGlzIHdhcyBhIG5ldyByZWNvcmRcclxuICAgIC8vIHRoaXMuY29sbGFwc2VFeHBhbmRlclJvd3MoKTtcclxuICAgIHJldHVybiByZWNvcmRJZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEFkZHMgYSAgbmV3IHJlb29yZC4gRXhwb3NlcyB0aGUgbmV3IHJlY29yZCB1aVxyXG4gICAqIEBwYXJhbSB7Rm9ybUdyb3VwfSBmb3JtUmVjb3JkXHJcbiAgICogQHBhcmFtIHtGb3JtQXJyYXl9IGZvcm1MaXN0XHJcbiAgICovXHJcbiAgcHVibGljIGFkZFJlY29yZChmb3JtUmVjb3JkOiBGb3JtR3JvdXAsIGZvcm1MaXN0OiBGb3JtQXJyYXkpIHtcclxuICAgIC8vIHRoaXMuY29sbGFwc2VFeHBhbmRlclJvd3MoKTsgLy8gaWYgeW91IGRvbid0IGRvIHRoaXMgdmlldyB3aWxsIG5vdCBsb29rIHJpZ2h0XHJcbiAgICBmb3JtTGlzdC5wdXNoKGZvcm1SZWNvcmQpO1xyXG4gICAgLy8gY29uc29sZS5sb2coZm9ybUxpc3QpO1xyXG4gICAgdGhpcy5uZXdSZWNvcmRJbmRpY2F0b3IgPSB0cnVlOyAvLyBUT0RPIHdoeSBkb2VzIHN1cGVyY2xhc3MgdmFyaWFibGUgbm90IHVwZGF0ZVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGVsZXRlcyBhIGZvcm0gcmVjb3JkIG9mIGEgZ2l2ZW4gaWRcclxuICAgKiBAcGFyYW0ge251bWJlcn0gaWRcclxuICAgKiBAcGFyYW0ge0Zvcm1BcnJheX0gcmVjb3JkTGlzdFxyXG4gICAqIEBwYXJhbSBzZXJ2aWNlXHJcbiAgICovXHJcbiAgcHVibGljIGRlbGV0ZVJlY29yZChpZDogbnVtYmVyLCByZWNvcmRMaXN0OiBGb3JtQXJyYXksIHNlcnZpY2U6IFJlY29yZExpc3RTZXJ2aWNlSW50ZXJmYWNlKSB7XHJcbiAgICBjb25zdCBzZXJ2aWNlUmVzdWx0ID0gc2VydmljZS5kZWxldGVNb2RlbFJlY29yZChpZCk7XHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlY29yZExpc3QuY29udHJvbHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgdGVtcCA9IDxGb3JtR3JvdXA+IHJlY29yZExpc3QuY29udHJvbHNbaV07XHJcbiAgICAgIGlmICh0ZW1wLmNvbnRyb2xzWydpZCddLnZhbHVlID09PSBpZCkge1xyXG4gICAgICAgIHJlY29yZExpc3QucmVtb3ZlQXQoaSk7XHJcbiAgICAgICAgaWYgKGlkID09PSBzZXJ2aWNlLmdldEN1cnJlbnRJbmRleCgpKSB7XHJcbiAgICAgICAgICBzZXJ2aWNlLnNldEluZGV4KGlkIC0gMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAvLyB0aGlzLmNvbGxhcHNlRXhwYW5kZXJSb3dzKCk7XHJcbiAgICB0aGlzLm5ld1JlY29yZEluZGljYXRvciA9IGZhbHNlO1xyXG4gICAgLy8gdGhpcy5wcmV2Um93ID0gLTE7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXRzIGEgcmVjb25kIG9mIGEgZ2l2ZW4gaWQsIHByb3ZpZGVkIHRoZSBsaXN0XHJcbiAgICogQHBhcmFtIHtudW1iZXJ9IGlkXHJcbiAgICogQHBhcmFtIHJlY29yZExpc3RcclxuICAgKiBAcmV0dXJucyB7YW55fVxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRSZWNvcmQoaWQ6IG51bWJlciwgcmVjb3JkTGlzdCkge1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZWNvcmRMaXN0LmNvbnRyb2xzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGxldCB0ZW1wID0gPEZvcm1Hcm91cD4gcmVjb3JkTGlzdC5jb250cm9sc1tpXTtcclxuICAgICAgaWYgKHRlbXAuY29udHJvbHNbJ2lkJ10udmFsdWUgPT09IGlkKSB7XHJcbiAgICAgICAgcmV0dXJuIHRlbXA7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldEV4cGFuZGVkUm93KCk6IG51bWJlciB7XHJcbiAgICAgcmV0dXJuIHRoaXMuZXhwYW5kZXIuZ2V0RXhwYW5kZWRSb3coKTtcclxuXHJcbiAgfVxyXG59XHJcbiJdfQ==