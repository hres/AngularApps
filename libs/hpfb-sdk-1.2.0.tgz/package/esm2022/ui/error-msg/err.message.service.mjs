import { Inject, Injectable } from '@angular/core';
import { VALIDATION_SERVICES } from '../validation/validation-service.token';
import * as i0 from "@angular/core";
export class ErrMessageService {
    constructor(validationServices) {
        this.validationServices = validationServices;
    }
    getValidatorErrorMessageKey(validatorName) {
        for (const service of this.validationServices) {
            // get the error message key in the en/fr.json for this errorz
            const messageKey = service.getValidatorErrorMessage(validatorName);
            if (messageKey)
                return messageKey; // Return the first matching key
        }
        return null; // Default to null if no match is found
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrMessageService, deps: [{ token: VALIDATION_SERVICES }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrMessageService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrMessageService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [VALIDATION_SERVICES]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyLm1lc3NhZ2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2Vycm9yLW1zZy9lcnIubWVzc2FnZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRW5ELE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHdDQUF3QyxDQUFDOztBQUc3RSxNQUFNLE9BQU8saUJBQWlCO0lBRTVCLFlBQ3VDLGtCQUF3QztRQUF4Qyx1QkFBa0IsR0FBbEIsa0JBQWtCLENBQXNCO0lBQzVFLENBQUM7SUFFSiwyQkFBMkIsQ0FBQyxhQUFxQjtRQUMvQyxLQUFLLE1BQU0sT0FBTyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzlDLDhEQUE4RDtZQUM5RCxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDbkUsSUFBSSxVQUFVO2dCQUFFLE9BQU8sVUFBVSxDQUFDLENBQUMsZ0NBQWdDO1FBQ3JFLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxDQUFDLHVDQUF1QztJQUN0RCxDQUFDOytHQWJVLGlCQUFpQixrQkFHbEIsbUJBQW1CO21IQUhsQixpQkFBaUI7OzRGQUFqQixpQkFBaUI7a0JBRDdCLFVBQVU7OzBCQUlOLE1BQU07MkJBQUMsbUJBQW1CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElWYWxpZGF0aW9uU2VydmljZSB9IGZyb20gJy4uL3ZhbGlkYXRpb24vdmFsaWRhdGlvbi1zZXJ2aWNlLmludGVyZmFjZSc7XHJcbmltcG9ydCB7IFZBTElEQVRJT05fU0VSVklDRVMgfSBmcm9tICcuLi92YWxpZGF0aW9uL3ZhbGlkYXRpb24tc2VydmljZS50b2tlbic7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBFcnJNZXNzYWdlU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgQEluamVjdChWQUxJREFUSU9OX1NFUlZJQ0VTKSBwcml2YXRlIHZhbGlkYXRpb25TZXJ2aWNlczogSVZhbGlkYXRpb25TZXJ2aWNlW11cclxuICApIHt9XHJcblxyXG4gIGdldFZhbGlkYXRvckVycm9yTWVzc2FnZUtleSh2YWxpZGF0b3JOYW1lOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICAgIGZvciAoY29uc3Qgc2VydmljZSBvZiB0aGlzLnZhbGlkYXRpb25TZXJ2aWNlcykge1xyXG4gICAgICAvLyBnZXQgdGhlIGVycm9yIG1lc3NhZ2Uga2V5IGluIHRoZSBlbi9mci5qc29uIGZvciB0aGlzIGVycm9yelxyXG4gICAgICBjb25zdCBtZXNzYWdlS2V5ID0gc2VydmljZS5nZXRWYWxpZGF0b3JFcnJvck1lc3NhZ2UodmFsaWRhdG9yTmFtZSk7XHJcbiAgICAgIGlmIChtZXNzYWdlS2V5KSByZXR1cm4gbWVzc2FnZUtleTsgLy8gUmV0dXJuIHRoZSBmaXJzdCBtYXRjaGluZyBrZXlcclxuICAgIH1cclxuICAgIHJldHVybiBudWxsOyAvLyBEZWZhdWx0IHRvIG51bGwgaWYgbm8gbWF0Y2ggaXMgZm91bmRcclxuICB9XHJcbn1cclxuIl19