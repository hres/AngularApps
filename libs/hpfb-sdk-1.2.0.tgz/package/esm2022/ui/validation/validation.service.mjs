import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class ValidationService {
    constructor() {
        // private translate: TranslateService
        // this.translate.get('error.msg.required').subscribe(res => { console.log(res); });
    }
    getValidatorErrorMessage(validatorName) {
        // TODO sucky need to make the keys the same as the translation for the error summary
        const config = {
            'required': 'required',
            'error.msg.number': 'error.msg.number',
            'error.msg.phone': 'error.msg.phone',
            'error.msg.fax': 'error.msg.fax',
            'error.msg.email': 'error.msg.email',
            'minlength': 'error.msg.minlength',
            'error.msg.postal': 'error.msg.postal',
            'error.mgs.zip': 'error.mgs.zip',
            'error.mgs.company.id': 'error.mgs.company.id',
            'error.mgs.contact.id': 'error.mgs.contact.id',
            'error.mgs.primary.company.id': 'error.mgs.primary.company.id',
            'error.mgs.primary.contact.id': 'error.mgs.primary.contact.id',
            'error.mgs.5.numeric': 'error.mgs.5.numeric',
            'error.mgs.6.numeric': 'error.mgs.6.numeric',
            'error.mgs.8.numeric': 'error.mgs.8.numeric',
            'error.mgs.regu.contact.id': 'error.mgs.regu.contact.id',
            'error.mgs.dossier.id': 'error.mgs.dossier.id',
            'error.mgs.licence.number': 'error.mgs.licence.number',
            'error.mgs.application.number': 'error.mgs.application.number',
            'error.mgs.din': 'error.mgs.din',
            'error.mgs.npn': 'error.mgs.npn',
            'error.msg.remove.contact': 'error.msg.remove.contact',
            'error.msg.revise.contact': 'error.msg.revise.contact',
            'error.mgs.incorrectFormat': 'error.mgs.incorrectFormat',
            'error.msg.invalidDate': 'error.msg.invalidDate',
            'error.msg.endDate': 'error.msg.endDate',
        };
        return config[validatorName];
    }
    static emailValidator(control) {
        if (!control.value) {
            return null;
        }
        // RFC 2822 compliant regex
        if (control.value.match(/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/)) {
            return null;
        }
        else {
            return { 'error.msg.email': true };
        }
    }
    /*static passwordValidator(control) {
      // {6,100}           - Assert password is between 6 and 100 characters
      // (?=.*[0-9])       - Assert a string has at least one number
      if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
        return null;
      } else {
        return {'invalidPassword': true};
      }
    }*/
    static canadaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^(?!.*[DFIOQU])[A-VXYa-vxy][0-9][A-Za-z] ?[0-9][A-Za-z][0-9]$/)) {
            return null;
        }
        else {
            return { 'error.msg.postal': true };
        }
    }
    static usaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}(?:-[0-9]{4})?$/)) {
            return null;
        }
        else {
            return { 'error.mgs.zip': true };
        }
    }
    static countryValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value[0].id !== '') {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static phoneNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.phone': true };
        }
    }
    static faxNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.fax': true };
        }
    }
    static numberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.number': true };
        }
    }
    static companyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static numeric5Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.5.numeric': true };
        }
    }
    static numeric6Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.6.numeric': true };
        }
    }
    static numeric8Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.8.numeric': true };
        }
    }
    static dossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[m]{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static dossierContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static regulatoryContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.regu.contact.id': true };
        }
    }
    static licenceNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.licence.number': true };
        }
    }
    static appNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.application.number': true };
        }
    }
    static dinValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.din': true };
        }
    }
    static npnValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.npn': true };
        }
    }
    static checkboxRequiredValidator(control) {
        if (control.value) {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static contactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static primaryCompanyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static atLeastOneCheckboxSelected(formArray) {
        // return (): { [key: string]: boolean } | null => {
        const controls = formArray.controls;
        // Check if at least one checkbox is selected
        const isAtLeastOneSelected = controls.some((control) => control.value === true);
        // Return validation error if none are selected
        return isAtLeastOneSelected ? null : { 'required': true };
        // };
    }
    static masterFileNumberValidator(control) {
        // todo
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{4}-[0-9]{3}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.incorrectFormat': true };
        }
    }
    // if first letter is e, then followed by 6 numbers
    // if first letter is f, then followed by 7 numbers
    static masterFileDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[e]{1}[0-9]{6}$/) ||
            control.value.match(/^[f]{1}[0-9]{7}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static accountNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.account': true };
        }
    }
    static businessNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.business': true };
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGlvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvdmFsaWRhdGlvbi92YWxpZGF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLGlCQUFpQjtJQUU1QjtRQUNFLHNDQUFzQztRQUN0QyxvRkFBb0Y7SUFFdEYsQ0FBQztJQUVELHdCQUF3QixDQUFDLGFBQXFCO1FBQzVDLHFGQUFxRjtRQUNyRixNQUFNLE1BQU0sR0FBRztZQUNiLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxpQkFBaUIsRUFBRSxpQkFBaUI7WUFDcEMsZUFBZSxFQUFFLGVBQWU7WUFDaEMsaUJBQWlCLEVBQUUsaUJBQWlCO1lBQ3BDLFdBQVcsRUFBRSxxQkFBcUI7WUFDbEMsa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLGVBQWUsRUFBRSxlQUFlO1lBQ2hDLHNCQUFzQixFQUFFLHNCQUFzQjtZQUM5QyxzQkFBc0IsRUFBRSxzQkFBc0I7WUFDOUMsOEJBQThCLEVBQUUsOEJBQThCO1lBQzlELDhCQUE4QixFQUFFLDhCQUE4QjtZQUM5RCxxQkFBcUIsRUFBRSxxQkFBcUI7WUFDNUMscUJBQXFCLEVBQUUscUJBQXFCO1lBQzVDLHFCQUFxQixFQUFDLHFCQUFxQjtZQUMzQywyQkFBMkIsRUFBRSwyQkFBMkI7WUFDeEQsc0JBQXNCLEVBQUUsc0JBQXNCO1lBQzlDLDBCQUEwQixFQUFFLDBCQUEwQjtZQUN0RCw4QkFBOEIsRUFBRSw4QkFBOEI7WUFDOUQsZUFBZSxFQUFFLGVBQWU7WUFDaEMsZUFBZSxFQUFFLGVBQWU7WUFDaEMsMEJBQTBCLEVBQUcsMEJBQTBCO1lBQ3ZELDBCQUEwQixFQUFHLDBCQUEwQjtZQUN2RCwyQkFBMkIsRUFBRSwyQkFBMkI7WUFDeEQsdUJBQXVCLEVBQUUsdUJBQXVCO1lBQ2hELG1CQUFtQixFQUFDLG1CQUFtQjtTQUN4QyxDQUFDO1FBRUYsT0FBTyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTztRQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELDJCQUEyQjtRQUMzQixJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtEQUFrRCxDQUFDLEVBQUUsQ0FBQztZQUM1RSxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLGlCQUFpQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ25DLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxNQUFNLENBQUMscUJBQXFCLENBQUMsT0FBTztRQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsK0RBQStELENBQUMsRUFBRSxDQUFDO1lBQ3pGLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsa0JBQWtCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDcEMsQ0FBQztJQUVILENBQUM7SUFFRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTztRQUMvQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsRUFBRSxDQUFDO1lBQ3BELE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsZUFBZSxFQUFFLElBQUksRUFBQyxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU87UUFDN0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO1lBQy9CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsVUFBVSxFQUFFLElBQUksRUFBQyxDQUFDO1FBQzVCLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLG9CQUFvQixDQUFDLE9BQU87UUFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxpQkFBaUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNuQyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsZUFBZSxFQUFFLElBQUksRUFBQyxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPO1FBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsa0JBQWtCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDcEMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTztRQUMvQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU87UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxxQkFBcUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMscUJBQXFCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDdkMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTztRQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHFCQUFxQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBR0QsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU87UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQztZQUM1QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHlCQUF5QixDQUFDLE9BQU87UUFDdEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxzQkFBc0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPO1FBQ3pDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsMkJBQTJCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsT0FBTztRQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDBCQUEwQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzVDLENBQUM7SUFDSCxDQUFDO0lBSUQsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPO1FBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsOEJBQThCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDaEQsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU87UUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU87UUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMseUJBQXlCLENBQUMsT0FBTztRQUN0QyxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNsQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsc0JBQXNCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMseUJBQXlCLENBQUMsT0FBTztRQUN0QyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLDBCQUEwQixDQUFDLFNBQW9CO1FBQ3BELG9EQUFvRDtRQUNsRCxNQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBRXBDLDZDQUE2QztRQUM3QyxNQUFNLG9CQUFvQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUF3QixFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDO1FBRWpHLCtDQUErQztRQUMvQyxPQUFPLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxDQUFDO1FBQzVELEtBQUs7SUFDUCxDQUFDO0lBRUQsTUFBTSxDQUFDLHlCQUF5QixDQUFDLE9BQU87UUFDdEMsT0FBTztRQUNQLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUM7WUFDL0MsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBRSwyQkFBMkIsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUMvQyxDQUFDO0lBQ0gsQ0FBQztJQUVELG1EQUFtRDtJQUNuRCxtREFBbUQ7SUFDbkQsTUFBTSxDQUFDLDRCQUE0QixDQUFDLE9BQU87UUFDekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUNFLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDO1lBQ3ZDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQ3ZDLENBQUM7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHNCQUFzQixDQUFDLE9BQU87UUFDbkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxtQkFBbUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNyQyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPO1FBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDdEMsQ0FBQztJQUNILENBQUM7K0dBeFZVLGlCQUFpQjttSEFBakIsaUJBQWlCOzs0RkFBakIsaUJBQWlCO2tCQUQ3QixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBYnN0cmFjdENvbnRyb2wsIEZvcm1BcnJheSwgRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBJVmFsaWRhdGlvblNlcnZpY2UgfSBmcm9tICcuL3ZhbGlkYXRpb24tc2VydmljZS5pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgVmFsaWRhdGlvblNlcnZpY2UgaW1wbGVtZW50cyBJVmFsaWRhdGlvblNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIC8vIHByaXZhdGUgdHJhbnNsYXRlOiBUcmFuc2xhdGVTZXJ2aWNlXHJcbiAgICAvLyB0aGlzLnRyYW5zbGF0ZS5nZXQoJ2Vycm9yLm1zZy5yZXF1aXJlZCcpLnN1YnNjcmliZShyZXMgPT4geyBjb25zb2xlLmxvZyhyZXMpOyB9KTtcclxuXHJcbiAgfVxyXG5cclxuICBnZXRWYWxpZGF0b3JFcnJvck1lc3NhZ2UodmFsaWRhdG9yTmFtZTogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICAvLyBUT0RPIHN1Y2t5IG5lZWQgdG8gbWFrZSB0aGUga2V5cyB0aGUgc2FtZSBhcyB0aGUgdHJhbnNsYXRpb24gZm9yIHRoZSBlcnJvciBzdW1tYXJ5XHJcbiAgICBjb25zdCBjb25maWcgPSB7XHJcbiAgICAgICdyZXF1aXJlZCc6ICdyZXF1aXJlZCcsXHJcbiAgICAgICdlcnJvci5tc2cubnVtYmVyJzogJ2Vycm9yLm1zZy5udW1iZXInLFxyXG4gICAgICAnZXJyb3IubXNnLnBob25lJzogJ2Vycm9yLm1zZy5waG9uZScsXHJcbiAgICAgICdlcnJvci5tc2cuZmF4JzogJ2Vycm9yLm1zZy5mYXgnLFxyXG4gICAgICAnZXJyb3IubXNnLmVtYWlsJzogJ2Vycm9yLm1zZy5lbWFpbCcsXHJcbiAgICAgICdtaW5sZW5ndGgnOiAnZXJyb3IubXNnLm1pbmxlbmd0aCcsXHJcbiAgICAgICdlcnJvci5tc2cucG9zdGFsJzogJ2Vycm9yLm1zZy5wb3N0YWwnLFxyXG4gICAgICAnZXJyb3IubWdzLnppcCc6ICdlcnJvci5tZ3MuemlwJyxcclxuICAgICAgJ2Vycm9yLm1ncy5jb21wYW55LmlkJzogJ2Vycm9yLm1ncy5jb21wYW55LmlkJyxcclxuICAgICAgJ2Vycm9yLm1ncy5jb250YWN0LmlkJzogJ2Vycm9yLm1ncy5jb250YWN0LmlkJyxcclxuICAgICAgJ2Vycm9yLm1ncy5wcmltYXJ5LmNvbXBhbnkuaWQnOiAnZXJyb3IubWdzLnByaW1hcnkuY29tcGFueS5pZCcsXHJcbiAgICAgICdlcnJvci5tZ3MucHJpbWFyeS5jb250YWN0LmlkJzogJ2Vycm9yLm1ncy5wcmltYXJ5LmNvbnRhY3QuaWQnLFxyXG4gICAgICAnZXJyb3IubWdzLjUubnVtZXJpYyc6ICdlcnJvci5tZ3MuNS5udW1lcmljJyxcclxuICAgICAgJ2Vycm9yLm1ncy42Lm51bWVyaWMnOiAnZXJyb3IubWdzLjYubnVtZXJpYycsXHJcbiAgICAgICdlcnJvci5tZ3MuOC5udW1lcmljJzonZXJyb3IubWdzLjgubnVtZXJpYycsXHJcbiAgICAgICdlcnJvci5tZ3MucmVndS5jb250YWN0LmlkJzogJ2Vycm9yLm1ncy5yZWd1LmNvbnRhY3QuaWQnLFxyXG4gICAgICAnZXJyb3IubWdzLmRvc3NpZXIuaWQnOiAnZXJyb3IubWdzLmRvc3NpZXIuaWQnLFxyXG4gICAgICAnZXJyb3IubWdzLmxpY2VuY2UubnVtYmVyJzogJ2Vycm9yLm1ncy5saWNlbmNlLm51bWJlcicsXHJcbiAgICAgICdlcnJvci5tZ3MuYXBwbGljYXRpb24ubnVtYmVyJzogJ2Vycm9yLm1ncy5hcHBsaWNhdGlvbi5udW1iZXInLFxyXG4gICAgICAnZXJyb3IubWdzLmRpbic6ICdlcnJvci5tZ3MuZGluJyxcclxuICAgICAgJ2Vycm9yLm1ncy5ucG4nOiAnZXJyb3IubWdzLm5wbicsXHJcbiAgICAgICdlcnJvci5tc2cucmVtb3ZlLmNvbnRhY3QnIDogJ2Vycm9yLm1zZy5yZW1vdmUuY29udGFjdCcsXHJcbiAgICAgICdlcnJvci5tc2cucmV2aXNlLmNvbnRhY3QnIDogJ2Vycm9yLm1zZy5yZXZpc2UuY29udGFjdCcsXHJcbiAgICAgICdlcnJvci5tZ3MuaW5jb3JyZWN0Rm9ybWF0JzogJ2Vycm9yLm1ncy5pbmNvcnJlY3RGb3JtYXQnLFxyXG4gICAgICAnZXJyb3IubXNnLmludmFsaWREYXRlJzogJ2Vycm9yLm1zZy5pbnZhbGlkRGF0ZScsXHJcbiAgICAgICdlcnJvci5tc2cuZW5kRGF0ZSc6J2Vycm9yLm1zZy5lbmREYXRlJyxcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIGNvbmZpZ1t2YWxpZGF0b3JOYW1lXTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBlbWFpbFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICAvLyBSRkMgMjgyMiBjb21wbGlhbnQgcmVnZXhcclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eW2EtekEtWjAtOV8uKy1dK0BbYS16QS1aMC05LV0rXFwuW2EtekEtWjAtOS0uXSskLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cuZW1haWwnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qc3RhdGljIHBhc3N3b3JkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIC8vIHs2LDEwMH0gICAgICAgICAgIC0gQXNzZXJ0IHBhc3N3b3JkIGlzIGJldHdlZW4gNiBhbmQgMTAwIGNoYXJhY3RlcnNcclxuICAgIC8vICg/PS4qWzAtOV0pICAgICAgIC0gQXNzZXJ0IGEgc3RyaW5nIGhhcyBhdCBsZWFzdCBvbmUgbnVtYmVyXHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXig/PS4qWzAtOV0pW2EtekEtWjAtOSFAIyQlXiYqXXs2LDEwMH0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydpbnZhbGlkUGFzc3dvcmQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9Ki9cclxuICBzdGF0aWMgY2FuYWRhUG9zdGFsVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eKD8hLipbREZJT1FVXSlbQS1WWFlhLXZ4eV1bMC05XVtBLVphLXpdID9bMC05XVtBLVphLXpdWzAtOV0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cucG9zdGFsJzogdHJ1ZX07XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHVzYVBvc3RhbFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezV9KD86LVswLTldezR9KT8kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuemlwJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgY291bnRyeVZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZVswXS5pZCAhPT0gJycpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydyZXF1aXJlZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHBob25lTnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLnBob25lJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZmF4TnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLmZheCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG51bWJlclZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldKiQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5udW1iZXInOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBjb21wYW55SWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs2fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5jb21wYW55LmlkJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgbnVtZXJpYzVWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs1fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy41Lm51bWVyaWMnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBudW1lcmljNlZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLjYubnVtZXJpYyc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG51bWVyaWM4VmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17OH0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuOC5udW1lcmljJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbiAgc3RhdGljIGRvc3NpZXJJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlttXXsxfVswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRvc3NpZXIuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBkb3NzaWVyQ29udGFjdElkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17NX0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuY29udGFjdC5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHJlZ3VsYXRvcnlDb250YWN0SWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs1fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5yZWd1LmNvbnRhY3QuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBsaWNlbmNlTnVtVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MubGljZW5jZS5udW1iZXInOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuXHJcbiAgc3RhdGljIGFwcE51bVZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmFwcGxpY2F0aW9uLm51bWJlcic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGRpblZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezh9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRpbic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG5wblZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezh9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLm5wbic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydyZXF1aXJlZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNvbnRhY3RJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezV9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmNvbnRhY3QuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBwcmltYXJ5Q29tcGFueUlkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuY29tcGFueS5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGF0TGVhc3RPbmVDaGVja2JveFNlbGVjdGVkKGZvcm1BcnJheTogRm9ybUFycmF5KSB7XHJcbiAgICAvLyByZXR1cm4gKCk6IHsgW2tleTogc3RyaW5nXTogYm9vbGVhbiB9IHwgbnVsbCA9PiB7XHJcbiAgICAgIGNvbnN0IGNvbnRyb2xzID0gZm9ybUFycmF5LmNvbnRyb2xzO1xyXG4gIFxyXG4gICAgICAvLyBDaGVjayBpZiBhdCBsZWFzdCBvbmUgY2hlY2tib3ggaXMgc2VsZWN0ZWRcclxuICAgICAgY29uc3QgaXNBdExlYXN0T25lU2VsZWN0ZWQgPSBjb250cm9scy5zb21lKChjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpID0+IGNvbnRyb2wudmFsdWUgPT09IHRydWUpO1xyXG4gIFxyXG4gICAgICAvLyBSZXR1cm4gdmFsaWRhdGlvbiBlcnJvciBpZiBub25lIGFyZSBzZWxlY3RlZFxyXG4gICAgICByZXR1cm4gaXNBdExlYXN0T25lU2VsZWN0ZWQgPyBudWxsIDogeyAncmVxdWlyZWQnOiB0cnVlIH07XHJcbiAgICAvLyB9O1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIG1hc3RlckZpbGVOdW1iZXJWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgLy8gdG9kb1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs0fS1bMC05XXszfSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7ICdlcnJvci5tZ3MuaW5jb3JyZWN0Rm9ybWF0JzogdHJ1ZSB9OyBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIGlmIGZpcnN0IGxldHRlciBpcyBlLCB0aGVuIGZvbGxvd2VkIGJ5IDYgbnVtYmVyc1xyXG4gIC8vIGlmIGZpcnN0IGxldHRlciBpcyBmLCB0aGVuIGZvbGxvd2VkIGJ5IDcgbnVtYmVyc1xyXG4gIHN0YXRpYyBtYXN0ZXJGaWxlRG9zc2llcklkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChcclxuICAgICAgY29udHJvbC52YWx1ZS5tYXRjaCgvXltlXXsxfVswLTldezZ9JC8pIHx8XHJcbiAgICAgIGNvbnRyb2wudmFsdWUubWF0Y2goL15bZl17MX1bMC05XXs3fSQvKVxyXG4gICAgKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRvc3NpZXIuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBhY2NvdW50TnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLmFjY291bnQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBidXNpbmVzc051bWJlclZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldKiQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5idXNpbmVzcyc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0=