import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class ValidationService {
    constructor() {
        // private translate: TranslateService
        // this.translate.get('error.msg.required').subscribe(res => { console.log(res); });
    }
    getValidatorErrorMessage(validatorName) {
        // TODO sucky need to make the keys the same as the translation for the error summary
        const config = {
            'required': 'required',
            'error.msg.number': 'error.msg.number',
            'error.msg.phone': 'error.msg.phone',
            'error.msg.fax': 'error.msg.fax',
            'error.msg.email': 'error.msg.email',
            'minlength': 'error.msg.minlength',
            'error.msg.postal': 'error.msg.postal',
            'error.mgs.zip': 'error.mgs.zip',
            'error.mgs.company.id': 'error.mgs.company.id',
            'error.mgs.contact.id': 'error.mgs.contact.id',
            'error.mgs.primary.company.id': 'error.mgs.primary.company.id',
            'error.mgs.primary.contact.id': 'error.mgs.primary.contact.id',
            'error.mgs.5.numeric': 'error.mgs.5.numeric',
            'error.mgs.6.numeric': 'error.mgs.6.numeric',
            'error.mgs.8.numeric': 'error.mgs.8.numeric',
            'error.mgs.regu.contact.id': 'error.mgs.regu.contact.id',
            'error.mgs.dossier.id': 'error.mgs.dossier.id',
            'error.mgs.licence.number': 'error.mgs.licence.number',
            'error.mgs.application.number': 'error.mgs.application.number',
            'error.mgs.din': 'error.mgs.din',
            'error.mgs.npn': 'error.mgs.npn',
            'error.msg.remove.contact': 'error.msg.remove.contact',
            'error.msg.revise.contact': 'error.msg.revise.contact',
            'error.mgs.incorrectFormat': 'error.mgs.incorrectFormat',
            'error.msg.invalidDate': 'error.msg.invalidDate',
            'error.msg.endDate': 'error.msg.endDate',
            'error.msg.roleSelected': 'error.msg.roleSelected'
        };
        return config[validatorName];
    }
    static emailValidator(control) {
        if (!control.value) {
            return null;
        }
        // RFC 2822 compliant regex
        if (control.value.match(/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/)) {
            return null;
        }
        else {
            return { 'error.msg.email': true };
        }
    }
    /*static passwordValidator(control) {
      // {6,100}           - Assert password is between 6 and 100 characters
      // (?=.*[0-9])       - Assert a string has at least one number
      if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
        return null;
      } else {
        return {'invalidPassword': true};
      }
    }*/
    static canadaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^(?!.*[DFIOQU])[A-VXYa-vxy][0-9][A-Za-z] ?[0-9][A-Za-z][0-9]$/)) {
            return null;
        }
        else {
            return { 'error.msg.postal': true };
        }
    }
    static usaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}(?:-[0-9]{4})?$/)) {
            return null;
        }
        else {
            return { 'error.mgs.zip': true };
        }
    }
    static countryValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value[0].id !== '') {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static phoneNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.phone': true };
        }
    }
    static faxNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.fax': true };
        }
    }
    static numberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.number': true };
        }
    }
    static companyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static numeric5Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.5.numeric': true };
        }
    }
    static numeric6Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.6.numeric': true };
        }
    }
    static numeric8Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.8.numeric': true };
        }
    }
    static dossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[m]{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static dossierContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static regulatoryContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.regu.contact.id': true };
        }
    }
    static licenceNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.licence.number': true };
        }
    }
    static appNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.application.number': true };
        }
    }
    static dinValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.din': true };
        }
    }
    static npnValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.npn': true };
        }
    }
    static checkboxRequiredValidator(control) {
        if (control.value) {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static contactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static primaryCompanyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static atLeastOneCheckboxSelected(formArray) {
        // return (): { [key: string]: boolean } | null => {
        const controls = formArray.controls;
        // Check if at least one checkbox is selected
        const isAtLeastOneSelected = controls.some((control) => control.value === true);
        // Return validation error if none are selected
        return isAtLeastOneSelected ? null : { 'required': true };
        // };
    }
    static masterFileNumberValidator(control) {
        // todo
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{4}-[0-9]{3}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.incorrectFormat': true };
        }
    }
    // if first letter is e, then followed by 6 numbers
    // if first letter is f, then followed by 7 numbers
    static masterFileDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[e]{1}[0-9]{6}$/) ||
            control.value.match(/^[f]{1}[0-9]{7}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static accountNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.account': true };
        }
    }
    static businessNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.business': true };
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGlvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvdmFsaWRhdGlvbi92YWxpZGF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLGlCQUFpQjtJQUU1QjtRQUNFLHNDQUFzQztRQUN0QyxvRkFBb0Y7SUFFdEYsQ0FBQztJQUVELHdCQUF3QixDQUFDLGFBQXFCO1FBQzVDLHFGQUFxRjtRQUNyRixNQUFNLE1BQU0sR0FBRztZQUNiLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxpQkFBaUIsRUFBRSxpQkFBaUI7WUFDcEMsZUFBZSxFQUFFLGVBQWU7WUFDaEMsaUJBQWlCLEVBQUUsaUJBQWlCO1lBQ3BDLFdBQVcsRUFBRSxxQkFBcUI7WUFDbEMsa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLGVBQWUsRUFBRSxlQUFlO1lBQ2hDLHNCQUFzQixFQUFFLHNCQUFzQjtZQUM5QyxzQkFBc0IsRUFBRSxzQkFBc0I7WUFDOUMsOEJBQThCLEVBQUUsOEJBQThCO1lBQzlELDhCQUE4QixFQUFFLDhCQUE4QjtZQUM5RCxxQkFBcUIsRUFBRSxxQkFBcUI7WUFDNUMscUJBQXFCLEVBQUUscUJBQXFCO1lBQzVDLHFCQUFxQixFQUFDLHFCQUFxQjtZQUMzQywyQkFBMkIsRUFBRSwyQkFBMkI7WUFDeEQsc0JBQXNCLEVBQUUsc0JBQXNCO1lBQzlDLDBCQUEwQixFQUFFLDBCQUEwQjtZQUN0RCw4QkFBOEIsRUFBRSw4QkFBOEI7WUFDOUQsZUFBZSxFQUFFLGVBQWU7WUFDaEMsZUFBZSxFQUFFLGVBQWU7WUFDaEMsMEJBQTBCLEVBQUcsMEJBQTBCO1lBQ3ZELDBCQUEwQixFQUFHLDBCQUEwQjtZQUN2RCwyQkFBMkIsRUFBRSwyQkFBMkI7WUFDeEQsdUJBQXVCLEVBQUUsdUJBQXVCO1lBQ2hELG1CQUFtQixFQUFDLG1CQUFtQjtZQUN2Qyx3QkFBd0IsRUFBQyx3QkFBd0I7U0FDbEQsQ0FBQztRQUVGLE9BQU8sTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRCxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU87UUFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCwyQkFBMkI7UUFDM0IsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxrREFBa0QsQ0FBQyxFQUFFLENBQUM7WUFDNUUsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxpQkFBaUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNuQyxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsTUFBTSxDQUFDLHFCQUFxQixDQUFDLE9BQU87UUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLCtEQUErRCxDQUFDLEVBQUUsQ0FBQztZQUN6RixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLGtCQUFrQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3BDLENBQUM7SUFFSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU87UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLEVBQUUsQ0FBQztZQUNwRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNqQyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPO1FBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPO1FBQ2pDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsaUJBQWlCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDbkMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTztRQUMvQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNqQyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTztRQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLGtCQUFrQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3BDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU87UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxzQkFBc0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMscUJBQXFCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDdkMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTztRQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHFCQUFxQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU87UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxxQkFBcUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUdELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUM7WUFDNUMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxzQkFBc0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPO1FBQ3RDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsc0JBQXNCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsNEJBQTRCLENBQUMsT0FBTztRQUN6QyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDJCQUEyQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzdDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLG1CQUFtQixDQUFDLE9BQU87UUFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQywwQkFBMEIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUM1QyxDQUFDO0lBQ0gsQ0FBQztJQUlELE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTztRQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDhCQUE4QixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ2hELENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPO1FBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsZUFBZSxFQUFFLElBQUksRUFBQyxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPO1FBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsZUFBZSxFQUFFLElBQUksRUFBQyxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHlCQUF5QixDQUFDLE9BQU87UUFDdEMsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbEIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxVQUFVLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTztRQUMvQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHlCQUF5QixDQUFDLE9BQU87UUFDdEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxzQkFBc0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxTQUFvQjtRQUNwRCxvREFBb0Q7UUFDbEQsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUVwQyw2Q0FBNkM7UUFDN0MsTUFBTSxvQkFBb0IsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBd0IsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQztRQUVqRywrQ0FBK0M7UUFDL0MsT0FBTyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUM1RCxLQUFLO0lBQ1AsQ0FBQztJQUVELE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPO1FBQ3RDLE9BQU87UUFDUCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDO1lBQy9DLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUUsMkJBQTJCLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFFRCxtREFBbUQ7SUFDbkQsbURBQW1EO0lBQ25ELE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPO1FBQ3pDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFDRSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQztZQUN2QyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxFQUN2QyxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxzQkFBc0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPO1FBQ25DLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsbUJBQW1CLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDckMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsdUJBQXVCLENBQUMsT0FBTztRQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLG9CQUFvQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3RDLENBQUM7SUFDSCxDQUFDOytHQXpWVSxpQkFBaUI7bUhBQWpCLGlCQUFpQjs7NEZBQWpCLGlCQUFpQjtrQkFEN0IsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQWJzdHJhY3RDb250cm9sLCBGb3JtQXJyYXksIEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgSVZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi92YWxpZGF0aW9uLXNlcnZpY2UuaW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFZhbGlkYXRpb25TZXJ2aWNlIGltcGxlbWVudHMgSVZhbGlkYXRpb25TZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAvLyBwcml2YXRlIHRyYW5zbGF0ZTogVHJhbnNsYXRlU2VydmljZVxyXG4gICAgLy8gdGhpcy50cmFuc2xhdGUuZ2V0KCdlcnJvci5tc2cucmVxdWlyZWQnKS5zdWJzY3JpYmUocmVzID0+IHsgY29uc29sZS5sb2cocmVzKTsgfSk7XHJcblxyXG4gIH1cclxuXHJcbiAgZ2V0VmFsaWRhdG9yRXJyb3JNZXNzYWdlKHZhbGlkYXRvck5hbWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgLy8gVE9ETyBzdWNreSBuZWVkIHRvIG1ha2UgdGhlIGtleXMgdGhlIHNhbWUgYXMgdGhlIHRyYW5zbGF0aW9uIGZvciB0aGUgZXJyb3Igc3VtbWFyeVxyXG4gICAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgICAncmVxdWlyZWQnOiAncmVxdWlyZWQnLFxyXG4gICAgICAnZXJyb3IubXNnLm51bWJlcic6ICdlcnJvci5tc2cubnVtYmVyJyxcclxuICAgICAgJ2Vycm9yLm1zZy5waG9uZSc6ICdlcnJvci5tc2cucGhvbmUnLFxyXG4gICAgICAnZXJyb3IubXNnLmZheCc6ICdlcnJvci5tc2cuZmF4JyxcclxuICAgICAgJ2Vycm9yLm1zZy5lbWFpbCc6ICdlcnJvci5tc2cuZW1haWwnLFxyXG4gICAgICAnbWlubGVuZ3RoJzogJ2Vycm9yLm1zZy5taW5sZW5ndGgnLFxyXG4gICAgICAnZXJyb3IubXNnLnBvc3RhbCc6ICdlcnJvci5tc2cucG9zdGFsJyxcclxuICAgICAgJ2Vycm9yLm1ncy56aXAnOiAnZXJyb3IubWdzLnppcCcsXHJcbiAgICAgICdlcnJvci5tZ3MuY29tcGFueS5pZCc6ICdlcnJvci5tZ3MuY29tcGFueS5pZCcsXHJcbiAgICAgICdlcnJvci5tZ3MuY29udGFjdC5pZCc6ICdlcnJvci5tZ3MuY29udGFjdC5pZCcsXHJcbiAgICAgICdlcnJvci5tZ3MucHJpbWFyeS5jb21wYW55LmlkJzogJ2Vycm9yLm1ncy5wcmltYXJ5LmNvbXBhbnkuaWQnLFxyXG4gICAgICAnZXJyb3IubWdzLnByaW1hcnkuY29udGFjdC5pZCc6ICdlcnJvci5tZ3MucHJpbWFyeS5jb250YWN0LmlkJyxcclxuICAgICAgJ2Vycm9yLm1ncy41Lm51bWVyaWMnOiAnZXJyb3IubWdzLjUubnVtZXJpYycsXHJcbiAgICAgICdlcnJvci5tZ3MuNi5udW1lcmljJzogJ2Vycm9yLm1ncy42Lm51bWVyaWMnLFxyXG4gICAgICAnZXJyb3IubWdzLjgubnVtZXJpYyc6J2Vycm9yLm1ncy44Lm51bWVyaWMnLFxyXG4gICAgICAnZXJyb3IubWdzLnJlZ3UuY29udGFjdC5pZCc6ICdlcnJvci5tZ3MucmVndS5jb250YWN0LmlkJyxcclxuICAgICAgJ2Vycm9yLm1ncy5kb3NzaWVyLmlkJzogJ2Vycm9yLm1ncy5kb3NzaWVyLmlkJyxcclxuICAgICAgJ2Vycm9yLm1ncy5saWNlbmNlLm51bWJlcic6ICdlcnJvci5tZ3MubGljZW5jZS5udW1iZXInLFxyXG4gICAgICAnZXJyb3IubWdzLmFwcGxpY2F0aW9uLm51bWJlcic6ICdlcnJvci5tZ3MuYXBwbGljYXRpb24ubnVtYmVyJyxcclxuICAgICAgJ2Vycm9yLm1ncy5kaW4nOiAnZXJyb3IubWdzLmRpbicsXHJcbiAgICAgICdlcnJvci5tZ3MubnBuJzogJ2Vycm9yLm1ncy5ucG4nLFxyXG4gICAgICAnZXJyb3IubXNnLnJlbW92ZS5jb250YWN0JyA6ICdlcnJvci5tc2cucmVtb3ZlLmNvbnRhY3QnLFxyXG4gICAgICAnZXJyb3IubXNnLnJldmlzZS5jb250YWN0JyA6ICdlcnJvci5tc2cucmV2aXNlLmNvbnRhY3QnLFxyXG4gICAgICAnZXJyb3IubWdzLmluY29ycmVjdEZvcm1hdCc6ICdlcnJvci5tZ3MuaW5jb3JyZWN0Rm9ybWF0JyxcclxuICAgICAgJ2Vycm9yLm1zZy5pbnZhbGlkRGF0ZSc6ICdlcnJvci5tc2cuaW52YWxpZERhdGUnLFxyXG4gICAgICAnZXJyb3IubXNnLmVuZERhdGUnOidlcnJvci5tc2cuZW5kRGF0ZScsXHJcbiAgICAgICdlcnJvci5tc2cucm9sZVNlbGVjdGVkJzonZXJyb3IubXNnLnJvbGVTZWxlY3RlZCdcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIGNvbmZpZ1t2YWxpZGF0b3JOYW1lXTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBlbWFpbFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICAvLyBSRkMgMjgyMiBjb21wbGlhbnQgcmVnZXhcclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eW2EtekEtWjAtOV8uKy1dK0BbYS16QS1aMC05LV0rXFwuW2EtekEtWjAtOS0uXSskLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cuZW1haWwnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qc3RhdGljIHBhc3N3b3JkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIC8vIHs2LDEwMH0gICAgICAgICAgIC0gQXNzZXJ0IHBhc3N3b3JkIGlzIGJldHdlZW4gNiBhbmQgMTAwIGNoYXJhY3RlcnNcclxuICAgIC8vICg/PS4qWzAtOV0pICAgICAgIC0gQXNzZXJ0IGEgc3RyaW5nIGhhcyBhdCBsZWFzdCBvbmUgbnVtYmVyXHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXig/PS4qWzAtOV0pW2EtekEtWjAtOSFAIyQlXiYqXXs2LDEwMH0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydpbnZhbGlkUGFzc3dvcmQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9Ki9cclxuICBzdGF0aWMgY2FuYWRhUG9zdGFsVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eKD8hLipbREZJT1FVXSlbQS1WWFlhLXZ4eV1bMC05XVtBLVphLXpdID9bMC05XVtBLVphLXpdWzAtOV0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cucG9zdGFsJzogdHJ1ZX07XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHVzYVBvc3RhbFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezV9KD86LVswLTldezR9KT8kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuemlwJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgY291bnRyeVZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZVswXS5pZCAhPT0gJycpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydyZXF1aXJlZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHBob25lTnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLnBob25lJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZmF4TnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLmZheCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG51bWJlclZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldKiQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5udW1iZXInOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBjb21wYW55SWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs2fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5jb21wYW55LmlkJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgbnVtZXJpYzVWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs1fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy41Lm51bWVyaWMnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBudW1lcmljNlZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLjYubnVtZXJpYyc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG51bWVyaWM4VmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17OH0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuOC5udW1lcmljJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbiAgc3RhdGljIGRvc3NpZXJJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlttXXsxfVswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRvc3NpZXIuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBkb3NzaWVyQ29udGFjdElkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17NX0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuY29udGFjdC5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHJlZ3VsYXRvcnlDb250YWN0SWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs1fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5yZWd1LmNvbnRhY3QuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBsaWNlbmNlTnVtVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MubGljZW5jZS5udW1iZXInOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuXHJcbiAgc3RhdGljIGFwcE51bVZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmFwcGxpY2F0aW9uLm51bWJlcic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGRpblZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezh9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRpbic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG5wblZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezh9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLm5wbic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydyZXF1aXJlZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNvbnRhY3RJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezV9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmNvbnRhY3QuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBwcmltYXJ5Q29tcGFueUlkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuY29tcGFueS5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGF0TGVhc3RPbmVDaGVja2JveFNlbGVjdGVkKGZvcm1BcnJheTogRm9ybUFycmF5KSB7XHJcbiAgICAvLyByZXR1cm4gKCk6IHsgW2tleTogc3RyaW5nXTogYm9vbGVhbiB9IHwgbnVsbCA9PiB7XHJcbiAgICAgIGNvbnN0IGNvbnRyb2xzID0gZm9ybUFycmF5LmNvbnRyb2xzO1xyXG4gIFxyXG4gICAgICAvLyBDaGVjayBpZiBhdCBsZWFzdCBvbmUgY2hlY2tib3ggaXMgc2VsZWN0ZWRcclxuICAgICAgY29uc3QgaXNBdExlYXN0T25lU2VsZWN0ZWQgPSBjb250cm9scy5zb21lKChjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpID0+IGNvbnRyb2wudmFsdWUgPT09IHRydWUpO1xyXG4gIFxyXG4gICAgICAvLyBSZXR1cm4gdmFsaWRhdGlvbiBlcnJvciBpZiBub25lIGFyZSBzZWxlY3RlZFxyXG4gICAgICByZXR1cm4gaXNBdExlYXN0T25lU2VsZWN0ZWQgPyBudWxsIDogeyAncmVxdWlyZWQnOiB0cnVlIH07XHJcbiAgICAvLyB9O1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIG1hc3RlckZpbGVOdW1iZXJWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgLy8gdG9kb1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs0fS1bMC05XXszfSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7ICdlcnJvci5tZ3MuaW5jb3JyZWN0Rm9ybWF0JzogdHJ1ZSB9OyBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIGlmIGZpcnN0IGxldHRlciBpcyBlLCB0aGVuIGZvbGxvd2VkIGJ5IDYgbnVtYmVyc1xyXG4gIC8vIGlmIGZpcnN0IGxldHRlciBpcyBmLCB0aGVuIGZvbGxvd2VkIGJ5IDcgbnVtYmVyc1xyXG4gIHN0YXRpYyBtYXN0ZXJGaWxlRG9zc2llcklkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChcclxuICAgICAgY29udHJvbC52YWx1ZS5tYXRjaCgvXltlXXsxfVswLTldezZ9JC8pIHx8XHJcbiAgICAgIGNvbnRyb2wudmFsdWUubWF0Y2goL15bZl17MX1bMC05XXs3fSQvKVxyXG4gICAgKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRvc3NpZXIuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBhY2NvdW50TnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLmFjY291bnQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBidXNpbmVzc051bWJlclZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldKiQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5idXNpbmVzcyc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0=