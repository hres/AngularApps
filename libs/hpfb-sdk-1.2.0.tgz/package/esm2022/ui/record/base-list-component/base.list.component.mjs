import { Component, Inject, Input } from "@angular/core";
import { BaseListService } from "../base-list-service/base.list.service";
import { BaseComponent } from "../../component-base/base.component";
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "../base-list-service/base.list.service";
export class BaseListComponent extends BaseComponent {
    constructor(_fb, listService) {
        super();
        this._fb = _fb;
        this.listService = listService;
    }
    ngOnChanges(changes) {
        if (changes['recordList']) {
            this._init(changes['recordList'].currentValue);
        }
    }
    _init(recordData) {
        // Clear existing controls
        this.recordFormArray.clear();
        if (recordData && recordData.length !== 0) {
            if (recordData.length > 0) {
                recordData.forEach(record => {
                    const group = this.recordService.createRecordFormGroup(this._fb);
                    // Set values after defining the form controls
                    group.patchValue({
                        id: record.id,
                        isNew: false,
                        expandFlag: false,
                    });
                    this._patchRecordInfoValue(group, record);
                    this._patchLastSavedStateValue(group.controls['lastSavedState'], record);
                    this.recordFormArray.push(group);
                });
            }
        }
        else {
            if (!this.isInternal) {
                const group = this.recordService.createRecordFormGroup(this._fb);
                this.recordFormArray.push(group);
                const firstFormRecord = this.recordFormArray.at(0);
                firstFormRecord.controls['expandFlag'].setValue(true);
            }
        }
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
        // Set the list of form groups
        this.listService.setList(this.recordFormArray.controls);
    }
    addRecord() {
        const group = this.recordService.createRecordFormGroup(this._fb);
        this.recordFormArray.push(group);
    }
    saveRecord(event) {
        const index = event.index;
        const group = this.recordFormArray.at(index);
        // if this is a new record, assign next available id, otherwise, use it's existing id
        const id = group.get('isNew').value ? this.listService.getNextId() : group.get('id').value;
        group.patchValue({
            id: id,
            isNew: false,
            expandFlag: false, // collapse this record
        });
        const recordInfo = this.getRecordInfo(group);
        // Update lastSavedState with the current value of contactInfo
        group.get('lastSavedState').setValue(recordInfo.value);
        this._expandNextInvalidRecord();
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    _expandNextInvalidRecord() {
        // expand next invalid record
        for (let index = 0; index < this.recordFormArray.controls.length; index++) {
            const group = this.recordFormArray.controls[index];
            if (group.invalid) {
                group.controls['expandFlag'].setValue(true);
                this.recordFormGroup.markAsDirty();
                break;
            }
        }
    }
    deleteRecord(index) {
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        recordInfo.reset();
        this.recordFormArray.removeAt(index);
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    revertRecord(event) {
        const index = event.index;
        const id = event.id;
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        // Revert to the last saved state
        const lastSavedState = group.get('lastSavedState').value;
        recordInfo.patchValue(lastSavedState);
    }
    handleRowClick(event) {
        const clickedIndex = event.index;
        const clickedRecordState = event.state;
        if (this.recordFormGroup.pristine) {
            this.recordFormArray.controls.forEach((element, index) => {
                if (clickedIndex === index) {
                    element.controls['expandFlag'].setValue(!clickedRecordState);
                }
            });
        }
        else {
            this.openPopup();
        }
    }
    showError(errs) {
        if (errs.length > 0) {
            this.showErrors = true;
        }
        else {
            this.showErrors = false;
        }
    }
    disableAddButton() {
        return (this.recordFormGroup.dirty || !this.recordFormGroup.valid || this.errorList?.length > 0);
    }
    openPopup() {
        jQuery("#" + this.popupId).trigger("open.wb-overlay");
    }
    get recordFormArray() {
        return this.recordFormGroup.get(this.records);
    }
    getRecordInfo(recordFormGroup) {
        return recordFormGroup.get(this.recordInfo);
    }
    getRecordFormArrValues() {
        return this.recordFormArray.value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, deps: [{ token: i1.FormBuilder }, { token: BaseListService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: BaseListComponent, selector: "ng-component", inputs: { recordList: "recordList", showErrors: "showErrors", isInternal: "isInternal" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }], ctorParameters: () => [{ type: i1.FormBuilder }, { type: i2.BaseListService, decorators: [{
                    type: Inject,
                    args: [BaseListService]
                }] }], propDecorators: { recordList: [{
                type: Input
            }], showErrors: [{
                type: Input
            }], isInternal: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5saXN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3JlY29yZC9iYXNlLWxpc3QtY29tcG9uZW50L2Jhc2UubGlzdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFpQixTQUFTLEVBQVUsTUFBTSxFQUFFLEtBQUssRUFBb0MsTUFBTSxlQUFlLENBQUM7QUFLbEgsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHdDQUF3QyxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQTs7OztBQU9uRSxNQUFNLE9BQWdCLGlCQUEwQyxTQUFRLGFBQWE7SUFlakYsWUFBb0IsR0FBZ0IsRUFDRyxXQUE0QjtRQUMvRCxLQUFLLEVBQUUsQ0FBQztRQUZRLFFBQUcsR0FBSCxHQUFHLENBQWE7UUFDRyxnQkFBVyxHQUFYLFdBQVcsQ0FBaUI7SUFFbkUsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ25ELENBQUM7SUFDTCxDQUFDO0lBRU8sS0FBSyxDQUFDLFVBQWU7UUFDekIsMEJBQTBCO1FBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFN0IsSUFBSSxVQUFVLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN4QyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzFCLFVBQVUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQzFCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUVqRSw4Q0FBOEM7b0JBQzlDLEtBQUssQ0FBQyxVQUFVLENBQUM7d0JBQ2YsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO3dCQUNiLEtBQUssRUFBRSxLQUFLO3dCQUNaLFVBQVUsRUFBRSxLQUFLO3FCQUNsQixDQUFDLENBQUM7b0JBRUgsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFFekUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25DLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztRQUNMLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDbkIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2pFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNqQyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQWMsQ0FBQztnQkFDaEUsZUFBZSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDMUQsQ0FBQztRQUNILENBQUM7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLENBQUM7UUFFekUsOEJBQThCO1FBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBdUIsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFLRCxTQUFTO1FBQ0wsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUFVO1FBQ2pCLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDMUIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFvQixDQUFDO1FBQ2hFLHFGQUFxRjtRQUNyRixNQUFNLEVBQUUsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUE7UUFDeEYsS0FBSyxDQUFDLFVBQVUsQ0FBQztZQUNqQixFQUFFLEVBQUUsRUFBRTtZQUNOLEtBQUssRUFBRSxLQUFLO1lBQ1osVUFBVSxFQUFFLEtBQUssRUFBSyx1QkFBdUI7U0FDNUMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3Qyw4REFBOEQ7UUFDOUQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdkQsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7UUFDaEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFTyx3QkFBd0I7UUFDNUIsNkJBQTZCO1FBQzdCLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztZQUMzRSxNQUFNLEtBQUssR0FBb0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFvQixDQUFDO1lBQ3ZGLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNuQixLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDakMsTUFBTTtZQUNULENBQUM7UUFDSCxDQUFDO0lBQ0osQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFhO1FBQ3RCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBb0IsQ0FBQztRQUNoRSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVyQyxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFVO1FBQ3BCLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDekIsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNwQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQW9CLENBQUM7UUFDaEUsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3QyxpQ0FBaUM7UUFDakMsTUFBTSxjQUFjLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUN6RCxVQUFVLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFRCxjQUFjLENBQUMsS0FBVTtRQUNyQixNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ2pDLE1BQU0sa0JBQWtCLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN2QyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFFLENBQUMsT0FBa0IsRUFBRSxLQUFhLEVBQUUsRUFBRTtnQkFDekUsSUFBSSxZQUFZLEtBQUcsS0FBSyxFQUFFLENBQUM7b0JBQzNCLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtnQkFDNUQsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFBO1FBQ0YsQ0FBQzthQUFNLENBQUM7WUFDUixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakIsQ0FBQztJQUNMLENBQUM7SUFFRCxTQUFTLENBQUMsSUFBUztRQUNmLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUMzQixDQUFDO2FBQU0sQ0FBQztZQUNKLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQzVCLENBQUM7SUFDTCxDQUFDO0lBRUQsZ0JBQWdCO1FBQ1osT0FBTyxDQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLElBQUssSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDdkcsQ0FBQztJQUVELFNBQVM7UUFDTCxNQUFNLENBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUUsQ0FBQyxPQUFPLENBQUUsaUJBQWlCLENBQUUsQ0FBQztJQUM5RCxDQUFDO0lBRUQsSUFBSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFjLENBQUM7SUFDL0QsQ0FBQztJQUVELGFBQWEsQ0FBQyxlQUEwQjtRQUNwQyxPQUFPLGVBQWUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBYyxDQUFDO0lBQzdELENBQUM7SUFFRCxzQkFBc0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztJQUN0QyxDQUFDOytHQTlKaUIsaUJBQWlCLDZDQWdCdkIsZUFBZTttR0FoQlQsaUJBQWlCLDBMQUZ6QixFQUFFOzs0RkFFTSxpQkFBaUI7a0JBSHRDLFNBQVM7bUJBQUM7b0JBQ1AsUUFBUSxFQUFFLEVBQUU7aUJBQ2Y7OzBCQWlCUSxNQUFNOzJCQUFDLGVBQWU7eUNBZmxCLFVBQVU7c0JBQWxCLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSztnQkFDRyxVQUFVO3NCQUFsQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWZ0ZXJWaWV3SW5pdCwgQ29tcG9uZW50LCBpbmplY3QsIEluamVjdCwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgSUJhc2VMaXN0IH0gZnJvbSBcIi4vYmFzZS5saXN0LmludGVyZmFjZVwiO1xyXG5pbXBvcnQgeyBGb3JtR3JvdXAsIEZvcm1BcnJheSwgRm9ybUJ1aWxkZXIgfSBmcm9tIFwiQGFuZ3VsYXIvZm9ybXNcIjtcclxuaW1wb3J0IHsgSVJlY29yZFNlcnZpY2UgfSBmcm9tIFwiLi4vcmVjb3JkLXNlcnZpY2UvcmVjb3JkLnNlcnZpY2UuaW50ZXJmYWNlXCI7XHJcbmltcG9ydCB7IE91dHB1dFJlY29yZCwgUmVjb3JkRm9ybUdyb3VwIH0gZnJvbSBcIi4uL3JlY29yZC1tb2RlbC9yZWNvcmQubW9kZWxcIjtcclxuaW1wb3J0IHsgQmFzZUxpc3RTZXJ2aWNlIH0gZnJvbSBcIi4uL2Jhc2UtbGlzdC1zZXJ2aWNlL2Jhc2UubGlzdC5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7IEJhc2VDb21wb25lbnQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50LWJhc2UvYmFzZS5jb21wb25lbnRcIlxyXG5cclxuaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgdGVtcGxhdGU6ICcnXHJcbn0pXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBCYXNlTGlzdENvbXBvbmVudDxUIGV4dGVuZHMgT3V0cHV0UmVjb3JkPiBleHRlbmRzIEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBJQmFzZUxpc3Q8VD4sIEFmdGVyVmlld0luaXQge1xyXG4gICAgQElucHV0KCkgcmVjb3JkTGlzdDogVFtdO1xyXG4gICAgQElucHV0KCkgc2hvd0Vycm9yczogYm9vbGVhbjtcclxuICAgIEBJbnB1dCgpIGlzSW50ZXJuYWw/OiBib29sZWFuO1xyXG5cclxuICAgIHJlY29yZEZvcm1Hcm91cDogRm9ybUdyb3VwO1xyXG4gICAgZXJyb3JTdW1tYXJ5Q2hpbGQ6IGFueTtcclxuXHJcbiAgICBhYnN0cmFjdCBzdGF0dXNNZXNzYWdlIDogc3RyaW5nO1xyXG4gICAgYWJzdHJhY3QgcmVjb3Jkczogc3RyaW5nO1xyXG4gICAgYWJzdHJhY3QgcmVjb3JkSW5mbzogc3RyaW5nO1xyXG4gICAgYWJzdHJhY3QgcmVjb3JkU2VydmljZTogSVJlY29yZFNlcnZpY2U7XHJcbiAgICBhYnN0cmFjdCBwb3B1cElkOiBzdHJpbmc7XHJcbiAgICBhYnN0cmFjdCBlcnJvckxpc3Q6IFtdO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2ZiOiBGb3JtQnVpbGRlciwgXHJcbiAgICAgICAgQEluamVjdChCYXNlTGlzdFNlcnZpY2UpIHByb3RlY3RlZCBsaXN0U2VydmljZTogQmFzZUxpc3RTZXJ2aWNlKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKGNoYW5nZXNbJ3JlY29yZExpc3QnXSkge1xyXG4gICAgICAgICAgICB0aGlzLl9pbml0KGNoYW5nZXNbJ3JlY29yZExpc3QnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0KHJlY29yZERhdGE6IFRbXSkge1xyXG4gICAgICAgIC8vIENsZWFyIGV4aXN0aW5nIGNvbnRyb2xzXHJcbiAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LmNsZWFyKCk7XHJcbiAgXHJcbiAgICAgIGlmIChyZWNvcmREYXRhICYmIHJlY29yZERhdGEubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICBpZiAocmVjb3JkRGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHJlY29yZERhdGEuZm9yRWFjaChyZWNvcmQgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRTZXJ2aWNlLmNyZWF0ZVJlY29yZEZvcm1Hcm91cCh0aGlzLl9mYik7XHJcbiAgXHJcbiAgICAgICAgICAgICAgLy8gU2V0IHZhbHVlcyBhZnRlciBkZWZpbmluZyB0aGUgZm9ybSBjb250cm9sc1xyXG4gICAgICAgICAgICAgIGdyb3VwLnBhdGNoVmFsdWUoe1xyXG4gICAgICAgICAgICAgICAgaWQ6IHJlY29yZC5pZCxcclxuICAgICAgICAgICAgICAgIGlzTmV3OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGV4cGFuZEZsYWc6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHRoaXMuX3BhdGNoUmVjb3JkSW5mb1ZhbHVlKGdyb3VwLCByZWNvcmQpO1xyXG4gICAgICAgICAgICAgIHRoaXMuX3BhdGNoTGFzdFNhdmVkU3RhdGVWYWx1ZShncm91cC5jb250cm9sc1snbGFzdFNhdmVkU3RhdGUnXSwgcmVjb3JkKTtcclxuICBcclxuICAgICAgICAgICAgICB0aGlzLnJlY29yZEZvcm1BcnJheS5wdXNoKGdyb3VwKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzSW50ZXJuYWwpIHtcclxuICAgICAgICAgICAgY29uc3QgZ3JvdXAgPSB0aGlzLnJlY29yZFNlcnZpY2UuY3JlYXRlUmVjb3JkRm9ybUdyb3VwKHRoaXMuX2ZiKTtcclxuICAgICAgICAgICAgdGhpcy5yZWNvcmRGb3JtQXJyYXkucHVzaChncm91cCk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0Rm9ybVJlY29yZCA9IHRoaXMucmVjb3JkRm9ybUFycmF5LmF0KDApIGFzIEZvcm1Hcm91cDtcclxuICAgICAgICAgICAgZmlyc3RGb3JtUmVjb3JkLmNvbnRyb2xzWydleHBhbmRGbGFnJ10uc2V0VmFsdWUodHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMucmVjb3JkU2VydmljZS5zZXRSZWNvcmRzRm9ybUFyclZhbHVlKHRoaXMuZ2V0UmVjb3JkRm9ybUFyclZhbHVlcygpKTtcclxuICBcclxuICAgICAgLy8gU2V0IHRoZSBsaXN0IG9mIGZvcm0gZ3JvdXBzXHJcbiAgICAgIHRoaXMubGlzdFNlcnZpY2Uuc2V0TGlzdCh0aGlzLnJlY29yZEZvcm1BcnJheS5jb250cm9scyBhcyBGb3JtR3JvdXBbXSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGFic3RyYWN0IF9wYXRjaFJlY29yZEluZm9WYWx1ZShncm91cCwgb3V0cHV0TW9kZWwpO1xyXG4gICAgcHJvdGVjdGVkIGFic3RyYWN0IF9wYXRjaExhc3RTYXZlZFN0YXRlVmFsdWUobGFzdFNhdmVkU3RhdGVGb3JtQ29udHJvbCwgb3V0cHV0TW9kZWwpO1xyXG5cclxuICAgIGFkZFJlY29yZCgpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBncm91cCA9IHRoaXMucmVjb3JkU2VydmljZS5jcmVhdGVSZWNvcmRGb3JtR3JvdXAodGhpcy5fZmIpO1xyXG4gICAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LnB1c2goZ3JvdXApOyAgICBcclxuICAgIH1cclxuXHJcbiAgICBzYXZlUmVjb3JkKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IGV2ZW50LmluZGV4O1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoaW5kZXgpIGFzIFJlY29yZEZvcm1Hcm91cDtcclxuICAgICAgICAvLyBpZiB0aGlzIGlzIGEgbmV3IHJlY29yZCwgYXNzaWduIG5leHQgYXZhaWxhYmxlIGlkLCBvdGhlcndpc2UsIHVzZSBpdCdzIGV4aXN0aW5nIGlkXHJcbiAgICAgICAgY29uc3QgaWQgPSBncm91cC5nZXQoJ2lzTmV3JykudmFsdWU/IHRoaXMubGlzdFNlcnZpY2UuZ2V0TmV4dElkKCk6IGdyb3VwLmdldCgnaWQnKS52YWx1ZVxyXG4gICAgICAgIGdyb3VwLnBhdGNoVmFsdWUoeyBcclxuICAgICAgICBpZDogaWQsXHJcbiAgICAgICAgaXNOZXc6IGZhbHNlLFxyXG4gICAgICAgIGV4cGFuZEZsYWc6IGZhbHNlLCAgICAvLyBjb2xsYXBzZSB0aGlzIHJlY29yZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnN0IHJlY29yZEluZm8gPSB0aGlzLmdldFJlY29yZEluZm8oZ3JvdXApO1xyXG4gICAgICAgIC8vIFVwZGF0ZSBsYXN0U2F2ZWRTdGF0ZSB3aXRoIHRoZSBjdXJyZW50IHZhbHVlIG9mIGNvbnRhY3RJbmZvXHJcbiAgICAgICAgZ3JvdXAuZ2V0KCdsYXN0U2F2ZWRTdGF0ZScpLnNldFZhbHVlKHJlY29yZEluZm8udmFsdWUpO1xyXG4gICAgICAgIHRoaXMuX2V4cGFuZE5leHRJbnZhbGlkUmVjb3JkKCk7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRTZXJ2aWNlLnNldFJlY29yZHNGb3JtQXJyVmFsdWUodGhpcy5nZXRSZWNvcmRGb3JtQXJyVmFsdWVzKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2V4cGFuZE5leHRJbnZhbGlkUmVjb3JkKCl7XHJcbiAgICAgICAgLy8gZXhwYW5kIG5leHQgaW52YWxpZCByZWNvcmRcclxuICAgICAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdGhpcy5yZWNvcmRGb3JtQXJyYXkuY29udHJvbHMubGVuZ3RoOyBpbmRleCsrKSB7XHJcbiAgICAgICAgIGNvbnN0IGdyb3VwOiBSZWNvcmRGb3JtR3JvdXAgPSB0aGlzLnJlY29yZEZvcm1BcnJheS5jb250cm9sc1tpbmRleF0gYXMgUmVjb3JkRm9ybUdyb3VwO1xyXG4gICAgICAgICBpZiAoZ3JvdXAuaW52YWxpZCkge1xyXG4gICAgICAgICAgZ3JvdXAuY29udHJvbHNbJ2V4cGFuZEZsYWcnXS5zZXRWYWx1ZSh0cnVlKTtcclxuICAgICAgICAgIHRoaXMucmVjb3JkRm9ybUdyb3VwLm1hcmtBc0RpcnR5KCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICB9IFxyXG4gICAgICAgfSAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgZGVsZXRlUmVjb3JkKGluZGV4OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBncm91cCA9IHRoaXMucmVjb3JkRm9ybUFycmF5LmF0KGluZGV4KSBhcyBSZWNvcmRGb3JtR3JvdXA7XHJcbiAgICAgICAgY29uc3QgcmVjb3JkSW5mbyA9IHRoaXMuZ2V0UmVjb3JkSW5mbyhncm91cCk7XHJcbiAgICAgICAgcmVjb3JkSW5mby5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LnJlbW92ZUF0KGluZGV4KTtcclxuICAgIFxyXG4gICAgICAgIHRoaXMucmVjb3JkU2VydmljZS5zZXRSZWNvcmRzRm9ybUFyclZhbHVlKHRoaXMuZ2V0UmVjb3JkRm9ybUFyclZhbHVlcygpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXZlcnRSZWNvcmQoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgY29uc3QgaW5kZXggPSBldmVudC5pbmRleDtcclxuICAgICAgICBjb25zdCBpZCA9IGV2ZW50LmlkO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoaW5kZXgpIGFzIFJlY29yZEZvcm1Hcm91cDtcclxuICAgICAgICBjb25zdCByZWNvcmRJbmZvID0gdGhpcy5nZXRSZWNvcmRJbmZvKGdyb3VwKTtcclxuICAgICAgICAvLyBSZXZlcnQgdG8gdGhlIGxhc3Qgc2F2ZWQgc3RhdGVcclxuICAgICAgICBjb25zdCBsYXN0U2F2ZWRTdGF0ZSA9IGdyb3VwLmdldCgnbGFzdFNhdmVkU3RhdGUnKS52YWx1ZTtcclxuICAgICAgICByZWNvcmRJbmZvLnBhdGNoVmFsdWUobGFzdFNhdmVkU3RhdGUpOyBcclxuICAgIH1cclxuXHJcbiAgICBoYW5kbGVSb3dDbGljayhldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgY29uc3QgY2xpY2tlZEluZGV4ID0gZXZlbnQuaW5kZXg7XHJcbiAgICAgICAgY29uc3QgY2xpY2tlZFJlY29yZFN0YXRlID0gZXZlbnQuc3RhdGU7XHJcbiAgICAgICAgaWYgKHRoaXMucmVjb3JkRm9ybUdyb3VwLnByaXN0aW5lKSB7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRGb3JtQXJyYXkuY29udHJvbHMuZm9yRWFjaCggKGVsZW1lbnQ6IEZvcm1Hcm91cCwgaW5kZXg6IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoY2xpY2tlZEluZGV4PT09aW5kZXgpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5jb250cm9sc1snZXhwYW5kRmxhZyddLnNldFZhbHVlKCFjbGlja2VkUmVjb3JkU3RhdGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5vcGVuUG9wdXAoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2hvd0Vycm9yKGVycnM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChlcnJzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93RXJyb3JzID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dFcnJvcnMgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGRpc2FibGVBZGRCdXR0b24oKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICggdGhpcy5yZWNvcmRGb3JtR3JvdXAuZGlydHkgfHwgIXRoaXMucmVjb3JkRm9ybUdyb3VwLnZhbGlkICB8fCB0aGlzLmVycm9yTGlzdD8ubGVuZ3RoID4gMCk7XHJcbiAgICB9XHJcblxyXG4gICAgb3BlblBvcHVwKCk6IHZvaWQge1xyXG4gICAgICAgIGpRdWVyeSggXCIjXCIgKyB0aGlzLnBvcHVwSWQgKS50cmlnZ2VyKCBcIm9wZW4ud2Itb3ZlcmxheVwiICk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IHJlY29yZEZvcm1BcnJheSgpOiBGb3JtQXJyYXkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZEZvcm1Hcm91cC5nZXQodGhpcy5yZWNvcmRzKSBhcyBGb3JtQXJyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UmVjb3JkSW5mbyhyZWNvcmRGb3JtR3JvdXA6IEZvcm1Hcm91cCk6IEZvcm1Hcm91cCB7XHJcbiAgICAgICAgcmV0dXJuIHJlY29yZEZvcm1Hcm91cC5nZXQodGhpcy5yZWNvcmRJbmZvKSBhcyBGb3JtR3JvdXA7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UmVjb3JkRm9ybUFyclZhbHVlcygpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5yZWNvcmRGb3JtQXJyYXkudmFsdWU7XHJcbiAgICB9XHJcbiAgICBcclxufSJdfQ==