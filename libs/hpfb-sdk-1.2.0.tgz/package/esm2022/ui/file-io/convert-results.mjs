export class ConvertResults {
    constructor() {
        this.messages = [];
        // public data: Transaction = null;  //todo
        this.data = null;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udmVydC1yZXN1bHRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvZmlsZS1pby9jb252ZXJ0LXJlc3VsdHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxPQUFPLGNBQWM7SUFBM0I7UUFDVyxhQUFRLEdBQWEsRUFBRSxDQUFDO1FBQy9CLDJDQUEyQztRQUNwQyxTQUFJLEdBQVEsSUFBSSxDQUFDO0lBQzVCLENBQUM7Q0FBQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBDb252ZXJ0UmVzdWx0cyB7XHJcbiAgICBwdWJsaWMgbWVzc2FnZXM6IHN0cmluZ1tdID0gW107XHJcbiAgICAvLyBwdWJsaWMgZGF0YTogVHJhbnNhY3Rpb24gPSBudWxsOyAgLy90b2RvXHJcbiAgICBwdWJsaWMgZGF0YTogYW55ID0gbnVsbDtcclxufSJdfQ==