import { Component, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { DRAFT_FILE_TYPE, FILE_TYPE_ERROR, FINAL_FILE_TYPE, FORM_TYPE_ERROR, IMPORT_SUCCESS, CHECK_SUM_ERROR } from '../file-io-constants';
import { ConvertResults } from '../convert-results';
import { FileConversionService } from '../file-conversion.service';
import { CheckSumService } from '../../check-sum/check-sum.service';
import { CHECK_SUM_CONST } from '../../check-sum/check-sum-constants';
import * as i0 from "@angular/core";
import * as i1 from "@ngx-translate/core";
import * as i2 from "@angular/common";
export class FilereaderComponent {
    constructor(translate) {
        this.translate = translate;
        this.complete = new EventEmitter();
        this.rootTag = '';
        this.lang = '';
        this.status = IMPORT_SUCCESS;
        this.importSuccess = false;
        this.importedFileName = "";
        this.displayAlert = false; // reloads the role=alert each message
        this.rootId = '';
        this.fileImported = false;
    }
    ngOnInit() {
        // console.log(this.rootTag);
    }
    ngOnChanges(changes) {
        if (changes['rootTag']) {
            this.rootId = changes['rootTag'].currentValue;
        }
    }
    /**
     * Attaches to the file browser, detecting the file selection change
     * @param $event
     */
    changeListener($event) {
        this.readSelectedFile($event.target);
    }
    /**
     * Determines if a file was selected. Sets a callback to process the file after load (asych)
     * @param inputValue
     */
    readSelectedFile(inputValue) {
        this.fileImported = true;
        let file = inputValue.files[0];
        let myReader = new FileReader();
        let self = this;
        myReader.onloadend = function (e) {
            // you can perform an action with data here callback for asynch load
            let convertResult = new ConvertResults();
            FilereaderComponent._readFile(file.name, myReader.result, self.rootId, convertResult, self.versionTagPath, self.startCheckSumVersion, self.devEnv, self.byPassCheckSum);
            if (convertResult.messages && convertResult.messages.length > 0) {
                self.status = convertResult.messages[0];
            }
            else {
                self.status = IMPORT_SUCCESS;
            }
            if (self.status === IMPORT_SUCCESS) {
                self.importSuccess = true;
            }
            self.importedFileName = file.name;
            self.displayAlert = false;
            setTimeout(() => {
                self.displayAlert = true;
            }, 10);
            setTimeout(() => {
            }, 100);
            self.complete.emit(convertResult);
        };
        if (file && file.name) {
            myReader.readAsText(file);
        }
    }
    /***
     * Processes the file data. Determines the type of file based on the filename suffix
     * @param name - the name of the file. Can include the path
     * @param result - the result of the file read i.e. file contents as text
     * @param rootId - the name of the rootTag. If null is ignored
     * @param {ConvertResults} convertResult -The results of the file read
     * @private
     */
    static _readFile(name, result, rootId, convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass) {
        let splitFile = name.split('.');
        let fileType = splitFile[splitFile.length - 1];
        let conversion = new FileConversionService();
        if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE || fileType.toLowerCase() === FINAL_FILE_TYPE) {
            if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE) {
                conversion.convertToJSONObjects(result, convertResult);
            }
            else {
                conversion.convertXMLToJSONObjects(result, convertResult);
            }
            // console.log(convertResult.data);
            FilereaderComponent.checkRootTagMatch(convertResult, rootId);
            if (fileType.toLowerCase() === FINAL_FILE_TYPE && convertResult.messages.length === 0) {
                if (this.doCheckSumCheck(convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass))
                    if (versionTagPath == null && startCheckSumVersion == null) {
                        this.checkSumCheck(convertResult, rootId);
                    }
                    else {
                        this.strictCheckSumCheck(convertResult, rootId);
                    }
            }
        }
        else {
            convertResult.data = null;
            convertResult.messages = []; //clear msessages
            convertResult.messages.push(FILE_TYPE_ERROR);
        }
    }
    static checkRootTagMatch(convertResult, rootName) {
        if (!rootName || !convertResult || !convertResult.data)
            return;
        if (!convertResult.data[rootName]) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(FORM_TYPE_ERROR);
        }
    }
    refreshPage() {
        location.reload();
    }
    static checkSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!convertResult.data[rootName][CHECK_SUM_CONST]) {
            return;
        }
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static strictCheckSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static doCheckSumCheck(convertResult, versionPath, startCheckSumVersion, devEnv, byPass) {
        if (versionPath != null && startCheckSumVersion != null) {
            var version = convertResult.data;
            versionPath.split(".").forEach(function (key) {
                version = version[key];
            });
            version = parseInt(version.split('.')[0], 10);
            if (version < startCheckSumVersion) {
                return false;
            }
        }
        if (devEnv && byPass) {
            console.warn("Bypassing Checksum Verification in Dev Mode!");
            return false;
        }
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FilereaderComponent, deps: [{ token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: FilereaderComponent, selector: "lib-file-reader", inputs: { rootTag: "rootTag", lang: "lang", versionTagPath: "versionTagPath", startCheckSumVersion: "startCheckSumVersion", devEnv: "devEnv", byPassCheckSum: "byPassCheckSum" }, outputs: { complete: "complete" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <div *ngIf=\"!importSuccess\">\r\n      <button id=\"fileLoadButton\" [attr.aria-labelledby]=\"fileImported ? 'fileName' : 'noFileChosen'\" onclick=\"document.getElementById('fileLoad').click()\" > {{ 'choose.file' | translate }} </button>\r\n      <input style=\"display:none\" type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n      <!-- FOR SCREEN READER : To read \"Select a file to load, no file chosen / (file name) button\" -->\r\n      <span hidden class=\"field-name\" *ngIf=\"!fileImported\" id=\"noFileChosen\"> {{ 'select.file'|translate }} {{ 'no.file.chosen' | translate }} </span>\r\n      <span hidden class=\"field-name\" *ngIf=\"fileImported\" id=\"fileName\"> {{ 'select.file'|translate }} {{importedFileName}} </span>\r\n      <!-- -->\r\n      <span class=\"field-name\" *ngIf=\"!fileImported\"> {{ 'no.file.chosen' | translate }} </span>\r\n      <span class=\"field-name\" *ngIf=\"fileImported\"> {{importedFileName}} </span>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"displayAlert\">\r\n  <span role=\"alert\">{{status | translate}}</span>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>", styles: [""], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FilereaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-file-reader', encapsulation: ViewEncapsulation.None, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <div *ngIf=\"!importSuccess\">\r\n      <button id=\"fileLoadButton\" [attr.aria-labelledby]=\"fileImported ? 'fileName' : 'noFileChosen'\" onclick=\"document.getElementById('fileLoad').click()\" > {{ 'choose.file' | translate }} </button>\r\n      <input style=\"display:none\" type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n      <!-- FOR SCREEN READER : To read \"Select a file to load, no file chosen / (file name) button\" -->\r\n      <span hidden class=\"field-name\" *ngIf=\"!fileImported\" id=\"noFileChosen\"> {{ 'select.file'|translate }} {{ 'no.file.chosen' | translate }} </span>\r\n      <span hidden class=\"field-name\" *ngIf=\"fileImported\" id=\"fileName\"> {{ 'select.file'|translate }} {{importedFileName}} </span>\r\n      <!-- -->\r\n      <span class=\"field-name\" *ngIf=\"!fileImported\"> {{ 'no.file.chosen' | translate }} </span>\r\n      <span class=\"field-name\" *ngIf=\"fileImported\"> {{importedFileName}} </span>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"displayAlert\">\r\n  <span role=\"alert\">{{status | translate}}</span>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>" }]
        }], ctorParameters: () => [{ type: i1.TranslateService }], propDecorators: { complete: [{
                type: Output
            }], rootTag: [{
                type: Input
            }], lang: [{
                type: Input
            }], versionTagPath: [{
                type: Input
            }], startCheckSumVersion: [{
                type: Input
            }], devEnv: [{
                type: Input
            }], byPassCheckSum: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZXJlYWRlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGVyZWFkZXIvZmlsZXJlYWRlci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGVyZWFkZXIvZmlsZXJlYWRlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsU0FBUyxFQUFVLFlBQVksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFpQixpQkFBaUIsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUMvRyxPQUFPLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFFLGNBQWMsRUFBRSxlQUFlLEVBQUMsTUFBTSxzQkFBc0IsQ0FBQztBQUUxSSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDcEQsT0FBTyxFQUFDLHFCQUFxQixFQUFDLE1BQU0sNEJBQTRCLENBQUM7QUFDakUsT0FBTyxFQUFDLGVBQWUsRUFBQyxNQUFNLG1DQUFtQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQzs7OztBQVN0RSxNQUFNLE9BQU8sbUJBQW1CO0lBaUI5QixZQUFvQixTQUEyQjtRQUEzQixjQUFTLEdBQVQsU0FBUyxDQUFrQjtRQWhCckMsYUFBUSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7UUFDL0IsWUFBTyxHQUFZLEVBQUUsQ0FBQztRQUN0QixTQUFJLEdBQVksRUFBRSxDQUFDO1FBT3JCLFdBQU0sR0FBRyxjQUFjLENBQUM7UUFDeEIsa0JBQWEsR0FBRyxLQUFLLENBQUM7UUFDdEIscUJBQWdCLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLGlCQUFZLEdBQUcsS0FBSyxDQUFDLENBQUcsc0NBQXNDO1FBQzdELFdBQU0sR0FBRyxFQUFFLENBQUM7UUFDYixpQkFBWSxHQUFHLEtBQUssQ0FBQztJQUc1QixDQUFDO0lBRUQsUUFBUTtRQUNOLDZCQUE2QjtJQUMvQixDQUFDO0lBR0QsV0FBVyxDQUFDLE9BQXNCO1FBQ2hDLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ2hELENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsY0FBYyxDQUFDLE1BQVc7UUFFeEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUV2QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZ0JBQWdCLENBQUMsVUFBZTtRQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztRQUN6QixJQUFJLElBQUksR0FBUyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLElBQUksUUFBUSxHQUFlLElBQUksVUFBVSxFQUFFLENBQUM7UUFDNUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLFFBQVEsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO1lBQzlCLG9FQUFvRTtZQUNwRSxJQUFJLGFBQWEsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ3pDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDeEssSUFBSSxhQUFhLENBQUMsUUFBUSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNoRSxJQUFJLENBQUMsTUFBTSxHQUFHLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUMsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDO1lBQy9CLENBQUM7WUFFRCxJQUFHLElBQUksQ0FBQyxNQUFNLEtBQUssY0FBYyxFQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzVCLENBQUM7WUFDRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUVsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztZQUMxQixVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUVQLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFFaEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBR1IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3RCLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFXLEVBQUUsTUFBTSxFQUFFLE1BQWEsRUFBRSxhQUE0QixFQUFFLGNBQXFCLEVBQUUsb0JBQTRCLEVBQUUsTUFBYyxFQUFFLE1BQWM7UUFDNUssSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoQyxJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLFVBQVUsR0FBd0IsSUFBSSxxQkFBcUIsRUFBRSxDQUFDO1FBRWxFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxlQUFlLElBQUksUUFBUSxDQUFDLFdBQVcsRUFBRSxLQUFLLGVBQWUsRUFBRSxDQUFDO1lBQy9GLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxlQUFlLEVBQUUsQ0FBQztnQkFDakQsVUFBVSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztZQUN6RCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztZQUM1RCxDQUFDO1lBQ0QsbUNBQW1DO1lBQ25DLG1CQUFtQixDQUFDLGlCQUFpQixDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUU3RCxJQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUUsS0FBSyxlQUFlLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFDLENBQUM7Z0JBQ3BGLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsY0FBYyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7b0JBQzNGLElBQUksY0FBYyxJQUFHLElBQUksSUFBSSxvQkFBb0IsSUFBSSxJQUFJLEVBQUUsQ0FBQzt3QkFDMUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBQzVDLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUNsRCxDQUFDO1lBQ0wsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDMUIsYUFBYSxDQUFDLFFBQVEsR0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUI7WUFDNUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFDTyxNQUFNLENBQUMsaUJBQWlCLENBQUMsYUFBNEIsRUFBRSxRQUFlO1FBQzVFLElBQUksQ0FBQyxRQUFRLElBQUcsQ0FBQyxhQUFhLElBQUcsQ0FBQyxhQUFhLENBQUMsSUFBSTtZQUFFLE9BQU87UUFFN0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztZQUNsQyxhQUFhLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUMxQixhQUFhLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUM1QixhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUMvQyxDQUFDO0lBQ0gsQ0FBQztJQUNNLFdBQVc7UUFDaEIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxNQUFNLENBQUMsYUFBYSxDQUFDLGFBQTRCLEVBQUUsUUFBZTtRQUN4RSxNQUFNLFFBQVEsR0FBb0IsSUFBSSxlQUFlLEVBQUUsQ0FBQztRQUV4RCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDO1lBQUEsT0FBTztRQUFBLENBQUM7UUFFN0QsSUFBRyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUM7WUFDMUMsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDMUIsYUFBYSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7WUFDNUIsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFFTyxNQUFNLENBQUMsbUJBQW1CLENBQUMsYUFBNEIsRUFBRSxRQUFlO1FBQzlFLE1BQU0sUUFBUSxHQUFvQixJQUFJLGVBQWUsRUFBRSxDQUFDO1FBRXhELElBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDO1lBQzFDLGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQzFCLGFBQWEsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQzVCLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQy9DLENBQUM7SUFDSCxDQUFDO0lBRU8sTUFBTSxDQUFDLGVBQWUsQ0FBQyxhQUE0QixFQUFFLFdBQW1CLEVBQUUsb0JBQTRCLEVBQUUsTUFBZSxFQUFFLE1BQWU7UUFDOUksSUFBSSxXQUFXLElBQUcsSUFBSSxJQUFJLG9CQUFvQixJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3ZELElBQUksT0FBTyxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUM7WUFDakMsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBUyxHQUFHO2dCQUN6QyxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3pCLENBQUMsQ0FBQyxDQUFBO1lBQ0YsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLElBQUksT0FBTyxHQUFHLG9CQUFvQixFQUFFLENBQUM7Z0JBQ25DLE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQztRQUNILENBQUM7UUFDRCxJQUFJLE1BQU0sSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNyQixPQUFPLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxDQUFDLENBQUE7WUFDNUQsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDOytHQXpLVSxtQkFBbUI7bUdBQW5CLG1CQUFtQixpU0NmaEMsK3ZEQXlCMEQ7OzRGRFY3QyxtQkFBbUI7a0JBUC9CLFNBQVM7K0JBQ0UsaUJBQWlCLGlCQUdaLGlCQUFpQixDQUFDLElBQUk7cUZBSTNCLFFBQVE7c0JBQWpCLE1BQU07Z0JBQ0UsT0FBTztzQkFBZixLQUFLO2dCQUNHLElBQUk7c0JBQVosS0FBSztnQkFDRyxjQUFjO3NCQUF0QixLQUFLO2dCQUNHLG9CQUFvQjtzQkFBNUIsS0FBSztnQkFDRyxNQUFNO3NCQUFkLEtBQUs7Z0JBQ0csY0FBYztzQkFBdEIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXQsIEV2ZW50RW1pdHRlciwgT3V0cHV0LCBJbnB1dCwgU2ltcGxlQ2hhbmdlcywgVmlld0VuY2Fwc3VsYXRpb259IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBEUkFGVF9GSUxFX1RZUEUsIEZJTEVfVFlQRV9FUlJPUiwgRklOQUxfRklMRV9UWVBFLCBGT1JNX1RZUEVfRVJST1IsIElNUE9SVF9TVUNDRVNTLCBDSEVDS19TVU1fRVJST1J9IGZyb20gJy4uL2ZpbGUtaW8tY29uc3RhbnRzJztcclxuaW1wb3J0IHtUcmFuc2xhdGVTZXJ2aWNlfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcclxuaW1wb3J0IHsgQ29udmVydFJlc3VsdHMgfSBmcm9tICcuLi9jb252ZXJ0LXJlc3VsdHMnO1xyXG5pbXBvcnQge0ZpbGVDb252ZXJzaW9uU2VydmljZX0gZnJvbSAnLi4vZmlsZS1jb252ZXJzaW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQge0NoZWNrU3VtU2VydmljZX0gZnJvbSAnLi4vLi4vY2hlY2stc3VtL2NoZWNrLXN1bS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ0hFQ0tfU1VNX0NPTlNUIH0gZnJvbSAnLi4vLi4vY2hlY2stc3VtL2NoZWNrLXN1bS1jb25zdGFudHMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItZmlsZS1yZWFkZXInLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9maWxlcmVhZGVyLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9maWxlcmVhZGVyLmNvbXBvbmVudC5jc3MnXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEZpbGVyZWFkZXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIEBPdXRwdXQoKSBjb21wbGV0ZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICBASW5wdXQoKSByb290VGFnIDogc3RyaW5nID0gJyc7XHJcbiAgQElucHV0KCkgbGFuZyA6IHN0cmluZyA9ICcnO1xyXG4gIEBJbnB1dCgpIHZlcnNpb25UYWdQYXRoPyA6IHN0cmluZzsgLy9UaGUgeG1sIHBhdGggb2YgdGhlIHZlcnNpb24gdGFnIGluIFhNTCBzZXBlcmF0ZWQgYnkgXCIuXCIgZXguIFwiVFJBTlNBQ1RJT05fRU5ST0wuc29mdHdhcmVfdmVyc2lvblwiXHJcbiAgQElucHV0KCkgc3RhcnRDaGVja1N1bVZlcnNpb24/IDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIGRldkVudj8gOiBib29sZWFuO1xyXG4gIEBJbnB1dCgpIGJ5UGFzc0NoZWNrU3VtPyA6IGJvb2xlYW47XHJcblxyXG5cclxuICBwdWJsaWMgc3RhdHVzID0gSU1QT1JUX1NVQ0NFU1M7XHJcbiAgcHVibGljIGltcG9ydFN1Y2Nlc3MgPSBmYWxzZTtcclxuICBwdWJsaWMgaW1wb3J0ZWRGaWxlTmFtZSA9IFwiXCI7XHJcbiAgcHVibGljIGRpc3BsYXlBbGVydCA9IGZhbHNlOyAgIC8vIHJlbG9hZHMgdGhlIHJvbGU9YWxlcnQgZWFjaCBtZXNzYWdlXHJcbiAgcHJpdmF0ZSByb290SWQgPSAnJztcclxuICBwdWJsaWMgZmlsZUltcG9ydGVkID0gZmFsc2U7XHJcbiAgXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSB0cmFuc2xhdGU6IFRyYW5zbGF0ZVNlcnZpY2UpIHtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgLy8gY29uc29sZS5sb2codGhpcy5yb290VGFnKTtcclxuICB9XHJcblxyXG5cclxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcbiAgICBpZiAoY2hhbmdlc1sncm9vdFRhZyddKSB7XHJcbiAgICAgIHRoaXMucm9vdElkID0gY2hhbmdlc1sncm9vdFRhZyddLmN1cnJlbnRWYWx1ZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEF0dGFjaGVzIHRvIHRoZSBmaWxlIGJyb3dzZXIsIGRldGVjdGluZyB0aGUgZmlsZSBzZWxlY3Rpb24gY2hhbmdlXHJcbiAgICogQHBhcmFtICRldmVudFxyXG4gICAqL1xyXG4gIGNoYW5nZUxpc3RlbmVyKCRldmVudDogYW55KSB7XHJcblxyXG4gICAgdGhpcy5yZWFkU2VsZWN0ZWRGaWxlKCRldmVudC50YXJnZXQpO1xyXG5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIERldGVybWluZXMgaWYgYSBmaWxlIHdhcyBzZWxlY3RlZC4gU2V0cyBhIGNhbGxiYWNrIHRvIHByb2Nlc3MgdGhlIGZpbGUgYWZ0ZXIgbG9hZCAoYXN5Y2gpXHJcbiAgICogQHBhcmFtIGlucHV0VmFsdWVcclxuICAgKi9cclxuICByZWFkU2VsZWN0ZWRGaWxlKGlucHV0VmFsdWU6IGFueSk6IHZvaWQge1xyXG4gICAgdGhpcy5maWxlSW1wb3J0ZWQgPSB0cnVlO1xyXG4gICAgbGV0IGZpbGU6IEZpbGUgPSBpbnB1dFZhbHVlLmZpbGVzWzBdO1xyXG4gICAgbGV0IG15UmVhZGVyOiBGaWxlUmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgIGxldCBzZWxmID0gdGhpcztcclxuICAgIG15UmVhZGVyLm9ubG9hZGVuZCA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgIC8vIHlvdSBjYW4gcGVyZm9ybSBhbiBhY3Rpb24gd2l0aCBkYXRhIGhlcmUgY2FsbGJhY2sgZm9yIGFzeW5jaCBsb2FkXHJcbiAgICAgIGxldCBjb252ZXJ0UmVzdWx0ID0gbmV3IENvbnZlcnRSZXN1bHRzKCk7XHJcbiAgICAgIEZpbGVyZWFkZXJDb21wb25lbnQuX3JlYWRGaWxlKGZpbGUubmFtZSwgbXlSZWFkZXIucmVzdWx0LCBzZWxmLnJvb3RJZCwgY29udmVydFJlc3VsdCwgc2VsZi52ZXJzaW9uVGFnUGF0aCwgc2VsZi5zdGFydENoZWNrU3VtVmVyc2lvbiwgc2VsZi5kZXZFbnYsIHNlbGYuYnlQYXNzQ2hlY2tTdW0pO1xyXG4gICAgICBpZiAoY29udmVydFJlc3VsdC5tZXNzYWdlcyAmJiBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBzZWxmLnN0YXR1cyA9IGNvbnZlcnRSZXN1bHQubWVzc2FnZXNbMF07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2VsZi5zdGF0dXMgPSBJTVBPUlRfU1VDQ0VTUztcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYoc2VsZi5zdGF0dXMgPT09IElNUE9SVF9TVUNDRVNTKXtcclxuICAgICAgICBzZWxmLmltcG9ydFN1Y2Nlc3MgPSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICAgIHNlbGYuaW1wb3J0ZWRGaWxlTmFtZSA9IGZpbGUubmFtZTtcclxuXHJcbiAgICAgIHNlbGYuZGlzcGxheUFsZXJ0ID0gZmFsc2U7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4geyAvLyB0aGlzIHJlbG9hZHMgdGhlIG1lc3NhZ2VcclxuICAgICAgICBzZWxmLmRpc3BsYXlBbGVydCA9IHRydWU7XHJcbiAgICAgIH0sIDEwKTtcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG5cclxuICAgICAgfSwgMTAwKTtcclxuXHJcblxyXG4gICAgICBzZWxmLmNvbXBsZXRlLmVtaXQoY29udmVydFJlc3VsdCk7XHJcbiAgICB9O1xyXG4gICAgaWYgKGZpbGUgJiYgZmlsZS5uYW1lKSB7XHJcbiAgICAgIG15UmVhZGVyLnJlYWRBc1RleHQoZmlsZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKioqXHJcbiAgICogUHJvY2Vzc2VzIHRoZSBmaWxlIGRhdGEuIERldGVybWluZXMgdGhlIHR5cGUgb2YgZmlsZSBiYXNlZCBvbiB0aGUgZmlsZW5hbWUgc3VmZml4XHJcbiAgICogQHBhcmFtIG5hbWUgLSB0aGUgbmFtZSBvZiB0aGUgZmlsZS4gQ2FuIGluY2x1ZGUgdGhlIHBhdGhcclxuICAgKiBAcGFyYW0gcmVzdWx0IC0gdGhlIHJlc3VsdCBvZiB0aGUgZmlsZSByZWFkIGkuZS4gZmlsZSBjb250ZW50cyBhcyB0ZXh0XHJcbiAgICogQHBhcmFtIHJvb3RJZCAtIHRoZSBuYW1lIG9mIHRoZSByb290VGFnLiBJZiBudWxsIGlzIGlnbm9yZWRcclxuICAgKiBAcGFyYW0ge0NvbnZlcnRSZXN1bHRzfSBjb252ZXJ0UmVzdWx0IC1UaGUgcmVzdWx0cyBvZiB0aGUgZmlsZSByZWFkXHJcbiAgICogQHByaXZhdGVcclxuICAgKi9cclxuICBwcml2YXRlIHN0YXRpYyBfcmVhZEZpbGUobmFtZTpzdHJpbmcsIHJlc3VsdCwgcm9vdElkOnN0cmluZywgY29udmVydFJlc3VsdDpDb252ZXJ0UmVzdWx0cywgdmVyc2lvblRhZ1BhdGg6c3RyaW5nLCBzdGFydENoZWNrU3VtVmVyc2lvbjogbnVtYmVyLCBkZXZFbnY6Ym9vbGVhbiwgYnlQYXNzOmJvb2xlYW4pIHtcclxuICAgIGxldCBzcGxpdEZpbGUgPSBuYW1lLnNwbGl0KCcuJyk7XHJcbiAgICBsZXQgZmlsZVR5cGUgPSBzcGxpdEZpbGVbc3BsaXRGaWxlLmxlbmd0aCAtIDFdO1xyXG4gICAgbGV0IGNvbnZlcnNpb246RmlsZUNvbnZlcnNpb25TZXJ2aWNlID1uZXcgRmlsZUNvbnZlcnNpb25TZXJ2aWNlKCk7XHJcblxyXG4gICAgaWYgKChmaWxlVHlwZS50b0xvd2VyQ2FzZSgpKSA9PT0gRFJBRlRfRklMRV9UWVBFIHx8IGZpbGVUeXBlLnRvTG93ZXJDYXNlKCkgPT09IEZJTkFMX0ZJTEVfVFlQRSkge1xyXG4gICAgICBpZiAoKGZpbGVUeXBlLnRvTG93ZXJDYXNlKCkpID09PSBEUkFGVF9GSUxFX1RZUEUpIHtcclxuICAgICAgICBjb252ZXJzaW9uLmNvbnZlcnRUb0pTT05PYmplY3RzKHJlc3VsdCwgY29udmVydFJlc3VsdCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29udmVyc2lvbi5jb252ZXJ0WE1MVG9KU09OT2JqZWN0cyhyZXN1bHQsIGNvbnZlcnRSZXN1bHQpO1xyXG4gICAgICB9XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKGNvbnZlcnRSZXN1bHQuZGF0YSk7XHJcbiAgICAgIEZpbGVyZWFkZXJDb21wb25lbnQuY2hlY2tSb290VGFnTWF0Y2goY29udmVydFJlc3VsdCwgcm9vdElkKTtcclxuICAgICAgXHJcbiAgICAgIGlmKGZpbGVUeXBlLnRvTG93ZXJDYXNlKCkgPT09IEZJTkFMX0ZJTEVfVFlQRSAmJiBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLmxlbmd0aCA9PT0gMCl7XHJcbiAgICAgICAgaWYgKHRoaXMuZG9DaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQsIHZlcnNpb25UYWdQYXRoLCBzdGFydENoZWNrU3VtVmVyc2lvbiwgZGV2RW52LCBieVBhc3MpKVxyXG4gICAgICAgICAgaWYgKHZlcnNpb25UYWdQYXRoID09bnVsbCAmJiBzdGFydENoZWNrU3VtVmVyc2lvbiA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2hlY2tTdW1DaGVjayhjb252ZXJ0UmVzdWx0LCByb290SWQpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5zdHJpY3RDaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQsIHJvb3RJZCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQuZGF0YSA9IG51bGw7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXM9W107IC8vY2xlYXIgbXNlc3NhZ2VzXHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMucHVzaChGSUxFX1RZUEVfRVJST1IpO1xyXG4gICAgfVxyXG4gIH1cclxuICBwcml2YXRlIHN0YXRpYyBjaGVja1Jvb3RUYWdNYXRjaChjb252ZXJ0UmVzdWx0OkNvbnZlcnRSZXN1bHRzLCByb290TmFtZTpzdHJpbmcpIHtcclxuICAgIGlmICghcm9vdE5hbWV8fCAhY29udmVydFJlc3VsdCB8fCFjb252ZXJ0UmVzdWx0LmRhdGEpIHJldHVybjtcclxuXHJcbiAgICBpZiAoIWNvbnZlcnRSZXN1bHQuZGF0YVtyb290TmFtZV0pIHtcclxuICAgICAgY29udmVydFJlc3VsdC5kYXRhID0gbnVsbDtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcyA9IFtdO1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLnB1c2goRk9STV9UWVBFX0VSUk9SKTtcclxuICAgIH1cclxuICB9XHJcbiAgcHVibGljIHJlZnJlc2hQYWdlKCl7XHJcbiAgICBsb2NhdGlvbi5yZWxvYWQoKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgc3RhdGljIGNoZWNrU3VtQ2hlY2soY29udmVydFJlc3VsdDpDb252ZXJ0UmVzdWx0cywgcm9vdE5hbWU6c3RyaW5nKSB7ICBcclxuICAgIGNvbnN0IGNoZWNrU3VtOiBDaGVja1N1bVNlcnZpY2UgPSBuZXcgQ2hlY2tTdW1TZXJ2aWNlKCk7XHJcblxyXG4gICAgaWYgKCFjb252ZXJ0UmVzdWx0LmRhdGFbcm9vdE5hbWVdW0NIRUNLX1NVTV9DT05TVF0pIHtyZXR1cm47fVxyXG5cclxuICAgIGlmKCFjaGVja1N1bS5jaGVja0hhc2goY29udmVydFJlc3VsdC5kYXRhKSl7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQuZGF0YSA9IG51bGw7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMgPSBbXTtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKENIRUNLX1NVTV9FUlJPUik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHN0YXRpYyBzdHJpY3RDaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQ6Q29udmVydFJlc3VsdHMsIHJvb3ROYW1lOnN0cmluZykge1xyXG4gICAgY29uc3QgY2hlY2tTdW06IENoZWNrU3VtU2VydmljZSA9IG5ldyBDaGVja1N1bVNlcnZpY2UoKTtcclxuXHJcbiAgICBpZighY2hlY2tTdW0uY2hlY2tIYXNoKGNvbnZlcnRSZXN1bHQuZGF0YSkpe1xyXG4gICAgICBjb252ZXJ0UmVzdWx0LmRhdGEgPSBudWxsO1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzID0gW107XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMucHVzaChDSEVDS19TVU1fRVJST1IpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzdGF0aWMgZG9DaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQ6Q29udmVydFJlc3VsdHMsIHZlcnNpb25QYXRoOiBzdHJpbmcsIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uOiBudW1iZXIsIGRldkVudjogYm9vbGVhbiwgYnlQYXNzOiBib29sZWFuKXtcclxuICAgIGlmICh2ZXJzaW9uUGF0aCAhPW51bGwgJiYgc3RhcnRDaGVja1N1bVZlcnNpb24gIT0gbnVsbCkge1xyXG4gICAgICB2YXIgdmVyc2lvbiA9IGNvbnZlcnRSZXN1bHQuZGF0YTtcclxuICAgICAgdmVyc2lvblBhdGguc3BsaXQoXCIuXCIpLmZvckVhY2goZnVuY3Rpb24oa2V5KXtcclxuICAgICAgICB2ZXJzaW9uID0gdmVyc2lvbltrZXldO1xyXG4gICAgICB9KVxyXG4gICAgICB2ZXJzaW9uID0gcGFyc2VJbnQodmVyc2lvbi5zcGxpdCgnLicpWzBdLCAxMCk7XHJcbiAgICAgIGlmICh2ZXJzaW9uIDwgc3RhcnRDaGVja1N1bVZlcnNpb24pIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gXHJcbiAgICBpZiAoZGV2RW52ICYmIGJ5UGFzcykge1xyXG4gICAgICBjb25zb2xlLndhcm4oXCJCeXBhc3NpbmcgQ2hlY2tzdW0gVmVyaWZpY2F0aW9uIGluIERldiBNb2RlIVwiKVxyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbn1cclxuXHJcbiIsIjxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICA8ZGl2ICpuZ0lmPVwiIWltcG9ydFN1Y2Nlc3NcIiBjbGFzcz1cImZvcm0tZ3JvdXAgY29sLWxnLTEyIGNvbC1tZC0xMiBjb2wtc20tMTIgY29sLXhzLTEyXCI+XHJcbiAgICA8bGFiZWwgZm9yPVwiZmlsZUxvYWRcIj5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJmaWVsZC1uYW1lXCI+e3sgJ3NlbGVjdC5maWxlJ3x0cmFuc2xhdGUgfX08L3NwYW4+XHJcbiAgICA8L2xhYmVsPlxyXG4gICAgPGRpdiAqbmdJZj1cIiFpbXBvcnRTdWNjZXNzXCI+XHJcbiAgICAgIDxidXR0b24gaWQ9XCJmaWxlTG9hZEJ1dHRvblwiIFthdHRyLmFyaWEtbGFiZWxsZWRieV09XCJmaWxlSW1wb3J0ZWQgPyAnZmlsZU5hbWUnIDogJ25vRmlsZUNob3NlbidcIiBvbmNsaWNrPVwiZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2ZpbGVMb2FkJykuY2xpY2soKVwiID4ge3sgJ2Nob29zZS5maWxlJyB8IHRyYW5zbGF0ZSB9fSA8L2J1dHRvbj5cclxuICAgICAgPGlucHV0IHN0eWxlPVwiZGlzcGxheTpub25lXCIgdHlwZT1cImZpbGVcIiBpZD1cImZpbGVMb2FkXCIgbmFtZT1cImZpbGVMb2FkXCIgYWNjZXB0PVwiLnhtbCwgLmhjc2NcIiAoY2hhbmdlKT1cImNoYW5nZUxpc3RlbmVyKCRldmVudClcIiAvPlxyXG4gICAgICA8IS0tIEZPUiBTQ1JFRU4gUkVBREVSIDogVG8gcmVhZCBcIlNlbGVjdCBhIGZpbGUgdG8gbG9hZCwgbm8gZmlsZSBjaG9zZW4gLyAoZmlsZSBuYW1lKSBidXR0b25cIiAtLT5cclxuICAgICAgPHNwYW4gaGlkZGVuIGNsYXNzPVwiZmllbGQtbmFtZVwiICpuZ0lmPVwiIWZpbGVJbXBvcnRlZFwiIGlkPVwibm9GaWxlQ2hvc2VuXCI+IHt7ICdzZWxlY3QuZmlsZSd8dHJhbnNsYXRlIH19IHt7ICduby5maWxlLmNob3NlbicgfCB0cmFuc2xhdGUgfX0gPC9zcGFuPlxyXG4gICAgICA8c3BhbiBoaWRkZW4gY2xhc3M9XCJmaWVsZC1uYW1lXCIgKm5nSWY9XCJmaWxlSW1wb3J0ZWRcIiBpZD1cImZpbGVOYW1lXCI+IHt7ICdzZWxlY3QuZmlsZSd8dHJhbnNsYXRlIH19IHt7aW1wb3J0ZWRGaWxlTmFtZX19IDwvc3Bhbj5cclxuICAgICAgPCEtLSAtLT5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJmaWVsZC1uYW1lXCIgKm5nSWY9XCIhZmlsZUltcG9ydGVkXCI+IHt7ICduby5maWxlLmNob3NlbicgfCB0cmFuc2xhdGUgfX0gPC9zcGFuPlxyXG4gICAgICA8c3BhbiBjbGFzcz1cImZpZWxkLW5hbWVcIiAqbmdJZj1cImZpbGVJbXBvcnRlZFwiPiB7e2ltcG9ydGVkRmlsZU5hbWV9fSA8L3NwYW4+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICA8ZGl2ICpuZ0lmPVwiaW1wb3J0U3VjY2Vzc1wiIGNsYXNzPVwiZm9ybS1ncm91cCBjb2wtbGctMTIgY29sLW1kLTEyIGNvbC1zbS0xMiBjb2wteHMtMTJcIj5cclxuICAgIDxidXR0b24gKGNsaWNrKT1cInJlZnJlc2hQYWdlKClcIj57eyAncmVmcmVzaC5maWxlLmlucHV0J3x0cmFuc2xhdGUgfX08L2J1dHRvbj5cclxuICAgIDxTdHJvbmc+IHt7aW1wb3J0ZWRGaWxlTmFtZX19PC9TdHJvbmc+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG48ZGl2IFtuZ0NsYXNzXT1cInN0YXR1cyA9PSAnbXNnLnN1Y2Nlc3MubG9hZCcgPyAnYWxlcnQgYWxlcnQtc3VjY2VzcycgOiAnYWxlcnQgYWxlcnQtZGFuZ2VyJ1wiICpuZ0lmPVwiZGlzcGxheUFsZXJ0XCI+XHJcbiAgPHNwYW4gcm9sZT1cImFsZXJ0XCI+e3tzdGF0dXMgfCB0cmFuc2xhdGV9fTwvc3Bhbj5cclxuPC9kaXY+XHJcblxyXG48bmctY29udGVudCBzZWxlY3Q9XCJbZmlsZVVwbG9hZEluc3RydWN0aW9uXVwiPjwvbmctY29udGVudD4iXX0=