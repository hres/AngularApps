import { Pipe } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import * as i0 from "@angular/core";
// take an ICode value and return either en or fr value based on lang
export class TextTransformPipe {
    transform(value, lang) {
        return UtilsService.isFrench(lang) ? value.fr : value.en;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: TextTransformPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: TextTransformPipe, name: "textTransform" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: TextTransformPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'textTransform'
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGV4dC10cmFuc2Zvcm0ucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3BpcGVzL3RleHQvdGV4dC10cmFuc2Zvcm0ucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUNwRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7O0FBR3pELHFFQUFxRTtBQUtyRSxNQUFNLE9BQU8saUJBQWlCO0lBRTVCLFNBQVMsQ0FBQyxLQUFZLEVBQUUsSUFBWTtRQUNsQyxPQUFPLFlBQVksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7SUFDM0QsQ0FBQzsrR0FKVSxpQkFBaUI7NkdBQWpCLGlCQUFpQjs7NEZBQWpCLGlCQUFpQjtrQkFIN0IsSUFBSTttQkFBQztvQkFDSixJQUFJLEVBQUUsZUFBZTtpQkFDdEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFV0aWxzU2VydmljZSB9IGZyb20gJy4uLy4uL3V0aWxzL3V0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBJQ29kZSB9IGZyb20gJy4uLy4uL2RhdGEtbG9hZGVyL2RhdGEnO1xyXG5cclxuLy8gdGFrZSBhbiBJQ29kZSB2YWx1ZSBhbmQgcmV0dXJuIGVpdGhlciBlbiBvciBmciB2YWx1ZSBiYXNlZCBvbiBsYW5nXHJcblxyXG5AUGlwZSh7XHJcbiAgbmFtZTogJ3RleHRUcmFuc2Zvcm0nXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBUZXh0VHJhbnNmb3JtUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xyXG5cclxuICB0cmFuc2Zvcm0odmFsdWU6IElDb2RlLCBsYW5nOiBzdHJpbmcpOiB1bmtub3duIHtcclxuICAgIHJldHVybiBVdGlsc1NlcnZpY2UuaXNGcmVuY2gobGFuZykgPyB2YWx1ZS5mciA6IHZhbHVlLmVuO1xyXG4gIH1cclxuXHJcbn1cclxuIl19