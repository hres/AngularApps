import * as i0 from "@angular/core";
export declare class CheckSumService {
    constructor();
    checkHash(convertResultData: any): Boolean;
    createHash(result: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckSumService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckSumService>;
}
