import * as i0 from "@angular/core";
export declare class LayoutComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutComponent, "lib-layout", never, {}, {}, never, ["[header]", "[body]"], true, never>;
}
