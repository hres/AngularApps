import { FormGroup } from "@angular/forms";
import { IListService } from "./base.list.service.interface";
export declare abstract class BaseListService implements IListService {
    protected list: FormGroup[];
    setList(list: FormGroup[]): void;
    getNextId(): number;
}
