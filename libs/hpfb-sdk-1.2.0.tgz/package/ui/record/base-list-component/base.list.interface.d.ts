import { SimpleChanges } from "@angular/core";
import { FormArray, FormGroup } from "@angular/forms";
import { OutputRecord } from "../record-model/record.model";
export interface IBaseList<T extends OutputRecord> {
    recordList: T[];
    recordFormGroup: FormGroup;
    showErrors: boolean;
    errorSummaryChild: any;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    addRecord(): void;
    saveRecord(event: any): void;
    deleteRecord(index: number): void;
    revertRecord(event: any): void;
    handleRowClick(event: any): void;
    showError(errs: any): void;
    disableAddButton(): boolean;
    openPopup(): void;
    get recordFormArray(): FormArray;
    getRecordInfo(recordFormGroup: FormGroup): FormGroup;
    getRecordFormArrValues(): any;
}
