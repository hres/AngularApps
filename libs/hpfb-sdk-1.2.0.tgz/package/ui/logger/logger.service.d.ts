import * as i0 from "@angular/core";
export declare class LoggerService {
    log(debugEnabled: boolean, className: string, methodName: string, ...messages: any[]): void;
    error(debugEnabled: boolean, className: string, methodName: string, ...messages: any[]): void;
    warn(debugEnabled: boolean, className: string, methodName: string, ...messages: any[]): void;
    private formatMessages;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}
