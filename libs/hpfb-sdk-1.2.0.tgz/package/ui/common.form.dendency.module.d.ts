import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@ngx-translate/core";
export declare class CommonFormDendencyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonFormDendencyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonFormDendencyModule, never, never, [typeof i1.FormsModule, typeof i1.ReactiveFormsModule, typeof i2.TranslateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonFormDendencyModule>;
}
