import { ICode } from '../data-loader/data';
import { IIdTextLabel } from '../model/entity-base';
import { UtilsService } from '../utils/utils.service';
import { CheckboxOption } from '../model/form-model';
import { FormArray } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ConverterService {
    private _utilsService;
    constructor(_utilsService: UtilsService);
    convertCodeToIdTextLabel(codeObj: ICode, lang: string): IIdTextLabel;
    convertCodeToCheckboxOption(codeObj: ICode, lang: string): CheckboxOption;
    findAndConverCodeToIdTextLabel(codeList: ICode[], controlVal: string, lang: string): IIdTextLabel;
    findAndConverCodesToIdTextLabels(codeList: ICode[], controlVals: string[], lang: string): IIdTextLabel[];
    checkCheckboxes(loadedCodes: string[], optionList: CheckboxOption[], checkboxFormArray: FormArray): void;
    getCheckedCheckboxValues(optionList: CheckboxOption[], checkboxFormArray: FormArray): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ConverterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConverterService>;
}
