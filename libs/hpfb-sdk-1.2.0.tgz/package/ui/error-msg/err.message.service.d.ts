import { IValidationService } from '../validation/validation-service.interface';
import * as i0 from "@angular/core";
export declare class ErrMessageService {
    private validationServices;
    constructor(validationServices: IValidationService[]);
    getValidatorErrorMessageKey(validatorName: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrMessageService>;
}
