import { ErrorSummaryComponent } from './error-summary/error-summary.component';
import * as i0 from "@angular/core";
export declare class ErrorNotificationService {
    private errorSummarySubject;
    errorSummaryChanged$: import("rxjs").Observable<{
        key: string;
        errSummaryMessage: ErrorSummaryComponent;
    }[]>;
    updateErrorSummary(key: string, errorMessage: ErrorSummaryComponent): void;
    removeErrorSummary(key: string): void;
    clearErrors(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorNotificationService>;
}
