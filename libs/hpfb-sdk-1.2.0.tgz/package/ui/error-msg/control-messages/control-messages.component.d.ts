import { OnChanges, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ErrMessageService } from '../err.message.service';
import * as i0 from "@angular/core";
export declare class ControlMessagesComponent implements OnChanges {
    private _errMessageService;
    /**
     *  The reactive form control that this message relates
     */
    control: FormControl;
    /**
     * When true, indicates to show the error, even if control was not touched
     * @type {boolean}
     */
    showError: boolean;
    /**
     * Label message key that is associated to the control. Used for the error summary
     */
    label: string;
    /**
     * The id of the control. Used for the error summary to create the anchor link
     */
    controlId: string;
    /**
     * The id of the parent of the control. For the error summary componnet, currently not used?
     */
    parentId: string;
    /**
     * The label message key of the parent of hte control . Used for the error summary component. Currently not used?
     */
    parentLabel: string;
    /**
     * The already translated label of the parent of hte control . Used for the error summary component.
     */
    translatedParentLabel: string;
    /***
     * Index of the error. Used to expand the expander for the error summaryt
     */
    index: Number;
    /**
    * Number of error from error summary
    */
    errorNumber: string;
    /**
     * Flag to indicate if error summary
     */
    errorSummaryFlag: boolean;
    /**
     * Current error type for the control
     * @type {string}
     */
    currentError: string;
    /**
     *  A reference the tabset control NgbTabset from Angular bootstrap
     * @type {null}
     */
    /**
     * Th id of the target tab, the tab containing the error
     * @type (string)
     */
    tabId: string;
    errorParams: {
        [key: string]: string;
    };
    /**
     * controls visiblity
     * @type boolean
     */
    private _errorVisible;
    constructor(_errMessageService: ErrMessageService);
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage(): string;
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ControlMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ControlMessagesComponent, "control-messages", never, { "control": { "alias": "control"; "required": false; }; "showError": { "alias": "showError"; "required": false; }; "label": { "alias": "label"; "required": false; }; "controlId": { "alias": "controlId"; "required": false; }; "parentId": { "alias": "parentId"; "required": false; }; "parentLabel": { "alias": "parentLabel"; "required": false; }; "translatedParentLabel": { "alias": "translatedParentLabel"; "required": false; }; "index": { "alias": "index"; "required": false; }; }, {}, never, never, false, never>;
}
