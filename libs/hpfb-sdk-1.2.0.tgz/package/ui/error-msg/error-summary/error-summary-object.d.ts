import { ExpanderComponent } from '../../expander/expander.component';
export interface ErrorSummaryObject {
    index: number;
    label: string;
    controlId: string;
    error: string;
    type: string;
    tabId: number;
    componentId: string;
    tableId: string;
    expander: ExpanderComponent;
    compRef: any;
    errorNumber: string;
}
export declare const ERR_TYPE_COMPONENT: string;
export declare const ERR_TYPE_LEAST_ONE_REC: string;
/**
 * Creates a flat json object for the error summary component UI
 * @returns {object}
 */
export declare function getEmptyErrorSummaryObj(): ErrorSummaryObject;
