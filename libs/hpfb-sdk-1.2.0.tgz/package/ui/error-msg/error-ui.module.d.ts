import * as i0 from "@angular/core";
import * as i1 from "./error-summary/error-summary.component";
import * as i2 from "./control-messages/control-messages.component";
import * as i3 from "@angular/common";
import * as i4 from "../pipes/pipes.module";
import * as i5 from "@ngx-translate/core";
export declare class ErrorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ErrorModule, [typeof i1.ErrorSummaryComponent, typeof i2.ControlMessagesComponent], [typeof i3.CommonModule, typeof i4.PipesModule, typeof i5.TranslateModule], [typeof i1.ErrorSummaryComponent, typeof i2.ControlMessagesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ErrorModule>;
}
