import * as i0 from "@angular/core";
import * as i1 from "./expander.component";
import * as i2 from "./accordion/accordion.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "@ngx-translate/core";
export declare class ExpanderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ExpanderModule, [typeof i1.ExpanderComponent, typeof i2.AccordionComponent], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i5.TranslateModule], [typeof i1.ExpanderComponent, typeof i2.AccordionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ExpanderModule>;
}
