import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ExpanderComponent implements OnChanges {
    accordionHeadingMsgKey: string;
    /**
     * Disable expand
     */
    disableExpand: boolean;
    /**
     * When set to true, disables collapse of a details section that is in error
     * @type {boolean}
     */
    /**
     * sets if the details form is valid. Controls collapses state
     * @type {boolean}
     */
    isValid: boolean;
    /**
     * The list of records to display in the expander component
     */
    itemsList: any;
    /**
     * Signal to indicate a record has been added
     * @type {number}
     */
    addRecord: number;
    /**
     * Expands a record when it has been added. Default is false
     */
    expandOnAdd: boolean;
    deleteRecord: number;
    collapseAll: number;
    loadFileIndicator: boolean;
    xmlStatus: any;
    expandedRow: EventEmitter<any>;
    private tableRowIndexCurrExpanded;
    private tableRowIndexPreExpanded;
    private _expandAdd;
    /**
     * for each table row, stores the state i.e. collapsed or expanded
     * @type {boolean[]}
     * @private
     */
    private _expanderTable;
    /**
     * an array of JSON objects to define the column labels, widths and bindings
     * @type {any[]}
     */
    columnDefinitions: any[];
    /**
     * The number of columns for this expander. Used to determine columnSpan
     * @type {number}
     */
    numberColSpan: number;
    dataItems: any[];
    private _expanderValid;
    constructor();
    ngOnInit(): void;
    /**
     * Looks for and reacts to changes in the expander component
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Adds an additional row to the expander UI state tracking array
     */
    updateDataRows(srcList: any): void;
    /**
     * For a given row denoted by a zero based index, returns if a row is collapsed or expanded
     * @param {number} index
     * @returns {boolean}
     */
    getExpandedState(index: number): boolean;
    /**
     *  Checks if a given zero based row denoted by index is expanded
     * @param {number} index
     * @returns {boolean}
     */
    isExpanded(index: number): boolean;
    /**
     *  Checks if a given zero based row denoted by index is collapsed
     * @param {number} index
     * @returns {boolean}
     */
    isCollapsed(index: number): boolean;
    broadcastExpandedRow(): void;
    getExpandedRow(): number;
    /**
     * Selects the table row to expand or collapse. If disable expand is enabled, will not collapse a row if it is in error
     * @param {number} index
     */
    selectTableRow(index: number): void;
    selectTableRowNoCheck(index: number): void;
    /**
     * Collapses all the table rows. Ignores any error states in the details.
     */
    collapseTableRows(): void;
    /**
     * Get the row title dynamic according to the expand/collapse status
     */
    getRowTitle(i: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpanderComponent, "lib-expander", never, { "accordionHeadingMsgKey": { "alias": "accordionHeadingMsgKey"; "required": false; }; "disableExpand": { "alias": "disableExpand"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "itemsList": { "alias": "group"; "required": false; }; "addRecord": { "alias": "addRecord"; "required": false; }; "expandOnAdd": { "alias": "expandOnAdd"; "required": false; }; "deleteRecord": { "alias": "deleteRecord"; "required": false; }; "collapseAll": { "alias": "collapseAll"; "required": false; }; "loadFileIndicator": { "alias": "loadFileIndicator"; "required": false; }; "xmlStatus": { "alias": "xmlStatus"; "required": false; }; "columnDefinitions": { "alias": "columnDefinitions"; "required": false; }; }, { "expandedRow": "expandedRow"; }, never, ["*"], false, never>;
}
