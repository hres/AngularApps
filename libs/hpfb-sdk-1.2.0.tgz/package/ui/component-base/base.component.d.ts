import { AfterViewInit, QueryList } from "@angular/core";
import { ControlMessagesComponent } from "../error-msg/control-messages/control-messages.component";
import * as i0 from "@angular/core";
export declare abstract class BaseComponent implements AfterViewInit {
    protected msgList: QueryList<ControlMessagesComponent>;
    constructor();
    ngAfterViewInit(): void;
    protected _updateAndEmitErrors(errorObjs: any): void;
    protected _appendErrorsFromChild(errorsFromChild: ControlMessagesComponent[]): void;
    protected abstract emitErrors(errors: any[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseComponent, never, never, {}, {}, never, never, false, never>;
}
