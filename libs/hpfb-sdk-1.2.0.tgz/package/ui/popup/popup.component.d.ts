import * as i0 from "@angular/core";
export declare class PopupComponent {
    message: string;
    title: string;
    id: string;
    close: string;
    closePopup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PopupComponent, "lib-popup", never, { "message": { "alias": "message"; "required": false; }; "title": { "alias": "title"; "required": false; }; "id": { "alias": "id"; "required": false; }; "close": { "alias": "close"; "required": false; }; }, {}, never, never, true, never>;
}
