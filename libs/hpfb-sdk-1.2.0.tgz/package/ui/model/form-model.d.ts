export interface CheckboxOption {
    value: string;
    label: string;
    checked: boolean;
}
