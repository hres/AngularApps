import { IIdText, IIdTextLabel, ILabel, ITextLabel } from './entity-base';
import * as i0 from "@angular/core";
export declare class EntityBaseService {
    getEmptyIdTextLabel(): IIdTextLabel;
    getEmptyIIdText(): IIdText;
    getEmptyLabel(): ILabel;
    getEmptyITextLabel(): ITextLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityBaseService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntityBaseService>;
}
