import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class JsonKeysPipe implements PipeTransform {
    /**
     * Transforms a list of json objects into an array
     * Creates key value pairs
     * @param value
     * @param {string[]} args
     * @returns {any}
     */
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonKeysPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<JsonKeysPipe, "keys", false>;
}
