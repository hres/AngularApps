import * as i0 from "@angular/core";
import * as i1 from "./json/json-keys.pipe";
import * as i2 from "./form/form-control.pipe";
import * as i3 from "./text/text-transform.pipe";
import * as i4 from "./text/aria-transform.pipe";
export declare class PipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PipesModule, [typeof i1.JsonKeysPipe, typeof i2.FormControlPipe, typeof i3.TextTransformPipe, typeof i4.AriaTransformPipe], never, [typeof i1.JsonKeysPipe, typeof i2.FormControlPipe, typeof i3.TextTransformPipe, typeof i4.AriaTransformPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PipesModule>;
}
