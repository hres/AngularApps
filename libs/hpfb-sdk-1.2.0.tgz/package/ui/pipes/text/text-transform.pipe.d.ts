import { PipeTransform } from '@angular/core';
import { ICode } from '../../data-loader/data';
import * as i0 from "@angular/core";
export declare class TextTransformPipe implements PipeTransform {
    transform(value: ICode, lang: string): unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextTransformPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TextTransformPipe, "textTransform", false>;
}
