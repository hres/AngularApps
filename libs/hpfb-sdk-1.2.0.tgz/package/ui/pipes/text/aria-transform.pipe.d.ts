import { PipeTransform } from '@angular/core';
import { ICodeAria } from '../../data-loader/data';
import * as i0 from "@angular/core";
export declare class AriaTransformPipe implements PipeTransform {
    transform(value: ICodeAria, lang: string): unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<AriaTransformPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AriaTransformPipe, "ariaTransform", false>;
}
