import { PipeTransform } from '@angular/core';
import { AbstractControl, FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormControlPipe implements PipeTransform {
    transform(value: AbstractControl): FormControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormControlPipe, "formControl", false>;
}
