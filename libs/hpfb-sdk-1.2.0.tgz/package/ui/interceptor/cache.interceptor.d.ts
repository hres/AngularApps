import { HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class NoCacheHeadersInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): import("rxjs").Observable<import("@angular/common/http").HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NoCacheHeadersInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NoCacheHeadersInterceptor>;
}
