import * as i0 from "@angular/core";
export declare class VersionService {
    getApplicationVersion(appEnvironment: any): any;
    /**
     * get the major and minor version of the application concatenated with '.'
     * @param appVersion format is 1.0.0
     * @returns string
     */
    getApplicationMajorVersion(appVersion: string): string;
    /**
    * get the major and minor version of the application concatenated with '_'
    * @param appVersion format is 1.0.0
    * @returns string
    */
    getApplicationMajorVersionWithUnderscore(appVersion: string): string;
    /**
     * Extracts the major version number from a version string.
     *
     * @param versionStr - The version string in the format "major.minor.patch", e.g., "1.0.0".
     * @returns The major version number as an integer.
     */
    getMajorVersion(versionStr: string): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionService>;
}
