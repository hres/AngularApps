export interface ICode {
    id: string;
    en: string;
    fr: string;
    sortPriority?: number;
}
export interface ICodeDefinition extends ICode {
    defEn: string;
    defFr: string;
}
export interface ICodeAria extends ICodeDefinition {
    ariaEn: string;
    ariaFr: string;
}
export interface IParentChildren {
    parentId: string;
    children: ICodeDefinition[];
}
export declare enum SortOn {
    ID = "id",
    ENGLISH = "en",
    FRENCH = "fr",
    PRIORITY = "sortPriority"
}
export interface IKeyword {
    name: string;
    data: ICode[];
}
