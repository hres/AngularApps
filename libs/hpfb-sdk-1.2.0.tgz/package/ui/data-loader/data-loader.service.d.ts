import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICode, SortOn } from './data';
import * as i0 from "@angular/core";
export declare class DataLoaderService {
    private http;
    constructor(http: HttpClient);
    getData<T>(endpoint: string): Observable<T[]>;
    /**
     * @deprecated Will not be used in the future, use getSortedDataAccents() instead
     * @param endpoint
     * @param compareField
     * @returns
     */
    getSortedData<T extends ICode>(endpoint: string, compareField: SortOn): Observable<T[]>;
    private getCompareFunction;
    getSortedDataAccents<T extends ICode>(endpoint: string, compareFields: SortOn[]): Observable<T[]>;
    private getCompareFunctions;
    private getFieldValue;
    handleError(err: HttpErrorResponse): Observable<never>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DataLoaderService>;
}
