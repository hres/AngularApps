import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class RoutingService {
    private router;
    constructor(router: Router);
    navigateTo(path: string): void;
    navigateToWithExtra(path: string, stateData: {
        [propertyKey: string]: any;
    }): void;
    getStateData<T>(propertyKey: string): T;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingService>;
}
