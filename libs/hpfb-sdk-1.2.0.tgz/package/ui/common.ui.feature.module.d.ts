import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
import * as i3 from "@ngx-translate/core";
export declare class CommonUiFeatureModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonUiFeatureModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonUiFeatureModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonUiFeatureModule>;
}
