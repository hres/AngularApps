export declare const IMPORT_SUCCESS = "msg.success.load";
export declare const PARSE_FAIL = "msg.err.parse.fail";
export declare const FILE_TYPE_ERROR = "msg.err.file.type";
export declare const FORM_TYPE_ERROR = "msg.err.form.type";
export declare const CHECK_SUM_ERROR = "msg.err.checksum";
export declare const DRAFT_FILE_TYPE = "hcsc";
export declare const FINAL_FILE_TYPE = "xml";
