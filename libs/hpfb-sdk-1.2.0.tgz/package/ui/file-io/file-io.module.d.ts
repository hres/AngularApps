import * as i0 from "@angular/core";
import * as i1 from "./filereader/filereader.component";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
export declare class FileIoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileIoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FileIoModule, [typeof i1.FilereaderComponent], [typeof i2.CommonModule, typeof i3.TranslateModule], [typeof i1.FilereaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FileIoModule>;
}
