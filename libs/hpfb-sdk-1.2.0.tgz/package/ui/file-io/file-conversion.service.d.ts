import { ConvertResults } from './convert-results';
import * as i0 from "@angular/core";
export declare class FileConversionService {
    constructor();
    /***
     * Converts an incoming json string to a json object
     * @param data -the json string to convert
     * @param convertResult -the json object to store the data in
     */
    convertToJSONObjects(jsonData: any, convertResult: ConvertResults): void;
    /***
     *  Using xml2js to do the coversion from JSON to XML
     * @param data
     * @param convertResult
     */
    convertXMLToJSONObjects(data: any, convertResult: ConvertResults): any;
    /***
     * Converts a json object to XML. Assumes root tag is root of JSON object
     * @param jsonObj
     * @returns {any}
     */
    convertJSONObjectsToXML(jsonObj: any): any;
    saveJsonToFile(jsonObj: any, fileName: string, rootTag: string): void;
    /**
     * Saves the incoming JSON data as an xml file
     * @param jsonObj -the json object to write as XML
     * @param {string} fileName - the bsse filename to save the file as. the suffix is sdded
     * @param {boolean} addXsl
     * @param {string} xslName
     */
    saveXmlToFile(jsonObj: any, fileName: string, addXsl?: boolean, xslName?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileConversionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileConversionService>;
}
