export declare class ConvertResults {
    messages: string[];
    data: any;
}
