import { InjectionToken } from '@angular/core';
import { IValidationService } from './validation-service.interface';
export declare const VALIDATION_SERVICES: InjectionToken<IValidationService[]>;
