import * as i0 from "@angular/core";
export declare class InstructionService {
    private helpTextIndx;
    constructor();
    /**
     * Sets the Help Text Index
     *
     * instructionHeadings should be a list
     * @deprecated Use `createtHelpTextIndex` instead
     */
    getHelpTextIndex(instructionHeadings: any): HelpIndex;
    createHelpSequence(prefix: string, suffix: string, instructionHeadings: string[]): HelpSequence;
    static ɵfac: i0.ɵɵFactoryDeclaration<InstructionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InstructionService>;
}
/**
 * @deprecated Use `HelpSequence` instead
 */
export interface HelpIndex {
    [key: string]: number;
}
export interface HelpSequence {
    [key: string]: [number, string, string];
}
