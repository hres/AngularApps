import * as i0 from "@angular/core";
export declare class SecurityDisclaimerComponent {
    lang: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurityDisclaimerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SecurityDisclaimerComponent, "lib-security-disclaimer", never, { "lang": { "alias": "lang"; "required": false; }; }, {}, never, never, true, never>;
}
