import { SimpleChanges } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { ICode, ICodeDefinition, IParentChildren, SortOn } from '../data-loader/data';
import { IIdTextLabel } from '../model/entity-base';
import * as i0 from "@angular/core";
export declare class UtilsService {
    isCanadaOrUSA(countryValue: any): boolean;
    /**
     * Checks of the value is canada or not. Checks for Json object vs single value
     * @param value the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isCanada(countryValue: any): boolean;
    /**
     * Checks if the value usa or not. Checks for Json object vs single value
     * @param value - the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isUsa(countryValue: any): boolean;
    static isFrench(lang: string): boolean;
    isFrench(lang: string): boolean;
    getFormattedDate(format: string): string;
    isFirstChange(changes: SimpleChanges): boolean;
    /**
     * find a code by its id in a code array
     * @param codeArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeById(codeArray: ICode[], id: string): ICode | undefined;
    filterCodesByIds(codeArray: ICode[], idsToFilter: string[]): ICode[];
    /**
     * find a codeDefinition by its id in a codeDefinition array
     * @param codeDefinitionArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeDefinitionById(codeDefinitionArray: ICodeDefinition[], id: string): ICodeDefinition | undefined;
    /**
     * get the id value from an IdTextLabel object
     * @param idTextLabelObj
     * @returns either id or undefined
     */
    getIdFromIdTextLabel(idTextLabelObj: IIdTextLabel): string;
    getIdsFromIdTextLabels(idTextLabelObjs: any): string[];
    getLabelFromIdTextLabelByLang(idTextLabelObj: IIdTextLabel, lang: string): string;
    isArrayOfIIdTextLabel(arr: any[]): arr is IIdTextLabel[];
    isIIdTextLabel(obj: any): obj is IIdTextLabel;
    filterParentChildrenArray(arr: IParentChildren[], pId: string): ICodeDefinition[];
    concat(...param: string[]): string;
    resetControlsValues(...controls: AbstractControl<any, any>[]): void;
    getCodeDefinitionByLang(codeDefinition: ICodeDefinition, lang: string): string;
    getCodeDefinitionByIdByLang(id: string, list: ICodeDefinition[], lang: string): string;
    toBoolean: (value: string | number | boolean) => boolean;
    isEmpty(value: any): boolean;
    flattenArrays<T>(arrays: T[]): T[];
    isArray1ElementInArray2(array1: any[], array2: any[]): boolean;
    copyFormGroupValues(source: FormGroup, destination: FormGroup): void;
    getControlName(control: AbstractControl): any;
    logFormControlState(form: AbstractControl, indent?: string): void;
    checkInputValidity(event: any, control: AbstractControl, errorMsgKey: string): void;
    checkComponentChanges(changes: SimpleChanges): any[];
    checkFormInvalidFields(FormGroup: FormGroup): void;
    findAndTranslateCode(codeArray: ICode[], lang: string, codeId: string): string;
    translateCode(code: ICode, lang: string): string;
    createIIdTextLabelObj(id: string, label_en: string, label_fr: string, text?: string): IIdTextLabel;
    sortCodeList(codeArray: ICode[], lang: string): ICode[];
    getEnumValueFromString<T>(enumType: T, value: string): T[keyof T] | undefined;
    formatAsSixDigitNumber(value: string): string;
    removeFirstAndLastChars(value: string): string;
    getCompareFields(sortOnPriority: boolean, lang: string): SortOn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UtilsService>;
}
