import * as i0 from "@angular/core";
import * as i1 from "./address.details/address.details.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@hpfb/sdk/ui";
import * as i5 from "@ngx-translate/core";
export declare class AddressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddressModule, [typeof i1.AddressDetailsComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule, typeof i4.ErrorModule, typeof i4.PipesModule, typeof i5.TranslateModule, typeof i4.NumbersOnlyDirective], [typeof i1.AddressDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddressModule>;
}
