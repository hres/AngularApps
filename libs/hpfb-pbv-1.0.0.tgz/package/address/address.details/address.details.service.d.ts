import { FormBuilder, FormGroup } from '@angular/forms';
import { ConverterService, ICode, UtilsService } from '@hpfb/sdk/ui';
import { INameAddress } from '../../model/entity-base';
import * as i0 from "@angular/core";
export declare class AddressDetailsService {
    private _utilsService;
    private _converterService;
    constructor(_utilsService: UtilsService, _converterService: ConverterService);
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb: FormBuilder): FormGroup<{
        address: import("@angular/forms").FormControl<null>;
        provText: import("@angular/forms").FormControl<string>;
        provState: import("@angular/forms").FormControl<string>;
        city: import("@angular/forms").FormControl<string>;
        country: import("@angular/forms").FormControl<null>;
        postal: import("@angular/forms").FormControl<string>;
    }>;
    mapFormModelToDataModel(formValue: any, addressModel: INameAddress, lang: any, countryList: any, combinedProvStatList: any): void;
    mapFormModelToDataModelCanadianAddress(formValue: any, addressModel: INameAddress, lang: any, countryList: any, combinedProvStatList: any): void;
    mapDataModelToFormModel(addressModel: any, formRecord: FormGroup): void;
    setProvinceState(record: FormGroup, countryId: string, provinceList: ICode[], stateList: ICode[]): ICode[];
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddressDetailsService>;
}
