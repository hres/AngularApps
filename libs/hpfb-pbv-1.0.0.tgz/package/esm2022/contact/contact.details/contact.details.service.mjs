import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class ContactDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            firstName: [null, Validators.required],
            initials: [null],
            lastName: [null, Validators.required],
            language: [null, Validators.required],
            jobTitle: [null, Validators.required],
            faxNumber: ['', [Validators.minLength(10), ValidationService.faxNumberValidator]],
            phoneNumber: ['', [Validators.required, Validators.minLength(10), ValidationService.phoneNumberValidator]],
            phoneExtension: '',
            email: [null, [Validators.required, ValidationService.emailValidator]],
        });
    }
    mapFormModelToDataModel(formValue, contactModel, lang, languageList) {
        contactModel.given_name = formValue['firstName'];
        contactModel.initials = formValue['initials'];
        // contactModel.initials = formRecord.controls['initials.value;
        contactModel.surname = formValue['lastName'];
        contactModel.language_correspondance = formValue['language'] ? this._converterService.findAndConverCodeToIdTextLabel(languageList, formValue['language'], lang) : null;
        contactModel.job_title = formValue['jobTitle'];
        contactModel.fax_num = formValue['faxNumber'];
        contactModel.phone_num = formValue['phoneNumber'];
        contactModel.phone_ext = formValue['phoneExtension'];
        contactModel.email = formValue['email'];
    }
    mapDataModelToFormModel(contactModel, formRecord) {
        formRecord.controls['firstName'].setValue(contactModel.given_name);
        formRecord.controls['initials'].setValue(contactModel.initials);
        formRecord.controls['lastName'].setValue(contactModel.surname);
        if (contactModel.language_correspondance) {
            formRecord.controls['language'].setValue(contactModel.language_correspondance._id);
        }
        else {
            formRecord.controls['language'].setValue(null);
        }
        formRecord.controls['jobTitle'].setValue(contactModel.job_title);
        formRecord.controls['faxNumber'].setValue(contactModel.fax_num);
        formRecord.controls['phoneNumber'].setValue(contactModel.phone_num);
        formRecord.controls['phoneExtension'].setValue(contactModel.phone_ext);
        formRecord.controls['email'].setValue(contactModel.email);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGFjdC5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvY29udGFjdC9jb250YWN0LmRldGFpbHMvY29udGFjdC5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFVBQVUsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQXlCLFVBQVUsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2xFLE9BQU8sRUFBeUMsaUJBQWlCLEVBQUUsTUFBTSxjQUFjLENBQUM7OztBQUt4RixNQUFNLE9BQU8scUJBQXFCO0lBRWhDLFlBQW9CLGFBQTJCLEVBQVUsaUJBQW1DO1FBQXhFLGtCQUFhLEdBQWIsYUFBYSxDQUFjO1FBQVUsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFrQjtJQUM1RixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGdCQUFnQixDQUFDLEVBQWU7UUFDckMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQUEsT0FBTyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQ3hCLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQztZQUNaLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3RDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUNoQixRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNyQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNyQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNyQyxTQUFTLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDakYsV0FBVyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDMUcsY0FBYyxFQUFFLEVBQUU7WUFDbEIsS0FBSyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUN6RSxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sdUJBQXVCLENBQUMsU0FBYyxFQUFFLFlBQXNCLEVBQUUsSUFBSSxFQUFFLFlBQVk7UUFDdkYsWUFBWSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDakQsWUFBWSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUMsK0RBQStEO1FBQy9ELFlBQVksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzdDLFlBQVksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyw4QkFBOEIsQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDdEssWUFBWSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDL0MsWUFBWSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDOUMsWUFBWSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDbEQsWUFBWSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNyRCxZQUFZLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRU0sdUJBQXVCLENBQUMsWUFBc0IsRUFBRSxVQUFxQjtRQUUxRSxVQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbkUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2hFLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvRCxJQUFJLFlBQVksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBQ3ZDLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2RixDQUFDO2FBQU0sQ0FBQztZQUNOLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2pELENBQUM7UUFDRCxVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDakUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2hFLFVBQVUsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNwRSxVQUFVLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2RSxVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDNUQsQ0FBQzsrR0FyRFUscUJBQXFCO21IQUFyQixxQkFBcUI7OzRGQUFyQixxQkFBcUI7a0JBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0luamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0Zvcm1CdWlsZGVyLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnN9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgQ29udmVydGVyU2VydmljZSwgSUNvZGUsIFV0aWxzU2VydmljZSwgVmFsaWRhdGlvblNlcnZpY2UgfSBmcm9tICdAaHBmYi9zZGsvdWknO1xyXG5pbXBvcnQgeyBJQ29udGFjdCB9IGZyb20gJy4uLy4uL21vZGVsL2VudGl0eS1iYXNlJztcclxuXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBDb250YWN0RGV0YWlsc1NlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF91dGlsc1NlcnZpY2U6IFV0aWxzU2VydmljZSwgcHJpdmF0ZSBfY29udmVydGVyU2VydmljZTogQ29udmVydGVyU2VydmljZSkge1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyB0aGUgcmVhY3RpdmUgZm9ybXMgTW9kZWwgZm9yIGFkZHJlc3MgZGV0YWlsc1xyXG4gICAqIEBwYXJhbSB7Rm9ybUJ1aWxkZXJ9IGZiXHJcbiAgICogQHJldHVybnMge2FueX1cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0UmVhY3RpdmVNb2RlbChmYjogRm9ybUJ1aWxkZXIpIHtcclxuICAgIGlmICghZmIpIHtyZXR1cm4gbnVsbDsgfVxyXG4gICAgcmV0dXJuIGZiLmdyb3VwKHtcclxuICAgICAgICBmaXJzdE5hbWU6IFtudWxsLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgICBpbml0aWFsczogW251bGxdLFxyXG4gICAgICAgIGxhc3ROYW1lOiBbbnVsbCwgVmFsaWRhdG9ycy5yZXF1aXJlZF0sXHJcbiAgICAgICAgbGFuZ3VhZ2U6IFtudWxsLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgICBqb2JUaXRsZTogW251bGwsIFZhbGlkYXRvcnMucmVxdWlyZWRdLFxyXG4gICAgICAgIGZheE51bWJlcjogWycnLCBbVmFsaWRhdG9ycy5taW5MZW5ndGgoMTApLCBWYWxpZGF0aW9uU2VydmljZS5mYXhOdW1iZXJWYWxpZGF0b3JdXSxcclxuICAgICAgICBwaG9uZU51bWJlcjogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdG9ycy5taW5MZW5ndGgoMTApLCBWYWxpZGF0aW9uU2VydmljZS5waG9uZU51bWJlclZhbGlkYXRvcl1dLFxyXG4gICAgICAgIHBob25lRXh0ZW5zaW9uOiAnJyxcclxuICAgICAgICBlbWFpbDogW251bGwsIFtWYWxpZGF0b3JzLnJlcXVpcmVkLCBWYWxpZGF0aW9uU2VydmljZS5lbWFpbFZhbGlkYXRvcl1dLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbWFwRm9ybU1vZGVsVG9EYXRhTW9kZWwoZm9ybVZhbHVlOiBhbnksIGNvbnRhY3RNb2RlbDogSUNvbnRhY3QsIGxhbmcsIGxhbmd1YWdlTGlzdCkge1xyXG4gICAgY29udGFjdE1vZGVsLmdpdmVuX25hbWUgPSBmb3JtVmFsdWVbJ2ZpcnN0TmFtZSddO1xyXG4gICAgY29udGFjdE1vZGVsLmluaXRpYWxzID0gZm9ybVZhbHVlWydpbml0aWFscyddO1xyXG4gICAgLy8gY29udGFjdE1vZGVsLmluaXRpYWxzID0gZm9ybVJlY29yZC5jb250cm9sc1snaW5pdGlhbHMudmFsdWU7XHJcbiAgICBjb250YWN0TW9kZWwuc3VybmFtZSA9IGZvcm1WYWx1ZVsnbGFzdE5hbWUnXTtcclxuICAgIGNvbnRhY3RNb2RlbC5sYW5ndWFnZV9jb3JyZXNwb25kYW5jZSA9IGZvcm1WYWx1ZVsnbGFuZ3VhZ2UnXT8gdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwobGFuZ3VhZ2VMaXN0LCBmb3JtVmFsdWVbJ2xhbmd1YWdlJ10sIGxhbmcpIDogbnVsbDtcclxuICAgIGNvbnRhY3RNb2RlbC5qb2JfdGl0bGUgPSBmb3JtVmFsdWVbJ2pvYlRpdGxlJ107XHJcbiAgICBjb250YWN0TW9kZWwuZmF4X251bSA9IGZvcm1WYWx1ZVsnZmF4TnVtYmVyJ107XHJcbiAgICBjb250YWN0TW9kZWwucGhvbmVfbnVtID0gZm9ybVZhbHVlWydwaG9uZU51bWJlciddO1xyXG4gICAgY29udGFjdE1vZGVsLnBob25lX2V4dCA9IGZvcm1WYWx1ZVsncGhvbmVFeHRlbnNpb24nXTtcclxuICAgIGNvbnRhY3RNb2RlbC5lbWFpbCA9IGZvcm1WYWx1ZVsnZW1haWwnXTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBtYXBEYXRhTW9kZWxUb0Zvcm1Nb2RlbChjb250YWN0TW9kZWw6IElDb250YWN0LCBmb3JtUmVjb3JkOiBGb3JtR3JvdXApIHtcclxuXHJcbiAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydmaXJzdE5hbWUnXS5zZXRWYWx1ZShjb250YWN0TW9kZWwuZ2l2ZW5fbmFtZSk7XHJcbiAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydpbml0aWFscyddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5pbml0aWFscyk7XHJcbiAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydsYXN0TmFtZSddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5zdXJuYW1lKTtcclxuICAgIGlmIChjb250YWN0TW9kZWwubGFuZ3VhZ2VfY29ycmVzcG9uZGFuY2UpIHtcclxuICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydsYW5ndWFnZSddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5sYW5ndWFnZV9jb3JyZXNwb25kYW5jZS5faWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snbGFuZ3VhZ2UnXS5zZXRWYWx1ZShudWxsKTtcclxuICAgIH1cclxuICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2pvYlRpdGxlJ10uc2V0VmFsdWUoY29udGFjdE1vZGVsLmpvYl90aXRsZSk7XHJcbiAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydmYXhOdW1iZXInXS5zZXRWYWx1ZShjb250YWN0TW9kZWwuZmF4X251bSk7XHJcbiAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwaG9uZU51bWJlciddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5waG9uZV9udW0pO1xyXG4gICAgZm9ybVJlY29yZC5jb250cm9sc1sncGhvbmVFeHRlbnNpb24nXS5zZXRWYWx1ZShjb250YWN0TW9kZWwucGhvbmVfZXh0KTtcclxuICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2VtYWlsJ10uc2V0VmFsdWUoY29udGFjdE1vZGVsLmVtYWlsKTtcclxuICB9XHJcblxyXG59Il19