import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class ContactDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            firstName: [null, Validators.required],
            initials: [null],
            lastName: [null, Validators.required],
            language: [null, Validators.required],
            jobTitle: [null, Validators.required],
            faxNumber: ['', [Validators.minLength(10), ValidationService.faxNumberValidator]],
            phoneNumber: ['', [Validators.required, Validators.minLength(10), ValidationService.phoneNumberValidator]],
            phoneExtension: '',
            email: [null, [Validators.required, ValidationService.emailValidator]],
        });
    }
    mapFormModelToDataModel(formValue, contactModel, lang, languageList) {
        contactModel.given_name = formValue['firstName'];
        // contactModel.initials = formRecord.controls['initials.value;
        contactModel.surname = formValue['lastName'];
        contactModel.language_correspondance = formValue['language'] ? this._converterService.findAndConverCodeToIdTextLabel(languageList, formValue['language'], lang) : null;
        contactModel.job_title = formValue['jobTitle'];
        contactModel.fax_num = formValue['faxNumber'];
        contactModel.phone_num = formValue['phoneNumber'];
        contactModel.phone_ext = formValue['phoneExtension'];
        contactModel.email = formValue['email'];
    }
    mapDataModelToFormModel(contactModel, formRecord) {
        formRecord.controls['firstName'].setValue(contactModel.given_name);
        formRecord.controls['lastName'].setValue(contactModel.surname);
        if (contactModel.language_correspondance) {
            formRecord.controls['language'].setValue(contactModel.language_correspondance._id);
        }
        else {
            formRecord.controls['language'].setValue(null);
        }
        formRecord.controls['jobTitle'].setValue(contactModel.job_title);
        formRecord.controls['faxNumber'].setValue(contactModel.fax_num);
        formRecord.controls['phoneNumber'].setValue(contactModel.phone_num);
        formRecord.controls['phoneExtension'].setValue(contactModel.phone_ext);
        formRecord.controls['email'].setValue(contactModel.email);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGFjdC5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvY29udGFjdC9jb250YWN0LmRldGFpbHMvY29udGFjdC5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFVBQVUsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQXlCLFVBQVUsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2xFLE9BQU8sRUFBeUMsaUJBQWlCLEVBQUUsTUFBTSxjQUFjLENBQUM7OztBQUt4RixNQUFNLE9BQU8scUJBQXFCO0lBRWhDLFlBQW9CLGFBQTJCLEVBQVUsaUJBQW1DO1FBQXhFLGtCQUFhLEdBQWIsYUFBYSxDQUFjO1FBQVUsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFrQjtJQUM1RixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGdCQUFnQixDQUFDLEVBQWU7UUFDckMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQUEsT0FBTyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQ3hCLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQztZQUNaLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3RDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUNoQixRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNyQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNyQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNyQyxTQUFTLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDakYsV0FBVyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDMUcsY0FBYyxFQUFFLEVBQUU7WUFDbEIsS0FBSyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUN6RSxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sdUJBQXVCLENBQUMsU0FBYyxFQUFFLFlBQXNCLEVBQUUsSUFBSSxFQUFFLFlBQVk7UUFDdkYsWUFBWSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDakQsK0RBQStEO1FBQy9ELFlBQVksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzdDLFlBQVksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyw4QkFBOEIsQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDdEssWUFBWSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDL0MsWUFBWSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDOUMsWUFBWSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDbEQsWUFBWSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNyRCxZQUFZLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRU0sdUJBQXVCLENBQUMsWUFBc0IsRUFBRSxVQUFxQjtRQUUxRSxVQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbkUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9ELElBQUksWUFBWSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDdkMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZGLENBQUM7YUFBTSxDQUFDO1lBQ04sVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDakQsQ0FBQztRQUNELFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRSxVQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDaEUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3BFLFVBQVUsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZFLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM1RCxDQUFDOytHQW5EVSxxQkFBcUI7bUhBQXJCLHFCQUFxQjs7NEZBQXJCLHFCQUFxQjtrQkFEakMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SW5qZWN0YWJsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7Rm9ybUJ1aWxkZXIsIEZvcm1Hcm91cCwgVmFsaWRhdG9yc30gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBDb252ZXJ0ZXJTZXJ2aWNlLCBJQ29kZSwgVXRpbHNTZXJ2aWNlLCBWYWxpZGF0aW9uU2VydmljZSB9IGZyb20gJ0BocGZiL3Nkay91aSc7XHJcbmltcG9ydCB7IElDb250YWN0IH0gZnJvbSAnLi4vLi4vbW9kZWwvZW50aXR5LWJhc2UnO1xyXG5cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIENvbnRhY3REZXRhaWxzU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX3V0aWxzU2VydmljZTogVXRpbHNTZXJ2aWNlLCBwcml2YXRlIF9jb252ZXJ0ZXJTZXJ2aWNlOiBDb252ZXJ0ZXJTZXJ2aWNlKSB7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXRzIHRoZSByZWFjdGl2ZSBmb3JtcyBNb2RlbCBmb3IgYWRkcmVzcyBkZXRhaWxzXHJcbiAgICogQHBhcmFtIHtGb3JtQnVpbGRlcn0gZmJcclxuICAgKiBAcmV0dXJucyB7YW55fVxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRSZWFjdGl2ZU1vZGVsKGZiOiBGb3JtQnVpbGRlcikge1xyXG4gICAgaWYgKCFmYikge3JldHVybiBudWxsOyB9XHJcbiAgICByZXR1cm4gZmIuZ3JvdXAoe1xyXG4gICAgICAgIGZpcnN0TmFtZTogW251bGwsIFZhbGlkYXRvcnMucmVxdWlyZWRdLFxyXG4gICAgICAgIGluaXRpYWxzOiBbbnVsbF0sXHJcbiAgICAgICAgbGFzdE5hbWU6IFtudWxsLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgICBsYW5ndWFnZTogW251bGwsIFZhbGlkYXRvcnMucmVxdWlyZWRdLFxyXG4gICAgICAgIGpvYlRpdGxlOiBbbnVsbCwgVmFsaWRhdG9ycy5yZXF1aXJlZF0sXHJcbiAgICAgICAgZmF4TnVtYmVyOiBbJycsIFtWYWxpZGF0b3JzLm1pbkxlbmd0aCgxMCksIFZhbGlkYXRpb25TZXJ2aWNlLmZheE51bWJlclZhbGlkYXRvcl1dLFxyXG4gICAgICAgIHBob25lTnVtYmVyOiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkLCBWYWxpZGF0b3JzLm1pbkxlbmd0aCgxMCksIFZhbGlkYXRpb25TZXJ2aWNlLnBob25lTnVtYmVyVmFsaWRhdG9yXV0sXHJcbiAgICAgICAgcGhvbmVFeHRlbnNpb246ICcnLFxyXG4gICAgICAgIGVtYWlsOiBbbnVsbCwgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLmVtYWlsVmFsaWRhdG9yXV0sXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBtYXBGb3JtTW9kZWxUb0RhdGFNb2RlbChmb3JtVmFsdWU6IGFueSwgY29udGFjdE1vZGVsOiBJQ29udGFjdCwgbGFuZywgbGFuZ3VhZ2VMaXN0KSB7XHJcbiAgICBjb250YWN0TW9kZWwuZ2l2ZW5fbmFtZSA9IGZvcm1WYWx1ZVsnZmlyc3ROYW1lJ107XHJcbiAgICAvLyBjb250YWN0TW9kZWwuaW5pdGlhbHMgPSBmb3JtUmVjb3JkLmNvbnRyb2xzWydpbml0aWFscy52YWx1ZTtcclxuICAgIGNvbnRhY3RNb2RlbC5zdXJuYW1lID0gZm9ybVZhbHVlWydsYXN0TmFtZSddO1xyXG4gICAgY29udGFjdE1vZGVsLmxhbmd1YWdlX2NvcnJlc3BvbmRhbmNlID0gZm9ybVZhbHVlWydsYW5ndWFnZSddPyB0aGlzLl9jb252ZXJ0ZXJTZXJ2aWNlLmZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChsYW5ndWFnZUxpc3QsIGZvcm1WYWx1ZVsnbGFuZ3VhZ2UnXSwgbGFuZykgOiBudWxsO1xyXG4gICAgY29udGFjdE1vZGVsLmpvYl90aXRsZSA9IGZvcm1WYWx1ZVsnam9iVGl0bGUnXTtcclxuICAgIGNvbnRhY3RNb2RlbC5mYXhfbnVtID0gZm9ybVZhbHVlWydmYXhOdW1iZXInXTtcclxuICAgIGNvbnRhY3RNb2RlbC5waG9uZV9udW0gPSBmb3JtVmFsdWVbJ3Bob25lTnVtYmVyJ107XHJcbiAgICBjb250YWN0TW9kZWwucGhvbmVfZXh0ID0gZm9ybVZhbHVlWydwaG9uZUV4dGVuc2lvbiddO1xyXG4gICAgY29udGFjdE1vZGVsLmVtYWlsID0gZm9ybVZhbHVlWydlbWFpbCddO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcERhdGFNb2RlbFRvRm9ybU1vZGVsKGNvbnRhY3RNb2RlbDogSUNvbnRhY3QsIGZvcm1SZWNvcmQ6IEZvcm1Hcm91cCkge1xyXG5cclxuICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2ZpcnN0TmFtZSddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5naXZlbl9uYW1lKTtcclxuICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2xhc3ROYW1lJ10uc2V0VmFsdWUoY29udGFjdE1vZGVsLnN1cm5hbWUpO1xyXG4gICAgaWYgKGNvbnRhY3RNb2RlbC5sYW5ndWFnZV9jb3JyZXNwb25kYW5jZSkge1xyXG4gICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2xhbmd1YWdlJ10uc2V0VmFsdWUoY29udGFjdE1vZGVsLmxhbmd1YWdlX2NvcnJlc3BvbmRhbmNlLl9pZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydsYW5ndWFnZSddLnNldFZhbHVlKG51bGwpO1xyXG4gICAgfVxyXG4gICAgZm9ybVJlY29yZC5jb250cm9sc1snam9iVGl0bGUnXS5zZXRWYWx1ZShjb250YWN0TW9kZWwuam9iX3RpdGxlKTtcclxuICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2ZheE51bWJlciddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5mYXhfbnVtKTtcclxuICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ3Bob25lTnVtYmVyJ10uc2V0VmFsdWUoY29udGFjdE1vZGVsLnBob25lX251bSk7XHJcbiAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwaG9uZUV4dGVuc2lvbiddLnNldFZhbHVlKGNvbnRhY3RNb2RlbC5waG9uZV9leHQpO1xyXG4gICAgZm9ybVJlY29yZC5jb250cm9sc1snZW1haWwnXS5zZXRWYWx1ZShjb250YWN0TW9kZWwuZW1haWwpO1xyXG4gIH1cclxuXHJcbn0iXX0=