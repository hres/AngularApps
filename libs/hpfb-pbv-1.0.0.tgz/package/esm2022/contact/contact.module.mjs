import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactDetailsComponent } from './contact.details/contact.details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';
import { TranslateModule } from '@ngx-translate/core';
import { ErrorModule, PipesModule, ExpanderModule, NumbersOnlyDirective, PopupComponent } from '@hpfb/sdk/ui';
import { ContactDetailsService } from './contact.details/contact.details.service';
import * as i0 from "@angular/core";
export class ContactModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: ContactModule, declarations: [ContactDetailsComponent], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            TranslateModule,
            ErrorModule,
            PipesModule,
            ExpanderModule,
            NumbersOnlyDirective,
            PopupComponent], exports: [ContactDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactModule, providers: [
            ContactDetailsService,
        ], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            TranslateModule,
            ErrorModule,
            PipesModule,
            ExpanderModule,
            PopupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ContactModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        ReactiveFormsModule,
                        FormsModule,
                        TranslateModule,
                        ErrorModule,
                        PipesModule,
                        ExpanderModule,
                        NumbersOnlyDirective,
                        PopupComponent
                    ],
                    declarations: [
                        ContactDetailsComponent
                    ],
                    exports: [
                        ContactDetailsComponent
                    ],
                    providers: [
                        ContactDetailsService,
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGFjdC5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvY29udGFjdC9jb250YWN0Lm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUN0RixPQUFPLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDbEUsNkRBQTZEO0FBQzdELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQUN0RCxPQUFPLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxjQUFjLEVBQUUsb0JBQW9CLEVBQUUsY0FBYyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQzlHLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDJDQUEyQyxDQUFDOztBQXlCbEYsTUFBTSxPQUFPLGFBQWE7K0dBQWIsYUFBYTtnSEFBYixhQUFhLGlCQVR0Qix1QkFBdUIsYUFadkIsWUFBWTtZQUNaLGlCQUFpQjtZQUNqQixtQkFBbUI7WUFDbkIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsV0FBVztZQUNYLGNBQWM7WUFDZCxvQkFBb0I7WUFDcEIsY0FBYyxhQU1kLHVCQUF1QjtnSEFNZCxhQUFhLGFBSmI7WUFDVCxxQkFBcUI7U0FDdEIsWUFuQkMsWUFBWTtZQUNaLGlCQUFpQjtZQUNqQixtQkFBbUI7WUFDbkIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsV0FBVztZQUNYLGNBQWM7WUFFZCxjQUFjOzs0RkFZTCxhQUFhO2tCQXZCekIsUUFBUTttQkFBQztvQkFDUixPQUFPLEVBQUU7d0JBQ1AsWUFBWTt3QkFDWixpQkFBaUI7d0JBQ2pCLG1CQUFtQjt3QkFDbkIsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCxjQUFjO3dCQUNkLG9CQUFvQjt3QkFDcEIsY0FBYztxQkFDZjtvQkFDRCxZQUFZLEVBQUU7d0JBQ1osdUJBQXVCO3FCQUN4QjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsdUJBQXVCO3FCQUN4QjtvQkFDRCxTQUFTLEVBQUU7d0JBQ1QscUJBQXFCO3FCQUN0QjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IENvbnRhY3REZXRhaWxzQ29tcG9uZW50IH0gZnJvbSAnLi9jb250YWN0LmRldGFpbHMvY29udGFjdC5kZXRhaWxzLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEZvcm1zTW9kdWxlLCBSZWFjdGl2ZUZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG4vLyBpbXBvcnQgeyBCcm93c2VyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7IFRyYW5zbGF0ZU1vZHVsZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xyXG5pbXBvcnQgeyBFcnJvck1vZHVsZSwgUGlwZXNNb2R1bGUsIEV4cGFuZGVyTW9kdWxlLCBOdW1iZXJzT25seURpcmVjdGl2ZSwgUG9wdXBDb21wb25lbnQgfSBmcm9tICdAaHBmYi9zZGsvdWknO1xyXG5pbXBvcnQgeyBDb250YWN0RGV0YWlsc1NlcnZpY2UgfSBmcm9tICcuL2NvbnRhY3QuZGV0YWlscy9jb250YWN0LmRldGFpbHMuc2VydmljZSc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGltcG9ydHM6IFtcclxuICAgIENvbW1vbk1vZHVsZSxcclxuICAgIC8vIEJyb3dzZXJNb2R1bGUsXHJcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gICAgRm9ybXNNb2R1bGUsXHJcbiAgICBUcmFuc2xhdGVNb2R1bGUsXHJcbiAgICBFcnJvck1vZHVsZSxcclxuICAgIFBpcGVzTW9kdWxlLFxyXG4gICAgRXhwYW5kZXJNb2R1bGUsXHJcbiAgICBOdW1iZXJzT25seURpcmVjdGl2ZSxcclxuICAgIFBvcHVwQ29tcG9uZW50XHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIENvbnRhY3REZXRhaWxzQ29tcG9uZW50XHJcbiAgXSxcclxuICBleHBvcnRzOiBbXHJcbiAgICBDb250YWN0RGV0YWlsc0NvbXBvbmVudFxyXG4gIF0sXHJcbiAgcHJvdmlkZXJzOiBbXHJcbiAgICBDb250YWN0RGV0YWlsc1NlcnZpY2UsXHJcbiAgXSxcclxufSlcclxuZXhwb3J0IGNsYXNzIENvbnRhY3RNb2R1bGUge30iXX0=