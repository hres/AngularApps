import { Injectable, signal } from '@angular/core';
import { Validators } from '@angular/forms';
import { ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class AddressDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
        this.isDefaultCountryCanada = signal(false);
    }
    getIsDefaultCountryCanada() {
        return this.isDefaultCountryCanada.asReadonly();
    }
    setIsDefaultCountryCanada(deault) {
        this.isDefaultCountryCanada.set(deault);
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            address: [null, Validators.required],
            provText: '',
            provState: '',
            city: ['', [Validators.required]],
            country: [null, [Validators.required]],
            postal: ['', [Validators.required]]
        });
    }
    mapFormModelToDataModel(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            if (this.getIsDefaultCountryCanada()) {
                // Since the country has been disabled, it was removed from the form group.
                // Manually map the country field
                addressModel.country = this._converterService.findAndConverCodeToIdTextLabel(countryList, 'CA', lang);
            }
            else {
                addressModel.country = formValue['country'] ?
                    this._converterService.findAndConverCodeToIdTextLabel(countryList, formValue['country'], lang) : null;
            }
            if (addressModel.country) {
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    addressModel.province_text = '';
                    addressModel.province_lov = formValue['provState'] ?
                        this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
                }
                else {
                    addressModel.province_text = formValue['provText'];
                    addressModel.province_lov = null;
                }
            }
            else {
                addressModel.province_text = formValue['provText'];
            }
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapDataModelToFormModel(addressModel, formRecord) {
        if (addressModel) {
            formRecord.controls['address'].setValue(addressModel.street_address);
            formRecord.controls['city'].setValue(addressModel.city);
            formRecord.controls['postal'].setValue(addressModel.postal_code);
            if (addressModel.country) {
                formRecord.controls['country'].setValue(addressModel.country._id);
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    formRecord.controls['provState'].setValue(addressModel.province_lov._id);
                }
                else {
                    formRecord.controls['provText'].setValue(addressModel.province_text);
                }
            }
            else {
                formRecord.controls['country'].setValue(null);
            }
        }
    }
    setProvinceState(record, countryId, provinceList, stateList) {
        let listToReturn = [];
        if (this._utilsService.isCanadaOrUSA(countryId)) {
            this._utilsService.resetControlsValues(record.controls['provText']);
            record.controls['provList'].setValidators([Validators.required]);
            if (this._utilsService.isCanada(countryId)) {
                record.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
                listToReturn = provinceList;
            }
            else {
                record.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
                listToReturn = stateList;
            }
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        else {
            record.controls['provList'].setValidators([]);
            record.controls['provList'].setValue('');
            record.controls['postal'].setValidators([Validators.required]);
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        return listToReturn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLmRldGFpbHMvYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBVSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0QsT0FBTyxFQUF5QixVQUFVLEVBQUMsTUFBTSxnQkFBZ0IsQ0FBQztBQUNsRSxPQUFPLEVBQXlDLGlCQUFpQixFQUFFLE1BQU0sY0FBYyxDQUFDOzs7QUFJeEYsTUFBTSxPQUFPLHFCQUFxQjtJQUVoQyxZQUFvQixhQUEyQixFQUFVLGlCQUFtQztRQUF4RSxrQkFBYSxHQUFiLGFBQWEsQ0FBYztRQUFVLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBa0I7UUFFcEYsMkJBQXNCLEdBQUcsTUFBTSxDQUFVLEtBQUssQ0FBQyxDQUFDO0lBRndDLENBQUM7SUFJakcseUJBQXlCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ2xELENBQUM7SUFFRCx5QkFBeUIsQ0FBQyxNQUFlO1FBQ3ZDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxnQkFBZ0IsQ0FBQyxFQUFlO1FBQ3JDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUFBLE9BQU8sSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUN4QixPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUM7WUFDZCxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNwQyxRQUFRLEVBQUUsRUFBRTtZQUNaLFNBQVMsRUFBRSxFQUFFO1lBQ2IsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2pDLE9BQU8sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN0QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDcEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFNBQWMsRUFBRSxZQUEwQixFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsb0JBQW9CO1FBQ2hILElBQUksU0FBUyxFQUFFLENBQUM7WUFDZCxZQUFZLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNuRCxZQUFZLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0QyxJQUFJLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxFQUFFLENBQUM7Z0JBQ3JDLDJFQUEyRTtnQkFDM0UsaUNBQWlDO2dCQUNqQyxZQUFZLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyw4QkFBOEIsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3hHLENBQUM7aUJBQU0sQ0FBQztnQkFDTixZQUFZLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUMzQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFHLENBQUM7WUFFRCxJQUFJLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9ELFlBQVksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNoQyxZQUFZLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO3dCQUNsRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25ILENBQUM7cUJBQUssQ0FBQztvQkFDTCxZQUFZLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDbkQsWUFBWSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ25DLENBQUM7WUFDTCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sWUFBWSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDckQsQ0FBQztZQUNELFlBQVksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pELENBQUM7SUFDSCxDQUFDO0lBRU0sdUJBQXVCLENBQUMsWUFBWSxFQUFFLFVBQXFCO1FBQ2hFLElBQUksWUFBWSxFQUFFLENBQUM7WUFDakIsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3JFLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4RCxVQUFVLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFakUsSUFBSSxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3pCLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRWxFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMvRCxVQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMzRSxDQUFDO3FCQUFNLENBQUM7b0JBQ04sVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUN2RSxDQUFDO1lBQ0gsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2hELENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVNLGdCQUFnQixDQUFDLE1BQWlCLEVBQUUsU0FBaUIsRUFBRSxZQUFxQixFQUFFLFNBQWtCO1FBRXJHLElBQUksWUFBWSxHQUFZLEVBQUUsQ0FBQztRQUUvQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFFaEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7WUFDbkUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUVqRSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7Z0JBQzNDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hHLFlBQVksR0FBRyxZQUFZLENBQUM7WUFDOUIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JHLFlBQVksR0FBRyxTQUFTLENBQUM7WUFDM0IsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNyRCxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFFckQsQ0FBQzthQUFNLENBQUM7WUFDTixNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUM5QyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN6QyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQy9ELE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNyRCxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDckQsQ0FBQztRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7K0dBN0dVLHFCQUFxQjttSEFBckIscUJBQXFCOzs0RkFBckIscUJBQXFCO2tCQURqQyxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgU2lnbmFsLCBzaWduYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtGb3JtQnVpbGRlciwgRm9ybUdyb3VwLCBWYWxpZGF0b3JzfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENvbnZlcnRlclNlcnZpY2UsIElDb2RlLCBVdGlsc1NlcnZpY2UsIFZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnQGhwZmIvc2RrL3VpJztcclxuaW1wb3J0IHsgSU5hbWVBZGRyZXNzIH0gZnJvbSAnLi4vLi4vbW9kZWwvZW50aXR5LWJhc2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQWRkcmVzc0RldGFpbHNTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfdXRpbHNTZXJ2aWNlOiBVdGlsc1NlcnZpY2UsIHByaXZhdGUgX2NvbnZlcnRlclNlcnZpY2U6IENvbnZlcnRlclNlcnZpY2UpIHsgfVxyXG4gIFxyXG4gIHByaXZhdGUgaXNEZWZhdWx0Q291bnRyeUNhbmFkYSA9IHNpZ25hbDxib29sZWFuPihmYWxzZSk7XHJcblxyXG4gIGdldElzRGVmYXVsdENvdW50cnlDYW5hZGEoKTogU2lnbmFsPGJvb2xlYW4+e1xyXG4gICAgcmV0dXJuIHRoaXMuaXNEZWZhdWx0Q291bnRyeUNhbmFkYS5hc1JlYWRvbmx5KCk7XHJcbiAgfVxyXG5cclxuICBzZXRJc0RlZmF1bHRDb3VudHJ5Q2FuYWRhKGRlYXVsdDogYm9vbGVhbik6IHZvaWR7XHJcbiAgICB0aGlzLmlzRGVmYXVsdENvdW50cnlDYW5hZGEuc2V0KGRlYXVsdCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXRzIHRoZSByZWFjdGl2ZSBmb3JtcyBNb2RlbCBmb3IgYWRkcmVzcyBkZXRhaWxzXHJcbiAgICogQHBhcmFtIHtGb3JtQnVpbGRlcn0gZmJcclxuICAgKiBAcmV0dXJucyB7YW55fVxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRSZWFjdGl2ZU1vZGVsKGZiOiBGb3JtQnVpbGRlcikge1xyXG4gICAgaWYgKCFmYikge3JldHVybiBudWxsOyB9XHJcbiAgICByZXR1cm4gZmIuZ3JvdXAoe1xyXG4gICAgICBhZGRyZXNzOiBbbnVsbCwgVmFsaWRhdG9ycy5yZXF1aXJlZF0sXHJcbiAgICAgIHByb3ZUZXh0OiAnJyxcclxuICAgICAgcHJvdlN0YXRlOiAnJyxcclxuICAgICAgY2l0eTogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF1dLFxyXG4gICAgICBjb3VudHJ5OiBbbnVsbCwgW1ZhbGlkYXRvcnMucmVxdWlyZWRdXSxcclxuICAgICAgcG9zdGFsOiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXV1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcEZvcm1Nb2RlbFRvRGF0YU1vZGVsKGZvcm1WYWx1ZTogYW55LCBhZGRyZXNzTW9kZWw6IElOYW1lQWRkcmVzcywgbGFuZywgY291bnRyeUxpc3QsIGNvbWJpbmVkUHJvdlN0YXRMaXN0KSB7XHJcbiAgICBpZiAoZm9ybVZhbHVlKSB7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5zdHJlZXRfYWRkcmVzcyA9IGZvcm1WYWx1ZVsnYWRkcmVzcyddO1xyXG4gICAgICBhZGRyZXNzTW9kZWwuY2l0eSA9IGZvcm1WYWx1ZVsnY2l0eSddO1xyXG5cclxuICAgICAgaWYgKHRoaXMuZ2V0SXNEZWZhdWx0Q291bnRyeUNhbmFkYSgpKSB7XHJcbiAgICAgICAgLy8gU2luY2UgdGhlIGNvdW50cnkgaGFzIGJlZW4gZGlzYWJsZWQsIGl0IHdhcyByZW1vdmVkIGZyb20gdGhlIGZvcm0gZ3JvdXAuXHJcbiAgICAgICAgLy8gTWFudWFsbHkgbWFwIHRoZSBjb3VudHJ5IGZpZWxkXHJcbiAgICAgICAgYWRkcmVzc01vZGVsLmNvdW50cnkgPSB0aGlzLl9jb252ZXJ0ZXJTZXJ2aWNlLmZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChjb3VudHJ5TGlzdCwgJ0NBJywgbGFuZyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWRkcmVzc01vZGVsLmNvdW50cnkgPSBmb3JtVmFsdWVbJ2NvdW50cnknXSA/IFxyXG4gICAgICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY291bnRyeUxpc3QsIGZvcm1WYWx1ZVsnY291bnRyeSddLCBsYW5nKSA6IG51bGw7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChhZGRyZXNzTW9kZWwuY291bnRyeSkge1xyXG4gICAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpKSB7XHJcbiAgICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9ICcnO1xyXG4gICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdiA9IGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10gPyBcclxuICAgICAgICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY29tYmluZWRQcm92U3RhdExpc3QsIGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10sIGxhbmcpIDogbnVsbDtcclxuICAgICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSBmb3JtVmFsdWVbJ3Byb3ZUZXh0J107XHJcbiAgICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YgPSBudWxsO1xyXG4gICAgICAgICAgfSBcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9IGZvcm1WYWx1ZVsncHJvdlRleHQnXTtcclxuICAgICAgfVxyXG4gICAgICBhZGRyZXNzTW9kZWwucG9zdGFsX2NvZGUgPSBmb3JtVmFsdWVbJ3Bvc3RhbCddO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcERhdGFNb2RlbFRvRm9ybU1vZGVsKGFkZHJlc3NNb2RlbCwgZm9ybVJlY29yZDogRm9ybUdyb3VwKSB7XHJcbiAgICBpZiAoYWRkcmVzc01vZGVsKSB7XHJcbiAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2FkZHJlc3MnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwuc3RyZWV0X2FkZHJlc3MpO1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydjaXR5J10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLmNpdHkpO1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwb3N0YWwnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwucG9zdGFsX2NvZGUpO1xyXG5cclxuICAgICAgaWYgKGFkZHJlc3NNb2RlbC5jb3VudHJ5KSB7XHJcbiAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snY291bnRyeSddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5jb3VudHJ5Ll9pZCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpKSB7XHJcbiAgICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwcm92U3RhdGUnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwucHJvdmluY2VfbG92Ll9pZCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ3Byb3ZUZXh0J10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydjb3VudHJ5J10uc2V0VmFsdWUobnVsbCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHB1YmxpYyBzZXRQcm92aW5jZVN0YXRlKHJlY29yZDogRm9ybUdyb3VwLCBjb3VudHJ5SWQ6IHN0cmluZywgcHJvdmluY2VMaXN0OiBJQ29kZVtdLCBzdGF0ZUxpc3Q6IElDb2RlW10pOiBJQ29kZVtdIHtcclxuXHJcbiAgICBsZXQgbGlzdFRvUmV0dXJuOiBJQ29kZVtdID0gW107XHJcblxyXG4gICAgaWYgKHRoaXMuX3V0aWxzU2VydmljZS5pc0NhbmFkYU9yVVNBKGNvdW50cnlJZCkpIHtcclxuXHJcbiAgICAgIHRoaXMuX3V0aWxzU2VydmljZS5yZXNldENvbnRyb2xzVmFsdWVzKHJlY29yZC5jb250cm9sc1sncHJvdlRleHQnXSlcclxuICAgICAgcmVjb3JkLmNvbnRyb2xzWydwcm92TGlzdCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWRdKTtcclxuXHJcbiAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGEoY291bnRyeUlkKSkge1xyXG4gICAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdGlvblNlcnZpY2UuY2FuYWRhUG9zdGFsVmFsaWRhdG9yXSk7XHJcbiAgICAgICAgbGlzdFRvUmV0dXJuID0gcHJvdmluY2VMaXN0O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdGlvblNlcnZpY2UudXNhUG9zdGFsVmFsaWRhdG9yXSk7XHJcbiAgICAgICAgbGlzdFRvUmV0dXJuID0gc3RhdGVMaXN0O1xyXG4gICAgICB9XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KCk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG5cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWxpZGF0b3JzKFtdKTtcclxuICAgICAgcmVjb3JkLmNvbnRyb2xzWydwcm92TGlzdCddLnNldFZhbHVlKCcnKTtcclxuICAgICAgcmVjb3JkLmNvbnRyb2xzWydwb3N0YWwnXS5zZXRWYWxpZGF0b3JzKFtWYWxpZGF0b3JzLnJlcXVpcmVkXSk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KCk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBsaXN0VG9SZXR1cm47XHJcbiAgfVxyXG4gIFxyXG59Il19