import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { CANADA, ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class AddressDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            address: [null, Validators.required],
            provText: '',
            provState: '',
            city: ['', [Validators.required]],
            country: [null, [Validators.required]],
            postal: ['', [Validators.required]]
        });
    }
    mapFormModelToDataModel(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = formValue['country'] ?
                this._converterService.findAndConverCodeToIdTextLabel(countryList, formValue['country'], lang) : null;
            if (addressModel.country) {
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    addressModel.province_text = '';
                    addressModel.province_lov = formValue['provState'] ?
                        this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
                }
                else {
                    addressModel.province_text = formValue['provText'];
                    addressModel.province_lov = null;
                }
            }
            else {
                addressModel.province_text = formValue['provText'];
            }
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapFormModelToDataModelCanadianAddress(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = this._converterService.findAndConverCodeToIdTextLabel(countryList, CANADA, lang);
            addressModel.province_text = '';
            addressModel.province_lov = formValue['provState'] ?
                this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapDataModelToFormModel(addressModel, formRecord) {
        if (addressModel) {
            formRecord.controls['address'].setValue(addressModel.street_address);
            formRecord.controls['city'].setValue(addressModel.city);
            formRecord.controls['postal'].setValue(addressModel.postal_code);
            if (addressModel.country) {
                formRecord.controls['country'].setValue(addressModel.country._id);
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    formRecord.controls['provState'].setValue(addressModel.province_lov._id);
                }
                else {
                    formRecord.controls['provText'].setValue(addressModel.province_text);
                }
            }
            else {
                formRecord.controls['country'].setValue(null);
            }
        }
    }
    setProvinceState(record, countryId, provinceList, stateList) {
        let listToReturn = [];
        if (this._utilsService.isCanadaOrUSA(countryId)) {
            this._utilsService.resetControlsValues(record.controls['provText']);
            record.controls['provList'].setValidators([Validators.required]);
            if (this._utilsService.isCanada(countryId)) {
                record.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
                listToReturn = provinceList;
            }
            else {
                record.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
                listToReturn = stateList;
            }
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        else {
            record.controls['provList'].setValidators([]);
            record.controls['provList'].setValue('');
            record.controls['postal'].setValidators([Validators.required]);
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        return listToReturn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLmRldGFpbHMvYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQXlCLFVBQVUsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxNQUFNLEVBQXlDLGlCQUFpQixFQUFFLE1BQU0sY0FBYyxDQUFDOzs7QUFJaEcsTUFBTSxPQUFPLHFCQUFxQjtJQUVoQyxZQUFvQixhQUEyQixFQUFVLGlCQUFtQztRQUF4RSxrQkFBYSxHQUFiLGFBQWEsQ0FBYztRQUFVLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBa0I7SUFBSSxDQUFDO0lBRWpHOzs7O09BSUc7SUFDSSxnQkFBZ0IsQ0FBQyxFQUFlO1FBQ3JDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUFBLE9BQU8sSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUN4QixPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUM7WUFDZCxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNwQyxRQUFRLEVBQUUsRUFBRTtZQUNaLFNBQVMsRUFBRSxFQUFFO1lBQ2IsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2pDLE9BQU8sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN0QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDcEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFNBQWMsRUFBRSxZQUEwQixFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsb0JBQW9CO1FBQ2hILElBQUksU0FBUyxFQUFFLENBQUM7WUFDZCxZQUFZLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNuRCxZQUFZLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0QyxZQUFZLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN6QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBRTFHLElBQUksWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN6QixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDL0QsWUFBWSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7b0JBQ2hDLFlBQVksQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7d0JBQ2xELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyw4QkFBOEIsQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkgsQ0FBQztxQkFBSyxDQUFDO29CQUNMLFlBQVksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUNuRCxZQUFZLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDbkMsQ0FBQztZQUNMLENBQUM7aUJBQU0sQ0FBQztnQkFDTixZQUFZLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNyRCxDQUFDO1lBQ0QsWUFBWSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakQsQ0FBQztJQUNILENBQUM7SUFFTSxzQ0FBc0MsQ0FBQyxTQUFjLEVBQUUsWUFBMEIsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLG9CQUFvQjtRQUMvSCxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsWUFBWSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkQsWUFBWSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFdEMsWUFBWSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4RyxZQUFZLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUNoQyxZQUFZLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNwRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDakgsWUFBWSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakQsQ0FBQztJQUNILENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxZQUFZLEVBQUUsVUFBcUI7UUFDaEUsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUNqQixVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDckUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3hELFVBQVUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUVqRSxJQUFJLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekIsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFbEUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9ELFVBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzNFLENBQUM7cUJBQU0sQ0FBQztvQkFDTixVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3ZFLENBQUM7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEQsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsTUFBaUIsRUFBRSxTQUFpQixFQUFFLFlBQXFCLEVBQUUsU0FBa0I7UUFFckcsSUFBSSxZQUFZLEdBQVksRUFBRSxDQUFDO1FBRS9CLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUVoRCxJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtZQUNuRSxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRWpFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztnQkFDM0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztnQkFDeEcsWUFBWSxHQUFHLFlBQVksQ0FBQztZQUM5QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztnQkFDckcsWUFBWSxHQUFHLFNBQVMsQ0FBQztZQUMzQixDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUVyRCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDL0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUNyRCxDQUFDO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQzsrR0ExR1UscUJBQXFCO21IQUFyQixxQkFBcUI7OzRGQUFyQixxQkFBcUI7a0JBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7Rm9ybUJ1aWxkZXIsIEZvcm1Hcm91cCwgVmFsaWRhdG9yc30gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBDQU5BREEsIENvbnZlcnRlclNlcnZpY2UsIElDb2RlLCBVdGlsc1NlcnZpY2UsIFZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnQGhwZmIvc2RrL3VpJztcclxuaW1wb3J0IHsgSU5hbWVBZGRyZXNzIH0gZnJvbSAnLi4vLi4vbW9kZWwvZW50aXR5LWJhc2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQWRkcmVzc0RldGFpbHNTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfdXRpbHNTZXJ2aWNlOiBVdGlsc1NlcnZpY2UsIHByaXZhdGUgX2NvbnZlcnRlclNlcnZpY2U6IENvbnZlcnRlclNlcnZpY2UpIHsgfVxyXG4gIFxyXG4gIC8qKlxyXG4gICAqIEdldHMgdGhlIHJlYWN0aXZlIGZvcm1zIE1vZGVsIGZvciBhZGRyZXNzIGRldGFpbHNcclxuICAgKiBAcGFyYW0ge0Zvcm1CdWlsZGVyfSBmYlxyXG4gICAqIEByZXR1cm5zIHthbnl9XHJcbiAgICovXHJcbiAgcHVibGljIGdldFJlYWN0aXZlTW9kZWwoZmI6IEZvcm1CdWlsZGVyKSB7XHJcbiAgICBpZiAoIWZiKSB7cmV0dXJuIG51bGw7IH1cclxuICAgIHJldHVybiBmYi5ncm91cCh7XHJcbiAgICAgIGFkZHJlc3M6IFtudWxsLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgcHJvdlRleHQ6ICcnLFxyXG4gICAgICBwcm92U3RhdGU6ICcnLFxyXG4gICAgICBjaXR5OiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXV0sXHJcbiAgICAgIGNvdW50cnk6IFtudWxsLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF1dLFxyXG4gICAgICBwb3N0YWw6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdXVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbWFwRm9ybU1vZGVsVG9EYXRhTW9kZWwoZm9ybVZhbHVlOiBhbnksIGFkZHJlc3NNb2RlbDogSU5hbWVBZGRyZXNzLCBsYW5nLCBjb3VudHJ5TGlzdCwgY29tYmluZWRQcm92U3RhdExpc3QpIHtcclxuICAgIGlmIChmb3JtVmFsdWUpIHtcclxuICAgICAgYWRkcmVzc01vZGVsLnN0cmVldF9hZGRyZXNzID0gZm9ybVZhbHVlWydhZGRyZXNzJ107XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5jaXR5ID0gZm9ybVZhbHVlWydjaXR5J107XHJcblxyXG4gICAgICBhZGRyZXNzTW9kZWwuY291bnRyeSA9IGZvcm1WYWx1ZVsnY291bnRyeSddID8gXHJcbiAgICAgICAgICB0aGlzLl9jb252ZXJ0ZXJTZXJ2aWNlLmZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChjb3VudHJ5TGlzdCwgZm9ybVZhbHVlWydjb3VudHJ5J10sIGxhbmcpIDogbnVsbDtcclxuXHJcbiAgICAgIGlmIChhZGRyZXNzTW9kZWwuY291bnRyeSkge1xyXG4gICAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpKSB7XHJcbiAgICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9ICcnO1xyXG4gICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdiA9IGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10gPyBcclxuICAgICAgICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY29tYmluZWRQcm92U3RhdExpc3QsIGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10sIGxhbmcpIDogbnVsbDtcclxuICAgICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSBmb3JtVmFsdWVbJ3Byb3ZUZXh0J107XHJcbiAgICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YgPSBudWxsO1xyXG4gICAgICAgICAgfSBcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9IGZvcm1WYWx1ZVsncHJvdlRleHQnXTtcclxuICAgICAgfVxyXG4gICAgICBhZGRyZXNzTW9kZWwucG9zdGFsX2NvZGUgPSBmb3JtVmFsdWVbJ3Bvc3RhbCddO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcEZvcm1Nb2RlbFRvRGF0YU1vZGVsQ2FuYWRpYW5BZGRyZXNzKGZvcm1WYWx1ZTogYW55LCBhZGRyZXNzTW9kZWw6IElOYW1lQWRkcmVzcywgbGFuZywgY291bnRyeUxpc3QsIGNvbWJpbmVkUHJvdlN0YXRMaXN0KSB7XHJcbiAgICBpZiAoZm9ybVZhbHVlKSB7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5zdHJlZXRfYWRkcmVzcyA9IGZvcm1WYWx1ZVsnYWRkcmVzcyddO1xyXG4gICAgICBhZGRyZXNzTW9kZWwuY2l0eSA9IGZvcm1WYWx1ZVsnY2l0eSddO1xyXG5cclxuICAgICAgYWRkcmVzc01vZGVsLmNvdW50cnkgPSB0aGlzLl9jb252ZXJ0ZXJTZXJ2aWNlLmZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChjb3VudHJ5TGlzdCwgQ0FOQURBLCBsYW5nKTtcclxuICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSAnJztcclxuICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdiA9IGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10gPyBcclxuICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY29tYmluZWRQcm92U3RhdExpc3QsIGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10sIGxhbmcpIDogbnVsbDtcclxuICAgICAgYWRkcmVzc01vZGVsLnBvc3RhbF9jb2RlID0gZm9ybVZhbHVlWydwb3N0YWwnXTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHB1YmxpYyBtYXBEYXRhTW9kZWxUb0Zvcm1Nb2RlbChhZGRyZXNzTW9kZWwsIGZvcm1SZWNvcmQ6IEZvcm1Hcm91cCkge1xyXG4gICAgaWYgKGFkZHJlc3NNb2RlbCkge1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydhZGRyZXNzJ10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnN0cmVldF9hZGRyZXNzKTtcclxuICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snY2l0eSddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5jaXR5KTtcclxuICAgICAgZm9ybVJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnBvc3RhbF9jb2RlKTtcclxuXHJcbiAgICAgIGlmIChhZGRyZXNzTW9kZWwuY291bnRyeSkge1xyXG4gICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2NvdW50cnknXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhT3JVU0EoYWRkcmVzc01vZGVsLmNvdW50cnkuX2lkKSkge1xyXG4gICAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1sncHJvdlN0YXRlJ10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdi5faWQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwcm92VGV4dCddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5wcm92aW5jZV90ZXh0KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snY291bnRyeSddLnNldFZhbHVlKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgc2V0UHJvdmluY2VTdGF0ZShyZWNvcmQ6IEZvcm1Hcm91cCwgY291bnRyeUlkOiBzdHJpbmcsIHByb3ZpbmNlTGlzdDogSUNvZGVbXSwgc3RhdGVMaXN0OiBJQ29kZVtdKTogSUNvZGVbXSB7XHJcblxyXG4gICAgbGV0IGxpc3RUb1JldHVybjogSUNvZGVbXSA9IFtdO1xyXG5cclxuICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShjb3VudHJ5SWQpKSB7XHJcblxyXG4gICAgICB0aGlzLl91dGlsc1NlcnZpY2UucmVzZXRDb250cm9sc1ZhbHVlcyhyZWNvcmQuY29udHJvbHNbJ3Byb3ZUZXh0J10pXHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWxpZGF0b3JzKFtWYWxpZGF0b3JzLnJlcXVpcmVkXSk7XHJcblxyXG4gICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhKGNvdW50cnlJZCkpIHtcclxuICAgICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLmNhbmFkYVBvc3RhbFZhbGlkYXRvcl0pO1xyXG4gICAgICAgIGxpc3RUb1JldHVybiA9IHByb3ZpbmNlTGlzdDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLnVzYVBvc3RhbFZhbGlkYXRvcl0pO1xyXG4gICAgICAgIGxpc3RUb1JldHVybiA9IHN0YXRlTGlzdDtcclxuICAgICAgfVxyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10uc2V0VmFsaWRhdG9ycyhbXSk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWx1ZSgnJyk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZF0pO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gbGlzdFRvUmV0dXJuO1xyXG4gIH1cclxuICBcclxufSJdfQ==