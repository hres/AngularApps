import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { CANADA, ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class AddressDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            address: [null, Validators.required],
            provText: '',
            provState: '',
            city: ['', [Validators.required]],
            country: [null, [Validators.required]],
            postal: ['', [Validators.required]]
        });
    }
    mapFormModelToDataModel(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = formValue['country'] ?
                this._converterService.findAndConverCodeToIdTextLabel(countryList, formValue['country'], lang) : null;
            if (addressModel.country) {
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    addressModel.province_text = '';
                    addressModel.province_lov = formValue['provState'] ?
                        this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
                }
                else {
                    addressModel.province_text = formValue['provText'];
                    addressModel.province_lov = null;
                }
            }
            else {
                addressModel.province_text = formValue['provText'];
            }
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapFormModelToDataModelCanadianAddress(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = this._converterService.findAndConverCodeToIdTextLabel(countryList, CANADA, lang);
            addressModel.province_text = '';
            addressModel.province_lov = formValue['provState'] ?
                this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
        }
        else {
            addressModel.province_text = formValue['provText'];
        }
        addressModel.postal_code = formValue['postal'];
    }
    mapDataModelToFormModel(addressModel, formRecord) {
        if (addressModel) {
            formRecord.controls['address'].setValue(addressModel.street_address);
            formRecord.controls['city'].setValue(addressModel.city);
            formRecord.controls['postal'].setValue(addressModel.postal_code);
            if (addressModel.country) {
                formRecord.controls['country'].setValue(addressModel.country._id);
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    formRecord.controls['provState'].setValue(addressModel.province_lov._id);
                }
                else {
                    formRecord.controls['provText'].setValue(addressModel.province_text);
                }
            }
            else {
                formRecord.controls['country'].setValue(null);
            }
        }
    }
    setProvinceState(record, countryId, provinceList, stateList) {
        let listToReturn = [];
        if (this._utilsService.isCanadaOrUSA(countryId)) {
            this._utilsService.resetControlsValues(record.controls['provText']);
            record.controls['provList'].setValidators([Validators.required]);
            if (this._utilsService.isCanada(countryId)) {
                record.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
                listToReturn = provinceList;
            }
            else {
                record.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
                listToReturn = stateList;
            }
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        else {
            record.controls['provList'].setValidators([]);
            record.controls['provList'].setValue('');
            record.controls['postal'].setValidators([Validators.required]);
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        return listToReturn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLmRldGFpbHMvYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBa0IsTUFBTSxlQUFlLENBQUM7QUFDM0QsT0FBTyxFQUF5QixVQUFVLEVBQUMsTUFBTSxnQkFBZ0IsQ0FBQztBQUNsRSxPQUFPLEVBQUUsTUFBTSxFQUF1RCxpQkFBaUIsRUFBRSxNQUFNLGNBQWMsQ0FBQzs7O0FBSTlHLE1BQU0sT0FBTyxxQkFBcUI7SUFFaEMsWUFBb0IsYUFBMkIsRUFBVSxpQkFBbUM7UUFBeEUsa0JBQWEsR0FBYixhQUFhLENBQWM7UUFBVSxzQkFBaUIsR0FBakIsaUJBQWlCLENBQWtCO0lBQUksQ0FBQztJQUVqRzs7OztPQUlHO0lBQ0ksZ0JBQWdCLENBQUMsRUFBZTtRQUNyQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7WUFBQSxPQUFPLElBQUksQ0FBQztRQUFDLENBQUM7UUFDeEIsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDO1lBQ2QsT0FBTyxFQUFFLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDcEMsUUFBUSxFQUFFLEVBQUU7WUFDWixTQUFTLEVBQUUsRUFBRTtZQUNiLElBQUksRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNqQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3BDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxTQUFjLEVBQUUsWUFBMEIsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLG9CQUFvQjtRQUNoSCxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsWUFBWSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkQsWUFBWSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFdEMsWUFBWSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDekMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLDhCQUE4QixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUUxRyxJQUFJLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9ELFlBQVksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUNoQyxZQUFZLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO3dCQUNsRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsOEJBQThCLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25ILENBQUM7cUJBQUssQ0FBQztvQkFDTCxZQUFZLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDbkQsWUFBWSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ25DLENBQUM7WUFDTCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sWUFBWSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDckQsQ0FBQztZQUNELFlBQVksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pELENBQUM7SUFDSCxDQUFDO0lBRU0sc0NBQXNDLENBQUMsU0FBYyxFQUFFLFlBQTBCLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxvQkFBb0I7UUFDL0gsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNkLFlBQVksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25ELFlBQVksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXRDLFlBQVksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLDhCQUE4QixDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDeEcsWUFBWSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7WUFDaEMsWUFBWSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztnQkFDcEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLDhCQUE4QixDQUFDLG9CQUFvQixFQUFFLFNBQVMsQ0FBQyxXQUFXLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ2pILENBQUM7YUFBTSxDQUFDO1lBQ04sWUFBWSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckQsQ0FBQztRQUNELFlBQVksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxZQUFZLEVBQUUsVUFBcUI7UUFDaEUsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUNqQixVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDckUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3hELFVBQVUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUVqRSxJQUFJLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekIsVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFbEUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9ELFVBQVUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzNFLENBQUM7cUJBQU0sQ0FBQztvQkFDTixVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3ZFLENBQUM7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEQsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsTUFBaUIsRUFBRSxTQUFpQixFQUFFLFlBQXFCLEVBQUUsU0FBa0I7UUFFckcsSUFBSSxZQUFZLEdBQVksRUFBRSxDQUFDO1FBRS9CLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUVoRCxJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtZQUNuRSxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRWpFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztnQkFDM0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztnQkFDeEcsWUFBWSxHQUFHLFlBQVksQ0FBQztZQUM5QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztnQkFDckcsWUFBWSxHQUFHLFNBQVMsQ0FBQztZQUMzQixDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUVyRCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDL0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUNyRCxDQUFDO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQzsrR0E1R1UscUJBQXFCO21IQUFyQixxQkFBcUI7OzRGQUFyQixxQkFBcUI7a0JBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBTaWduYWwsIHNpZ25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0Zvcm1CdWlsZGVyLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnN9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgQ0FOQURBLCBDb252ZXJ0ZXJTZXJ2aWNlLCBJQ29kZSwgSUlkVGV4dExhYmVsLCBVdGlsc1NlcnZpY2UsIFZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnQGhwZmIvc2RrL3VpJztcclxuaW1wb3J0IHsgSU5hbWVBZGRyZXNzIH0gZnJvbSAnLi4vLi4vbW9kZWwvZW50aXR5LWJhc2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQWRkcmVzc0RldGFpbHNTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfdXRpbHNTZXJ2aWNlOiBVdGlsc1NlcnZpY2UsIHByaXZhdGUgX2NvbnZlcnRlclNlcnZpY2U6IENvbnZlcnRlclNlcnZpY2UpIHsgfVxyXG4gIFxyXG4gIC8qKlxyXG4gICAqIEdldHMgdGhlIHJlYWN0aXZlIGZvcm1zIE1vZGVsIGZvciBhZGRyZXNzIGRldGFpbHNcclxuICAgKiBAcGFyYW0ge0Zvcm1CdWlsZGVyfSBmYlxyXG4gICAqIEByZXR1cm5zIHthbnl9XHJcbiAgICovXHJcbiAgcHVibGljIGdldFJlYWN0aXZlTW9kZWwoZmI6IEZvcm1CdWlsZGVyKSB7XHJcbiAgICBpZiAoIWZiKSB7cmV0dXJuIG51bGw7IH1cclxuICAgIHJldHVybiBmYi5ncm91cCh7XHJcbiAgICAgIGFkZHJlc3M6IFtudWxsLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgcHJvdlRleHQ6ICcnLFxyXG4gICAgICBwcm92U3RhdGU6ICcnLFxyXG4gICAgICBjaXR5OiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXV0sXHJcbiAgICAgIGNvdW50cnk6IFtudWxsLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF1dLFxyXG4gICAgICBwb3N0YWw6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWRdXVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbWFwRm9ybU1vZGVsVG9EYXRhTW9kZWwoZm9ybVZhbHVlOiBhbnksIGFkZHJlc3NNb2RlbDogSU5hbWVBZGRyZXNzLCBsYW5nLCBjb3VudHJ5TGlzdCwgY29tYmluZWRQcm92U3RhdExpc3QpIHtcclxuICAgIGlmIChmb3JtVmFsdWUpIHtcclxuICAgICAgYWRkcmVzc01vZGVsLnN0cmVldF9hZGRyZXNzID0gZm9ybVZhbHVlWydhZGRyZXNzJ107XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5jaXR5ID0gZm9ybVZhbHVlWydjaXR5J107XHJcblxyXG4gICAgICBhZGRyZXNzTW9kZWwuY291bnRyeSA9IGZvcm1WYWx1ZVsnY291bnRyeSddID8gXHJcbiAgICAgICAgICB0aGlzLl9jb252ZXJ0ZXJTZXJ2aWNlLmZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChjb3VudHJ5TGlzdCwgZm9ybVZhbHVlWydjb3VudHJ5J10sIGxhbmcpIDogbnVsbDtcclxuXHJcbiAgICAgIGlmIChhZGRyZXNzTW9kZWwuY291bnRyeSkge1xyXG4gICAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpKSB7XHJcbiAgICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9ICcnO1xyXG4gICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdiA9IGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10gPyBcclxuICAgICAgICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY29tYmluZWRQcm92U3RhdExpc3QsIGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10sIGxhbmcpIDogbnVsbDtcclxuICAgICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSBmb3JtVmFsdWVbJ3Byb3ZUZXh0J107XHJcbiAgICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YgPSBudWxsO1xyXG4gICAgICAgICAgfSBcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9IGZvcm1WYWx1ZVsncHJvdlRleHQnXTtcclxuICAgICAgfVxyXG4gICAgICBhZGRyZXNzTW9kZWwucG9zdGFsX2NvZGUgPSBmb3JtVmFsdWVbJ3Bvc3RhbCddO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcEZvcm1Nb2RlbFRvRGF0YU1vZGVsQ2FuYWRpYW5BZGRyZXNzKGZvcm1WYWx1ZTogYW55LCBhZGRyZXNzTW9kZWw6IElOYW1lQWRkcmVzcywgbGFuZywgY291bnRyeUxpc3QsIGNvbWJpbmVkUHJvdlN0YXRMaXN0KSB7XHJcbiAgICBpZiAoZm9ybVZhbHVlKSB7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5zdHJlZXRfYWRkcmVzcyA9IGZvcm1WYWx1ZVsnYWRkcmVzcyddO1xyXG4gICAgICBhZGRyZXNzTW9kZWwuY2l0eSA9IGZvcm1WYWx1ZVsnY2l0eSddO1xyXG5cclxuICAgICAgYWRkcmVzc01vZGVsLmNvdW50cnkgPSB0aGlzLl9jb252ZXJ0ZXJTZXJ2aWNlLmZpbmRBbmRDb252ZXJDb2RlVG9JZFRleHRMYWJlbChjb3VudHJ5TGlzdCwgQ0FOQURBLCBsYW5nKTtcclxuICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSAnJztcclxuICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdiA9IGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10gPyBcclxuICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY29tYmluZWRQcm92U3RhdExpc3QsIGZvcm1WYWx1ZVsncHJvdlN0YXRlJ10sIGxhbmcpIDogbnVsbDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfdGV4dCA9IGZvcm1WYWx1ZVsncHJvdlRleHQnXTtcclxuICAgICAgfVxyXG4gICAgICBhZGRyZXNzTW9kZWwucG9zdGFsX2NvZGUgPSBmb3JtVmFsdWVbJ3Bvc3RhbCddO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcERhdGFNb2RlbFRvRm9ybU1vZGVsKGFkZHJlc3NNb2RlbCwgZm9ybVJlY29yZDogRm9ybUdyb3VwKSB7XHJcbiAgICBpZiAoYWRkcmVzc01vZGVsKSB7XHJcbiAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2FkZHJlc3MnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwuc3RyZWV0X2FkZHJlc3MpO1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydjaXR5J10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLmNpdHkpO1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwb3N0YWwnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwucG9zdGFsX2NvZGUpO1xyXG5cclxuICAgICAgaWYgKGFkZHJlc3NNb2RlbC5jb3VudHJ5KSB7XHJcbiAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snY291bnRyeSddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5jb3VudHJ5Ll9pZCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpKSB7XHJcbiAgICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwcm92U3RhdGUnXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwucHJvdmluY2VfbG92Ll9pZCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ3Byb3ZUZXh0J10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydjb3VudHJ5J10uc2V0VmFsdWUobnVsbCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHB1YmxpYyBzZXRQcm92aW5jZVN0YXRlKHJlY29yZDogRm9ybUdyb3VwLCBjb3VudHJ5SWQ6IHN0cmluZywgcHJvdmluY2VMaXN0OiBJQ29kZVtdLCBzdGF0ZUxpc3Q6IElDb2RlW10pOiBJQ29kZVtdIHtcclxuXHJcbiAgICBsZXQgbGlzdFRvUmV0dXJuOiBJQ29kZVtdID0gW107XHJcblxyXG4gICAgaWYgKHRoaXMuX3V0aWxzU2VydmljZS5pc0NhbmFkYU9yVVNBKGNvdW50cnlJZCkpIHtcclxuXHJcbiAgICAgIHRoaXMuX3V0aWxzU2VydmljZS5yZXNldENvbnRyb2xzVmFsdWVzKHJlY29yZC5jb250cm9sc1sncHJvdlRleHQnXSlcclxuICAgICAgcmVjb3JkLmNvbnRyb2xzWydwcm92TGlzdCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWRdKTtcclxuXHJcbiAgICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGEoY291bnRyeUlkKSkge1xyXG4gICAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdGlvblNlcnZpY2UuY2FuYWRhUG9zdGFsVmFsaWRhdG9yXSk7XHJcbiAgICAgICAgbGlzdFRvUmV0dXJuID0gcHJvdmluY2VMaXN0O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdGlvblNlcnZpY2UudXNhUG9zdGFsVmFsaWRhdG9yXSk7XHJcbiAgICAgICAgbGlzdFRvUmV0dXJuID0gc3RhdGVMaXN0O1xyXG4gICAgICB9XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KCk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG5cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWxpZGF0b3JzKFtdKTtcclxuICAgICAgcmVjb3JkLmNvbnRyb2xzWydwcm92TGlzdCddLnNldFZhbHVlKCcnKTtcclxuICAgICAgcmVjb3JkLmNvbnRyb2xzWydwb3N0YWwnXS5zZXRWYWxpZGF0b3JzKFtWYWxpZGF0b3JzLnJlcXVpcmVkXSk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KCk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBsaXN0VG9SZXR1cm47XHJcbiAgfVxyXG4gIFxyXG59Il19