import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { ValidationService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
import * as i1 from "@hpfb/sdk/ui";
export class AddressDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            address: [null, Validators.required],
            provText: '',
            provState: '',
            city: ['', [Validators.required]],
            country: [null, [Validators.required]],
            postal: ['', [Validators.required]]
        });
    }
    mapFormModelToDataModel(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = formValue['country'] ?
                this._converterService.findAndConverCodeToIdTextLabel(countryList, formValue['country'], lang) : null;
            if (addressModel.country) {
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    addressModel.province_text = '';
                    addressModel.province_lov = formValue['provState'] ?
                        this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
                }
                else {
                    addressModel.province_text = formValue['provText'];
                    addressModel.province_lov = null;
                }
            }
            else {
                addressModel.province_text = formValue['provText'];
            }
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapDataModelToFormModel(addressModel, formRecord) {
        if (addressModel) {
            formRecord.controls['address'].setValue(addressModel.street_address);
            formRecord.controls['city'].setValue(addressModel.city);
            formRecord.controls['postal'].setValue(addressModel.postal_code);
            if (addressModel.country) {
                formRecord.controls['country'].setValue(addressModel.country._id);
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    formRecord.controls['provState'].setValue(addressModel.province_lov._id);
                }
                else {
                    formRecord.controls['provText'].setValue(addressModel.province_text);
                }
            }
            else {
                formRecord.controls['country'].setValue(null);
            }
        }
    }
    setProvinceState(record, countryId, provinceList, stateList) {
        let listToReturn = [];
        if (this._utilsService.isCanadaOrUSA(countryId)) {
            this._utilsService.resetControlsValues(record.controls['provText']);
            record.controls['provList'].setValidators([Validators.required]);
            if (this._utilsService.isCanada(countryId)) {
                record.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
                listToReturn = provinceList;
            }
            else {
                record.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
                listToReturn = stateList;
            }
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        else {
            record.controls['provList'].setValidators([]);
            record.controls['provList'].setValue('');
            record.controls['postal'].setValidators([Validators.required]);
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        return listToReturn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, deps: [{ token: i1.UtilsService }, { token: i1.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UtilsService }, { type: i1.ConverterService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLmRldGFpbHMvYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQXlCLFVBQVUsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2xFLE9BQU8sRUFBeUMsaUJBQWlCLEVBQUUsTUFBTSxjQUFjLENBQUM7OztBQUl4RixNQUFNLE9BQU8scUJBQXFCO0lBRWhDLFlBQW9CLGFBQTJCLEVBQVUsaUJBQW1DO1FBQXhFLGtCQUFhLEdBQWIsYUFBYSxDQUFjO1FBQVUsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFrQjtJQUFJLENBQUM7SUFFakc7Ozs7T0FJRztJQUNJLGdCQUFnQixDQUFDLEVBQWU7UUFDckMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQUEsT0FBTyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQ3hCLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQztZQUNkLE9BQU8sRUFBRSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3BDLFFBQVEsRUFBRSxFQUFFO1lBQ1osU0FBUyxFQUFFLEVBQUU7WUFDYixJQUFJLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDakMsT0FBTyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUNwQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sdUJBQXVCLENBQUMsU0FBYyxFQUFFLFlBQTBCLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxvQkFBb0I7UUFDaEgsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNkLFlBQVksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25ELFlBQVksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXRDLFlBQVksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyw4QkFBOEIsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFFMUcsSUFBSSxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3pCLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMvRCxZQUFZLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztvQkFDaEMsWUFBWSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzt3QkFDbEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLDhCQUE4QixDQUFDLG9CQUFvQixFQUFFLFNBQVMsQ0FBQyxXQUFXLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuSCxDQUFDO3FCQUFLLENBQUM7b0JBQ0wsWUFBWSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ25ELFlBQVksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUNuQyxDQUFDO1lBQ0wsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLFlBQVksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3JELENBQUM7WUFDRCxZQUFZLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxDQUFDO0lBQ0gsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFlBQVksRUFBRSxVQUFxQjtRQUNoRSxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ2pCLFVBQVUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNyRSxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDeEQsVUFBVSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRWpFLElBQUksWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN6QixVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVsRSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDL0QsVUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDM0UsQ0FBQztxQkFBTSxDQUFDO29CQUNOLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDdkUsQ0FBQztZQUNILENBQUM7aUJBQU0sQ0FBQztnQkFDTixVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoRCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxNQUFpQixFQUFFLFNBQWlCLEVBQUUsWUFBcUIsRUFBRSxTQUFrQjtRQUVyRyxJQUFJLFlBQVksR0FBWSxFQUFFLENBQUM7UUFFL0IsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBRWhELElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFBO1lBQ25FLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFakUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO2dCQUMzQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO2dCQUN4RyxZQUFZLEdBQUcsWUFBWSxDQUFDO1lBQzlCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO2dCQUNyRyxZQUFZLEdBQUcsU0FBUyxDQUFDO1lBQzNCLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLENBQUM7WUFDckQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBRXJELENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDOUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDekMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUMvRCxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLENBQUM7WUFDckQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3JELENBQUM7UUFFRCxPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDOytHQTdGVSxxQkFBcUI7bUhBQXJCLHFCQUFxQjs7NEZBQXJCLHFCQUFxQjtrQkFEakMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtGb3JtQnVpbGRlciwgRm9ybUdyb3VwLCBWYWxpZGF0b3JzfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENvbnZlcnRlclNlcnZpY2UsIElDb2RlLCBVdGlsc1NlcnZpY2UsIFZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnQGhwZmIvc2RrL3VpJztcclxuaW1wb3J0IHsgSU5hbWVBZGRyZXNzIH0gZnJvbSAnLi4vLi4vbW9kZWwvZW50aXR5LWJhc2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQWRkcmVzc0RldGFpbHNTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfdXRpbHNTZXJ2aWNlOiBVdGlsc1NlcnZpY2UsIHByaXZhdGUgX2NvbnZlcnRlclNlcnZpY2U6IENvbnZlcnRlclNlcnZpY2UpIHsgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXRzIHRoZSByZWFjdGl2ZSBmb3JtcyBNb2RlbCBmb3IgYWRkcmVzcyBkZXRhaWxzXHJcbiAgICogQHBhcmFtIHtGb3JtQnVpbGRlcn0gZmJcclxuICAgKiBAcmV0dXJucyB7YW55fVxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRSZWFjdGl2ZU1vZGVsKGZiOiBGb3JtQnVpbGRlcikge1xyXG4gICAgaWYgKCFmYikge3JldHVybiBudWxsOyB9XHJcbiAgICByZXR1cm4gZmIuZ3JvdXAoe1xyXG4gICAgICBhZGRyZXNzOiBbbnVsbCwgVmFsaWRhdG9ycy5yZXF1aXJlZF0sXHJcbiAgICAgIHByb3ZUZXh0OiAnJyxcclxuICAgICAgcHJvdlN0YXRlOiAnJyxcclxuICAgICAgY2l0eTogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF1dLFxyXG4gICAgICBjb3VudHJ5OiBbbnVsbCwgW1ZhbGlkYXRvcnMucmVxdWlyZWRdXSxcclxuICAgICAgcG9zdGFsOiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkXV1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG1hcEZvcm1Nb2RlbFRvRGF0YU1vZGVsKGZvcm1WYWx1ZTogYW55LCBhZGRyZXNzTW9kZWw6IElOYW1lQWRkcmVzcywgbGFuZywgY291bnRyeUxpc3QsIGNvbWJpbmVkUHJvdlN0YXRMaXN0KSB7XHJcbiAgICBpZiAoZm9ybVZhbHVlKSB7XHJcbiAgICAgIGFkZHJlc3NNb2RlbC5zdHJlZXRfYWRkcmVzcyA9IGZvcm1WYWx1ZVsnYWRkcmVzcyddO1xyXG4gICAgICBhZGRyZXNzTW9kZWwuY2l0eSA9IGZvcm1WYWx1ZVsnY2l0eSddO1xyXG5cclxuICAgICAgYWRkcmVzc01vZGVsLmNvdW50cnkgPSBmb3JtVmFsdWVbJ2NvdW50cnknXSA/IFxyXG4gICAgICAgICAgdGhpcy5fY29udmVydGVyU2VydmljZS5maW5kQW5kQ29udmVyQ29kZVRvSWRUZXh0TGFiZWwoY291bnRyeUxpc3QsIGZvcm1WYWx1ZVsnY291bnRyeSddLCBsYW5nKSA6IG51bGw7XHJcblxyXG4gICAgICBpZiAoYWRkcmVzc01vZGVsLmNvdW50cnkpIHtcclxuICAgICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhT3JVU0EoYWRkcmVzc01vZGVsLmNvdW50cnkuX2lkKSkge1xyXG4gICAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSAnJztcclxuICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV9sb3YgPSBmb3JtVmFsdWVbJ3Byb3ZTdGF0ZSddID8gXHJcbiAgICAgICAgICAgIHRoaXMuX2NvbnZlcnRlclNlcnZpY2UuZmluZEFuZENvbnZlckNvZGVUb0lkVGV4dExhYmVsKGNvbWJpbmVkUHJvdlN0YXRMaXN0LCBmb3JtVmFsdWVbJ3Byb3ZTdGF0ZSddLCBsYW5nKSA6IG51bGw7XHJcbiAgICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgIGFkZHJlc3NNb2RlbC5wcm92aW5jZV90ZXh0ID0gZm9ybVZhbHVlWydwcm92VGV4dCddO1xyXG4gICAgICAgICAgICBhZGRyZXNzTW9kZWwucHJvdmluY2VfbG92ID0gbnVsbDtcclxuICAgICAgICAgIH0gXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWRkcmVzc01vZGVsLnByb3ZpbmNlX3RleHQgPSBmb3JtVmFsdWVbJ3Byb3ZUZXh0J107XHJcbiAgICAgIH1cclxuICAgICAgYWRkcmVzc01vZGVsLnBvc3RhbF9jb2RlID0gZm9ybVZhbHVlWydwb3N0YWwnXTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHB1YmxpYyBtYXBEYXRhTW9kZWxUb0Zvcm1Nb2RlbChhZGRyZXNzTW9kZWwsIGZvcm1SZWNvcmQ6IEZvcm1Hcm91cCkge1xyXG4gICAgaWYgKGFkZHJlc3NNb2RlbCkge1xyXG4gICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydhZGRyZXNzJ10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnN0cmVldF9hZGRyZXNzKTtcclxuICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snY2l0eSddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5jaXR5KTtcclxuICAgICAgZm9ybVJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnBvc3RhbF9jb2RlKTtcclxuXHJcbiAgICAgIGlmIChhZGRyZXNzTW9kZWwuY291bnRyeSkge1xyXG4gICAgICAgIGZvcm1SZWNvcmQuY29udHJvbHNbJ2NvdW50cnknXS5zZXRWYWx1ZShhZGRyZXNzTW9kZWwuY291bnRyeS5faWQpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhT3JVU0EoYWRkcmVzc01vZGVsLmNvdW50cnkuX2lkKSkge1xyXG4gICAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1sncHJvdlN0YXRlJ10uc2V0VmFsdWUoYWRkcmVzc01vZGVsLnByb3ZpbmNlX2xvdi5faWQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBmb3JtUmVjb3JkLmNvbnRyb2xzWydwcm92VGV4dCddLnNldFZhbHVlKGFkZHJlc3NNb2RlbC5wcm92aW5jZV90ZXh0KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9ybVJlY29yZC5jb250cm9sc1snY291bnRyeSddLnNldFZhbHVlKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgc2V0UHJvdmluY2VTdGF0ZShyZWNvcmQ6IEZvcm1Hcm91cCwgY291bnRyeUlkOiBzdHJpbmcsIHByb3ZpbmNlTGlzdDogSUNvZGVbXSwgc3RhdGVMaXN0OiBJQ29kZVtdKTogSUNvZGVbXSB7XHJcblxyXG4gICAgbGV0IGxpc3RUb1JldHVybjogSUNvZGVbXSA9IFtdO1xyXG5cclxuICAgIGlmICh0aGlzLl91dGlsc1NlcnZpY2UuaXNDYW5hZGFPclVTQShjb3VudHJ5SWQpKSB7XHJcblxyXG4gICAgICB0aGlzLl91dGlsc1NlcnZpY2UucmVzZXRDb250cm9sc1ZhbHVlcyhyZWNvcmQuY29udHJvbHNbJ3Byb3ZUZXh0J10pXHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWxpZGF0b3JzKFtWYWxpZGF0b3JzLnJlcXVpcmVkXSk7XHJcblxyXG4gICAgICBpZiAodGhpcy5fdXRpbHNTZXJ2aWNlLmlzQ2FuYWRhKGNvdW50cnlJZCkpIHtcclxuICAgICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLmNhbmFkYVBvc3RhbFZhbGlkYXRvcl0pO1xyXG4gICAgICAgIGxpc3RUb1JldHVybiA9IHByb3ZpbmNlTGlzdDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRpb25TZXJ2aWNlLnVzYVBvc3RhbFZhbGlkYXRvcl0pO1xyXG4gICAgICAgIGxpc3RUb1JldHVybiA9IHN0YXRlTGlzdDtcclxuICAgICAgfVxyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10uc2V0VmFsaWRhdG9ycyhbXSk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncHJvdkxpc3QnXS5zZXRWYWx1ZSgnJyk7XHJcbiAgICAgIHJlY29yZC5jb250cm9sc1sncG9zdGFsJ10uc2V0VmFsaWRhdG9ycyhbVmFsaWRhdG9ycy5yZXF1aXJlZF0pO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Byb3ZMaXN0J10udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xyXG4gICAgICByZWNvcmQuY29udHJvbHNbJ3Bvc3RhbCddLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gbGlzdFRvUmV0dXJuO1xyXG4gIH1cclxuICBcclxufSJdfQ==