import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressDetailsComponent } from './address.details/address.details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';
import { ErrorModule } from '@hpfb/sdk/ui';
import { PipesModule } from '@hpfb/sdk/ui';
import { NumbersOnlyDirective } from '@hpfb/sdk/ui';
import { TranslateModule } from '@ngx-translate/core';
import { AddressDetailsService } from './address.details/address.details.service';
import * as i0 from "@angular/core";
export class AddressModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, declarations: [AddressDetailsComponent], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            ErrorModule,
            PipesModule,
            TranslateModule,
            NumbersOnlyDirective], exports: [AddressDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, providers: [AddressDetailsService], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            ErrorModule,
            PipesModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        ReactiveFormsModule,
                        FormsModule,
                        ErrorModule,
                        PipesModule,
                        TranslateModule,
                        NumbersOnlyDirective
                    ],
                    declarations: [AddressDetailsComponent],
                    exports: [AddressDetailsComponent],
                    providers: [AddressDetailsService],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUN0RixPQUFPLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDbEUsNkRBQTZEO0FBQzdELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDM0MsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUMzQyxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDcEQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDJDQUEyQyxDQUFDOztBQWlCbEYsTUFBTSxPQUFPLGFBQWE7K0dBQWIsYUFBYTtnSEFBYixhQUFhLGlCQUpULHVCQUF1QixhQVRwQyxZQUFZO1lBQ1osaUJBQWlCO1lBQ2pCLG1CQUFtQjtZQUNuQixXQUFXO1lBQ1gsV0FBVztZQUNYLFdBQVc7WUFDWCxlQUFlO1lBQ2Ysb0JBQW9CLGFBR1osdUJBQXVCO2dIQUd0QixhQUFhLGFBRmIsQ0FBQyxxQkFBcUIsQ0FBQyxZQVhoQyxZQUFZO1lBQ1osaUJBQWlCO1lBQ2pCLG1CQUFtQjtZQUNuQixXQUFXO1lBQ1gsV0FBVztZQUNYLFdBQVc7WUFDWCxlQUFlOzs0RkFPTixhQUFhO2tCQWZ6QixRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRTt3QkFDUCxZQUFZO3dCQUNaLGlCQUFpQjt3QkFDakIsbUJBQW1CO3dCQUNuQixXQUFXO3dCQUNYLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLG9CQUFvQjtxQkFDckI7b0JBQ0QsWUFBWSxFQUFFLENBQUMsdUJBQXVCLENBQUM7b0JBQ3ZDLE9BQU8sRUFBRSxDQUFDLHVCQUF1QixDQUFDO29CQUNsQyxTQUFTLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQztpQkFDbkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBBZGRyZXNzRGV0YWlsc0NvbXBvbmVudCB9IGZyb20gJy4vYWRkcmVzcy5kZXRhaWxzL2FkZHJlc3MuZGV0YWlscy5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuLy8gaW1wb3J0IHsgQnJvd3Nlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5pbXBvcnQgeyBFcnJvck1vZHVsZSB9IGZyb20gJ0BocGZiL3Nkay91aSc7XHJcbmltcG9ydCB7IFBpcGVzTW9kdWxlIH0gZnJvbSAnQGhwZmIvc2RrL3VpJztcclxuaW1wb3J0IHsgTnVtYmVyc09ubHlEaXJlY3RpdmUgfSBmcm9tICdAaHBmYi9zZGsvdWknO1xyXG5pbXBvcnQgeyBUcmFuc2xhdGVNb2R1bGUgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcclxuaW1wb3J0IHsgQWRkcmVzc0RldGFpbHNTZXJ2aWNlIH0gZnJvbSAnLi9hZGRyZXNzLmRldGFpbHMvYWRkcmVzcy5kZXRhaWxzLnNlcnZpY2UnO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgICBDb21tb25Nb2R1bGUsXHJcbiAgICAvLyBCcm93c2VyTW9kdWxlLFxyXG4gICAgUmVhY3RpdmVGb3Jtc01vZHVsZSxcclxuICAgIEZvcm1zTW9kdWxlLFxyXG4gICAgRXJyb3JNb2R1bGUsXHJcbiAgICBQaXBlc01vZHVsZSxcclxuICAgIFRyYW5zbGF0ZU1vZHVsZSxcclxuICAgIE51bWJlcnNPbmx5RGlyZWN0aXZlXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtBZGRyZXNzRGV0YWlsc0NvbXBvbmVudF0sXHJcbiAgZXhwb3J0czogW0FkZHJlc3NEZXRhaWxzQ29tcG9uZW50XSxcclxuICBwcm92aWRlcnM6IFtBZGRyZXNzRGV0YWlsc1NlcnZpY2VdLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgQWRkcmVzc01vZHVsZSB7fSJdfQ==