import { Injectable } from "@angular/core";
import * as i0 from "@angular/core";
export class EntityBasePbvService {
    getEmptyAddressDetailsModel() {
        return ({
            street_address: '',
            city: '',
            country: undefined,
            province_lov: undefined,
            province_text: '',
            postal_code: ''
        });
    }
    getEmptyContactModel() {
        return ({
            given_name: '',
            initials: '',
            surname: '',
            language_correspondance: undefined,
            job_title: '',
            phone_num: '',
            phone_ext: '',
            fax_num: '',
            email: ''
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBasePbvService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBasePbvService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBasePbvService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW50aXR5LWJhc2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvcGJ2L3NyYy9tb2RlbC9lbnRpdHktYmFzZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBTTNDLE1BQU0sT0FBTyxvQkFBb0I7SUFFMUIsMkJBQTJCO1FBRTlCLE9BQU8sQ0FDTDtZQUNDLGNBQWMsRUFBRSxFQUFFO1lBQ2xCLElBQUksRUFBRSxFQUFFO1lBQ1IsT0FBTyxFQUFFLFNBQVM7WUFDbEIsWUFBWSxFQUFFLFNBQVM7WUFDdkIsYUFBYSxFQUFFLEVBQUU7WUFDakIsV0FBVyxFQUFFLEVBQUU7U0FDZixDQUNGLENBQUM7SUFDSixDQUFDO0lBRU0sb0JBQW9CO1FBRXpCLE9BQU8sQ0FDTDtZQUNFLFVBQVUsRUFBRSxFQUFFO1lBQ2QsUUFBUSxFQUFDLEVBQUU7WUFDWCxPQUFPLEVBQUUsRUFBRTtZQUNYLHVCQUF1QixFQUFFLFNBQVM7WUFDbEMsU0FBUyxFQUFFLEVBQUU7WUFDYixTQUFTLEVBQUUsRUFBRTtZQUNiLFNBQVMsRUFBRSxFQUFFO1lBQ2IsT0FBTyxFQUFFLEVBQUU7WUFDWCxLQUFLLEVBQUUsRUFBRTtTQUNWLENBQ0YsQ0FBQztJQUNKLENBQUM7K0dBL0JVLG9CQUFvQjttSEFBcEIsb0JBQW9COzs0RkFBcEIsb0JBQW9CO2tCQURoQyxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IElDb250YWN0LCBJTmFtZUFkZHJlc3MgfSBmcm9tIFwiLi9lbnRpdHktYmFzZVwiO1xyXG5cclxuXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBFbnRpdHlCYXNlUGJ2U2VydmljZSB7XHJcblxyXG5wdWJsaWMgZ2V0RW1wdHlBZGRyZXNzRGV0YWlsc01vZGVsKCkgOiBJTmFtZUFkZHJlc3N7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAge1xyXG5cdCAgICAgIHN0cmVldF9hZGRyZXNzOiAnJyxcclxuXHQgICAgICBjaXR5OiAnJyxcclxuXHQgICAgICBjb3VudHJ5OiB1bmRlZmluZWQsXHJcblx0ICAgICAgcHJvdmluY2VfbG92OiB1bmRlZmluZWQsXHJcblx0ICAgICAgcHJvdmluY2VfdGV4dDogJycsXHJcblx0ICAgICAgcG9zdGFsX2NvZGU6ICcnXHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZ2V0RW1wdHlDb250YWN0TW9kZWwoKSA6IElDb250YWN0e1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIHtcclxuICAgICAgICBnaXZlbl9uYW1lOiAnJyxcclxuICAgICAgICBpbml0aWFsczonJyxcclxuICAgICAgICBzdXJuYW1lOiAnJyxcclxuICAgICAgICBsYW5ndWFnZV9jb3JyZXNwb25kYW5jZTogdW5kZWZpbmVkLFxyXG4gICAgICAgIGpvYl90aXRsZTogJycsXHJcbiAgICAgICAgcGhvbmVfbnVtOiAnJyxcclxuICAgICAgICBwaG9uZV9leHQ6ICcnLFxyXG4gICAgICAgIGZheF9udW06ICcnLFxyXG4gICAgICAgIGVtYWlsOiAnJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gIH1cclxufSJdfQ==