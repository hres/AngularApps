import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class PbvValidationService {
    constructor() { }
    getValidatorErrorMessage(validatorName) {
        const config = {
            'error.mgs.pbv.dossier.id': 'error.mgs.dossier.id',
        };
        return config[validatorName];
    }
    static pharmabioDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[a-z]{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PbvValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PbvValidationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PbvValidationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGJ2LnZhbGlkYXRpb24uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvcGJ2L3NyYy92YWxpZGF0aW9uL3Bidi52YWxpZGF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLG9CQUFvQjtJQUUvQixnQkFBZ0IsQ0FBQztJQUVqQix3QkFBd0IsQ0FBQyxhQUFxQjtRQUM1QyxNQUFNLE1BQU0sR0FBRztZQUNiLDBCQUEwQixFQUFFLHNCQUFzQjtTQUNuRCxDQUFDO1FBRUYsT0FBTyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxPQUFPO1FBQ3hDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUM7WUFDOUMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQywwQkFBMEIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUM1QyxDQUFDO0lBQ0gsQ0FBQzsrR0FyQlUsb0JBQW9CO21IQUFwQixvQkFBb0IsY0FGbkIsTUFBTTs7NEZBRVAsb0JBQW9CO2tCQUhoQyxVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFBidlZhbGlkYXRpb25TZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgZ2V0VmFsaWRhdG9yRXJyb3JNZXNzYWdlKHZhbGlkYXRvck5hbWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgICAnZXJyb3IubWdzLnBidi5kb3NzaWVyLmlkJzogJ2Vycm9yLm1ncy5kb3NzaWVyLmlkJyxcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIGNvbmZpZ1t2YWxpZGF0b3JOYW1lXTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBwaGFybWFiaW9Eb3NzaWVySWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bYS16XXsxfVswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLnBidi5kb3NzaWVyLmlkJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ==