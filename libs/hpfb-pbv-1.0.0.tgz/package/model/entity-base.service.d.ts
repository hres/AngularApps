import { IContact, INameAddress } from "./entity-base";
import * as i0 from "@angular/core";
export declare class EntityBaseService {
    getEmptyAddressDetailsModel(): INameAddress;
    getEmptyContactModel(): IContact;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityBaseService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntityBaseService>;
}
