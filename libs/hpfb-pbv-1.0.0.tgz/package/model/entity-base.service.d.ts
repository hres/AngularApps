import { IContact, INameAddress } from "./entity-base";
import * as i0 from "@angular/core";
export declare class EntityBasePbvService {
    getEmptyAddressDetailsModel(): INameAddress;
    getEmptyContactModel(): IContact;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityBasePbvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntityBasePbvService>;
}
