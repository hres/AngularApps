import * as i0 from "@angular/core";
export declare class PrivacyStatementComponent {
    lang: any;
    purposeOfCollection?: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrivacyStatementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PrivacyStatementComponent, "pb-lib-privacy-statement", never, { "lang": { "alias": "lang"; "required": false; }; "purposeOfCollection": { "alias": "purposeOfCollection"; "required": false; }; }, {}, never, never, true, never>;
}
