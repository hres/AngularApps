import * as i0 from "@angular/core";
import * as i1 from "./contact.details/contact.details.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@hpfb/sdk/ui";
export declare class ContactModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ContactModule, [typeof i1.ContactDetailsComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule, typeof i4.TranslateModule, typeof i5.ErrorModule, typeof i5.PipesModule, typeof i5.ExpanderModule, typeof i5.NumbersOnlyDirective, typeof i5.PopupComponent], [typeof i1.ContactDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ContactModule>;
}
