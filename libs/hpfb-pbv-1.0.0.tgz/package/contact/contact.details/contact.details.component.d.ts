import { EventEmitter, OnInit, SimpleChanges } from '@angular/core';
import { BaseComponent, UtilsService } from '@hpfb/sdk/ui';
import { IContact } from '../../model/entity-base';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ContactDetailsService } from './contact.details.service';
import * as i0 from "@angular/core";
export declare class ContactDetailsComponent extends BaseComponent implements OnInit {
    private _contactDetailsService;
    private _fb;
    private _utilsService;
    showFieldErrors: boolean;
    contactDetailsForm: FormGroup;
    showErrors: boolean;
    contactDetailsModel: IContact;
    lang: any;
    languageList: any;
    contactType: any;
    contactGroupLabelKey: any;
    errorList: EventEmitter<any>;
    constructor(_contactDetailsService: ContactDetailsService, _fb: FormBuilder, _utilsService: UtilsService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    protected emitErrors(errors: any[]): void;
    getFormValue(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContactDetailsComponent, "pbv-contact-details", never, { "showErrors": { "alias": "showErrors"; "required": false; }; "contactDetailsModel": { "alias": "contactDetailsModel"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "languageList": { "alias": "languageList"; "required": false; }; "contactType": { "alias": "contactType"; "required": false; }; "contactGroupLabelKey": { "alias": "contactGroupLabelKey"; "required": false; }; }, { "errorList": "errorList"; }, never, never, false, never>;
}
