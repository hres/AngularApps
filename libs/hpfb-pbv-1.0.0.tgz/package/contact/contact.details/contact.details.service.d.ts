import { FormBuilder, FormGroup } from '@angular/forms';
import { ConverterService, UtilsService } from '@hpfb/sdk/ui';
import { IContact } from '../../model/entity-base';
import * as i0 from "@angular/core";
export declare class ContactDetailsService {
    private _utilsService;
    private _converterService;
    constructor(_utilsService: UtilsService, _converterService: ConverterService);
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb: FormBuilder): FormGroup<{
        firstName: import("@angular/forms").FormControl<null>;
        initials: import("@angular/forms").FormControl<any>;
        lastName: import("@angular/forms").FormControl<null>;
        language: import("@angular/forms").FormControl<null>;
        jobTitle: import("@angular/forms").FormControl<null>;
        faxNumber: import("@angular/forms").FormControl<string>;
        phoneNumber: import("@angular/forms").FormControl<string>;
        phoneExtension: import("@angular/forms").FormControl<string>;
        email: import("@angular/forms").FormControl<null>;
    }>;
    mapFormModelToDataModel(formValue: any, contactModel: IContact, lang: any, languageList: any): void;
    mapDataModelToFormModel(contactModel: IContact, formRecord: FormGroup): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContactDetailsService>;
}
