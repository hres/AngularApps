import * as i0 from '@angular/core';
import { Injectable, Component, Input } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class PbvService {
    constructor() { }
    static pharmabioDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[a-z]{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PbvService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PbvService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PbvService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class PbvComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PbvComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.11", type: PbvComponent, isStandalone: true, selector: "pb-lib-pbv", ngImport: i0, template: `
    <p>
      pbv works!
    </p>
  `, isInline: true, styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PbvComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pb-lib-pbv', standalone: true, imports: [], template: `
    <p>
      pbv works!
    </p>
  ` }]
        }] });

class PrivacyStatementComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PrivacyStatementComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.11", type: PrivacyStatementComponent, isStandalone: true, selector: "pb-lib-privacy-statement", inputs: { lang: "lang" }, ngImport: i0, template: "<div *ngIf=\"lang === 'en'\">\r\n    <p>\r\n        The personal information that you provide is protected and governed in accordance with the Privacy Act. We\r\n        only collect\r\n        personal information required to administer the Canadian drug registration process. The personal information\r\n        is\r\n        collected under the authority of the Food and Drugs Act and the Food and Drug Regulations.\r\n    </p>\r\n    <p>\r\n        <b>Purpose of collection</b>: \r\n            Health Canada requires the personal information to process regulatory application forms related to human and veterinary \r\n            drug products under the Regulatory Enrolment Process (REP) within the Canadian drug registration framework. The information \r\n            you provide may be used to contact you to verify provided information, to assess the feasibility of enrolling companies, \r\n            dossiers, and track regulatory activities and transactions.\r\n    </p>\r\n    \r\n    <p>\r\n        <b>For more information</b>: The class of records are described under HC HP 005 on <a\r\n            href=\"https://www.canada.ca/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html\">Info\r\n            Source website</a>.\r\n        The personal information bank for this collection is currently under development.\r\n    </p>\r\n    <p>\r\n        <b>Your rights under the Privacy Act</b>: In addition to protecting your personal information, the Privacy Act\r\n        gives you the right to request access to and\r\n        correct your personal information. You also have the right to file a complaint to the Office of the Privacy\r\n        Commissioner\r\n        if you think your personal information has been handled improperly.\r\n    </p>\r\n    <p>\r\n        For more information about the program, please contact <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>\r\n<div *ngIf=\"lang === 'fr'\">\r\n    <p>\r\n        Les renseignements que vous fournissez \u00E0 Sant\u00E9 Canada sont prot\u00E9g\u00E9s et r\u00E9gis par la Loi sur la protection des\r\n        renseignements personnels. Sant\u00E9 Canada ne recueille que les renseignements personnels n\u00E9cessaires \u00E0\r\n        l'administration du\r\n        processus d'homologation des m\u00E9dicaments. Ces renseignements sont recueillis en vertu de la Loi sur les aliments\r\n        et\r\n        drogues et du R\u00E8glement sur les aliments et drogues.\r\n    </p>\r\n    <p>\r\n        <b>But de la collecte </b>:\r\n            Sant\u00E9 Canada a besoin des renseignements personnels pour traiter les formulaires \r\n            de demande r\u00E9glementaire li\u00E9s aux m\u00E9dicaments \u00E0 usage humain et v\u00E9t\u00E9rinaire dans le cadre du processus \r\n            d'inscription r\u00E9glementaire (PIR) dans le cadre canadien d'enregistrement des m\u00E9dicaments. Les informations \r\n            que vous fournissez peuvent \u00EAtre utilis\u00E9es pour vous contacter afin de v\u00E9rifier les informations fournies, \r\n            d'\u00E9valuer la faisabilit\u00E9 de l'inscription d'entreprises, de dossiers et de suivre les activit\u00E9s et transactions \r\n            r\u00E9glementaires.\r\n    </p>\r\n    <p>\r\n        <b>Pour de plus amples renseignements </b>: La cat\u00E9gorie de documents est d\u00E9crite sous HC HP 005 sur le site web\r\n        d'<a\r\n            href=\"https://www.canada.ca/fr/sante-canada/organisation/a-propos-sante-canada/activites-responsabilites/acces-information-protection-renseignements-personnels/info-source-renseignements-gouvernement-federal-fonctionnaires-federaux.html\">\r\n            Info Source</a>.\r\n        La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n    </p>\r\n    <p>\r\n        <b>Vos droits en vertu de la Loi sur la protection des renseignements personnels </b>: En plus de prot\u00E9ger vos\r\n        renseignements personnels, la Loi sur la protection des renseignements personnels vous donne le\r\n        droit de demander l'acc\u00E8s \u00E0 vos renseignements personnels et de les faire corriger. Vous avez \u00E9galement le droit\r\n        de\r\n        d\u00E9poser une plainte aupr\u00E8s du Commissariat \u00E0 la protection de la vie priv\u00E9e si vous estimez que vos\r\n        renseignements\r\n        personnels ont \u00E9t\u00E9 trait\u00E9s de fa\u00E7on inappropri\u00E9e.\r\n    </p>\r\n    <p>\r\n        Pour obtenir de plus amples renseignements sur le programme, veuillez nous \u00E9crire \u00E0 <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.11", ngImport: i0, type: PrivacyStatementComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pb-lib-privacy-statement', standalone: true, imports: [CommonModule], template: "<div *ngIf=\"lang === 'en'\">\r\n    <p>\r\n        The personal information that you provide is protected and governed in accordance with the Privacy Act. We\r\n        only collect\r\n        personal information required to administer the Canadian drug registration process. The personal information\r\n        is\r\n        collected under the authority of the Food and Drugs Act and the Food and Drug Regulations.\r\n    </p>\r\n    <p>\r\n        <b>Purpose of collection</b>: \r\n            Health Canada requires the personal information to process regulatory application forms related to human and veterinary \r\n            drug products under the Regulatory Enrolment Process (REP) within the Canadian drug registration framework. The information \r\n            you provide may be used to contact you to verify provided information, to assess the feasibility of enrolling companies, \r\n            dossiers, and track regulatory activities and transactions.\r\n    </p>\r\n    \r\n    <p>\r\n        <b>For more information</b>: The class of records are described under HC HP 005 on <a\r\n            href=\"https://www.canada.ca/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html\">Info\r\n            Source website</a>.\r\n        The personal information bank for this collection is currently under development.\r\n    </p>\r\n    <p>\r\n        <b>Your rights under the Privacy Act</b>: In addition to protecting your personal information, the Privacy Act\r\n        gives you the right to request access to and\r\n        correct your personal information. You also have the right to file a complaint to the Office of the Privacy\r\n        Commissioner\r\n        if you think your personal information has been handled improperly.\r\n    </p>\r\n    <p>\r\n        For more information about the program, please contact <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>\r\n<div *ngIf=\"lang === 'fr'\">\r\n    <p>\r\n        Les renseignements que vous fournissez \u00E0 Sant\u00E9 Canada sont prot\u00E9g\u00E9s et r\u00E9gis par la Loi sur la protection des\r\n        renseignements personnels. Sant\u00E9 Canada ne recueille que les renseignements personnels n\u00E9cessaires \u00E0\r\n        l'administration du\r\n        processus d'homologation des m\u00E9dicaments. Ces renseignements sont recueillis en vertu de la Loi sur les aliments\r\n        et\r\n        drogues et du R\u00E8glement sur les aliments et drogues.\r\n    </p>\r\n    <p>\r\n        <b>But de la collecte </b>:\r\n            Sant\u00E9 Canada a besoin des renseignements personnels pour traiter les formulaires \r\n            de demande r\u00E9glementaire li\u00E9s aux m\u00E9dicaments \u00E0 usage humain et v\u00E9t\u00E9rinaire dans le cadre du processus \r\n            d'inscription r\u00E9glementaire (PIR) dans le cadre canadien d'enregistrement des m\u00E9dicaments. Les informations \r\n            que vous fournissez peuvent \u00EAtre utilis\u00E9es pour vous contacter afin de v\u00E9rifier les informations fournies, \r\n            d'\u00E9valuer la faisabilit\u00E9 de l'inscription d'entreprises, de dossiers et de suivre les activit\u00E9s et transactions \r\n            r\u00E9glementaires.\r\n    </p>\r\n    <p>\r\n        <b>Pour de plus amples renseignements </b>: La cat\u00E9gorie de documents est d\u00E9crite sous HC HP 005 sur le site web\r\n        d'<a\r\n            href=\"https://www.canada.ca/fr/sante-canada/organisation/a-propos-sante-canada/activites-responsabilites/acces-information-protection-renseignements-personnels/info-source-renseignements-gouvernement-federal-fonctionnaires-federaux.html\">\r\n            Info Source</a>.\r\n        La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n    </p>\r\n    <p>\r\n        <b>Vos droits en vertu de la Loi sur la protection des renseignements personnels </b>: En plus de prot\u00E9ger vos\r\n        renseignements personnels, la Loi sur la protection des renseignements personnels vous donne le\r\n        droit de demander l'acc\u00E8s \u00E0 vos renseignements personnels et de les faire corriger. Vous avez \u00E9galement le droit\r\n        de\r\n        d\u00E9poser une plainte aupr\u00E8s du Commissariat \u00E0 la protection de la vie priv\u00E9e si vous estimez que vos\r\n        renseignements\r\n        personnels ont \u00E9t\u00E9 trait\u00E9s de fa\u00E7on inappropri\u00E9e.\r\n    </p>\r\n    <p>\r\n        Pour obtenir de plus amples renseignements sur le programme, veuillez nous \u00E9crire \u00E0 <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>" }]
        }], propDecorators: { lang: [{
                type: Input
            }] } });

/*
 * Public API Surface of pbv
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PbvComponent, PbvService, PrivacyStatementComponent };
//# sourceMappingURL=hpfb-pbv.mjs.map
