import * as i0 from "@angular/core";
export declare class PbvService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PbvService>;
}
