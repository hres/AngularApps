import * as i0 from "@angular/core";
export declare class PbvService {
    constructor();
    static pharmabioDossierIdValidator(control: any): {
        'error.mgs.dossier.id': boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PbvService>;
}
