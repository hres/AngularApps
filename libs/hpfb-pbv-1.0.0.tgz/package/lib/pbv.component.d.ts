import * as i0 from "@angular/core";
export declare class PbvComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PbvComponent, "pb-lib-pbv", never, {}, {}, never, never, true, never>;
}
