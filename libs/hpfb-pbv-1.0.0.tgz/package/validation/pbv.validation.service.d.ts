import * as i0 from "@angular/core";
export declare class PbvValidationService {
    constructor();
    getValidatorErrorMessage(validatorName: string): string | null;
    static pharmabioDossierIdValidator(control: any): {
        'error.mgs.pbv.dossier.id': boolean;
    };
    static vetDossierIdValidator(control: any): {
        'error.mgs.pbv.dossier.id': boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PbvValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PbvValidationService>;
}
