import * as i0 from '@angular/core';

declare class PrivacyStatementComponent {
    lang: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrivacyStatementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PrivacyStatementComponent, "md-lib-privacy-statement", never, { "lang": { "alias": "lang"; "required": false; }; }, {}, never, never, true, never>;
}

export { PrivacyStatementComponent };
