import { OnInit, SimpleChanges, OnChanges, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AddressDetailsService } from './address.details.service';
import { BaseComponent, ICode, UtilsService } from '@hpfb/sdk/ui';
import * as i0 from "@angular/core";
export declare class AddressDetailsComponent extends BaseComponent implements OnInit, OnChanges {
    private _fb;
    private cdr;
    private _detailsService;
    private _utilsService;
    showErrors: boolean;
    addressModel: any;
    lang: any;
    countryList: any;
    provinceList: any;
    stateList: any;
    canadaDefault: boolean;
    formGroup?: FormGroup;
    addrType: any;
    addrGroupLabelKey: any;
    errorList: EventEmitter<any>;
    addressForm: FormGroup;
    showFieldErrors: boolean;
    constructor(_fb: FormBuilder, cdr: ChangeDetectorRef, _detailsService: AddressDetailsService, _utilsService: UtilsService);
    ngOnInit(): void;
    protected emitErrors(errors: any[]): void;
    ngOnChanges(changes: SimpleChanges): void;
    onCountryChange(e: any): void;
    getFormValue(): any;
    private _resetControlValues;
    isCanadaOrUSA(): boolean;
    isCanada(): boolean;
    isUsa(): boolean;
    getCountryValue(): any;
    /**
     * Reactive funtion to return the provStateList based on selected country
     *
     * @returns ICode[] of either states or provinces or empty if neither Canada or USA is selected
     */
    provStateList(): ICode[];
    /**
     * Reactive function to return province label if country is Canada or USA
     * @returns Either "Province" or "State"
     */
    provinceLabel(): string;
    /**
     * Reactive function to return postal code label if country is Canada/USA/neither
     * @returns Either "Postal code"/"ZIP code"/"Postal/ZIP code"
     */
    postalLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddressDetailsComponent, "pbv-address-details", never, { "showErrors": { "alias": "showErrors"; "required": false; }; "addressModel": { "alias": "addressModel"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "countryList": { "alias": "countryList"; "required": false; }; "provinceList": { "alias": "provinceList"; "required": false; }; "stateList": { "alias": "stateList"; "required": false; }; "canadaDefault": { "alias": "canadaDefault"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "addrType": { "alias": "addrType"; "required": false; }; "addrGroupLabelKey": { "alias": "addrGroupLabelKey"; "required": false; }; }, { "errorList": "errorList"; }, never, never, false, never>;
}
