import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressDetailsComponent } from './address.details/address.details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';
import { ErrorModule } from '@hpfb/sdk/ui';
import { PipesModule } from '@hpfb/sdk/ui';
import { NumbersOnlyDirective, NumbersLettersDirective } from '@hpfb/sdk/ui';
import { TranslateModule } from '@ngx-translate/core';
import { AddressDetailsService } from './address.details/address.details.service';
import * as i0 from "@angular/core";
export class AddressModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, declarations: [AddressDetailsComponent], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            ErrorModule,
            PipesModule,
            TranslateModule,
            NumbersOnlyDirective,
            NumbersLettersDirective], exports: [AddressDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, providers: [AddressDetailsService], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            ErrorModule,
            PipesModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AddressModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        ReactiveFormsModule,
                        FormsModule,
                        ErrorModule,
                        PipesModule,
                        TranslateModule,
                        NumbersOnlyDirective,
                        NumbersLettersDirective
                    ],
                    declarations: [AddressDetailsComponent],
                    exports: [AddressDetailsComponent],
                    providers: [AddressDetailsService],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkcmVzcy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Bidi9zcmMvYWRkcmVzcy9hZGRyZXNzLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUN0RixPQUFPLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDbEUsNkRBQTZEO0FBQzdELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDM0MsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUMzQyxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDN0UsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDJDQUEyQyxDQUFDOztBQWtCbEYsTUFBTSxPQUFPLGFBQWE7K0dBQWIsYUFBYTtnSEFBYixhQUFhLGlCQUpULHVCQUF1QixhQVZwQyxZQUFZO1lBQ1osaUJBQWlCO1lBQ2pCLG1CQUFtQjtZQUNuQixXQUFXO1lBQ1gsV0FBVztZQUNYLFdBQVc7WUFDWCxlQUFlO1lBQ2Ysb0JBQW9CO1lBQ3BCLHVCQUF1QixhQUdmLHVCQUF1QjtnSEFHdEIsYUFBYSxhQUZiLENBQUMscUJBQXFCLENBQUMsWUFaaEMsWUFBWTtZQUNaLGlCQUFpQjtZQUNqQixtQkFBbUI7WUFDbkIsV0FBVztZQUNYLFdBQVc7WUFDWCxXQUFXO1lBQ1gsZUFBZTs7NEZBUU4sYUFBYTtrQkFoQnpCLFFBQVE7bUJBQUM7b0JBQ1IsT0FBTyxFQUFFO3dCQUNQLFlBQVk7d0JBQ1osaUJBQWlCO3dCQUNqQixtQkFBbUI7d0JBQ25CLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCxXQUFXO3dCQUNYLGVBQWU7d0JBQ2Ysb0JBQW9CO3dCQUNwQix1QkFBdUI7cUJBQ3hCO29CQUNELFlBQVksRUFBRSxDQUFDLHVCQUF1QixDQUFDO29CQUN2QyxPQUFPLEVBQUUsQ0FBQyx1QkFBdUIsQ0FBQztvQkFDbEMsU0FBUyxFQUFFLENBQUMscUJBQXFCLENBQUM7aUJBQ25DIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgQWRkcmVzc0RldGFpbHNDb21wb25lbnQgfSBmcm9tICcuL2FkZHJlc3MuZGV0YWlscy9hZGRyZXNzLmRldGFpbHMuY29tcG9uZW50JztcclxuaW1wb3J0IHsgRm9ybXNNb2R1bGUsIFJlYWN0aXZlRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbi8vIGltcG9ydCB7IEJyb3dzZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuaW1wb3J0IHsgRXJyb3JNb2R1bGUgfSBmcm9tICdAaHBmYi9zZGsvdWknO1xyXG5pbXBvcnQgeyBQaXBlc01vZHVsZSB9IGZyb20gJ0BocGZiL3Nkay91aSc7XHJcbmltcG9ydCB7IE51bWJlcnNPbmx5RGlyZWN0aXZlLCBOdW1iZXJzTGV0dGVyc0RpcmVjdGl2ZSB9IGZyb20gJ0BocGZiL3Nkay91aSc7XHJcbmltcG9ydCB7IFRyYW5zbGF0ZU1vZHVsZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xyXG5pbXBvcnQgeyBBZGRyZXNzRGV0YWlsc1NlcnZpY2UgfSBmcm9tICcuL2FkZHJlc3MuZGV0YWlscy9hZGRyZXNzLmRldGFpbHMuc2VydmljZSc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGltcG9ydHM6IFtcclxuICAgIENvbW1vbk1vZHVsZSxcclxuICAgIC8vIEJyb3dzZXJNb2R1bGUsXHJcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gICAgRm9ybXNNb2R1bGUsXHJcbiAgICBFcnJvck1vZHVsZSxcclxuICAgIFBpcGVzTW9kdWxlLFxyXG4gICAgVHJhbnNsYXRlTW9kdWxlLFxyXG4gICAgTnVtYmVyc09ubHlEaXJlY3RpdmUsXHJcbiAgICBOdW1iZXJzTGV0dGVyc0RpcmVjdGl2ZVxyXG4gIF0sXHJcbiAgZGVjbGFyYXRpb25zOiBbQWRkcmVzc0RldGFpbHNDb21wb25lbnRdLFxyXG4gIGV4cG9ydHM6IFtBZGRyZXNzRGV0YWlsc0NvbXBvbmVudF0sXHJcbiAgcHJvdmlkZXJzOiBbQWRkcmVzc0RldGFpbHNTZXJ2aWNlXSxcclxufSlcclxuZXhwb3J0IGNsYXNzIEFkZHJlc3NNb2R1bGUge30iXX0=