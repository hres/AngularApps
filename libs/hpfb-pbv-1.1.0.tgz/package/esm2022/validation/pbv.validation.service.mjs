import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class PbvValidationService {
    constructor() { }
    getValidatorErrorMessage(validatorName) {
        const config = {
            'error.mgs.pbv.dossier.id': 'error.mgs.dossier.id',
            'error.msg.roleSelected': 'error.msg.roleSelected',
            'error.msg.business': 'error.msg.business',
        };
        return config[validatorName];
    }
    static pharmabioDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^['e','p','d']{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static vetDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^['v']{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static dossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^['e','p','d','v']{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static businessNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{9}$/)) {
            return null;
        }
        else {
            return { 'error.msg.business': true };
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PbvValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PbvValidationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PbvValidationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGJ2LnZhbGlkYXRpb24uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvcGJ2L3NyYy92YWxpZGF0aW9uL3Bidi52YWxpZGF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLG9CQUFvQjtJQUUvQixnQkFBZ0IsQ0FBQztJQUVqQix3QkFBd0IsQ0FBQyxhQUFxQjtRQUM1QyxNQUFNLE1BQU0sR0FBRztZQUNiLDBCQUEwQixFQUFFLHNCQUFzQjtZQUNsRCx3QkFBd0IsRUFBQyx3QkFBd0I7WUFDakQsb0JBQW9CLEVBQUMsb0JBQW9CO1NBQzFDLENBQUM7UUFFRixPQUFPLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQsTUFBTSxDQUFDLDJCQUEyQixDQUFDLE9BQU87UUFDeEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLDRCQUE0QixDQUFDLEVBQUUsQ0FBQztZQUN0RCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDBCQUEwQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzVDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHFCQUFxQixDQUFDLE9BQU87UUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQztZQUM5QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDBCQUEwQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzVDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU87UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxDQUFDLEVBQUUsQ0FBQztZQUMxRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDBCQUEwQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzVDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLG9CQUFvQixDQUFDLE9BQU87UUFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxvQkFBb0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQzsrR0F4RFUsb0JBQW9CO21IQUFwQixvQkFBb0IsY0FGbkIsTUFBTTs7NEZBRVAsb0JBQW9CO2tCQUhoQyxVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFBidlZhbGlkYXRpb25TZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgZ2V0VmFsaWRhdG9yRXJyb3JNZXNzYWdlKHZhbGlkYXRvck5hbWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgICAnZXJyb3IubWdzLnBidi5kb3NzaWVyLmlkJzogJ2Vycm9yLm1ncy5kb3NzaWVyLmlkJyxcclxuICAgICAgJ2Vycm9yLm1zZy5yb2xlU2VsZWN0ZWQnOidlcnJvci5tc2cucm9sZVNlbGVjdGVkJyxcclxuICAgICAgJ2Vycm9yLm1zZy5idXNpbmVzcyc6J2Vycm9yLm1zZy5idXNpbmVzcycsXHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiBjb25maWdbdmFsaWRhdG9yTmFtZV07XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgcGhhcm1hYmlvRG9zc2llcklkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWydlJywncCcsJ2QnXXsxfVswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLnBidi5kb3NzaWVyLmlkJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgdmV0RG9zc2llcklkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWyd2J117MX1bMC05XXs2fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5wYnYuZG9zc2llci5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGRvc3NpZXJJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlsnZScsJ3AnLCdkJywndiddezF9WzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MucGJ2LmRvc3NpZXIuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBidXNpbmVzc051bVZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezl9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLmJ1c2luZXNzJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ==