import * as i0 from '@angular/core';
import { Injectable, NgModule, Component, Input, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import * as i4 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i3 from '@hpfb/sdk/ui';
import { VALIDATION_SERVICES, CANADA, ValidationService, BaseComponent, ErrorModule, PipesModule, NumbersOnlyDirective, NumbersLettersDirective, ExpanderModule, PopupComponent, UtilsService, ConverterService } from '@hpfb/sdk/ui';

class EntityBasePbvService {
    getEmptyAddressDetailsModel() {
        return ({
            street_address: '',
            city: '',
            country: undefined,
            province_lov: undefined,
            province_text: '',
            postal_code: ''
        });
    }
    getEmptyContactModel() {
        return ({
            given_name: '',
            initials: '',
            surname: '',
            language_correspondance: undefined,
            job_title: '',
            phone_num: '',
            phone_ext: '',
            fax_num: '',
            email: ''
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: EntityBasePbvService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: EntityBasePbvService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: EntityBasePbvService, decorators: [{
            type: Injectable
        }] });

class PbvValidationService {
    constructor() { }
    getValidatorErrorMessage(validatorName) {
        const config = {
            'error.mgs.pbv.dossier.id': 'error.mgs.dossier.id',
            'error.msg.roleSelected': 'error.msg.roleSelected',
            'error.msg.business': 'error.msg.business',
        };
        return config[validatorName] ?? validatorName;
    }
    static pharmabioDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^['e','p','d']{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static vetDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^['v']{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static dossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^['e','p','d','v']{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.pbv.dossier.id': true };
        }
    }
    static businessNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{9}$/)) {
            return null;
        }
        else {
            return { 'error.msg.business': true };
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvValidationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvValidationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

// import { BrowserModule } from '@angular/platform-browser';
class CommonPbvModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: CommonPbvModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.18", ngImport: i0, type: CommonPbvModule, imports: [CommonModule,
            // BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            TranslateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: CommonPbvModule, providers: [
            EntityBasePbvService,
            PbvValidationService,
            {
                provide: VALIDATION_SERVICES,
                useExisting: PbvValidationService,
                multi: true
            }
        ], imports: [CommonModule,
            // BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: CommonPbvModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        FormsModule,
                        ReactiveFormsModule,
                        TranslateModule,
                    ],
                    providers: [
                        EntityBasePbvService,
                        PbvValidationService,
                        {
                            provide: VALIDATION_SERVICES,
                            useExisting: PbvValidationService,
                            multi: true
                        }
                    ],
                    exports: [],
                }]
        }] });

class PbvService {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class PbvComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.18", type: PbvComponent, isStandalone: true, selector: "pb-lib-pbv", ngImport: i0, template: `
    <p>
      pbv works!
    </p>
  `, isInline: true, styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PbvComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pb-lib-pbv', imports: [], template: `
    <p>
      pbv works!
    </p>
  ` }]
        }] });

class PrivacyStatementComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PrivacyStatementComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.18", type: PrivacyStatementComponent, isStandalone: true, selector: "pb-lib-privacy-statement", inputs: { lang: "lang" }, ngImport: i0, template: "@if (lang === 'en') {\r\n  <div>\r\n    <p>\r\n      The personal information that you provide is protected and governed in accordance with the Privacy Act. We\r\n      only collect\r\n      personal information required to administer the Canadian medical device licensing process. The personal information\r\n      is\r\n      collected under the authority of the Food and Medical Device Regulations.\r\n    </p>\r\n    <p>\r\n      <b>Purpose of collection</b>:\r\n      Health Canada requires the personal information to process regulatory application forms related to human and veterinary\r\n      drug products under the regulatory enrolment process (REP) within the Canadian medical device licensing framework. The information\r\n      you provide may be used to contact you to verify provided information, to assess the feasibility of enrolling companies,\r\n      dossiers, and track regulatory activities and transactions.\r\n    </p>\r\n    <p>\r\n      <b>For more information</b>: The class of records are described under HC HP 005 on <a\r\n      href=\"https://www.canada.ca/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html\">Info\r\n      Source</a><span aria-hidden=\"true\"><span id=\"openNewWindowPrivacy\"> (opens in new window)</span></span>.\r\n    The personal information bank for this collection is currently under development.\r\n  </p>\r\n  <p>\r\n    <b>Your rights under the Privacy Act</b>: In addition to protecting your personal information, the Privacy Act\r\n    gives you the right to request access to and\r\n    correct your personal information. You also have the right to file a complaint to the Office of the Privacy\r\n    Commissioner\r\n    if you think your personal information has been handled improperly.\r\n  </p>\r\n  <p>\r\n    For more information about the program, please contact <a\r\n  href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n</p>\r\n</div>\r\n}\r\n@if (lang === 'fr') {\r\n  <div>\r\n    <p>\r\n      Les renseignements que vous fournissez \u00E0 Sant\u00E9 Canada sont prot\u00E9g\u00E9s et r\u00E9gis par la Loi sur la protection des\r\n      renseignements personnels. Sant\u00E9 Canada ne recueille que les renseignements personnels n\u00E9cessaires \u00E0\r\n      l'administration du\r\n      processus d'homologation des instruments m\u00E9dicaux. Ces renseignements sont recueillis en vertu de la Loi sur les aliments\r\n      et\r\n      drogues et du R\u00E8glement sur les instruments m\u00E9dicaux.\r\n    </p>\r\n    <p>\r\n      <b>But de la collecte </b>:\r\n      Sant\u00E9 Canada a besoin des renseignements personnels pour traiter les formulaires\r\n      de demande r\u00E9glementaire li\u00E9s aux m\u00E9dicaments \u00E0 usage humain et v\u00E9t\u00E9rinaire dans le cadre du processus\r\n      d'inscription r\u00E9glementaire (PIR) dans le cadre canadien d'homologation des instruments m\u00E9dicaux. Les informations\r\n      que vous fournissez peuvent \u00EAtre utilis\u00E9es pour vous contacter afin de v\u00E9rifier les informations fournies,\r\n      d'\u00E9valuer la faisabilit\u00E9 de l'inscription d'entreprises, de dossiers et de suivre les activit\u00E9s et transactions\r\n      r\u00E9glementaires.\r\n    </p>\r\n    <p>\r\n      <b>Pour plus derenseignements </b>: La cat\u00E9gorie de documents est d\u00E9crite sous HC HP 005 sur <a\r\n      href=\"https://www.canada.ca/fr/sante-canada/organisation/a-propos-sante-canada/activites-responsabilites/acces-information-protection-renseignements-personnels/info-source-renseignements-gouvernement-federal-fonctionnaires-federaux.html\">\r\n      Info Source</a><span aria-hidden=\"true\"><span id=\"openNewWindowPrivacy\"> (s'ouvre dans une nouvelle fen\u00EAtre)</span></span>. La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n    La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n  </p>\r\n  <p>\r\n    <b>Vos droits en vertu de la Loi sur la protection des renseignements personnels </b>: En plus de prot\u00E9ger vos\r\n    renseignements personnels, la Loi sur la protection des renseignements personnels vous donne le\r\n    droit de demander l'acc\u00E8s \u00E0 vos renseignements personnels et de les faire corriger. Vous avez \u00E9galement le droit\r\n    de\r\n    d\u00E9poser une plainte aupr\u00E8s du Commissariat \u00E0 la protection de la vie priv\u00E9e si vous estimez que vos\r\n    renseignements\r\n    personnels ont \u00E9t\u00E9 trait\u00E9s de fa\u00E7on inappropri\u00E9e.\r\n  </p>\r\n  <p>\r\n    Pour obtenir plus de renseignements sur le programme, veuillez nous \u00E9crire \u00E0 <a\r\n  href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n</p>\r\n</div>\r\n}" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: PrivacyStatementComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pb-lib-privacy-statement', imports: [], template: "@if (lang === 'en') {\r\n  <div>\r\n    <p>\r\n      The personal information that you provide is protected and governed in accordance with the Privacy Act. We\r\n      only collect\r\n      personal information required to administer the Canadian medical device licensing process. The personal information\r\n      is\r\n      collected under the authority of the Food and Medical Device Regulations.\r\n    </p>\r\n    <p>\r\n      <b>Purpose of collection</b>:\r\n      Health Canada requires the personal information to process regulatory application forms related to human and veterinary\r\n      drug products under the regulatory enrolment process (REP) within the Canadian medical device licensing framework. The information\r\n      you provide may be used to contact you to verify provided information, to assess the feasibility of enrolling companies,\r\n      dossiers, and track regulatory activities and transactions.\r\n    </p>\r\n    <p>\r\n      <b>For more information</b>: The class of records are described under HC HP 005 on <a\r\n      href=\"https://www.canada.ca/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html\">Info\r\n      Source</a><span aria-hidden=\"true\"><span id=\"openNewWindowPrivacy\"> (opens in new window)</span></span>.\r\n    The personal information bank for this collection is currently under development.\r\n  </p>\r\n  <p>\r\n    <b>Your rights under the Privacy Act</b>: In addition to protecting your personal information, the Privacy Act\r\n    gives you the right to request access to and\r\n    correct your personal information. You also have the right to file a complaint to the Office of the Privacy\r\n    Commissioner\r\n    if you think your personal information has been handled improperly.\r\n  </p>\r\n  <p>\r\n    For more information about the program, please contact <a\r\n  href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n</p>\r\n</div>\r\n}\r\n@if (lang === 'fr') {\r\n  <div>\r\n    <p>\r\n      Les renseignements que vous fournissez \u00E0 Sant\u00E9 Canada sont prot\u00E9g\u00E9s et r\u00E9gis par la Loi sur la protection des\r\n      renseignements personnels. Sant\u00E9 Canada ne recueille que les renseignements personnels n\u00E9cessaires \u00E0\r\n      l'administration du\r\n      processus d'homologation des instruments m\u00E9dicaux. Ces renseignements sont recueillis en vertu de la Loi sur les aliments\r\n      et\r\n      drogues et du R\u00E8glement sur les instruments m\u00E9dicaux.\r\n    </p>\r\n    <p>\r\n      <b>But de la collecte </b>:\r\n      Sant\u00E9 Canada a besoin des renseignements personnels pour traiter les formulaires\r\n      de demande r\u00E9glementaire li\u00E9s aux m\u00E9dicaments \u00E0 usage humain et v\u00E9t\u00E9rinaire dans le cadre du processus\r\n      d'inscription r\u00E9glementaire (PIR) dans le cadre canadien d'homologation des instruments m\u00E9dicaux. Les informations\r\n      que vous fournissez peuvent \u00EAtre utilis\u00E9es pour vous contacter afin de v\u00E9rifier les informations fournies,\r\n      d'\u00E9valuer la faisabilit\u00E9 de l'inscription d'entreprises, de dossiers et de suivre les activit\u00E9s et transactions\r\n      r\u00E9glementaires.\r\n    </p>\r\n    <p>\r\n      <b>Pour plus derenseignements </b>: La cat\u00E9gorie de documents est d\u00E9crite sous HC HP 005 sur <a\r\n      href=\"https://www.canada.ca/fr/sante-canada/organisation/a-propos-sante-canada/activites-responsabilites/acces-information-protection-renseignements-personnels/info-source-renseignements-gouvernement-federal-fonctionnaires-federaux.html\">\r\n      Info Source</a><span aria-hidden=\"true\"><span id=\"openNewWindowPrivacy\"> (s'ouvre dans une nouvelle fen\u00EAtre)</span></span>. La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n    La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n  </p>\r\n  <p>\r\n    <b>Vos droits en vertu de la Loi sur la protection des renseignements personnels </b>: En plus de prot\u00E9ger vos\r\n    renseignements personnels, la Loi sur la protection des renseignements personnels vous donne le\r\n    droit de demander l'acc\u00E8s \u00E0 vos renseignements personnels et de les faire corriger. Vous avez \u00E9galement le droit\r\n    de\r\n    d\u00E9poser une plainte aupr\u00E8s du Commissariat \u00E0 la protection de la vie priv\u00E9e si vous estimez que vos\r\n    renseignements\r\n    personnels ont \u00E9t\u00E9 trait\u00E9s de fa\u00E7on inappropri\u00E9e.\r\n  </p>\r\n  <p>\r\n    Pour obtenir plus de renseignements sur le programme, veuillez nous \u00E9crire \u00E0 <a\r\n  href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n</p>\r\n</div>\r\n}" }]
        }], propDecorators: { lang: [{
                type: Input
            }] } });

class AddressDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        return fb.group({
            address: [null, Validators.required],
            provText: '',
            provState: '',
            city: ['', [Validators.required]],
            country: ['', [Validators.required]],
            postal: ['', [Validators.required]]
        });
    }
    mapFormModelToDataModel(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = formValue['country'] ?
                this._converterService.findAndConverCodeToIdTextLabel(countryList, formValue['country'], lang) : null;
            if (addressModel.country) {
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    addressModel.province_text = '';
                    addressModel.province_lov = formValue['provState'] ?
                        this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
                }
                else {
                    addressModel.province_text = formValue['provText'];
                    addressModel.province_lov = null;
                }
            }
            else {
                addressModel.province_text = formValue['provText'];
            }
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapFormModelToDataModelCanadianAddress(formValue, addressModel, lang, countryList, combinedProvStatList) {
        if (formValue) {
            addressModel.street_address = formValue['address'];
            addressModel.city = formValue['city'];
            addressModel.country = this._converterService.findAndConverCodeToIdTextLabel(countryList, CANADA, lang);
            addressModel.province_text = '';
            addressModel.province_lov = formValue['provState'] ?
                this._converterService.findAndConverCodeToIdTextLabel(combinedProvStatList, formValue['provState'], lang) : null;
            addressModel.postal_code = formValue['postal'];
        }
    }
    mapDataModelToFormModel(addressModel, formRecord) {
        if (addressModel) {
            formRecord.controls['address'].setValue(addressModel.street_address);
            formRecord.controls['city'].setValue(addressModel.city);
            formRecord.controls['postal'].setValue(addressModel.postal_code);
            if (addressModel.country) {
                formRecord.controls['country'].setValue(addressModel.country._id);
                if (this._utilsService.isCanadaOrUSA(addressModel.country._id)) {
                    formRecord.controls['provState'].setValue(addressModel.province_lov._id);
                }
                else {
                    formRecord.controls['provText'].setValue(addressModel.province_text);
                }
            }
            else {
                formRecord.controls['country'].setValue(null);
            }
        }
    }
    setProvinceState(record, countryId, provinceList, stateList) {
        let listToReturn = [];
        if (this._utilsService.isCanadaOrUSA(countryId)) {
            this._utilsService.resetControlsValues(record.controls['provText']);
            record.controls['provList'].setValidators([Validators.required]);
            if (this._utilsService.isCanada(countryId)) {
                record.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
                listToReturn = provinceList;
            }
            else {
                record.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
                listToReturn = stateList;
            }
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        else {
            record.controls['provList'].setValidators([]);
            record.controls['provList'].setValue('');
            record.controls['postal'].setValidators([Validators.required]);
            record.controls['provList'].updateValueAndValidity();
            record.controls['postal'].updateValueAndValidity();
        }
        return listToReturn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressDetailsService, deps: [{ token: i3.UtilsService }, { token: i3.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i3.UtilsService }, { type: i3.ConverterService }] });

class AddressDetailsComponent extends BaseComponent {
    constructor(_fb, cdr, _detailsService, _utilsService) {
        super();
        this._fb = _fb;
        this.cdr = cdr;
        this._detailsService = _detailsService;
        this._utilsService = _utilsService;
        this.errorList = new EventEmitter(true);
        this.recordId = null;
        this.resetFormGroup = null;
        // public provinceLabel = 'addressDetails.province';
        // public postalLabel = 'addressDetails.postalZipCode';
        this.showFieldErrors = false;
        this.showFieldErrors = false;
        this.showErrors = false;
    }
    ngOnInit() {
        if (!this.addressForm) {
            this.addressForm = this._detailsService.getReactiveModel(this._fb);
        }
        if (this.canadaDefault) {
            this.addressForm.controls['country'].setValue(CANADA);
            this.addressForm.controls['country'].disable(); // Method to grey out/disable the country dropdown
            this.onCountryChange(null); // Call onCountryChange to change Postal/ZIP code -> Postal Code, Province or state -> Province
        }
    }
    emitErrors(errors) {
        this.errorList.emit(errors);
    }
    ngOnChanges(changes) {
        this.showFieldErrors = this.showErrors || this.showFieldErrors;
        const isFirstChange = this._utilsService.isFirstChange(changes);
        if (changes['formGroup']) {
            this.addressForm = this.formGroup;
            this.onCountryChange(null);
        }
        if (!isFirstChange) {
            if (changes['addressModel']) {
                const dataModel = changes['addressModel'].currentValue;
                if (dataModel) {
                    this._detailsService.mapDataModelToFormModel(dataModel, this.addressForm);
                    this.onCountryChange(null);
                }
            }
            if (changes['resetFormGroup']) {
                if (this.resetFormGroup > 0) {
                    this._resetFormGroup();
                }
            }
        }
    }
    onCountryChange(e) {
        if (e) {
            // reset provText etc fields when the action is triggered from the UI
            const valuesToReset = ['provText', 'postal', 'provState'];
            this._resetControlValues(valuesToReset);
        }
        if (this.isCanadaOrUSA()) {
            // update provState and postal fields' validator
            this.addressForm.controls['provState'].setValidators([Validators.required]);
            if (this.addressForm.controls['provState'].value == null) {
                this.addressForm.controls['provState'].setValue('');
            }
            this.addressForm.controls['provState'].updateValueAndValidity();
            if (this.isCanada()) {
                this.addressForm.controls['postal'].setValidators([Validators.required, ValidationService.canadaPostalValidator]);
            }
            else {
                this.addressForm.controls['postal'].setValidators([Validators.required, ValidationService.usaPostalValidator]);
            }
            this.addressForm.controls['postal'].updateValueAndValidity();
        }
        else {
            // update provState and postal fields' validator
            this.addressForm.controls['provState'].setValidators([]);
            this.addressForm.controls['provState'].updateValueAndValidity();
            this.addressForm.controls['postal'].setValidators([Validators.required]);
            this.addressForm.controls['postal'].updateValueAndValidity();
        }
    }
    getFormValue() {
        return this.addressForm.value;
    }
    _resetControlValues(controlNames) {
        for (let i = 0; i < controlNames.length; i++) {
            this._utilsService.resetControlsValues(this.addressForm.controls[controlNames[i]]);
        }
    }
    isCanadaOrUSA() {
        return this._utilsService.isCanadaOrUSA(this.getCountryValue());
    }
    isCanada() {
        return this._utilsService.isCanada(this.getCountryValue());
    }
    isUsa() {
        return this._utilsService.isUsa(this.getCountryValue());
    }
    getCountryValue() {
        return this.addressForm.controls['country'].value;
    }
    /**
     * Reactive funtion to return the provStateList based on selected country
     *
     * @returns ICode[] of either states or provinces or empty if neither Canada or USA is selected
     */
    provStateList() {
        if (this.isCanada()) {
            return this.provinceList;
        }
        else if (this.isUsa()) {
            return this.stateList;
        }
        else {
            return [];
        }
    }
    /**
     * Reactive function to return province label if country is Canada or USA
     * @returns Either "Province" or "State"
     */
    provinceLabel() {
        if (this.isCanada()) {
            return 'addressDetails.province';
        }
        else {
            return 'addressDetails.state';
        }
    }
    /**
     * Reactive function to return postal code label if country is Canada/USA/neither
     * @returns Either "Postal code"/"ZIP code"/"Postal/ZIP code"
     */
    postalLabel() {
        if (this.isCanada()) {
            return 'addressDetails.postalCode';
        }
        else if (this.isUsa()) {
            return 'addressDetails.zipCode';
        }
        else {
            return 'addressDetails.postalZipCode';
        }
    }
    _resetFormGroup() {
        this.addressForm.reset();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressDetailsComponent, deps: [{ token: i1.FormBuilder }, { token: i0.ChangeDetectorRef }, { token: AddressDetailsService }, { token: i3.UtilsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.18", type: AddressDetailsComponent, isStandalone: false, selector: "pbv-address-details", inputs: { showErrors: "showErrors", addressModel: "addressModel", lang: "lang", countryList: "countryList", provinceList: "provinceList", stateList: "stateList", canadaDefault: "canadaDefault", addrType: "addrType", addrGroupLabelKey: "addrGroupLabelKey", formGroup: "formGroup", recordId: "recordId", resetFormGroup: "resetFormGroup" }, outputs: { errorList: "errorList" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div>\r\n  <div [formGroup]=\"addressForm\">\r\n    <!--<div class=\"row\">-->\r\n    <!--<div class=\"form-group col-xs-6\" >-->\r\n    <!--<label for=\"businessNum\">-->\r\n    <!--<span class=\"field-name\">{{'business.num' |translate}}</span>-->\r\n    <!--<sup id=\"co3-rf\">-->\r\n    <!--<a class=\"fn-lnk\" href=\"#co3\"><span class=\"wb-inv\">{{'instruction'|translate}}</span>{{helpTextSequences.busNumInx}}</a>-->\r\n  <!--</sup>-->\r\n  <!--<input name=\"businessNum\" id=\"businessNum\" class=\"form-control full-width\"-->\r\n  <!--[formControl]=\"addressForm.controls.businessNum\"   maxlength=\"9\"/>-->\r\n<!--</label>-->\r\n<!--</div>-->\r\n<!--</div>-->\r\n<div class=\"row\">\r\n  <div class=\"form-group col-xs-12\" >\r\n    <label for=\"{{addrType}}address{{recordId}}\" class=\"required full-width\">\r\n      <span class=\"field-name\">{{'addressDetails.street'|translate}}\r\n        <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n      </span>\r\n      @if (addressForm.controls['address'].invalid) {\r\n        <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n          [showError]=\"showFieldErrors\"\r\n          [control]=\"addressForm.controls['address'] | formControl\"\r\n          controlId=\"{{addrType}}address{{recordId}}\" label=\"addressDetails.street\" parentId=\"{{addrType}}addressInfo\"\r\n        translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n      }\r\n      <input name=\"address\" id=\"{{addrType}}address{{recordId}}\" class=\"form-control full-width\"  required\r\n        [formControlName]=\"'address'\" maxlength=\"250\"/>\r\n      </label>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"form-group col-sm-6 col-xs-12\" >\r\n      <label for=\"{{addrType}}city{{recordId}}\" class=\"required full-width\">\r\n        <span class=\"field-name\">{{'addressDetails.city'|translate}}\r\n          <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n        </span>\r\n        @if (addressForm.controls['city'].invalid) {\r\n          <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n            [showError]=\"showFieldErrors\"\r\n            [control]=\"addressForm.controls['city'] | formControl\"\r\n            controlId=\"{{addrType}}city{{recordId}}\" label=\"addressDetails.city\" parentId=\"{{addrType}}addressInfo\"\r\n          translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n        }\r\n        <input name=\"city\" id=\"{{addrType}}city{{recordId}}\" class=\"form-control full-width\" required\r\n          [formControlName]=\"'city'\" maxlength=\"60\"/>\r\n        </label>\r\n      </div>\r\n      <div class=\"form-group col-sm-5 col-xs-12\" >\r\n        <label class=\"required full-width\" for=\"{{addrType}}country{{recordId}}\">\r\n          <span class=\"field-name\">{{'addressDetails.country'|translate}}\r\n            <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n          </span>\r\n          @if (addressForm.controls['country'].invalid) {\r\n            <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n              [showError]=\"showFieldErrors\"\r\n              [control]=\"addressForm.controls['country'] | formControl\"\r\n              controlId=\"{{addrType}}country{{recordId}}\" label=\"addressDetails.country\" parentId=\"{{addrType}}addressInfo\"\r\n            translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n          }\r\n          <select id=\"{{addrType}}country{{recordId}}\" required [formControlName]=\"'country'\" class=\"required form-control\"\r\n            (change)=\"onCountryChange($event)\">\r\n            <option label=\"{{ 'select.option'|translate }}\"></option>\r\n            @for (ctry of countryList; track ctry) {\r\n              <option [value]=\"ctry.id\">{{ ctry| textTransform: lang }}</option>\r\n            }\r\n          </select>\r\n        </label>\r\n      </div>\r\n    </div>\r\n    <div class=\"row\">\r\n      @if (isCanadaOrUSA()) {\r\n        <div class=\"form-group col-xs-12 col-sm-6\" >\r\n          <label for=\"{{addrType}}provState{{recordId}}\" class=\"required full-width\">\r\n            <span class=\"field-name\">{{provinceLabel() |translate}}\r\n              @if (isCanadaOrUSA()) {\r\n                <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n              }\r\n            </span>\r\n            @if (addressForm.controls['provState'].invalid) {\r\n              <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                [showError]=\"showFieldErrors\"\r\n                [control]=\"addressForm.controls['provState'] | formControl\"\r\n                controlId=\"{{addrType}}provState{{recordId}}\" label=\"{{provinceLabel()}}\" parentId=\"{{addrType}}addressInfo\"\r\n              translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n            }\r\n            <select id=\"{{addrType}}provState{{recordId}}\" required class=\"form-control full-width\"  [formControlName]=\"'provState'\">\r\n              <option label=\"{{ 'select.option'|translate }}\"></option>\r\n              @for (prov of provStateList(); track prov) {\r\n                <option [ngValue]=\"prov.id\"> {{prov | textTransform: lang}}</option>\r\n              }\r\n            </select>\r\n          </label>\r\n        </div>\r\n      }\r\n      @if (!isCanadaOrUSA()) {\r\n        <div class=\"form-group col-xs-12 col-sm-6\">\r\n          <label for=\"{{addrType}}provText{{recordId}}\" class=\"full-width\">\r\n            <span class=\"field-name\">{{'addressDetails.provState'|translate}}</span>\r\n            <input name=\"provText\" id=\"{{addrType}}provText{{recordId}}\" class=\"form-control full-width\"\r\n              [formControlName]=\"'provText'\" maxlength=\"40\"/>\r\n            </label>\r\n          </div>\r\n        }\r\n        <div class=\"form-group col-sm-6 col-xs-12\">\r\n          <label for=\"{{addrType}}postal{{recordId}}\" class=\"required\">\r\n            <span class=\"field-name\">{{ postalLabel() |translate}}\r\n              <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n            </span><br/>\r\n            @if (addressForm.controls['postal'].invalid) {\r\n              <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                [showError]=\"showFieldErrors\"\r\n                [control]=\"addressForm.controls['postal'] | formControl\"\r\n                controlId=\"{{addrType}}postal{{recordId}}\" label=\"{{postalLabel()}}\" parentId=\"{{addrType}}addressInfo\"\r\n              translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n            }\r\n            @if (!isCanadaOrUSA()) {\r\n              <input name=\"postal\" id=\"{{addrType}}postal{{recordId}}\" class=\"form-control\" [formControlName]=\"'postal'\"\r\n                maxlength=\"20\" required/>\r\n            }\r\n            @if (isCanada()) {\r\n              <input name=\"postal\" id=\"{{addrType}}postal{{recordId}}\" class=\"form-control\" [formControlName]=\"'postal'\"\r\n                maxlength=\"6\" data-number-letter required=\"\"/>\r\n            }\r\n            @if (isUsa()) {\r\n              <input name=\"postal\" id=\"{{addrType}}postal{{recordId}}\" class=\"form-control\" [formControlName]=\"'postal'\"\r\n                maxlength=\"5\" data-only-digits required/>\r\n            }\r\n          </label>\r\n        </div>\r\n        <!-- <pre>{{addressForm.value |json}}</pre> -->\r\n      </div>\r\n    </div>", dependencies: [{ kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i3.ControlMessagesComponent, selector: "control-messages", inputs: ["control", "showError", "label", "controlId", "parentId", "parentLabel", "translatedParentLabel", "index", "disabledError"] }, { kind: "directive", type: i3.NumbersOnlyDirective, selector: "[data-only-digits]" }, { kind: "directive", type: i3.NumbersLettersDirective, selector: "[data-number-letter]" }, { kind: "pipe", type: i3.FormControlPipe, name: "formControl" }, { kind: "pipe", type: i3.TextTransformPipe, name: "textTransform" }, { kind: "pipe", type: i4.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pbv-address-details', encapsulation: ViewEncapsulation.None, standalone: false, template: "<div>\r\n  <div [formGroup]=\"addressForm\">\r\n    <!--<div class=\"row\">-->\r\n    <!--<div class=\"form-group col-xs-6\" >-->\r\n    <!--<label for=\"businessNum\">-->\r\n    <!--<span class=\"field-name\">{{'business.num' |translate}}</span>-->\r\n    <!--<sup id=\"co3-rf\">-->\r\n    <!--<a class=\"fn-lnk\" href=\"#co3\"><span class=\"wb-inv\">{{'instruction'|translate}}</span>{{helpTextSequences.busNumInx}}</a>-->\r\n  <!--</sup>-->\r\n  <!--<input name=\"businessNum\" id=\"businessNum\" class=\"form-control full-width\"-->\r\n  <!--[formControl]=\"addressForm.controls.businessNum\"   maxlength=\"9\"/>-->\r\n<!--</label>-->\r\n<!--</div>-->\r\n<!--</div>-->\r\n<div class=\"row\">\r\n  <div class=\"form-group col-xs-12\" >\r\n    <label for=\"{{addrType}}address{{recordId}}\" class=\"required full-width\">\r\n      <span class=\"field-name\">{{'addressDetails.street'|translate}}\r\n        <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n      </span>\r\n      @if (addressForm.controls['address'].invalid) {\r\n        <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n          [showError]=\"showFieldErrors\"\r\n          [control]=\"addressForm.controls['address'] | formControl\"\r\n          controlId=\"{{addrType}}address{{recordId}}\" label=\"addressDetails.street\" parentId=\"{{addrType}}addressInfo\"\r\n        translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n      }\r\n      <input name=\"address\" id=\"{{addrType}}address{{recordId}}\" class=\"form-control full-width\"  required\r\n        [formControlName]=\"'address'\" maxlength=\"250\"/>\r\n      </label>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"form-group col-sm-6 col-xs-12\" >\r\n      <label for=\"{{addrType}}city{{recordId}}\" class=\"required full-width\">\r\n        <span class=\"field-name\">{{'addressDetails.city'|translate}}\r\n          <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n        </span>\r\n        @if (addressForm.controls['city'].invalid) {\r\n          <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n            [showError]=\"showFieldErrors\"\r\n            [control]=\"addressForm.controls['city'] | formControl\"\r\n            controlId=\"{{addrType}}city{{recordId}}\" label=\"addressDetails.city\" parentId=\"{{addrType}}addressInfo\"\r\n          translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n        }\r\n        <input name=\"city\" id=\"{{addrType}}city{{recordId}}\" class=\"form-control full-width\" required\r\n          [formControlName]=\"'city'\" maxlength=\"60\"/>\r\n        </label>\r\n      </div>\r\n      <div class=\"form-group col-sm-5 col-xs-12\" >\r\n        <label class=\"required full-width\" for=\"{{addrType}}country{{recordId}}\">\r\n          <span class=\"field-name\">{{'addressDetails.country'|translate}}\r\n            <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n          </span>\r\n          @if (addressForm.controls['country'].invalid) {\r\n            <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n              [showError]=\"showFieldErrors\"\r\n              [control]=\"addressForm.controls['country'] | formControl\"\r\n              controlId=\"{{addrType}}country{{recordId}}\" label=\"addressDetails.country\" parentId=\"{{addrType}}addressInfo\"\r\n            translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n          }\r\n          <select id=\"{{addrType}}country{{recordId}}\" required [formControlName]=\"'country'\" class=\"required form-control\"\r\n            (change)=\"onCountryChange($event)\">\r\n            <option label=\"{{ 'select.option'|translate }}\"></option>\r\n            @for (ctry of countryList; track ctry) {\r\n              <option [value]=\"ctry.id\">{{ ctry| textTransform: lang }}</option>\r\n            }\r\n          </select>\r\n        </label>\r\n      </div>\r\n    </div>\r\n    <div class=\"row\">\r\n      @if (isCanadaOrUSA()) {\r\n        <div class=\"form-group col-xs-12 col-sm-6\" >\r\n          <label for=\"{{addrType}}provState{{recordId}}\" class=\"required full-width\">\r\n            <span class=\"field-name\">{{provinceLabel() |translate}}\r\n              @if (isCanadaOrUSA()) {\r\n                <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n              }\r\n            </span>\r\n            @if (addressForm.controls['provState'].invalid) {\r\n              <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                [showError]=\"showFieldErrors\"\r\n                [control]=\"addressForm.controls['provState'] | formControl\"\r\n                controlId=\"{{addrType}}provState{{recordId}}\" label=\"{{provinceLabel()}}\" parentId=\"{{addrType}}addressInfo\"\r\n              translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n            }\r\n            <select id=\"{{addrType}}provState{{recordId}}\" required class=\"form-control full-width\"  [formControlName]=\"'provState'\">\r\n              <option label=\"{{ 'select.option'|translate }}\"></option>\r\n              @for (prov of provStateList(); track prov) {\r\n                <option [ngValue]=\"prov.id\"> {{prov | textTransform: lang}}</option>\r\n              }\r\n            </select>\r\n          </label>\r\n        </div>\r\n      }\r\n      @if (!isCanadaOrUSA()) {\r\n        <div class=\"form-group col-xs-12 col-sm-6\">\r\n          <label for=\"{{addrType}}provText{{recordId}}\" class=\"full-width\">\r\n            <span class=\"field-name\">{{'addressDetails.provState'|translate}}</span>\r\n            <input name=\"provText\" id=\"{{addrType}}provText{{recordId}}\" class=\"form-control full-width\"\r\n              [formControlName]=\"'provText'\" maxlength=\"40\"/>\r\n            </label>\r\n          </div>\r\n        }\r\n        <div class=\"form-group col-sm-6 col-xs-12\">\r\n          <label for=\"{{addrType}}postal{{recordId}}\" class=\"required\">\r\n            <span class=\"field-name\">{{ postalLabel() |translate}}\r\n              <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n            </span><br/>\r\n            @if (addressForm.controls['postal'].invalid) {\r\n              <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                [showError]=\"showFieldErrors\"\r\n                [control]=\"addressForm.controls['postal'] | formControl\"\r\n                controlId=\"{{addrType}}postal{{recordId}}\" label=\"{{postalLabel()}}\" parentId=\"{{addrType}}addressInfo\"\r\n              translatedParentLabel=\"{{addrGroupLabelKey|translate}}\"></control-messages>\r\n            }\r\n            @if (!isCanadaOrUSA()) {\r\n              <input name=\"postal\" id=\"{{addrType}}postal{{recordId}}\" class=\"form-control\" [formControlName]=\"'postal'\"\r\n                maxlength=\"20\" required/>\r\n            }\r\n            @if (isCanada()) {\r\n              <input name=\"postal\" id=\"{{addrType}}postal{{recordId}}\" class=\"form-control\" [formControlName]=\"'postal'\"\r\n                maxlength=\"6\" data-number-letter required=\"\"/>\r\n            }\r\n            @if (isUsa()) {\r\n              <input name=\"postal\" id=\"{{addrType}}postal{{recordId}}\" class=\"form-control\" [formControlName]=\"'postal'\"\r\n                maxlength=\"5\" data-only-digits required/>\r\n            }\r\n          </label>\r\n        </div>\r\n        <!-- <pre>{{addressForm.value |json}}</pre> -->\r\n      </div>\r\n    </div>" }]
        }], ctorParameters: () => [{ type: i1.FormBuilder }, { type: i0.ChangeDetectorRef }, { type: AddressDetailsService }, { type: i3.UtilsService }], propDecorators: { showErrors: [{
                type: Input
            }], addressModel: [{
                type: Input
            }], lang: [{
                type: Input
            }], countryList: [{
                type: Input
            }], provinceList: [{
                type: Input
            }], stateList: [{
                type: Input
            }], canadaDefault: [{
                type: Input
            }], addrType: [{
                type: Input
            }], addrGroupLabelKey: [{
                type: Input
            }], errorList: [{
                type: Output
            }], formGroup: [{
                type: Input
            }], recordId: [{
                type: Input
            }], resetFormGroup: [{
                type: Input
            }] } });

class AddressModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.18", ngImport: i0, type: AddressModule, declarations: [AddressDetailsComponent], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            ErrorModule,
            PipesModule,
            TranslateModule,
            NumbersOnlyDirective,
            NumbersLettersDirective], exports: [AddressDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressModule, providers: [AddressDetailsService], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            ErrorModule,
            PipesModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: AddressModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        ReactiveFormsModule,
                        FormsModule,
                        ErrorModule,
                        PipesModule,
                        TranslateModule,
                        NumbersOnlyDirective,
                        NumbersLettersDirective
                    ],
                    declarations: [AddressDetailsComponent],
                    exports: [AddressDetailsComponent],
                    providers: [AddressDetailsService],
                }]
        }] });

class ContactDetailsService {
    constructor(_utilsService, _converterService) {
        this._utilsService = _utilsService;
        this._converterService = _converterService;
    }
    /**
     * Gets the reactive forms Model for address details
     * @param {FormBuilder} fb
     * @returns {any}
     */
    getReactiveModel(fb) {
        if (!fb) {
            return null;
        }
        const form = fb.group({
            firstName: [null, Validators.required],
            initials: [null],
            lastName: [null, Validators.required],
            fullName: [{ value: '', disabled: true }],
            language: ['', Validators.required],
            jobTitle: [null, Validators.required],
            faxNumber: ['', [Validators.required, Validators.minLength(10), ValidationService.faxNumberValidator]],
            phoneNumber: ['', [Validators.required, Validators.minLength(10), ValidationService.phoneNumberValidator]],
            phoneExtension: '',
            email: [null, [Validators.required, ValidationService.emailValidator]],
        });
        form.get('firstName')?.valueChanges.subscribe(() => this.updateFullName(form));
        form.get('lastName')?.valueChanges.subscribe(() => this.updateFullName(form));
        return form;
    }
    updateFullName(form) {
        const firstName = form.get('firstName')?.value || '';
        const lastName = form.get('lastName')?.value || '';
        const fullName = `${firstName} ${lastName}`.trim();
        form.get('fullName')?.setValue(fullName, { emitEvent: false });
    }
    mapFormModelToDataModel(formValue, contactModel, lang, languageList) {
        contactModel.given_name = formValue['firstName'];
        contactModel.initials = formValue['initials'];
        // contactModel.initials = formRecord.controls['initials.value;
        contactModel.surname = formValue['lastName'];
        contactModel.language_correspondance = formValue['language'] ? this._converterService.findAndConverCodeToIdTextLabel(languageList, formValue['language'], lang) : null;
        contactModel.job_title = formValue['jobTitle'];
        contactModel.fax_num = formValue['faxNumber'];
        contactModel.phone_num = formValue['phoneNumber'];
        contactModel.phone_ext = formValue['phoneExtension'];
        contactModel.email = formValue['email'];
    }
    mapDataModelToFormModel(contactModel, formRecord) {
        formRecord.controls['firstName'].setValue(contactModel.given_name);
        formRecord.controls['initials'].setValue(contactModel.initials);
        formRecord.controls['lastName'].setValue(contactModel.surname);
        if (contactModel.language_correspondance) {
            formRecord.controls['language'].setValue(contactModel.language_correspondance._id);
        }
        else {
            formRecord.controls['language'].setValue(null);
        }
        formRecord.controls['jobTitle'].setValue(contactModel.job_title);
        formRecord.controls['faxNumber'].setValue(contactModel.fax_num);
        formRecord.controls['phoneNumber'].setValue(contactModel.phone_num);
        formRecord.controls['phoneExtension'].setValue(contactModel.phone_ext);
        formRecord.controls['email'].setValue(contactModel.email);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactDetailsService, deps: [{ token: i3.UtilsService }, { token: i3.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactDetailsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i3.UtilsService }, { type: i3.ConverterService }] });

class ContactDetailsComponent extends BaseComponent {
    constructor(_contactDetailsService, _fb, _utilsService) {
        super();
        this._contactDetailsService = _contactDetailsService;
        this._fb = _fb;
        this._utilsService = _utilsService;
        this.showFieldErrors = false;
        this.errorList = new EventEmitter(true);
        this.recordId = null;
        this.resetFormGroup = null;
        this.autocomplete = false;
        this.showFieldErrors = false;
        this.showErrors = false;
        if (!this.contactDetailsForm) {
            this.contactDetailsForm = this._contactDetailsService.getReactiveModel(this._fb);
        }
    }
    ngOnInit() {
    }
    ngOnChanges(changes) {
        this.showFieldErrors = this.showErrors || this.showFieldErrors;
        const isFirstChange = this._utilsService.isFirstChange(changes);
        if (changes['formGroup']) {
            this.contactDetailsForm = this.formGroup;
        }
        if (!isFirstChange) {
            if (changes['contactDetailsModel']) {
                const dataModel = changes['contactDetailsModel'].currentValue;
                if (dataModel) {
                    this._contactDetailsService.mapDataModelToFormModel(dataModel, this.contactDetailsForm);
                }
            }
            if (changes['resetFormGroup']) {
                if (this.resetFormGroup > 0) {
                    this._resetFormGroup();
                }
            }
        }
    }
    emitErrors(errors) {
        this.errorList.emit(errors);
    }
    getFormValue() {
        return this.contactDetailsForm.value;
    }
    _resetFormGroup() {
        this.contactDetailsForm.reset();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactDetailsComponent, deps: [{ token: ContactDetailsService }, { token: i1.FormBuilder }, { token: i3.UtilsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.18", type: ContactDetailsComponent, isStandalone: false, selector: "pbv-contact-details", inputs: { showErrors: "showErrors", contactDetailsModel: "contactDetailsModel", lang: "lang", languageList: "languageList", contactType: "contactType", contactGroupLabelKey: "contactGroupLabelKey", formGroup: "formGroup", recordId: "recordId", resetFormGroup: "resetFormGroup", autocomplete: "autocomplete" }, outputs: { errorList: "errorList" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div>\r\n  <div [formGroup]=\"contactDetailsForm\">\r\n    <div class=\"row\">\r\n      <div class=\"form-group col-sm-6\" >\r\n        <label for=\"{{contactType}}firstName{{recordId}}\" class=\"required full-width\">\r\n          <span class=\"field-name\">{{'first.name'|translate}}\r\n            <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n          </span>\r\n          @if (contactDetailsForm.controls['firstName'].invalid) {\r\n            <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n              [showError]=\"showFieldErrors\"\r\n              [control]=\"contactDetailsForm.controls['firstName'] | formControl\"\r\n              controlId=\"{{contactType}}firstName{{recordId}}\" label=\"first.name\" parentId=\"{{contactType}}contactInfo\"\r\n            translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n          }\r\n          <input name=\"firstName\" id=\"{{contactType}}firstName{{recordId}}\" class=\"form-control full-width\" maxlength=\"60\" required\r\n            [formControlName]=\"'firstName'\"/>\r\n          </label>\r\n        </div>\r\n        <div class=\"form-group col-sm-6\" >\r\n          <label for=\"{{contactType}}initials{{recordId}}\">\r\n            <span class=\"field-name\">{{'initials'|translate}}</span>\r\n            <input name=\"initials\" id=\"{{contactType}}initials{{recordId}}\" class=\"form-control full-width\" maxlength=\"10\"\r\n              [formControlName]=\"'initials'\"/>\r\n            </label>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"form-group col-sm-6\" >\r\n            <label for=\"{{contactType}}lastName{{recordId}}\" class=\"required full-width\">\r\n              <span class=\"field-name\">{{'last.name'|translate}}\r\n                <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n              </span>\r\n              @if (contactDetailsForm.controls['lastName'].invalid) {\r\n                <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                  [showError]=\"showFieldErrors\"\r\n                  [control]=\"contactDetailsForm.controls['lastName'] | formControl\"\r\n                  controlId=\"{{contactType}}lastName{{recordId}}\" label=\"last.name\" parentId=\"{{contactType}}contactInfo\"\r\n                translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n              }\r\n              <input name=\"lastName\" id=\"{{contactType}}lastName{{recordId}}\" class=\"form-control full-width\" maxlength=\"60\" required\r\n                [formControlName]=\"'lastName'\"/>\r\n              </label>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"form-group col-sm-6\" >\r\n              <label for=\"{{contactType}}language{{recordId}}\" class=\"required\">\r\n                <span class=\"field-name\">{{'lang.correspond' |translate}}\r\n                  <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                </span>\r\n                @if (contactDetailsForm.controls['language'].invalid) {\r\n                  <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                    [showError]=\"showFieldErrors\"\r\n                    [control]=\"contactDetailsForm.controls['language'] | formControl\"\r\n                    controlId=\"{{contactType}}language{{recordId}}\" label=\"lang.correspond\" parentId=\"{{contactType}}contactInfo\"\r\n                  translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                }\r\n                <select id=\"{{contactType}}language{{recordId}}\" required class=\"form-control\" [formControlName]=\"'language'\">\r\n                  <option label=\"{{ 'select.option'|translate }}\"></option>\r\n                  @for (langOption of languageList; track langOption) {\r\n                    <option [value]=\"langOption.id\">{{langOption | textTransform: lang }}</option>\r\n                  }\r\n                </select>\r\n              </label>\r\n            </div>\r\n            <div class=\"form-group col-sm-6\">\r\n              <label for=\"{{contactType}}jobTitle{{recordId}}\" class=\"required\">\r\n                <span class=\"field-name\">{{'job.title'|translate}}\r\n                  <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                </span>\r\n                @if (contactDetailsForm.controls['jobTitle'].invalid) {\r\n                  <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                    [showError]=\"showFieldErrors\"\r\n                    [control]=\"contactDetailsForm.controls['jobTitle'] | formControl\"\r\n                    controlId=\"{{contactType}}jobTitle{{recordId}}\" label=\"job.title\" parentId=\"{{contactType}}contactInfo\"\r\n                  translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                }\r\n                <input name=\"jobTitle\" id=\"{{contactType}}jobTitle{{recordId}}\" class=\"form-control full-width\" maxlength=\"40\" [formControlName]=\"'jobTitle'\" required/>\r\n              </label>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"form-group col-sm-6\" >\r\n              <label for=\"{{contactType}}phoneNumber{{recordId}}\" class=\"required full-width\">\r\n                <span class=\"field-name\">{{'phone.number'|translate}}\r\n                  <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                </span>\r\n                @if (contactDetailsForm.controls['phoneNumber'].invalid) {\r\n                  <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                    [showError]=\"showFieldErrors\"\r\n                    [control]=\"contactDetailsForm.controls['phoneNumber'] | formControl\"\r\n                    controlId=\"{{contactType}}phoneNumber{{recordId}}\" label=\"phone.number\" parentId=\"{{contactType}}contactInfo\"\r\n                    requiredLength=\"10\"\r\n                  translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                }\r\n                <input name=\"phoneNumber\" id=\"{{contactType}}phoneNumber{{recordId}}\" class=\"form-control full-width\" data-only-digits [attr.autocomplete]=\"autocomplete ? 'tel' : 'off'\" required\r\n                  [formControlName]=\"'phoneNumber'\" maxlength=\"25\"/>\r\n                </label>\r\n              </div>\r\n              <div class=\"form-group col-sm-3\">\r\n                <label for=\"{{contactType}}phoneExtension{{recordId}}\">\r\n                  <span class=\"field-name\">{{'phone.extension' |translate}}</span>\r\n                  <input name=\"phoneExtension\" id=\"{{contactType}}phoneExtension{{recordId}}\" class=\"form-control\" maxlength=\"10\" data-only-digits [attr.autocomplete]=\"autocomplete ? 'tel-exttension' : 'off'\"\r\n                    [formControlName]=\"'phoneExtension'\"/>\r\n                  </label>\r\n                </div>\r\n              </div>\r\n              <div class=\"row\">\r\n                <div class=\"form-group col-sm-6\">\r\n                  <label class=\"required full-width\" for=\"{{contactType}}faxNumber{{recordId}}\">\r\n                    <span class=\"field-name\">{{'fax.number' |translate }}\r\n                      <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                    </span>\r\n                    @if (contactDetailsForm.controls['faxNumber'].invalid) {\r\n                      <control-messages [showError]=\"showFieldErrors\" [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                        [control]=\"contactDetailsForm.controls['faxNumber'] | formControl\" controlId=\"{{contactType}}faxNumber{{recordId}}\" label=\"fax.number\"\r\n                        parentId=\"{{contactType}}contactInfo\" requiredLength=\"10\"\r\n                      translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                    }\r\n                    <input name=\"faxNumber\" id=\"{{contactType}}faxNumber{{recordId}}\" class=\"form-control full-width\" data-only-digits maxlength=\"25\" [attr.autocomplete]=\"autocomplete ? 'faxNumber' : 'off'\"\r\n                      [formControlName]=\"'faxNumber'\" required/>\r\n                      <span class=\"field-name small\">{{'fax.number.nofaxnum' |translate }}</span>\r\n                    </label>\r\n                  </div>\r\n                </div>\r\n                <div class=\"row\">\r\n                  <div class=\"form-group col-sm-6\" >\r\n                    <label for=\"{{contactType}}email{{recordId}}\" class=\"required full-width\">\r\n                      <span class=\"field-name\">{{'contact.email'|translate}}\r\n                        <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                      </span>\r\n                      @if (contactDetailsForm.controls['email'].invalid) {\r\n                        <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                          [showError]=\"showFieldErrors\"\r\n                          [control]=\"contactDetailsForm.controls['email'] | formControl\"\r\n                          controlId=\"{{contactType}}email{{recordId}}\" label=\"contact.email\" parentId=\"{{contactType}}contactInfo\"\r\n                        translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                      }\r\n                      <input name=\"email\" id=\"{{contactType}}email{{recordId}}\" class=\"form-control full-width\" maxlength=\"80\" [formControlName]=\"'email'\" required/>\r\n                      <span class=\"field-name small\">{{'email.text' |translate }}</span>\r\n                    </label>\r\n                  </div>\r\n\r\n                </div>\r\n              </div>\r\n            </div>", dependencies: [{ kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i3.ControlMessagesComponent, selector: "control-messages", inputs: ["control", "showError", "label", "controlId", "parentId", "parentLabel", "translatedParentLabel", "index", "disabledError"] }, { kind: "directive", type: i3.NumbersOnlyDirective, selector: "[data-only-digits]" }, { kind: "pipe", type: i4.TranslatePipe, name: "translate" }, { kind: "pipe", type: i3.FormControlPipe, name: "formControl" }, { kind: "pipe", type: i3.TextTransformPipe, name: "textTransform" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pbv-contact-details', encapsulation: ViewEncapsulation.None, standalone: false, template: "<div>\r\n  <div [formGroup]=\"contactDetailsForm\">\r\n    <div class=\"row\">\r\n      <div class=\"form-group col-sm-6\" >\r\n        <label for=\"{{contactType}}firstName{{recordId}}\" class=\"required full-width\">\r\n          <span class=\"field-name\">{{'first.name'|translate}}\r\n            <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n          </span>\r\n          @if (contactDetailsForm.controls['firstName'].invalid) {\r\n            <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n              [showError]=\"showFieldErrors\"\r\n              [control]=\"contactDetailsForm.controls['firstName'] | formControl\"\r\n              controlId=\"{{contactType}}firstName{{recordId}}\" label=\"first.name\" parentId=\"{{contactType}}contactInfo\"\r\n            translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n          }\r\n          <input name=\"firstName\" id=\"{{contactType}}firstName{{recordId}}\" class=\"form-control full-width\" maxlength=\"60\" required\r\n            [formControlName]=\"'firstName'\"/>\r\n          </label>\r\n        </div>\r\n        <div class=\"form-group col-sm-6\" >\r\n          <label for=\"{{contactType}}initials{{recordId}}\">\r\n            <span class=\"field-name\">{{'initials'|translate}}</span>\r\n            <input name=\"initials\" id=\"{{contactType}}initials{{recordId}}\" class=\"form-control full-width\" maxlength=\"10\"\r\n              [formControlName]=\"'initials'\"/>\r\n            </label>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"form-group col-sm-6\" >\r\n            <label for=\"{{contactType}}lastName{{recordId}}\" class=\"required full-width\">\r\n              <span class=\"field-name\">{{'last.name'|translate}}\r\n                <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n              </span>\r\n              @if (contactDetailsForm.controls['lastName'].invalid) {\r\n                <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                  [showError]=\"showFieldErrors\"\r\n                  [control]=\"contactDetailsForm.controls['lastName'] | formControl\"\r\n                  controlId=\"{{contactType}}lastName{{recordId}}\" label=\"last.name\" parentId=\"{{contactType}}contactInfo\"\r\n                translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n              }\r\n              <input name=\"lastName\" id=\"{{contactType}}lastName{{recordId}}\" class=\"form-control full-width\" maxlength=\"60\" required\r\n                [formControlName]=\"'lastName'\"/>\r\n              </label>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"form-group col-sm-6\" >\r\n              <label for=\"{{contactType}}language{{recordId}}\" class=\"required\">\r\n                <span class=\"field-name\">{{'lang.correspond' |translate}}\r\n                  <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                </span>\r\n                @if (contactDetailsForm.controls['language'].invalid) {\r\n                  <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                    [showError]=\"showFieldErrors\"\r\n                    [control]=\"contactDetailsForm.controls['language'] | formControl\"\r\n                    controlId=\"{{contactType}}language{{recordId}}\" label=\"lang.correspond\" parentId=\"{{contactType}}contactInfo\"\r\n                  translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                }\r\n                <select id=\"{{contactType}}language{{recordId}}\" required class=\"form-control\" [formControlName]=\"'language'\">\r\n                  <option label=\"{{ 'select.option'|translate }}\"></option>\r\n                  @for (langOption of languageList; track langOption) {\r\n                    <option [value]=\"langOption.id\">{{langOption | textTransform: lang }}</option>\r\n                  }\r\n                </select>\r\n              </label>\r\n            </div>\r\n            <div class=\"form-group col-sm-6\">\r\n              <label for=\"{{contactType}}jobTitle{{recordId}}\" class=\"required\">\r\n                <span class=\"field-name\">{{'job.title'|translate}}\r\n                  <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                </span>\r\n                @if (contactDetailsForm.controls['jobTitle'].invalid) {\r\n                  <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                    [showError]=\"showFieldErrors\"\r\n                    [control]=\"contactDetailsForm.controls['jobTitle'] | formControl\"\r\n                    controlId=\"{{contactType}}jobTitle{{recordId}}\" label=\"job.title\" parentId=\"{{contactType}}contactInfo\"\r\n                  translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                }\r\n                <input name=\"jobTitle\" id=\"{{contactType}}jobTitle{{recordId}}\" class=\"form-control full-width\" maxlength=\"40\" [formControlName]=\"'jobTitle'\" required/>\r\n              </label>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"form-group col-sm-6\" >\r\n              <label for=\"{{contactType}}phoneNumber{{recordId}}\" class=\"required full-width\">\r\n                <span class=\"field-name\">{{'phone.number'|translate}}\r\n                  <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                </span>\r\n                @if (contactDetailsForm.controls['phoneNumber'].invalid) {\r\n                  <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                    [showError]=\"showFieldErrors\"\r\n                    [control]=\"contactDetailsForm.controls['phoneNumber'] | formControl\"\r\n                    controlId=\"{{contactType}}phoneNumber{{recordId}}\" label=\"phone.number\" parentId=\"{{contactType}}contactInfo\"\r\n                    requiredLength=\"10\"\r\n                  translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                }\r\n                <input name=\"phoneNumber\" id=\"{{contactType}}phoneNumber{{recordId}}\" class=\"form-control full-width\" data-only-digits [attr.autocomplete]=\"autocomplete ? 'tel' : 'off'\" required\r\n                  [formControlName]=\"'phoneNumber'\" maxlength=\"25\"/>\r\n                </label>\r\n              </div>\r\n              <div class=\"form-group col-sm-3\">\r\n                <label for=\"{{contactType}}phoneExtension{{recordId}}\">\r\n                  <span class=\"field-name\">{{'phone.extension' |translate}}</span>\r\n                  <input name=\"phoneExtension\" id=\"{{contactType}}phoneExtension{{recordId}}\" class=\"form-control\" maxlength=\"10\" data-only-digits [attr.autocomplete]=\"autocomplete ? 'tel-exttension' : 'off'\"\r\n                    [formControlName]=\"'phoneExtension'\"/>\r\n                  </label>\r\n                </div>\r\n              </div>\r\n              <div class=\"row\">\r\n                <div class=\"form-group col-sm-6\">\r\n                  <label class=\"required full-width\" for=\"{{contactType}}faxNumber{{recordId}}\">\r\n                    <span class=\"field-name\">{{'fax.number' |translate }}\r\n                      <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                    </span>\r\n                    @if (contactDetailsForm.controls['faxNumber'].invalid) {\r\n                      <control-messages [showError]=\"showFieldErrors\" [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                        [control]=\"contactDetailsForm.controls['faxNumber'] | formControl\" controlId=\"{{contactType}}faxNumber{{recordId}}\" label=\"fax.number\"\r\n                        parentId=\"{{contactType}}contactInfo\" requiredLength=\"10\"\r\n                      translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                    }\r\n                    <input name=\"faxNumber\" id=\"{{contactType}}faxNumber{{recordId}}\" class=\"form-control full-width\" data-only-digits maxlength=\"25\" [attr.autocomplete]=\"autocomplete ? 'faxNumber' : 'off'\"\r\n                      [formControlName]=\"'faxNumber'\" required/>\r\n                      <span class=\"field-name small\">{{'fax.number.nofaxnum' |translate }}</span>\r\n                    </label>\r\n                  </div>\r\n                </div>\r\n                <div class=\"row\">\r\n                  <div class=\"form-group col-sm-6\" >\r\n                    <label for=\"{{contactType}}email{{recordId}}\" class=\"required full-width\">\r\n                      <span class=\"field-name\">{{'contact.email'|translate}}\r\n                        <strong class=\"required\" aria-hidden=\"true\">{{'commmon.required.bracket'|translate}}</strong>\r\n                      </span>\r\n                      @if (contactDetailsForm.controls['email'].invalid) {\r\n                        <control-messages [attr.aria-live]=\"showFieldErrors? null: 'assertive'\"\r\n                          [showError]=\"showFieldErrors\"\r\n                          [control]=\"contactDetailsForm.controls['email'] | formControl\"\r\n                          controlId=\"{{contactType}}email{{recordId}}\" label=\"contact.email\" parentId=\"{{contactType}}contactInfo\"\r\n                        translatedParentLabel=\"{{contactGroupLabelKey|translate}}\"></control-messages>\r\n                      }\r\n                      <input name=\"email\" id=\"{{contactType}}email{{recordId}}\" class=\"form-control full-width\" maxlength=\"80\" [formControlName]=\"'email'\" required/>\r\n                      <span class=\"field-name small\">{{'email.text' |translate }}</span>\r\n                    </label>\r\n                  </div>\r\n\r\n                </div>\r\n              </div>\r\n            </div>" }]
        }], ctorParameters: () => [{ type: ContactDetailsService }, { type: i1.FormBuilder }, { type: i3.UtilsService }], propDecorators: { showErrors: [{
                type: Input
            }], contactDetailsModel: [{
                type: Input
            }], lang: [{
                type: Input
            }], languageList: [{
                type: Input
            }], contactType: [{
                type: Input
            }], contactGroupLabelKey: [{
                type: Input
            }], errorList: [{
                type: Output
            }], formGroup: [{
                type: Input
            }], recordId: [{
                type: Input
            }], resetFormGroup: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }] } });

class ContactModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.18", ngImport: i0, type: ContactModule, declarations: [ContactDetailsComponent], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            TranslateModule,
            ErrorModule,
            PipesModule,
            ExpanderModule,
            NumbersOnlyDirective,
            PopupComponent], exports: [ContactDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactModule, providers: [
            ContactDetailsService,
            UtilsService,
            ConverterService
        ], imports: [CommonModule,
            // BrowserModule,
            ReactiveFormsModule,
            FormsModule,
            TranslateModule,
            ErrorModule,
            PipesModule,
            ExpanderModule,
            PopupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.18", ngImport: i0, type: ContactModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        ReactiveFormsModule,
                        FormsModule,
                        TranslateModule,
                        ErrorModule,
                        PipesModule,
                        ExpanderModule,
                        NumbersOnlyDirective,
                        PopupComponent
                    ],
                    declarations: [
                        ContactDetailsComponent
                    ],
                    exports: [
                        ContactDetailsComponent
                    ],
                    providers: [
                        ContactDetailsService,
                        UtilsService,
                        ConverterService
                    ],
                }]
        }] });

/*
 * Public API Surface of pbv
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AddressDetailsComponent, AddressDetailsService, AddressModule, CommonPbvModule, ContactDetailsComponent, ContactDetailsService, ContactModule, EntityBasePbvService, PbvComponent, PbvService, PbvValidationService, PrivacyStatementComponent };
//# sourceMappingURL=hpfb-pbv.mjs.map
