export declare const CANADA: string;
export declare const USA: string;
export declare const ENGLISH: string;
export declare const FRENCH: string;
export declare const YES: string;
export declare const NO: string;
export declare const FINAL: string;
export declare const OTHER_EN: string;
export declare const OTHER_FR: string;
export declare const RECORD_ACTIONS: {
    SAVE: string;
    DISCARD: string;
    DELETE: string;
};
