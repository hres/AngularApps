import { ElementRef } from '@angular/core';
import { NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class NumbersLettersDirective {
    private control;
    private el;
    constructor(control: NgControl, el: ElementRef);
    onInput(value: string): void;
    onPaste(event: ClipboardEvent): void;
    private filterValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumbersLettersDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NumbersLettersDirective, "[data-number-letter]", never, {}, {}, never, never, true, never>;
}
