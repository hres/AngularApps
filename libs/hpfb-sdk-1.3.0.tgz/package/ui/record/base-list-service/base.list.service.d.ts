import { FormGroup } from "@angular/forms";
import { IListService } from "./base.list.service.interface";
export declare abstract class BaseListService implements IListService {
    protected list: FormGroup[];
    protected idCount: number;
    setList(list: FormGroup[]): void;
    getNextId(): number;
    getId(): number;
}
