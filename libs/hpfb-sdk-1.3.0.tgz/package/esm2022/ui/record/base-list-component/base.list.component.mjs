import { Component, Inject, Input } from "@angular/core";
import { BaseListService } from "../base-list-service/base.list.service";
import { BaseComponent } from "../../component-base/base.component";
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "../base-list-service/base.list.service";
export class BaseListComponent extends BaseComponent {
    constructor(_fb, listService) {
        super();
        this._fb = _fb;
        this.listService = listService;
    }
    ngOnChanges(changes) {
        if (changes['recordList']) {
            this._init(changes['recordList'].currentValue);
        }
    }
    _init(recordData) {
        // Clear existing controls
        this.recordFormArray.clear();
        if (recordData && recordData.length !== 0) {
            if (recordData.length > 0) {
                recordData.forEach((record, index) => {
                    const group = this.recordService.createRecordFormGroup(this._fb);
                    // Set values after defining the form controls
                    group.patchValue({
                        id: record.id,
                        recordId: index + 1,
                        isNew: false,
                        expandFlag: false,
                    });
                    this._patchRecordInfoValue(group, record);
                    this._patchLastSavedStateValue(group.controls['lastSavedState'], record);
                    this.recordFormArray.push(group);
                });
                this.listService.setMaxId(recordData.length);
            }
        }
        else {
            if (!this.isInternal) {
                const group = this.recordService.createRecordFormGroup(this._fb);
                group.patchValue({
                    recordId: this.listService.getId()
                });
                this.recordFormArray.push(group);
                const firstFormRecord = this.recordFormArray.at(0);
                firstFormRecord.controls['expandFlag'].setValue(true);
            }
        }
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
        // Set the list of form groups
        this.listService.setList(this.recordFormArray.controls);
    }
    addRecord() {
        const group = this.recordService.createRecordFormGroup(this._fb);
        group.patchValue({
            recordId: this.listService.getId()
        });
        this.recordFormArray.push(group);
    }
    saveRecord(event) {
        const index = event.index;
        const group = this.recordFormArray.at(index);
        // if this is a new record, assign next available id, otherwise, use it's existing id
        const id = group.get('isNew').value ? this.listService.getNextId() : group.get('id').value;
        group.patchValue({
            id: id,
            isNew: false,
            expandFlag: false, // collapse this record
        });
        const recordInfo = this.getRecordInfo(group);
        // Update lastSavedState with the current value of contactInfo
        group.get('lastSavedState').setValue(recordInfo.value);
        this._expandNextInvalidRecord();
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    _expandNextInvalidRecord() {
        // expand next invalid record
        for (let index = 0; index < this.recordFormArray.controls.length; index++) {
            const group = this.recordFormArray.controls[index];
            if (group.invalid) {
                group.controls['expandFlag'].setValue(true);
                this.recordFormGroup.markAsDirty();
                break;
            }
        }
    }
    deleteRecord(index) {
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        recordInfo.reset();
        this.recordFormArray.removeAt(index);
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    revertRecord(event) {
        const index = event.index;
        const id = event.id;
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        // Revert to the last saved state
        const lastSavedState = group.get('lastSavedState').value;
        recordInfo.patchValue(lastSavedState);
    }
    handleRowClick(event) {
        const clickedIndex = event.index;
        const clickedRecordState = event.state;
        if (this.recordFormGroup.pristine) {
            this.recordFormArray.controls.forEach((element, index) => {
                if (clickedIndex === index) {
                    element.controls['expandFlag'].setValue(!clickedRecordState);
                }
            });
        }
        else {
            this.openPopup();
        }
    }
    showError(errs) {
        if (errs.length > 0) {
            this.showErrors = true;
        }
        else {
            this.showErrors = false;
        }
    }
    disableAddButton() {
        return (this.recordFormGroup.dirty || !this.recordFormGroup.valid || this.errorList?.length > 0);
    }
    openPopup() {
        jQuery("#" + this.popupId).trigger("open.wb-overlay");
    }
    get recordFormArray() {
        return this.recordFormGroup.get(this.records);
    }
    getRecordInfo(recordFormGroup) {
        return recordFormGroup.get(this.recordInfo);
    }
    getRecordFormArrValues() {
        return this.recordFormArray.value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, deps: [{ token: i1.FormBuilder }, { token: BaseListService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: BaseListComponent, selector: "ng-component", inputs: { recordList: "recordList", showErrors: "showErrors", isInternal: "isInternal" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }], ctorParameters: () => [{ type: i1.FormBuilder }, { type: i2.BaseListService, decorators: [{
                    type: Inject,
                    args: [BaseListService]
                }] }], propDecorators: { recordList: [{
                type: Input
            }], showErrors: [{
                type: Input
            }], isInternal: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5saXN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3JlY29yZC9iYXNlLWxpc3QtY29tcG9uZW50L2Jhc2UubGlzdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFpQixTQUFTLEVBQVUsTUFBTSxFQUFFLEtBQUssRUFBb0MsTUFBTSxlQUFlLENBQUM7QUFLbEgsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHdDQUF3QyxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQTs7OztBQU9uRSxNQUFNLE9BQWdCLGlCQUEwQyxTQUFRLGFBQWE7SUFlakYsWUFBb0IsR0FBZ0IsRUFDRyxXQUE0QjtRQUMvRCxLQUFLLEVBQUUsQ0FBQztRQUZRLFFBQUcsR0FBSCxHQUFHLENBQWE7UUFDRyxnQkFBVyxHQUFYLFdBQVcsQ0FBaUI7SUFFbkUsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ25ELENBQUM7SUFDTCxDQUFDO0lBRU8sS0FBSyxDQUFDLFVBQWU7UUFDekIsMEJBQTBCO1FBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFN0IsSUFBSSxVQUFVLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN4QyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzFCLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7b0JBQ25DLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUVqRSw4Q0FBOEM7b0JBQzlDLEtBQUssQ0FBQyxVQUFVLENBQUM7d0JBQ2YsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO3dCQUNiLFFBQVEsRUFBRSxLQUFLLEdBQUcsQ0FBQzt3QkFDbkIsS0FBSyxFQUFFLEtBQUs7d0JBQ1osVUFBVSxFQUFFLEtBQUs7cUJBQ2xCLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxJQUFJLENBQUMseUJBQXlCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUV6RSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQy9DLENBQUM7UUFDTCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ25CLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNqRSxLQUFLLENBQUMsVUFBVSxDQUFDO29CQUNiLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRTtpQkFDckMsQ0FBQyxDQUFBO2dCQUNGLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNqQyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQWMsQ0FBQztnQkFDaEUsZUFBZSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDMUQsQ0FBQztRQUNILENBQUM7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLENBQUM7UUFFekUsOEJBQThCO1FBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBdUIsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFLRCxTQUFTO1FBQ0wsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDakUsS0FBSyxDQUFDLFVBQVUsQ0FBQztZQUNiLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRTtTQUNyQyxDQUFDLENBQUE7UUFDRixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQVU7UUFDakIsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUMxQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQW9CLENBQUM7UUFDaEUscUZBQXFGO1FBQ3JGLE1BQU0sRUFBRSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFBLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFBLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQTtRQUN4RixLQUFLLENBQUMsVUFBVSxDQUFDO1lBQ2pCLEVBQUUsRUFBRSxFQUFFO1lBQ04sS0FBSyxFQUFFLEtBQUs7WUFDWixVQUFVLEVBQUUsS0FBSyxFQUFLLHVCQUF1QjtTQUM1QyxDQUFDLENBQUM7UUFDSCxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLDhEQUE4RDtRQUM5RCxLQUFLLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2RCxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVPLHdCQUF3QjtRQUM1Qiw2QkFBNkI7UUFDN0IsS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO1lBQzNFLE1BQU0sS0FBSyxHQUFvQixJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQW9CLENBQUM7WUFDdkYsSUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ25CLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNqQyxNQUFNO1lBQ1QsQ0FBQztRQUNILENBQUM7SUFDSixDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQWE7UUFDdEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFvQixDQUFDO1FBQ2hFLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0MsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJDLElBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQVU7UUFDcEIsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN6QixNQUFNLEVBQUUsR0FBRyxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3BCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBb0IsQ0FBQztRQUNoRSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLGlDQUFpQztRQUNqQyxNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3pELFVBQVUsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELGNBQWMsQ0FBQyxLQUFVO1FBQ3JCLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDakMsTUFBTSxrQkFBa0IsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3ZDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUUsQ0FBQyxPQUFrQixFQUFFLEtBQWEsRUFBRSxFQUFFO2dCQUN6RSxJQUFJLFlBQVksS0FBRyxLQUFLLEVBQUUsQ0FBQztvQkFDM0IsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO2dCQUM1RCxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUE7UUFDRixDQUFDO2FBQU0sQ0FBQztZQUNSLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixDQUFDO0lBQ0wsQ0FBQztJQUVELFNBQVMsQ0FBQyxJQUFTO1FBQ2YsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQzNCLENBQUM7YUFBTSxDQUFDO1lBQ0osSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDNUIsQ0FBQztJQUNMLENBQUM7SUFFRCxnQkFBZ0I7UUFDWixPQUFPLENBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssSUFBSyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN2RyxDQUFDO0lBRUQsU0FBUztRQUNMLE1BQU0sQ0FBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBRSxDQUFDLE9BQU8sQ0FBRSxpQkFBaUIsQ0FBRSxDQUFDO0lBQzlELENBQUM7SUFFRCxJQUFJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQWMsQ0FBQztJQUMvRCxDQUFDO0lBRUQsYUFBYSxDQUFDLGVBQTBCO1FBQ3BDLE9BQU8sZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFjLENBQUM7SUFDN0QsQ0FBQztJQUVELHNCQUFzQjtRQUNsQixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO0lBQ3RDLENBQUM7K0dBdEtpQixpQkFBaUIsNkNBZ0J2QixlQUFlO21HQWhCVCxpQkFBaUIsMExBRnpCLEVBQUU7OzRGQUVNLGlCQUFpQjtrQkFIdEMsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsRUFBRTtpQkFDZjs7MEJBaUJRLE1BQU07MkJBQUMsZUFBZTt5Q0FmbEIsVUFBVTtzQkFBbEIsS0FBSztnQkFDRyxVQUFVO3NCQUFsQixLQUFLO2dCQUNHLFVBQVU7c0JBQWxCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBZnRlclZpZXdJbml0LCBDb21wb25lbnQsIGluamVjdCwgSW5qZWN0LCBJbnB1dCwgT25DaGFuZ2VzLCBPbkluaXQsIFNpbXBsZUNoYW5nZXMgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBJQmFzZUxpc3QgfSBmcm9tIFwiLi9iYXNlLmxpc3QuaW50ZXJmYWNlXCI7XHJcbmltcG9ydCB7IEZvcm1Hcm91cCwgRm9ybUFycmF5LCBGb3JtQnVpbGRlciB9IGZyb20gXCJAYW5ndWxhci9mb3Jtc1wiO1xyXG5pbXBvcnQgeyBJUmVjb3JkU2VydmljZSB9IGZyb20gXCIuLi9yZWNvcmQtc2VydmljZS9yZWNvcmQuc2VydmljZS5pbnRlcmZhY2VcIjtcclxuaW1wb3J0IHsgT3V0cHV0UmVjb3JkLCBSZWNvcmRGb3JtR3JvdXAgfSBmcm9tIFwiLi4vcmVjb3JkLW1vZGVsL3JlY29yZC5tb2RlbFwiO1xyXG5pbXBvcnQgeyBCYXNlTGlzdFNlcnZpY2UgfSBmcm9tIFwiLi4vYmFzZS1saXN0LXNlcnZpY2UvYmFzZS5saXN0LnNlcnZpY2VcIjtcclxuaW1wb3J0IHsgQmFzZUNvbXBvbmVudCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnQtYmFzZS9iYXNlLmNvbXBvbmVudFwiXHJcblxyXG5pbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICB0ZW1wbGF0ZTogJydcclxufSlcclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEJhc2VMaXN0Q29tcG9uZW50PFQgZXh0ZW5kcyBPdXRwdXRSZWNvcmQ+IGV4dGVuZHMgQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIElCYXNlTGlzdDxUPiwgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgICBASW5wdXQoKSByZWNvcmRMaXN0OiBUW107XHJcbiAgICBASW5wdXQoKSBzaG93RXJyb3JzOiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgaXNJbnRlcm5hbD86IGJvb2xlYW47XHJcblxyXG4gICAgcmVjb3JkRm9ybUdyb3VwOiBGb3JtR3JvdXA7XHJcbiAgICBlcnJvclN1bW1hcnlDaGlsZDogYW55O1xyXG5cclxuICAgIGFic3RyYWN0IHN0YXR1c01lc3NhZ2UgOiBzdHJpbmc7XHJcbiAgICBhYnN0cmFjdCByZWNvcmRzOiBzdHJpbmc7XHJcbiAgICBhYnN0cmFjdCByZWNvcmRJbmZvOiBzdHJpbmc7XHJcbiAgICBhYnN0cmFjdCByZWNvcmRTZXJ2aWNlOiBJUmVjb3JkU2VydmljZTtcclxuICAgIGFic3RyYWN0IHBvcHVwSWQ6IHN0cmluZztcclxuICAgIGFic3RyYWN0IGVycm9yTGlzdDogW107XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfZmI6IEZvcm1CdWlsZGVyLCBcclxuICAgICAgICBASW5qZWN0KEJhc2VMaXN0U2VydmljZSkgcHJvdGVjdGVkIGxpc3RTZXJ2aWNlOiBCYXNlTGlzdFNlcnZpY2UpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoY2hhbmdlc1sncmVjb3JkTGlzdCddKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXQoY2hhbmdlc1sncmVjb3JkTGlzdCddLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXQocmVjb3JkRGF0YTogVFtdKSB7XHJcbiAgICAgICAgLy8gQ2xlYXIgZXhpc3RpbmcgY29udHJvbHNcclxuICAgICAgdGhpcy5yZWNvcmRGb3JtQXJyYXkuY2xlYXIoKTtcclxuICBcclxuICAgICAgaWYgKHJlY29yZERhdGEgJiYgcmVjb3JkRGF0YS5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgIGlmIChyZWNvcmREYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmVjb3JkRGF0YS5mb3JFYWNoKChyZWNvcmQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgZ3JvdXAgPSB0aGlzLnJlY29yZFNlcnZpY2UuY3JlYXRlUmVjb3JkRm9ybUdyb3VwKHRoaXMuX2ZiKTtcclxuICBcclxuICAgICAgICAgICAgICAvLyBTZXQgdmFsdWVzIGFmdGVyIGRlZmluaW5nIHRoZSBmb3JtIGNvbnRyb2xzXHJcbiAgICAgICAgICAgICAgZ3JvdXAucGF0Y2hWYWx1ZSh7XHJcbiAgICAgICAgICAgICAgICBpZDogcmVjb3JkLmlkLFxyXG4gICAgICAgICAgICAgICAgcmVjb3JkSWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICAgIGlzTmV3OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGV4cGFuZEZsYWc6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHRoaXMuX3BhdGNoUmVjb3JkSW5mb1ZhbHVlKGdyb3VwLCByZWNvcmQpO1xyXG4gICAgICAgICAgICAgIHRoaXMuX3BhdGNoTGFzdFNhdmVkU3RhdGVWYWx1ZShncm91cC5jb250cm9sc1snbGFzdFNhdmVkU3RhdGUnXSwgcmVjb3JkKTtcclxuICBcclxuICAgICAgICAgICAgICB0aGlzLnJlY29yZEZvcm1BcnJheS5wdXNoKGdyb3VwKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMubGlzdFNlcnZpY2Uuc2V0TWF4SWQocmVjb3JkRGF0YS5sZW5ndGgpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmICghdGhpcy5pc0ludGVybmFsKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRTZXJ2aWNlLmNyZWF0ZVJlY29yZEZvcm1Hcm91cCh0aGlzLl9mYik7XHJcbiAgICAgICAgICAgIGdyb3VwLnBhdGNoVmFsdWUoe1xyXG4gICAgICAgICAgICAgICAgcmVjb3JkSWQ6IHRoaXMubGlzdFNlcnZpY2UuZ2V0SWQoKVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB0aGlzLnJlY29yZEZvcm1BcnJheS5wdXNoKGdyb3VwKTtcclxuICAgICAgICAgICAgY29uc3QgZmlyc3RGb3JtUmVjb3JkID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoMCkgYXMgRm9ybUdyb3VwO1xyXG4gICAgICAgICAgICBmaXJzdEZvcm1SZWNvcmQuY29udHJvbHNbJ2V4cGFuZEZsYWcnXS5zZXRWYWx1ZSh0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5yZWNvcmRTZXJ2aWNlLnNldFJlY29yZHNGb3JtQXJyVmFsdWUodGhpcy5nZXRSZWNvcmRGb3JtQXJyVmFsdWVzKCkpO1xyXG4gIFxyXG4gICAgICAvLyBTZXQgdGhlIGxpc3Qgb2YgZm9ybSBncm91cHNcclxuICAgICAgdGhpcy5saXN0U2VydmljZS5zZXRMaXN0KHRoaXMucmVjb3JkRm9ybUFycmF5LmNvbnRyb2xzIGFzIEZvcm1Hcm91cFtdKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgX3BhdGNoUmVjb3JkSW5mb1ZhbHVlKGdyb3VwLCBvdXRwdXRNb2RlbCk7XHJcbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgX3BhdGNoTGFzdFNhdmVkU3RhdGVWYWx1ZShsYXN0U2F2ZWRTdGF0ZUZvcm1Db250cm9sLCBvdXRwdXRNb2RlbCk7XHJcblxyXG4gICAgYWRkUmVjb3JkKCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRTZXJ2aWNlLmNyZWF0ZVJlY29yZEZvcm1Hcm91cCh0aGlzLl9mYik7XHJcbiAgICAgICAgZ3JvdXAucGF0Y2hWYWx1ZSh7XHJcbiAgICAgICAgICAgIHJlY29yZElkOiB0aGlzLmxpc3RTZXJ2aWNlLmdldElkKClcclxuICAgICAgICB9KVxyXG4gICAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LnB1c2goZ3JvdXApOyAgICBcclxuICAgIH1cclxuXHJcbiAgICBzYXZlUmVjb3JkKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IGV2ZW50LmluZGV4O1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoaW5kZXgpIGFzIFJlY29yZEZvcm1Hcm91cDtcclxuICAgICAgICAvLyBpZiB0aGlzIGlzIGEgbmV3IHJlY29yZCwgYXNzaWduIG5leHQgYXZhaWxhYmxlIGlkLCBvdGhlcndpc2UsIHVzZSBpdCdzIGV4aXN0aW5nIGlkXHJcbiAgICAgICAgY29uc3QgaWQgPSBncm91cC5nZXQoJ2lzTmV3JykudmFsdWU/IHRoaXMubGlzdFNlcnZpY2UuZ2V0TmV4dElkKCk6IGdyb3VwLmdldCgnaWQnKS52YWx1ZVxyXG4gICAgICAgIGdyb3VwLnBhdGNoVmFsdWUoeyBcclxuICAgICAgICBpZDogaWQsXHJcbiAgICAgICAgaXNOZXc6IGZhbHNlLFxyXG4gICAgICAgIGV4cGFuZEZsYWc6IGZhbHNlLCAgICAvLyBjb2xsYXBzZSB0aGlzIHJlY29yZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnN0IHJlY29yZEluZm8gPSB0aGlzLmdldFJlY29yZEluZm8oZ3JvdXApO1xyXG4gICAgICAgIC8vIFVwZGF0ZSBsYXN0U2F2ZWRTdGF0ZSB3aXRoIHRoZSBjdXJyZW50IHZhbHVlIG9mIGNvbnRhY3RJbmZvXHJcbiAgICAgICAgZ3JvdXAuZ2V0KCdsYXN0U2F2ZWRTdGF0ZScpLnNldFZhbHVlKHJlY29yZEluZm8udmFsdWUpO1xyXG4gICAgICAgIHRoaXMuX2V4cGFuZE5leHRJbnZhbGlkUmVjb3JkKCk7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRTZXJ2aWNlLnNldFJlY29yZHNGb3JtQXJyVmFsdWUodGhpcy5nZXRSZWNvcmRGb3JtQXJyVmFsdWVzKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2V4cGFuZE5leHRJbnZhbGlkUmVjb3JkKCl7XHJcbiAgICAgICAgLy8gZXhwYW5kIG5leHQgaW52YWxpZCByZWNvcmRcclxuICAgICAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdGhpcy5yZWNvcmRGb3JtQXJyYXkuY29udHJvbHMubGVuZ3RoOyBpbmRleCsrKSB7XHJcbiAgICAgICAgIGNvbnN0IGdyb3VwOiBSZWNvcmRGb3JtR3JvdXAgPSB0aGlzLnJlY29yZEZvcm1BcnJheS5jb250cm9sc1tpbmRleF0gYXMgUmVjb3JkRm9ybUdyb3VwO1xyXG4gICAgICAgICBpZiAoZ3JvdXAuaW52YWxpZCkge1xyXG4gICAgICAgICAgZ3JvdXAuY29udHJvbHNbJ2V4cGFuZEZsYWcnXS5zZXRWYWx1ZSh0cnVlKTtcclxuICAgICAgICAgIHRoaXMucmVjb3JkRm9ybUdyb3VwLm1hcmtBc0RpcnR5KCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICB9IFxyXG4gICAgICAgfSAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgZGVsZXRlUmVjb3JkKGluZGV4OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBncm91cCA9IHRoaXMucmVjb3JkRm9ybUFycmF5LmF0KGluZGV4KSBhcyBSZWNvcmRGb3JtR3JvdXA7XHJcbiAgICAgICAgY29uc3QgcmVjb3JkSW5mbyA9IHRoaXMuZ2V0UmVjb3JkSW5mbyhncm91cCk7XHJcbiAgICAgICAgcmVjb3JkSW5mby5yZXNldCgpO1xyXG4gICAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LnJlbW92ZUF0KGluZGV4KTtcclxuICAgIFxyXG4gICAgICAgIHRoaXMucmVjb3JkU2VydmljZS5zZXRSZWNvcmRzRm9ybUFyclZhbHVlKHRoaXMuZ2V0UmVjb3JkRm9ybUFyclZhbHVlcygpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXZlcnRSZWNvcmQoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgY29uc3QgaW5kZXggPSBldmVudC5pbmRleDtcclxuICAgICAgICBjb25zdCBpZCA9IGV2ZW50LmlkO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoaW5kZXgpIGFzIFJlY29yZEZvcm1Hcm91cDtcclxuICAgICAgICBjb25zdCByZWNvcmRJbmZvID0gdGhpcy5nZXRSZWNvcmRJbmZvKGdyb3VwKTtcclxuICAgICAgICAvLyBSZXZlcnQgdG8gdGhlIGxhc3Qgc2F2ZWQgc3RhdGVcclxuICAgICAgICBjb25zdCBsYXN0U2F2ZWRTdGF0ZSA9IGdyb3VwLmdldCgnbGFzdFNhdmVkU3RhdGUnKS52YWx1ZTtcclxuICAgICAgICByZWNvcmRJbmZvLnBhdGNoVmFsdWUobGFzdFNhdmVkU3RhdGUpOyBcclxuICAgIH1cclxuXHJcbiAgICBoYW5kbGVSb3dDbGljayhldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgY29uc3QgY2xpY2tlZEluZGV4ID0gZXZlbnQuaW5kZXg7XHJcbiAgICAgICAgY29uc3QgY2xpY2tlZFJlY29yZFN0YXRlID0gZXZlbnQuc3RhdGU7XHJcbiAgICAgICAgaWYgKHRoaXMucmVjb3JkRm9ybUdyb3VwLnByaXN0aW5lKSB7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRGb3JtQXJyYXkuY29udHJvbHMuZm9yRWFjaCggKGVsZW1lbnQ6IEZvcm1Hcm91cCwgaW5kZXg6IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoY2xpY2tlZEluZGV4PT09aW5kZXgpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5jb250cm9sc1snZXhwYW5kRmxhZyddLnNldFZhbHVlKCFjbGlja2VkUmVjb3JkU3RhdGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5vcGVuUG9wdXAoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2hvd0Vycm9yKGVycnM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChlcnJzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93RXJyb3JzID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dFcnJvcnMgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGRpc2FibGVBZGRCdXR0b24oKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICggdGhpcy5yZWNvcmRGb3JtR3JvdXAuZGlydHkgfHwgIXRoaXMucmVjb3JkRm9ybUdyb3VwLnZhbGlkICB8fCB0aGlzLmVycm9yTGlzdD8ubGVuZ3RoID4gMCk7XHJcbiAgICB9XHJcblxyXG4gICAgb3BlblBvcHVwKCk6IHZvaWQge1xyXG4gICAgICAgIGpRdWVyeSggXCIjXCIgKyB0aGlzLnBvcHVwSWQgKS50cmlnZ2VyKCBcIm9wZW4ud2Itb3ZlcmxheVwiICk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IHJlY29yZEZvcm1BcnJheSgpOiBGb3JtQXJyYXkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZEZvcm1Hcm91cC5nZXQodGhpcy5yZWNvcmRzKSBhcyBGb3JtQXJyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UmVjb3JkSW5mbyhyZWNvcmRGb3JtR3JvdXA6IEZvcm1Hcm91cCk6IEZvcm1Hcm91cCB7XHJcbiAgICAgICAgcmV0dXJuIHJlY29yZEZvcm1Hcm91cC5nZXQodGhpcy5yZWNvcmRJbmZvKSBhcyBGb3JtR3JvdXA7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UmVjb3JkRm9ybUFyclZhbHVlcygpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5yZWNvcmRGb3JtQXJyYXkudmFsdWU7XHJcbiAgICB9XHJcbiAgICBcclxufSJdfQ==