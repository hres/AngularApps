import { Component, Inject, Input } from "@angular/core";
import { BaseListService } from "../base-list-service/base.list.service";
import { BaseComponent } from "../../component-base/base.component";
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "../base-list-service/base.list.service";
export class BaseListComponent extends BaseComponent {
    constructor(_fb, listService) {
        super();
        this._fb = _fb;
        this.listService = listService;
    }
    ngOnChanges(changes) {
        if (changes['recordList']) {
            this._init(changes['recordList'].currentValue);
        }
    }
    _init(recordData) {
        // Clear existing controls
        this.recordFormArray.clear();
        if (recordData && recordData.length !== 0) {
            if (recordData.length > 0) {
                let maxId = -1;
                recordData.forEach((record, index) => {
                    const group = this.recordService.createRecordFormGroup(this._fb);
                    // Set values after defining the form controls
                    group.patchValue({
                        id: record.id,
                        recordId: index + 1,
                        isNew: false,
                        expandFlag: false,
                    });
                    this._patchRecordInfoValue(group, record);
                    this._patchLastSavedStateValue(group.controls['lastSavedState'], record);
                    this.recordFormArray.push(group);
                    // Parse the ID as a number and update maxId if necessary
                    maxId = Math.max(Number(record.id), maxId);
                });
                this.listService.setMaxId(maxId);
                this._expandInvalidRecordUponLoading();
            }
        }
        else {
            if (!this.isInternal) {
                const group = this.recordService.createRecordFormGroup(this._fb);
                group.patchValue({
                    recordId: this.listService.getId()
                });
                this.recordFormArray.push(group);
                const firstFormRecord = this.recordFormArray.at(0);
                firstFormRecord.controls['expandFlag'].setValue(true);
            }
        }
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
        // Set the list of form groups
        this.listService.setList(this.recordFormArray.controls);
    }
    addRecord() {
        const group = this.recordService.createRecordFormGroup(this._fb);
        group.patchValue({
            recordId: this.listService.getId()
        });
        this.recordFormArray.push(group);
    }
    saveRecord(event) {
        const index = event.index;
        const group = this.recordFormArray.at(index);
        // if this is a new record, assign next available id, otherwise, use it's existing id
        const id = group.get('isNew').value ? this.listService.getNextId() : group.get('id').value;
        group.patchValue({
            id: id,
            isNew: false,
            expandFlag: false, // collapse this record
        });
        const recordInfo = this.getRecordInfo(group);
        // Update lastSavedState with the current value of contactInfo
        group.get('lastSavedState').setValue(recordInfo.value);
        this._expandNextInvalidRecord();
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    _expandNextInvalidRecord() {
        // expand next invalid record
        for (let index = 0; index < this.recordFormArray.controls.length; index++) {
            const group = this.recordFormArray.controls[index];
            if (group.invalid) {
                group.controls['expandFlag'].setValue(true);
                this.recordFormGroup.markAsDirty();
                break;
            }
        }
    }
    deleteRecord(index) {
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        recordInfo.reset();
        this.recordFormArray.removeAt(index);
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    revertRecord(event) {
        const index = event.index;
        const id = event.id;
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        // Revert to the last saved state
        const lastSavedState = group.get('lastSavedState').value;
        recordInfo.patchValue(lastSavedState);
    }
    handleRowClick(event) {
        const clickedIndex = event.index;
        const clickedRecordState = event.state;
        if (this.recordFormGroup.pristine) {
            this.recordFormArray.controls.forEach((element, index) => {
                if (clickedIndex === index) {
                    element.controls['expandFlag'].setValue(!clickedRecordState);
                }
            });
        }
        else {
            this.openPopup();
        }
    }
    showError(errs) {
        if (errs.length > 0) {
            this.showErrors = true;
        }
        else {
            this.showErrors = false;
        }
    }
    disableAddButton() {
        return (this.recordFormGroup.dirty || !this.recordFormGroup.valid || this.errorList?.length > 0);
    }
    openPopup() {
        jQuery("#" + this.popupId).trigger("open.wb-overlay");
    }
    get recordFormArray() {
        return this.recordFormGroup.get(this.records);
    }
    getRecordInfo(recordFormGroup) {
        return recordFormGroup.get(this.recordInfo);
    }
    getRecordFormArrValues() {
        return this.recordFormArray.value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, deps: [{ token: i1.FormBuilder }, { token: BaseListService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: BaseListComponent, selector: "ng-component", inputs: { recordList: "recordList", showErrors: "showErrors", isInternal: "isInternal" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }], ctorParameters: () => [{ type: i1.FormBuilder }, { type: i2.BaseListService, decorators: [{
                    type: Inject,
                    args: [BaseListService]
                }] }], propDecorators: { recordList: [{
                type: Input
            }], showErrors: [{
                type: Input
            }], isInternal: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5saXN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3JlY29yZC9iYXNlLWxpc3QtY29tcG9uZW50L2Jhc2UubGlzdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFpQixTQUFTLEVBQVUsTUFBTSxFQUFFLEtBQUssRUFBb0MsTUFBTSxlQUFlLENBQUM7QUFLbEgsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHdDQUF3QyxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQTs7OztBQU9uRSxNQUFNLE9BQWdCLGlCQUEwQyxTQUFRLGFBQWE7SUFlakYsWUFBb0IsR0FBZ0IsRUFDRyxXQUE0QjtRQUMvRCxLQUFLLEVBQUUsQ0FBQztRQUZRLFFBQUcsR0FBSCxHQUFHLENBQWE7UUFDRyxnQkFBVyxHQUFYLFdBQVcsQ0FBaUI7SUFFbkUsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ25ELENBQUM7SUFDTCxDQUFDO0lBRU8sS0FBSyxDQUFDLFVBQWU7UUFDekIsMEJBQTBCO1FBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFN0IsSUFBSSxVQUFVLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN4QyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzFCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNmLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7b0JBQ25DLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUVqRSw4Q0FBOEM7b0JBQzlDLEtBQUssQ0FBQyxVQUFVLENBQUM7d0JBQ2YsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO3dCQUNiLFFBQVEsRUFBRSxLQUFLLEdBQUcsQ0FBQzt3QkFDbkIsS0FBSyxFQUFFLEtBQUs7d0JBQ1osVUFBVSxFQUFFLEtBQUs7cUJBQ2xCLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUMxQyxJQUFJLENBQUMseUJBQXlCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUV6RSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDakMseURBQXlEO29CQUN6RCxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUM3QyxDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLCtCQUErQixFQUFFLENBQUM7WUFDekMsQ0FBQztRQUNMLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDbkIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2pFLEtBQUssQ0FBQyxVQUFVLENBQUM7b0JBQ2IsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFO2lCQUNyQyxDQUFDLENBQUE7Z0JBQ0YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2pDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBYyxDQUFDO2dCQUNoRSxlQUFlLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMxRCxDQUFDO1FBQ0gsQ0FBQztRQUNELElBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUMsQ0FBQztRQUV6RSw4QkFBOEI7UUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUF1QixDQUFDLENBQUM7SUFDekUsQ0FBQztJQU1ELFNBQVM7UUFDTCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNqRSxLQUFLLENBQUMsVUFBVSxDQUFDO1lBQ2IsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFO1NBQ3JDLENBQUMsQ0FBQTtRQUNGLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNqQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzFCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBb0IsQ0FBQztRQUNoRSxxRkFBcUY7UUFDckYsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLENBQUEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFBO1FBQ3hGLEtBQUssQ0FBQyxVQUFVLENBQUM7WUFDakIsRUFBRSxFQUFFLEVBQUU7WUFDTixLQUFLLEVBQUUsS0FBSztZQUNaLFVBQVUsRUFBRSxLQUFLLEVBQUssdUJBQXVCO1NBQzVDLENBQUMsQ0FBQztRQUNILE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0MsOERBQThEO1FBQzlELEtBQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZELElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRVMsd0JBQXdCO1FBQzlCLDZCQUE2QjtRQUM3QixLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7WUFDM0UsTUFBTSxLQUFLLEdBQW9CLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBb0IsQ0FBQztZQUN2RixJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDbkIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ2pDLE1BQU07WUFDVCxDQUFDO1FBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBYTtRQUN0QixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQW9CLENBQUM7UUFDaEUsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3QyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFckMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBVTtRQUNwQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3pCLE1BQU0sRUFBRSxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDcEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFvQixDQUFDO1FBQ2hFLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0MsaUNBQWlDO1FBQ2pDLE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDekQsVUFBVSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsY0FBYyxDQUFDLEtBQVU7UUFDckIsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUNqQyxNQUFNLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDdkMsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBRSxDQUFDLE9BQWtCLEVBQUUsS0FBYSxFQUFFLEVBQUU7Z0JBQ3pFLElBQUksWUFBWSxLQUFHLEtBQUssRUFBRSxDQUFDO29CQUMzQixPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUE7Z0JBQzVELENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQTtRQUNGLENBQUM7YUFBTSxDQUFDO1lBQ1IsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLENBQUM7SUFDTCxDQUFDO0lBRUQsU0FBUyxDQUFDLElBQVM7UUFDZixJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFDM0IsQ0FBQzthQUFNLENBQUM7WUFDSixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUM1QixDQUFDO0lBQ0wsQ0FBQztJQUVELGdCQUFnQjtRQUNaLE9BQU8sQ0FBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxJQUFLLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3ZHLENBQUM7SUFFRCxTQUFTO1FBQ0wsTUFBTSxDQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFFLENBQUMsT0FBTyxDQUFFLGlCQUFpQixDQUFFLENBQUM7SUFDOUQsQ0FBQztJQUVELElBQUksZUFBZTtRQUNmLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBYyxDQUFDO0lBQy9ELENBQUM7SUFFRCxhQUFhLENBQUMsZUFBMEI7UUFDcEMsT0FBTyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQWMsQ0FBQztJQUM3RCxDQUFDO0lBRUQsc0JBQXNCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7SUFDdEMsQ0FBQzsrR0EzS2lCLGlCQUFpQiw2Q0FnQnZCLGVBQWU7bUdBaEJULGlCQUFpQiwwTEFGekIsRUFBRTs7NEZBRU0saUJBQWlCO2tCQUh0QyxTQUFTO21CQUFDO29CQUNQLFFBQVEsRUFBRSxFQUFFO2lCQUNmOzswQkFpQlEsTUFBTTsyQkFBQyxlQUFlO3lDQWZsQixVQUFVO3NCQUFsQixLQUFLO2dCQUNHLFVBQVU7c0JBQWxCLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgaW5qZWN0LCBJbmplY3QsIElucHV0LCBPbkNoYW5nZXMsIE9uSW5pdCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IElCYXNlTGlzdCB9IGZyb20gXCIuL2Jhc2UubGlzdC5pbnRlcmZhY2VcIjtcclxuaW1wb3J0IHsgRm9ybUdyb3VwLCBGb3JtQXJyYXksIEZvcm1CdWlsZGVyIH0gZnJvbSBcIkBhbmd1bGFyL2Zvcm1zXCI7XHJcbmltcG9ydCB7IElSZWNvcmRTZXJ2aWNlIH0gZnJvbSBcIi4uL3JlY29yZC1zZXJ2aWNlL3JlY29yZC5zZXJ2aWNlLmludGVyZmFjZVwiO1xyXG5pbXBvcnQgeyBPdXRwdXRSZWNvcmQsIFJlY29yZEZvcm1Hcm91cCB9IGZyb20gXCIuLi9yZWNvcmQtbW9kZWwvcmVjb3JkLm1vZGVsXCI7XHJcbmltcG9ydCB7IEJhc2VMaXN0U2VydmljZSB9IGZyb20gXCIuLi9iYXNlLWxpc3Qtc2VydmljZS9iYXNlLmxpc3Quc2VydmljZVwiO1xyXG5pbXBvcnQgeyBCYXNlQ29tcG9uZW50IH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudC1iYXNlL2Jhc2UuY29tcG9uZW50XCJcclxuXHJcbmltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHRlbXBsYXRlOiAnJ1xyXG59KVxyXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgQmFzZUxpc3RDb21wb25lbnQ8VCBleHRlbmRzIE91dHB1dFJlY29yZD4gZXh0ZW5kcyBCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgSUJhc2VMaXN0PFQ+LCBBZnRlclZpZXdJbml0IHtcclxuICAgIEBJbnB1dCgpIHJlY29yZExpc3Q6IFRbXTtcclxuICAgIEBJbnB1dCgpIHNob3dFcnJvcnM6IGJvb2xlYW47XHJcbiAgICBASW5wdXQoKSBpc0ludGVybmFsPzogYm9vbGVhbjtcclxuXHJcbiAgICByZWNvcmRGb3JtR3JvdXA6IEZvcm1Hcm91cDtcclxuICAgIGVycm9yU3VtbWFyeUNoaWxkOiBhbnk7XHJcblxyXG4gICAgYWJzdHJhY3Qgc3RhdHVzTWVzc2FnZSA6IHN0cmluZztcclxuICAgIGFic3RyYWN0IHJlY29yZHM6IHN0cmluZztcclxuICAgIGFic3RyYWN0IHJlY29yZEluZm86IHN0cmluZztcclxuICAgIGFic3RyYWN0IHJlY29yZFNlcnZpY2U6IElSZWNvcmRTZXJ2aWNlO1xyXG4gICAgYWJzdHJhY3QgcG9wdXBJZDogc3RyaW5nO1xyXG4gICAgYWJzdHJhY3QgZXJyb3JMaXN0OiBbXTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9mYjogRm9ybUJ1aWxkZXIsIFxyXG4gICAgICAgIEBJbmplY3QoQmFzZUxpc3RTZXJ2aWNlKSBwcm90ZWN0ZWQgbGlzdFNlcnZpY2U6IEJhc2VMaXN0U2VydmljZSkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChjaGFuZ2VzWydyZWNvcmRMaXN0J10pIHtcclxuICAgICAgICAgICAgdGhpcy5faW5pdChjaGFuZ2VzWydyZWNvcmRMaXN0J10uY3VycmVudFZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdChyZWNvcmREYXRhOiBUW10pIHtcclxuICAgICAgICAvLyBDbGVhciBleGlzdGluZyBjb250cm9sc1xyXG4gICAgICB0aGlzLnJlY29yZEZvcm1BcnJheS5jbGVhcigpO1xyXG4gIFxyXG4gICAgICBpZiAocmVjb3JkRGF0YSAmJiByZWNvcmREYXRhLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgaWYgKHJlY29yZERhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBsZXQgbWF4SWQgPSAtMTtcclxuICAgICAgICAgICAgcmVjb3JkRGF0YS5mb3JFYWNoKChyZWNvcmQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgZ3JvdXAgPSB0aGlzLnJlY29yZFNlcnZpY2UuY3JlYXRlUmVjb3JkRm9ybUdyb3VwKHRoaXMuX2ZiKTtcclxuICBcclxuICAgICAgICAgICAgICAvLyBTZXQgdmFsdWVzIGFmdGVyIGRlZmluaW5nIHRoZSBmb3JtIGNvbnRyb2xzXHJcbiAgICAgICAgICAgICAgZ3JvdXAucGF0Y2hWYWx1ZSh7XHJcbiAgICAgICAgICAgICAgICBpZDogcmVjb3JkLmlkLFxyXG4gICAgICAgICAgICAgICAgcmVjb3JkSWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICAgIGlzTmV3OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGV4cGFuZEZsYWc6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHRoaXMuX3BhdGNoUmVjb3JkSW5mb1ZhbHVlKGdyb3VwLCByZWNvcmQpO1xyXG4gICAgICAgICAgICAgIHRoaXMuX3BhdGNoTGFzdFNhdmVkU3RhdGVWYWx1ZShncm91cC5jb250cm9sc1snbGFzdFNhdmVkU3RhdGUnXSwgcmVjb3JkKTtcclxuICBcclxuICAgICAgICAgICAgICB0aGlzLnJlY29yZEZvcm1BcnJheS5wdXNoKGdyb3VwKTtcclxuICAgICAgICAgICAgICAvLyBQYXJzZSB0aGUgSUQgYXMgYSBudW1iZXIgYW5kIHVwZGF0ZSBtYXhJZCBpZiBuZWNlc3NhcnlcclxuICAgICAgICAgICAgICBtYXhJZCA9IE1hdGgubWF4KE51bWJlcihyZWNvcmQuaWQpLCBtYXhJZCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLmxpc3RTZXJ2aWNlLnNldE1heElkKG1heElkKTtcclxuICAgICAgICAgICAgdGhpcy5fZXhwYW5kSW52YWxpZFJlY29yZFVwb25Mb2FkaW5nKCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzSW50ZXJuYWwpIHtcclxuICAgICAgICAgICAgY29uc3QgZ3JvdXAgPSB0aGlzLnJlY29yZFNlcnZpY2UuY3JlYXRlUmVjb3JkRm9ybUdyb3VwKHRoaXMuX2ZiKTtcclxuICAgICAgICAgICAgZ3JvdXAucGF0Y2hWYWx1ZSh7XHJcbiAgICAgICAgICAgICAgICByZWNvcmRJZDogdGhpcy5saXN0U2VydmljZS5nZXRJZCgpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LnB1c2goZ3JvdXApO1xyXG4gICAgICAgICAgICBjb25zdCBmaXJzdEZvcm1SZWNvcmQgPSB0aGlzLnJlY29yZEZvcm1BcnJheS5hdCgwKSBhcyBGb3JtR3JvdXA7XHJcbiAgICAgICAgICAgIGZpcnN0Rm9ybVJlY29yZC5jb250cm9sc1snZXhwYW5kRmxhZyddLnNldFZhbHVlKHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICB0aGlzLnJlY29yZFNlcnZpY2Uuc2V0UmVjb3Jkc0Zvcm1BcnJWYWx1ZSh0aGlzLmdldFJlY29yZEZvcm1BcnJWYWx1ZXMoKSk7XHJcbiAgXHJcbiAgICAgIC8vIFNldCB0aGUgbGlzdCBvZiBmb3JtIGdyb3Vwc1xyXG4gICAgICB0aGlzLmxpc3RTZXJ2aWNlLnNldExpc3QodGhpcy5yZWNvcmRGb3JtQXJyYXkuY29udHJvbHMgYXMgRm9ybUdyb3VwW10pO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBhYnN0cmFjdCBfZXhwYW5kSW52YWxpZFJlY29yZFVwb25Mb2FkaW5nKCk7XHJcbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgX3BhdGNoUmVjb3JkSW5mb1ZhbHVlKGdyb3VwLCBvdXRwdXRNb2RlbCk7XHJcbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgX3BhdGNoTGFzdFNhdmVkU3RhdGVWYWx1ZShsYXN0U2F2ZWRTdGF0ZUZvcm1Db250cm9sLCBvdXRwdXRNb2RlbCk7XHJcblxyXG4gICAgYWRkUmVjb3JkKCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRTZXJ2aWNlLmNyZWF0ZVJlY29yZEZvcm1Hcm91cCh0aGlzLl9mYik7XHJcbiAgICAgICAgZ3JvdXAucGF0Y2hWYWx1ZSh7XHJcbiAgICAgICAgICAgIHJlY29yZElkOiB0aGlzLmxpc3RTZXJ2aWNlLmdldElkKClcclxuICAgICAgICB9KVxyXG4gICAgICAgIHRoaXMucmVjb3JkRm9ybUFycmF5LnB1c2goZ3JvdXApOyAgICBcclxuICAgIH1cclxuXHJcbiAgICBzYXZlUmVjb3JkKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IGV2ZW50LmluZGV4O1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoaW5kZXgpIGFzIFJlY29yZEZvcm1Hcm91cDtcclxuICAgICAgICAvLyBpZiB0aGlzIGlzIGEgbmV3IHJlY29yZCwgYXNzaWduIG5leHQgYXZhaWxhYmxlIGlkLCBvdGhlcndpc2UsIHVzZSBpdCdzIGV4aXN0aW5nIGlkXHJcbiAgICAgICAgY29uc3QgaWQgPSBncm91cC5nZXQoJ2lzTmV3JykudmFsdWU/IHRoaXMubGlzdFNlcnZpY2UuZ2V0TmV4dElkKCk6IGdyb3VwLmdldCgnaWQnKS52YWx1ZVxyXG4gICAgICAgIGdyb3VwLnBhdGNoVmFsdWUoeyBcclxuICAgICAgICBpZDogaWQsXHJcbiAgICAgICAgaXNOZXc6IGZhbHNlLFxyXG4gICAgICAgIGV4cGFuZEZsYWc6IGZhbHNlLCAgICAvLyBjb2xsYXBzZSB0aGlzIHJlY29yZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnN0IHJlY29yZEluZm8gPSB0aGlzLmdldFJlY29yZEluZm8oZ3JvdXApO1xyXG4gICAgICAgIC8vIFVwZGF0ZSBsYXN0U2F2ZWRTdGF0ZSB3aXRoIHRoZSBjdXJyZW50IHZhbHVlIG9mIGNvbnRhY3RJbmZvXHJcbiAgICAgICAgZ3JvdXAuZ2V0KCdsYXN0U2F2ZWRTdGF0ZScpLnNldFZhbHVlKHJlY29yZEluZm8udmFsdWUpO1xyXG4gICAgICAgIHRoaXMuX2V4cGFuZE5leHRJbnZhbGlkUmVjb3JkKCk7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRTZXJ2aWNlLnNldFJlY29yZHNGb3JtQXJyVmFsdWUodGhpcy5nZXRSZWNvcmRGb3JtQXJyVmFsdWVzKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBfZXhwYW5kTmV4dEludmFsaWRSZWNvcmQoKXtcclxuICAgICAgICAvLyBleHBhbmQgbmV4dCBpbnZhbGlkIHJlY29yZFxyXG4gICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB0aGlzLnJlY29yZEZvcm1BcnJheS5jb250cm9scy5sZW5ndGg7IGluZGV4KyspIHtcclxuICAgICAgICAgY29uc3QgZ3JvdXA6IFJlY29yZEZvcm1Hcm91cCA9IHRoaXMucmVjb3JkRm9ybUFycmF5LmNvbnRyb2xzW2luZGV4XSBhcyBSZWNvcmRGb3JtR3JvdXA7XHJcbiAgICAgICAgIGlmIChncm91cC5pbnZhbGlkKSB7XHJcbiAgICAgICAgICBncm91cC5jb250cm9sc1snZXhwYW5kRmxhZyddLnNldFZhbHVlKHRydWUpO1xyXG4gICAgICAgICAgdGhpcy5yZWNvcmRGb3JtR3JvdXAubWFya0FzRGlydHkoKTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgIH0gXHJcbiAgICAgICB9ICAgICBcclxuICAgIH1cclxuXHJcbiAgICBkZWxldGVSZWNvcmQoaW5kZXg6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGdyb3VwID0gdGhpcy5yZWNvcmRGb3JtQXJyYXkuYXQoaW5kZXgpIGFzIFJlY29yZEZvcm1Hcm91cDtcclxuICAgICAgICBjb25zdCByZWNvcmRJbmZvID0gdGhpcy5nZXRSZWNvcmRJbmZvKGdyb3VwKTtcclxuICAgICAgICByZWNvcmRJbmZvLnJlc2V0KCk7XHJcbiAgICAgICAgdGhpcy5yZWNvcmRGb3JtQXJyYXkucmVtb3ZlQXQoaW5kZXgpO1xyXG4gICAgXHJcbiAgICAgICAgdGhpcy5yZWNvcmRTZXJ2aWNlLnNldFJlY29yZHNGb3JtQXJyVmFsdWUodGhpcy5nZXRSZWNvcmRGb3JtQXJyVmFsdWVzKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmVydFJlY29yZChldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICBjb25zdCBpbmRleCA9IGV2ZW50LmluZGV4O1xyXG4gICAgICAgIGNvbnN0IGlkID0gZXZlbnQuaWQ7XHJcbiAgICAgICAgY29uc3QgZ3JvdXAgPSB0aGlzLnJlY29yZEZvcm1BcnJheS5hdChpbmRleCkgYXMgUmVjb3JkRm9ybUdyb3VwO1xyXG4gICAgICAgIGNvbnN0IHJlY29yZEluZm8gPSB0aGlzLmdldFJlY29yZEluZm8oZ3JvdXApO1xyXG4gICAgICAgIC8vIFJldmVydCB0byB0aGUgbGFzdCBzYXZlZCBzdGF0ZVxyXG4gICAgICAgIGNvbnN0IGxhc3RTYXZlZFN0YXRlID0gZ3JvdXAuZ2V0KCdsYXN0U2F2ZWRTdGF0ZScpLnZhbHVlO1xyXG4gICAgICAgIHJlY29yZEluZm8ucGF0Y2hWYWx1ZShsYXN0U2F2ZWRTdGF0ZSk7IFxyXG4gICAgfVxyXG5cclxuICAgIGhhbmRsZVJvd0NsaWNrKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBjbGlja2VkSW5kZXggPSBldmVudC5pbmRleDtcclxuICAgICAgICBjb25zdCBjbGlja2VkUmVjb3JkU3RhdGUgPSBldmVudC5zdGF0ZTtcclxuICAgICAgICBpZiAodGhpcy5yZWNvcmRGb3JtR3JvdXAucHJpc3RpbmUpIHtcclxuICAgICAgICB0aGlzLnJlY29yZEZvcm1BcnJheS5jb250cm9scy5mb3JFYWNoKCAoZWxlbWVudDogRm9ybUdyb3VwLCBpbmRleDogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChjbGlja2VkSW5kZXg9PT1pbmRleCkge1xyXG4gICAgICAgICAgICBlbGVtZW50LmNvbnRyb2xzWydleHBhbmRGbGFnJ10uc2V0VmFsdWUoIWNsaWNrZWRSZWNvcmRTdGF0ZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLm9wZW5Qb3B1cCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzaG93RXJyb3IoZXJyczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKGVycnMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dFcnJvcnMgPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd0Vycm9ycyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgZGlzYWJsZUFkZEJ1dHRvbigpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKCB0aGlzLnJlY29yZEZvcm1Hcm91cC5kaXJ0eSB8fCAhdGhpcy5yZWNvcmRGb3JtR3JvdXAudmFsaWQgIHx8IHRoaXMuZXJyb3JMaXN0Py5sZW5ndGggPiAwKTtcclxuICAgIH1cclxuXHJcbiAgICBvcGVuUG9wdXAoKTogdm9pZCB7XHJcbiAgICAgICAgalF1ZXJ5KCBcIiNcIiArIHRoaXMucG9wdXBJZCApLnRyaWdnZXIoIFwib3Blbi53Yi1vdmVybGF5XCIgKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXQgcmVjb3JkRm9ybUFycmF5KCk6IEZvcm1BcnJheSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucmVjb3JkRm9ybUdyb3VwLmdldCh0aGlzLnJlY29yZHMpIGFzIEZvcm1BcnJheTtcclxuICAgIH1cclxuXHJcbiAgICBnZXRSZWNvcmRJbmZvKHJlY29yZEZvcm1Hcm91cDogRm9ybUdyb3VwKTogRm9ybUdyb3VwIHtcclxuICAgICAgICByZXR1cm4gcmVjb3JkRm9ybUdyb3VwLmdldCh0aGlzLnJlY29yZEluZm8pIGFzIEZvcm1Hcm91cDtcclxuICAgIH1cclxuXHJcbiAgICBnZXRSZWNvcmRGb3JtQXJyVmFsdWVzKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZEZvcm1BcnJheS52YWx1ZTtcclxuICAgIH1cclxuICAgIFxyXG59Il19