import { Component, Input, ViewEncapsulation } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../err.message.service";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
export class ControlMessagesComponent {
    constructor(_errMessageService) {
        this._errMessageService = _errMessageService;
        this.errorParams = {};
        // this.tabSet = null;
        this.tabId = null;
        this._errorVisible = false;
    }
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['showError']) {
            this._errorVisible = changes['showError'].currentValue;
            this.makeErrorVisible();
        }
    }
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage() {
        for (let propertyName in this.control.errors) {
            this.currentError = propertyName;
            // values to replace placeholders in the error message if they exist. eg "Minimum length {{ requiredLength }} numbers"
            this.errorParams = this.control.errors[propertyName];
            // console.log(propertyName, Object.keys(this.errorParams).length, JSON.stringify(this.errorParams))
            return this._errMessageService.getValidatorErrorMessageKey(propertyName);
        }
        this.currentError = '';
        return null;
    }
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible() {
        const test = ((this.control.invalid && this.control.touched && this.control.dirty) || (this.control.invalid && this._errorVisible));
        return test;
    }
    isCanadianPostalCode() {
        const controlName = this.controlId?.toLowerCase() || '';
        const labelText = this.label?.toLowerCase() || '';
        return controlName.includes('postal') && labelText.includes('postal') && this.control?.errors?.['pattern'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, deps: [{ token: i1.ErrMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: ControlMessagesComponent, selector: "control-messages", inputs: { control: "control", showError: "showError", label: "label", controlId: "controlId", parentId: "parentId", parentLabel: "parentLabel", translatedParentLabel: "translatedParentLabel", index: "index", ariaMessage: "ariaMessage" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\" attr.aria-label=\"{{ariaMessage}}\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'control-messages', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\" attr.aria-label=\"{{ariaMessage}}\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.ErrMessageService }], propDecorators: { control: [{
                type: Input
            }], showError: [{
                type: Input
            }], label: [{
                type: Input
            }], controlId: [{
                type: Input
            }], parentId: [{
                type: Input
            }], parentLabel: [{
                type: Input
            }], translatedParentLabel: [{
                type: Input
            }], index: [{
                type: Input
            }], ariaMessage: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udHJvbC1tZXNzYWdlcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9lcnJvci1tc2cvY29udHJvbC1tZXNzYWdlcy9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2Vycm9yLW1zZy9jb250cm9sLW1lc3NhZ2VzL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBRSxLQUFLLEVBQTJCLGlCQUFpQixFQUFTLE1BQU0sZUFBZSxDQUFDOzs7OztBQWFuRyxNQUFNLE9BQU8sd0JBQXdCO0lBd0VuQyxZQUFvQixrQkFBcUM7UUFBckMsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFtQjtRQVBsRCxnQkFBVyxHQUE2QixFQUFFLENBQUM7UUFRaEQsc0JBQXNCO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxXQUFXLENBQUMsT0FBc0I7UUFFaEMsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUM7WUFDdkQsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxZQUFZO1FBQ2QsS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1lBQ2pDLHNIQUFzSDtZQUN0SCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3JELG9HQUFvRztZQUVwRyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7UUFDdkIsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZ0JBQWdCO1FBQ2QsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztRQUNwSSxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRCxvQkFBb0I7UUFDbEIsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFDeEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFDbEQsT0FBTyxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM3RyxDQUFDOytHQXpIVSx3QkFBd0I7bUdBQXhCLHdCQUF3QiwyVENickMsOFpBVUE7OzRGREdhLHdCQUF3QjtrQkFQcEMsU0FBUzsrQkFDRSxrQkFBa0IsaUJBR2IsaUJBQWlCLENBQUMsSUFBSTtzRkFRNUIsT0FBTztzQkFBZixLQUFLO2dCQUtHLFNBQVM7c0JBQWpCLEtBQUs7Z0JBSUcsS0FBSztzQkFBYixLQUFLO2dCQUlHLFNBQVM7c0JBQWpCLEtBQUs7Z0JBSUcsUUFBUTtzQkFBaEIsS0FBSztnQkFJRyxXQUFXO3NCQUFuQixLQUFLO2dCQUlHLHFCQUFxQjtzQkFBN0IsS0FBSztnQkFJRyxLQUFLO3NCQUFiLEtBQUs7Z0JBS0csV0FBVztzQkFBbkIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBJbnB1dCwgT25DaGFuZ2VzLCBTaW1wbGVDaGFuZ2VzLFZpZXdFbmNhcHN1bGF0aW9uLCBpbmplY3R9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0Zvcm1Db250cm9sfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IFZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi4vLi4vdmFsaWRhdGlvbi92YWxpZGF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQge1RyYW5zbGF0ZVNlcnZpY2V9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xyXG5pbXBvcnQgeyBFcnJNZXNzYWdlU2VydmljZSB9IGZyb20gJy4uL2Vyci5tZXNzYWdlLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdjb250cm9sLW1lc3NhZ2VzJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vY29udHJvbC1tZXNzYWdlcy5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vY29udHJvbC1tZXNzYWdlcy5jb21wb25lbnQuY3NzJ10sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBDb250cm9sTWVzc2FnZXNDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xyXG5cclxuICAvKipcclxuICAgKiAgVGhlIHJlYWN0aXZlIGZvcm0gY29udHJvbCB0aGF0IHRoaXMgbWVzc2FnZSByZWxhdGVzXHJcbiAgICovXHJcbiAgQElucHV0KCkgY29udHJvbDogRm9ybUNvbnRyb2w7XHJcbiAgLyoqXHJcbiAgICogV2hlbiB0cnVlLCBpbmRpY2F0ZXMgdG8gc2hvdyB0aGUgZXJyb3IsIGV2ZW4gaWYgY29udHJvbCB3YXMgbm90IHRvdWNoZWRcclxuICAgKiBAdHlwZSB7Ym9vbGVhbn1cclxuICAgKi9cclxuICBASW5wdXQoKSBzaG93RXJyb3I6IGJvb2xlYW47XHJcbiAgLyoqXHJcbiAgICogTGFiZWwgbWVzc2FnZSBrZXkgdGhhdCBpcyBhc3NvY2lhdGVkIHRvIHRoZSBjb250cm9sLiBVc2VkIGZvciB0aGUgZXJyb3Igc3VtbWFyeVxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGxhYmVsOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogVGhlIGlkIG9mIHRoZSBjb250cm9sLiBVc2VkIGZvciB0aGUgZXJyb3Igc3VtbWFyeSB0byBjcmVhdGUgdGhlIGFuY2hvciBsaW5rXHJcbiAgICovXHJcbiAgQElucHV0KCkgY29udHJvbElkOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogVGhlIGlkIG9mIHRoZSBwYXJlbnQgb2YgdGhlIGNvbnRyb2wuIEZvciB0aGUgZXJyb3Igc3VtbWFyeSBjb21wb25uZXQsIGN1cnJlbnRseSBub3QgdXNlZD9cclxuICAgKi9cclxuICBASW5wdXQoKSBwYXJlbnRJZDogc3RyaW5nO1xyXG4gIC8qKlxyXG4gICAqIFRoZSBsYWJlbCBtZXNzYWdlIGtleSBvZiB0aGUgcGFyZW50IG9mIGh0ZSBjb250cm9sIC4gVXNlZCBmb3IgdGhlIGVycm9yIHN1bW1hcnkgY29tcG9uZW50LiBDdXJyZW50bHkgbm90IHVzZWQ/XHJcbiAgICovXHJcbiAgQElucHV0KCkgcGFyZW50TGFiZWw6IHN0cmluZztcclxuICAvKipcclxuICAgKiBUaGUgYWxyZWFkeSB0cmFuc2xhdGVkIGxhYmVsIG9mIHRoZSBwYXJlbnQgb2YgaHRlIGNvbnRyb2wgLiBVc2VkIGZvciB0aGUgZXJyb3Igc3VtbWFyeSBjb21wb25lbnQuIFxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIHRyYW5zbGF0ZWRQYXJlbnRMYWJlbDogc3RyaW5nO1xyXG4gIC8qKipcclxuICAgKiBJbmRleCBvZiB0aGUgZXJyb3IuIFVzZWQgdG8gZXhwYW5kIHRoZSBleHBhbmRlciBmb3IgdGhlIGVycm9yIHN1bW1hcnl0XHJcbiAgICovXHJcbiAgQElucHV0KCkgaW5kZXg6IE51bWJlcjtcclxuXHJcbiAgLyoqXHJcbiAgICogQXJpYSBsYWJlbCBmb3Igd2hlbiBzY3JlZW4gcmVhZGVyIG5lZWRzIHRvIGFubm91bmNlIHNvbWV0aGluZyBkaWZmZXJlbnQgZnJvbSBpbmxpbmUgZXJyb3IgbWVzc2FnZS5cclxuICAgKi9cclxuICBASW5wdXQoKSBhcmlhTWVzc2FnZSA6IHN0cmluZztcclxuXHJcbiAgIC8qKlxyXG4gICAqIE51bWJlciBvZiBlcnJvciBmcm9tIGVycm9yIHN1bW1hcnlcclxuICAgKi9cclxuICAgcHVibGljIGVycm9yTnVtYmVyOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogRmxhZyB0byBpbmRpY2F0ZSBpZiBlcnJvciBzdW1tYXJ5XHJcbiAgICovXHJcbiAgcHVibGljIGVycm9yU3VtbWFyeUZsYWc6IGJvb2xlYW47ICAgXHJcbiAgLyoqXHJcbiAgICogQ3VycmVudCBlcnJvciB0eXBlIGZvciB0aGUgY29udHJvbFxyXG4gICAqIEB0eXBlIHtzdHJpbmd9XHJcbiAgICovXHJcbiAgcHVibGljIGN1cnJlbnRFcnJvcjogc3RyaW5nIDtcclxuICAvKipcclxuICAgKiAgQSByZWZlcmVuY2UgdGhlIHRhYnNldCBjb250cm9sIE5nYlRhYnNldCBmcm9tIEFuZ3VsYXIgYm9vdHN0cmFwXHJcbiAgICogQHR5cGUge251bGx9XHJcbiAgICovXHJcbiAgLy8gcHVibGljIHRhYlNldDogTmdiVGFic2V0O1xyXG4gIC8qKlxyXG4gICAqIFRoIGlkIG9mIHRoZSB0YXJnZXQgdGFiLCB0aGUgdGFiIGNvbnRhaW5pbmcgdGhlIGVycm9yXHJcbiAgICogQHR5cGUgKHN0cmluZylcclxuICAgKi9cclxuICBwdWJsaWMgdGFiSWQ6IHN0cmluZztcclxuXHJcbiAgcHVibGljIGVycm9yUGFyYW1zOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9PSB7fTtcclxuICAvKipcclxuICAgKiBjb250cm9scyB2aXNpYmxpdHlcclxuICAgKiBAdHlwZSBib29sZWFuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBfZXJyb3JWaXNpYmxlOiBib29sZWFuO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Vyck1lc3NhZ2VTZXJ2aWNlOiBFcnJNZXNzYWdlU2VydmljZSkge1xyXG4gICAgLy8gdGhpcy50YWJTZXQgPSBudWxsO1xyXG4gICAgdGhpcy50YWJJZCA9IG51bGw7XHJcbiAgICB0aGlzLl9lcnJvclZpc2libGUgPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoYW5nZSBldmVudCBwcm9jZXNzaW5nIGZyb20gaW5wdXRzXHJcbiAgICogQHBhcmFtIHtTaW1wbGVDaGFuZ2VzfSBjaGFuZ2VzXHJcbiAgICovXHJcbiAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG5cclxuICAgIGlmIChjaGFuZ2VzWydzaG93RXJyb3InXSkge1xyXG4gICAgICB0aGlzLl9lcnJvclZpc2libGUgPSBjaGFuZ2VzWydzaG93RXJyb3InXS5jdXJyZW50VmFsdWU7XHJcbiAgICAgIHRoaXMubWFrZUVycm9yVmlzaWJsZSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyB0aGUgRXJyb3IgbWVzc2FnZSBrZXkgYW5kIGl0cyBwYXJhbWV0ZXIgdmFsdWVzIGZvciBhIGdpdmVuIGVycm9yIHR5cGUuXHJcbiAgICpcclxuICAgKiBAcmV0dXJucyB7YW55fVxyXG4gICAqL1xyXG4gIGdldCBlcnJvck1lc3NhZ2UoKSB7XHJcbiAgICBmb3IgKGxldCBwcm9wZXJ0eU5hbWUgaW4gdGhpcy5jb250cm9sLmVycm9ycykge1xyXG4gICAgICB0aGlzLmN1cnJlbnRFcnJvciA9IHByb3BlcnR5TmFtZTsgICAgICBcclxuICAgICAgLy8gdmFsdWVzIHRvIHJlcGxhY2UgcGxhY2Vob2xkZXJzIGluIHRoZSBlcnJvciBtZXNzYWdlIGlmIHRoZXkgZXhpc3QuIGVnIFwiTWluaW11bSBsZW5ndGgge3sgcmVxdWlyZWRMZW5ndGggfX0gbnVtYmVyc1wiXHJcbiAgICAgIHRoaXMuZXJyb3JQYXJhbXMgPSB0aGlzLmNvbnRyb2wuZXJyb3JzW3Byb3BlcnR5TmFtZV07ICAgXHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKHByb3BlcnR5TmFtZSwgT2JqZWN0LmtleXModGhpcy5lcnJvclBhcmFtcykubGVuZ3RoLCBKU09OLnN0cmluZ2lmeSh0aGlzLmVycm9yUGFyYW1zKSlcclxuXHJcbiAgICAgIHJldHVybiB0aGlzLl9lcnJNZXNzYWdlU2VydmljZS5nZXRWYWxpZGF0b3JFcnJvck1lc3NhZ2VLZXkocHJvcGVydHlOYW1lKTtcclxuICAgIH1cclxuICAgIHRoaXMuY3VycmVudEVycm9yID0gJyc7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnRyb2xzIHRoZSB2aXNpYmlsaXR5IG9mIGFuIGVycm9yXHJcbiAgICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAgICovXHJcbiAgbWFrZUVycm9yVmlzaWJsZSgpIHtcclxuICAgIGNvbnN0IHRlc3QgPSAoKHRoaXMuY29udHJvbC5pbnZhbGlkICYmIHRoaXMuY29udHJvbC50b3VjaGVkICYmIHRoaXMuY29udHJvbC5kaXJ0eSkgfHwgKHRoaXMuY29udHJvbC5pbnZhbGlkICYmIHRoaXMuX2Vycm9yVmlzaWJsZSkpO1xyXG4gICAgcmV0dXJuIHRlc3Q7XHJcbiAgfVxyXG5cclxuICBpc0NhbmFkaWFuUG9zdGFsQ29kZSgpOiBib29sZWFuIHtcclxuICAgIGNvbnN0IGNvbnRyb2xOYW1lID0gdGhpcy5jb250cm9sSWQ/LnRvTG93ZXJDYXNlKCkgfHwgJyc7XHJcbiAgICBjb25zdCBsYWJlbFRleHQgPSB0aGlzLmxhYmVsPy50b0xvd2VyQ2FzZSgpIHx8ICcnO1xyXG4gICAgcmV0dXJuIGNvbnRyb2xOYW1lLmluY2x1ZGVzKCdwb3N0YWwnKSAmJiBsYWJlbFRleHQuaW5jbHVkZXMoJ3Bvc3RhbCcpICYmIHRoaXMuY29udHJvbD8uZXJyb3JzPy5bJ3BhdHRlcm4nXTtcclxuICB9XHJcbiAgXHJcblxyXG59XHJcblxyXG5cclxuXHJcbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJtYWtlRXJyb3JWaXNpYmxlKClcIj5cclxuICA8c3Ryb25nIGNsYXNzPVwiZXJyb3JcIj5cclxuICAgIDxzcGFuIGNsYXNzPVwibGFiZWwgbGFiZWwtZGFuZ2VyXCIgYXR0ci5hcmlhLWxhYmVsPVwie3thcmlhTWVzc2FnZX19XCI+XHJcbiAgICAgIEBpZihlcnJvclN1bW1hcnlGbGFnICYmIGVycm9yTnVtYmVyKSB7XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJwcmVmaXhcIj57eydlcnJvcicgfCB0cmFuc2xhdGU6IHtudW1iZXI6IGVycm9yTnVtYmVyfSB9fSZuYnNwOzwvc3Bhbj5cclxuICAgICAgfSBcclxuICAgICAge3tlcnJvck1lc3NhZ2UgfCB0cmFuc2xhdGU6IGVycm9yUGFyYW1zIH19XHJcbiAgICA8L3NwYW4+XHJcbiAgPC9zdHJvbmc+XHJcbjwvbmctY29udGFpbmVyPlxyXG4iXX0=