import { Component, Input, ViewEncapsulation } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../err.message.service";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
export class ControlMessagesComponent {
    constructor(_errMessageService) {
        this._errMessageService = _errMessageService;
        /**
         * For manually showing inline control message for disabled FormControl.
         */
        this.hasErrors = undefined;
        this.errorParams = {};
        // this.tabSet = null;
        this.tabId = null;
        this._errorVisible = false;
    }
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['showError']) {
            this._errorVisible = changes['showError'].currentValue;
            this.makeErrorVisible();
        }
    }
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage() {
        for (let propertyName in this.control.errors) {
            this.currentError = propertyName;
            // values to replace placeholders in the error message if they exist. eg "Minimum length {{ requiredLength }} numbers"
            this.errorParams = this.control.errors[propertyName];
            // console.log(propertyName, Object.keys(this.errorParams).length, JSON.stringify(this.errorParams))
            return this._errMessageService.getValidatorErrorMessageKey(propertyName);
        }
        this.currentError = '';
        return null;
    }
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible() {
        const hasManualError = this.hasErrors ?? false;
        if (hasManualError) {
            return ((this.control.invalid && this.control.touched && this.control.dirty) ||
                (this.control.invalid && this._errorVisible) || (this.hasErrors && this._errorVisible));
        }
        return (this.control.invalid && this.control.touched && this.control.dirty) || (this.control.invalid && this._errorVisible);
    }
    isCanadianPostalCode() {
        const controlName = this.controlId?.toLowerCase() || '';
        const labelText = this.label?.toLowerCase() || '';
        return controlName.includes('postal') && labelText.includes('postal') && this.control?.errors?.['pattern'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, deps: [{ token: i1.ErrMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: ControlMessagesComponent, selector: "control-messages", inputs: { control: "control", showError: "showError", label: "label", controlId: "controlId", parentId: "parentId", parentLabel: "parentLabel", translatedParentLabel: "translatedParentLabel", index: "index", hasErrors: "hasErrors" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'control-messages', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.ErrMessageService }], propDecorators: { control: [{
                type: Input
            }], showError: [{
                type: Input
            }], label: [{
                type: Input
            }], controlId: [{
                type: Input
            }], parentId: [{
                type: Input
            }], parentLabel: [{
                type: Input
            }], translatedParentLabel: [{
                type: Input
            }], index: [{
                type: Input
            }], hasErrors: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udHJvbC1tZXNzYWdlcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9lcnJvci1tc2cvY29udHJvbC1tZXNzYWdlcy9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2Vycm9yLW1zZy9jb250cm9sLW1lc3NhZ2VzL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBRSxLQUFLLEVBQTJCLGlCQUFpQixFQUFTLE1BQU0sZUFBZSxDQUFDOzs7OztBQWFuRyxNQUFNLE9BQU8sd0JBQXdCO0lBd0VuQyxZQUFvQixrQkFBcUM7UUFBckMsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFtQjtRQXBDekQ7O1dBRUc7UUFDTSxjQUFTLEdBQWEsU0FBUyxDQUFDO1FBMEJsQyxnQkFBVyxHQUE2QixFQUFFLENBQUM7UUFRaEQsc0JBQXNCO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxXQUFXLENBQUMsT0FBc0I7UUFFaEMsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUM7WUFDdkQsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxZQUFZO1FBQ2QsS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1lBQ2pDLHNIQUFzSDtZQUN0SCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3JELG9HQUFvRztZQUVwRyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7UUFDdkIsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZ0JBQWdCO1FBQ2QsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUM7UUFFL0MsSUFBSSxjQUFjLEVBQUUsQ0FBQztZQUNuQixPQUFPLENBQ0wsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDcEUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FDdkYsQ0FBQztRQUNKLENBQUM7UUFFRCxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUU5SCxDQUFDO0lBR0Qsb0JBQW9CO1FBQ2xCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ3hELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ2xELE9BQU8sV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDN0csQ0FBQzsrR0FuSVUsd0JBQXdCO21HQUF4Qix3QkFBd0IsdVRDYnJDLDBYQVVBOzs0RkRHYSx3QkFBd0I7a0JBUHBDLFNBQVM7K0JBQ0Usa0JBQWtCLGlCQUdiLGlCQUFpQixDQUFDLElBQUk7c0ZBUTVCLE9BQU87c0JBQWYsS0FBSztnQkFLRyxTQUFTO3NCQUFqQixLQUFLO2dCQUlHLEtBQUs7c0JBQWIsS0FBSztnQkFJRyxTQUFTO3NCQUFqQixLQUFLO2dCQUlHLFFBQVE7c0JBQWhCLEtBQUs7Z0JBSUcsV0FBVztzQkFBbkIsS0FBSztnQkFJRyxxQkFBcUI7c0JBQTdCLEtBQUs7Z0JBSUcsS0FBSztzQkFBYixLQUFLO2dCQUtHLFNBQVM7c0JBQWpCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcyxWaWV3RW5jYXBzdWxhdGlvbiwgaW5qZWN0fSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtGb3JtQ29udHJvbH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBWYWxpZGF0aW9uU2VydmljZSB9IGZyb20gJy4uLy4uL3ZhbGlkYXRpb24vdmFsaWRhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHtUcmFuc2xhdGVTZXJ2aWNlfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcclxuaW1wb3J0IHsgRXJyTWVzc2FnZVNlcnZpY2UgfSBmcm9tICcuLi9lcnIubWVzc2FnZS5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnY29udHJvbC1tZXNzYWdlcycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50LmNzcyddLFxyXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQ29udHJvbE1lc3NhZ2VzQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzIHtcclxuXHJcbiAgLyoqXHJcbiAgICogIFRoZSByZWFjdGl2ZSBmb3JtIGNvbnRyb2wgdGhhdCB0aGlzIG1lc3NhZ2UgcmVsYXRlc1xyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGNvbnRyb2w6IEZvcm1Db250cm9sO1xyXG4gIC8qKlxyXG4gICAqIFdoZW4gdHJ1ZSwgaW5kaWNhdGVzIHRvIHNob3cgdGhlIGVycm9yLCBldmVuIGlmIGNvbnRyb2wgd2FzIG5vdCB0b3VjaGVkXHJcbiAgICogQHR5cGUge2Jvb2xlYW59XHJcbiAgICovXHJcbiAgQElucHV0KCkgc2hvd0Vycm9yOiBib29sZWFuO1xyXG4gIC8qKlxyXG4gICAqIExhYmVsIG1lc3NhZ2Uga2V5IHRoYXQgaXMgYXNzb2NpYXRlZCB0byB0aGUgY29udHJvbC4gVXNlZCBmb3IgdGhlIGVycm9yIHN1bW1hcnlcclxuICAgKi9cclxuICBASW5wdXQoKSBsYWJlbDogc3RyaW5nO1xyXG4gIC8qKlxyXG4gICAqIFRoZSBpZCBvZiB0aGUgY29udHJvbC4gVXNlZCBmb3IgdGhlIGVycm9yIHN1bW1hcnkgdG8gY3JlYXRlIHRoZSBhbmNob3IgbGlua1xyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGNvbnRyb2xJZDogc3RyaW5nO1xyXG4gIC8qKlxyXG4gICAqIFRoZSBpZCBvZiB0aGUgcGFyZW50IG9mIHRoZSBjb250cm9sLiBGb3IgdGhlIGVycm9yIHN1bW1hcnkgY29tcG9ubmV0LCBjdXJyZW50bHkgbm90IHVzZWQ/XHJcbiAgICovXHJcbiAgQElucHV0KCkgcGFyZW50SWQ6IHN0cmluZztcclxuICAvKipcclxuICAgKiBUaGUgbGFiZWwgbWVzc2FnZSBrZXkgb2YgdGhlIHBhcmVudCBvZiBodGUgY29udHJvbCAuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5IGNvbXBvbmVudC4gQ3VycmVudGx5IG5vdCB1c2VkP1xyXG4gICAqL1xyXG4gIEBJbnB1dCgpIHBhcmVudExhYmVsOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogVGhlIGFscmVhZHkgdHJhbnNsYXRlZCBsYWJlbCBvZiB0aGUgcGFyZW50IG9mIGh0ZSBjb250cm9sIC4gVXNlZCBmb3IgdGhlIGVycm9yIHN1bW1hcnkgY29tcG9uZW50LiBcclxuICAgKi9cclxuICBASW5wdXQoKSB0cmFuc2xhdGVkUGFyZW50TGFiZWw6IHN0cmluZztcclxuICAvKioqXHJcbiAgICogSW5kZXggb2YgdGhlIGVycm9yLiBVc2VkIHRvIGV4cGFuZCB0aGUgZXhwYW5kZXIgZm9yIHRoZSBlcnJvciBzdW1tYXJ5dFxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGluZGV4OiBOdW1iZXI7XHJcblxyXG4gIC8qKlxyXG4gICAqIEZvciBtYW51YWxseSBzaG93aW5nIGlubGluZSBjb250cm9sIG1lc3NhZ2UgZm9yIGRpc2FibGVkIEZvcm1Db250cm9sLlxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIGhhc0Vycm9ycz86IGJvb2xlYW4gPSB1bmRlZmluZWQ7XHJcblxyXG4gICAvKipcclxuICAgKiBOdW1iZXIgb2YgZXJyb3IgZnJvbSBlcnJvciBzdW1tYXJ5XHJcbiAgICovXHJcbiAgIHB1YmxpYyBlcnJvck51bWJlcjogc3RyaW5nO1xyXG4gIC8qKlxyXG4gICAqIEZsYWcgdG8gaW5kaWNhdGUgaWYgZXJyb3Igc3VtbWFyeVxyXG4gICAqL1xyXG4gIHB1YmxpYyBlcnJvclN1bW1hcnlGbGFnOiBib29sZWFuOyAgIFxyXG4gIC8qKlxyXG4gICAqIEN1cnJlbnQgZXJyb3IgdHlwZSBmb3IgdGhlIGNvbnRyb2xcclxuICAgKiBAdHlwZSB7c3RyaW5nfVxyXG4gICAqL1xyXG4gIHB1YmxpYyBjdXJyZW50RXJyb3I6IHN0cmluZyA7XHJcbiAgLyoqXHJcbiAgICogIEEgcmVmZXJlbmNlIHRoZSB0YWJzZXQgY29udHJvbCBOZ2JUYWJzZXQgZnJvbSBBbmd1bGFyIGJvb3RzdHJhcFxyXG4gICAqIEB0eXBlIHtudWxsfVxyXG4gICAqL1xyXG4gIC8vIHB1YmxpYyB0YWJTZXQ6IE5nYlRhYnNldDtcclxuICAvKipcclxuICAgKiBUaCBpZCBvZiB0aGUgdGFyZ2V0IHRhYiwgdGhlIHRhYiBjb250YWluaW5nIHRoZSBlcnJvclxyXG4gICAqIEB0eXBlIChzdHJpbmcpXHJcbiAgICovXHJcbiAgcHVibGljIHRhYklkOiBzdHJpbmc7XHJcblxyXG4gIHB1YmxpYyBlcnJvclBhcmFtczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfT0ge307XHJcbiAgLyoqXHJcbiAgICogY29udHJvbHMgdmlzaWJsaXR5XHJcbiAgICogQHR5cGUgYm9vbGVhblxyXG4gICAqL1xyXG4gIHByaXZhdGUgX2Vycm9yVmlzaWJsZTogYm9vbGVhbjtcclxuICBcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9lcnJNZXNzYWdlU2VydmljZTogRXJyTWVzc2FnZVNlcnZpY2UpIHtcclxuICAgIC8vIHRoaXMudGFiU2V0ID0gbnVsbDtcclxuICAgIHRoaXMudGFiSWQgPSBudWxsO1xyXG4gICAgdGhpcy5fZXJyb3JWaXNpYmxlID0gZmFsc2U7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDaGFuZ2UgZXZlbnQgcHJvY2Vzc2luZyBmcm9tIGlucHV0c1xyXG4gICAqIEBwYXJhbSB7U2ltcGxlQ2hhbmdlc30gY2hhbmdlc1xyXG4gICAqL1xyXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuXHJcbiAgICBpZiAoY2hhbmdlc1snc2hvd0Vycm9yJ10pIHtcclxuICAgICAgdGhpcy5fZXJyb3JWaXNpYmxlID0gY2hhbmdlc1snc2hvd0Vycm9yJ10uY3VycmVudFZhbHVlO1xyXG4gICAgICB0aGlzLm1ha2VFcnJvclZpc2libGUoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldHMgdGhlIEVycm9yIG1lc3NhZ2Uga2V5IGFuZCBpdHMgcGFyYW1ldGVyIHZhbHVlcyBmb3IgYSBnaXZlbiBlcnJvciB0eXBlLlxyXG4gICAqXHJcbiAgICogQHJldHVybnMge2FueX1cclxuICAgKi9cclxuICBnZXQgZXJyb3JNZXNzYWdlKCkge1xyXG4gICAgZm9yIChsZXQgcHJvcGVydHlOYW1lIGluIHRoaXMuY29udHJvbC5lcnJvcnMpIHtcclxuICAgICAgdGhpcy5jdXJyZW50RXJyb3IgPSBwcm9wZXJ0eU5hbWU7ICAgICAgXHJcbiAgICAgIC8vIHZhbHVlcyB0byByZXBsYWNlIHBsYWNlaG9sZGVycyBpbiB0aGUgZXJyb3IgbWVzc2FnZSBpZiB0aGV5IGV4aXN0LiBlZyBcIk1pbmltdW0gbGVuZ3RoIHt7IHJlcXVpcmVkTGVuZ3RoIH19IG51bWJlcnNcIlxyXG4gICAgICB0aGlzLmVycm9yUGFyYW1zID0gdGhpcy5jb250cm9sLmVycm9yc1twcm9wZXJ0eU5hbWVdOyAgIFxyXG4gICAgICAvLyBjb25zb2xlLmxvZyhwcm9wZXJ0eU5hbWUsIE9iamVjdC5rZXlzKHRoaXMuZXJyb3JQYXJhbXMpLmxlbmd0aCwgSlNPTi5zdHJpbmdpZnkodGhpcy5lcnJvclBhcmFtcykpXHJcblxyXG4gICAgICByZXR1cm4gdGhpcy5fZXJyTWVzc2FnZVNlcnZpY2UuZ2V0VmFsaWRhdG9yRXJyb3JNZXNzYWdlS2V5KHByb3BlcnR5TmFtZSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmN1cnJlbnRFcnJvciA9ICcnO1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb250cm9scyB0aGUgdmlzaWJpbGl0eSBvZiBhbiBlcnJvclxyXG4gICAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gICAqL1xyXG4gIG1ha2VFcnJvclZpc2libGUoKTogYm9vbGVhbiB7XHJcbiAgICBjb25zdCBoYXNNYW51YWxFcnJvciA9IHRoaXMuaGFzRXJyb3JzID8/IGZhbHNlO1xyXG4gIFxyXG4gICAgaWYgKGhhc01hbnVhbEVycm9yKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgKHRoaXMuY29udHJvbC5pbnZhbGlkICYmIHRoaXMuY29udHJvbC50b3VjaGVkICYmIHRoaXMuY29udHJvbC5kaXJ0eSkgfHxcclxuICAgICAgICAodGhpcy5jb250cm9sLmludmFsaWQgJiYgdGhpcy5fZXJyb3JWaXNpYmxlKSB8fCAodGhpcy5oYXNFcnJvcnMgJiYgdGhpcy5fZXJyb3JWaXNpYmxlKVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgcmV0dXJuICh0aGlzLmNvbnRyb2wuaW52YWxpZCAmJiB0aGlzLmNvbnRyb2wudG91Y2hlZCAmJiB0aGlzLmNvbnRyb2wuZGlydHkpIHx8ICh0aGlzLmNvbnRyb2wuaW52YWxpZCAmJiB0aGlzLl9lcnJvclZpc2libGUpO1xyXG4gICAgXHJcbiAgfVxyXG4gIFxyXG5cclxuICBpc0NhbmFkaWFuUG9zdGFsQ29kZSgpOiBib29sZWFuIHtcclxuICAgIGNvbnN0IGNvbnRyb2xOYW1lID0gdGhpcy5jb250cm9sSWQ/LnRvTG93ZXJDYXNlKCkgfHwgJyc7XHJcbiAgICBjb25zdCBsYWJlbFRleHQgPSB0aGlzLmxhYmVsPy50b0xvd2VyQ2FzZSgpIHx8ICcnO1xyXG4gICAgcmV0dXJuIGNvbnRyb2xOYW1lLmluY2x1ZGVzKCdwb3N0YWwnKSAmJiBsYWJlbFRleHQuaW5jbHVkZXMoJ3Bvc3RhbCcpICYmIHRoaXMuY29udHJvbD8uZXJyb3JzPy5bJ3BhdHRlcm4nXTtcclxuICB9XHJcbiAgXHJcblxyXG59XHJcblxyXG5cclxuXHJcbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJtYWtlRXJyb3JWaXNpYmxlKClcIj5cclxuICA8c3Ryb25nIGNsYXNzPVwiZXJyb3JcIj5cclxuICAgIDxzcGFuIGNsYXNzPVwibGFiZWwgbGFiZWwtZGFuZ2VyXCI+XHJcbiAgICAgIEBpZihlcnJvclN1bW1hcnlGbGFnICYmIGVycm9yTnVtYmVyKSB7XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJwcmVmaXhcIj57eydlcnJvcicgfCB0cmFuc2xhdGU6IHtudW1iZXI6IGVycm9yTnVtYmVyfSB9fSZuYnNwOzwvc3Bhbj5cclxuICAgICAgfSBcclxuICAgICAge3tlcnJvck1lc3NhZ2UgfCB0cmFuc2xhdGU6IGVycm9yUGFyYW1zIH19XHJcbiAgICA8L3NwYW4+XHJcbiAgPC9zdHJvbmc+XHJcbjwvbmctY29udGFpbmVyPlxyXG4iXX0=