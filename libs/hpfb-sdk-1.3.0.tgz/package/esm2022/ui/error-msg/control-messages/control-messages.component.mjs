import { Component, Input, ViewEncapsulation } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../err.message.service";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
export class ControlMessagesComponent {
    constructor(_errMessageService) {
        this._errMessageService = _errMessageService;
        /**
         * For manually showing inline control message for disabled FormControl.
         */
        this.hasErrors = undefined;
        this.errorParams = {};
        // this.tabSet = null;
        this.tabId = null;
        this._errorVisible = false;
    }
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['showError']) {
            this._errorVisible = changes['showError'].currentValue;
            this.makeErrorVisible();
        }
    }
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage() {
        for (let propertyName in this.control.errors) {
            this.currentError = propertyName;
            // values to replace placeholders in the error message if they exist. eg "Minimum length {{ requiredLength }} numbers"
            this.errorParams = this.control.errors[propertyName];
            // console.log(propertyName, Object.keys(this.errorParams).length, JSON.stringify(this.errorParams))
            return this._errMessageService.getValidatorErrorMessageKey(propertyName);
        }
        this.currentError = '';
        return null;
    }
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible() {
        // If this.hasErrors (manual error check for disabled form group) is defined, check for this flag.
        const hasManualError = this.hasErrors ?? false;
        if (hasManualError) {
            return this.hasErrors && this._errorVisible || (this.hasErrors && !this.control.valid);
        }
        return (this.control.invalid && this.control.touched && this.control.dirty) || (this.control.invalid && this._errorVisible);
    }
    isCanadianPostalCode() {
        const controlName = this.controlId?.toLowerCase() || '';
        const labelText = this.label?.toLowerCase() || '';
        return controlName.includes('postal') && labelText.includes('postal') && this.control?.errors?.['pattern'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, deps: [{ token: i1.ErrMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: ControlMessagesComponent, selector: "control-messages", inputs: { control: "control", showError: "showError", label: "label", controlId: "controlId", parentId: "parentId", parentLabel: "parentLabel", translatedParentLabel: "translatedParentLabel", index: "index", hasErrors: "hasErrors" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'control-messages', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.ErrMessageService }], propDecorators: { control: [{
                type: Input
            }], showError: [{
                type: Input
            }], label: [{
                type: Input
            }], controlId: [{
                type: Input
            }], parentId: [{
                type: Input
            }], parentLabel: [{
                type: Input
            }], translatedParentLabel: [{
                type: Input
            }], index: [{
                type: Input
            }], hasErrors: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udHJvbC1tZXNzYWdlcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9lcnJvci1tc2cvY29udHJvbC1tZXNzYWdlcy9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2Vycm9yLW1zZy9jb250cm9sLW1lc3NhZ2VzL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBRSxLQUFLLEVBQTJCLGlCQUFpQixFQUFTLE1BQU0sZUFBZSxDQUFDOzs7OztBQWFuRyxNQUFNLE9BQU8sd0JBQXdCO0lBd0VuQyxZQUFvQixrQkFBcUM7UUFBckMsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFtQjtRQXBDekQ7O1dBRUc7UUFDTSxjQUFTLEdBQWEsU0FBUyxDQUFDO1FBMEJsQyxnQkFBVyxHQUE2QixFQUFFLENBQUM7UUFRaEQsc0JBQXNCO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxXQUFXLENBQUMsT0FBc0I7UUFFaEMsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUM7WUFDdkQsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxZQUFZO1FBQ2QsS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1lBQ2pDLHNIQUFzSDtZQUN0SCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3JELG9HQUFvRztZQUVwRyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7UUFDdkIsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZ0JBQWdCO1FBQ2Qsa0dBQWtHO1FBQ2xHLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDO1FBQy9DLElBQUksY0FBYyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN6RixDQUFDO1FBRUQsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFFOUgsQ0FBQztJQUdELG9CQUFvQjtRQUNsQixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUN4RCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUNsRCxPQUFPLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzdHLENBQUM7K0dBaElVLHdCQUF3QjttR0FBeEIsd0JBQXdCLHVUQ2JyQywwWEFVQTs7NEZER2Esd0JBQXdCO2tCQVBwQyxTQUFTOytCQUNFLGtCQUFrQixpQkFHYixpQkFBaUIsQ0FBQyxJQUFJO3NGQVE1QixPQUFPO3NCQUFmLEtBQUs7Z0JBS0csU0FBUztzQkFBakIsS0FBSztnQkFJRyxLQUFLO3NCQUFiLEtBQUs7Z0JBSUcsU0FBUztzQkFBakIsS0FBSztnQkFJRyxRQUFRO3NCQUFoQixLQUFLO2dCQUlHLFdBQVc7c0JBQW5CLEtBQUs7Z0JBSUcscUJBQXFCO3NCQUE3QixLQUFLO2dCQUlHLEtBQUs7c0JBQWIsS0FBSztnQkFLRyxTQUFTO3NCQUFqQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIElucHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMsVmlld0VuY2Fwc3VsYXRpb24sIGluamVjdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7Rm9ybUNvbnRyb2x9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgVmFsaWRhdGlvblNlcnZpY2UgfSBmcm9tICcuLi8uLi92YWxpZGF0aW9uL3ZhbGlkYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7VHJhbnNsYXRlU2VydmljZX0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XHJcbmltcG9ydCB7IEVyck1lc3NhZ2VTZXJ2aWNlIH0gZnJvbSAnLi4vZXJyLm1lc3NhZ2Uuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2NvbnRyb2wtbWVzc2FnZXMnLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC5jc3MnXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIENvbnRyb2xNZXNzYWdlc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XHJcblxyXG4gIC8qKlxyXG4gICAqICBUaGUgcmVhY3RpdmUgZm9ybSBjb250cm9sIHRoYXQgdGhpcyBtZXNzYWdlIHJlbGF0ZXNcclxuICAgKi9cclxuICBASW5wdXQoKSBjb250cm9sOiBGb3JtQ29udHJvbDtcclxuICAvKipcclxuICAgKiBXaGVuIHRydWUsIGluZGljYXRlcyB0byBzaG93IHRoZSBlcnJvciwgZXZlbiBpZiBjb250cm9sIHdhcyBub3QgdG91Y2hlZFxyXG4gICAqIEB0eXBlIHtib29sZWFufVxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIHNob3dFcnJvcjogYm9vbGVhbjtcclxuICAvKipcclxuICAgKiBMYWJlbCBtZXNzYWdlIGtleSB0aGF0IGlzIGFzc29jaWF0ZWQgdG8gdGhlIGNvbnRyb2wuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5XHJcbiAgICovXHJcbiAgQElucHV0KCkgbGFiZWw6IHN0cmluZztcclxuICAvKipcclxuICAgKiBUaGUgaWQgb2YgdGhlIGNvbnRyb2wuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5IHRvIGNyZWF0ZSB0aGUgYW5jaG9yIGxpbmtcclxuICAgKi9cclxuICBASW5wdXQoKSBjb250cm9sSWQ6IHN0cmluZztcclxuICAvKipcclxuICAgKiBUaGUgaWQgb2YgdGhlIHBhcmVudCBvZiB0aGUgY29udHJvbC4gRm9yIHRoZSBlcnJvciBzdW1tYXJ5IGNvbXBvbm5ldCwgY3VycmVudGx5IG5vdCB1c2VkP1xyXG4gICAqL1xyXG4gIEBJbnB1dCgpIHBhcmVudElkOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogVGhlIGxhYmVsIG1lc3NhZ2Uga2V5IG9mIHRoZSBwYXJlbnQgb2YgaHRlIGNvbnRyb2wgLiBVc2VkIGZvciB0aGUgZXJyb3Igc3VtbWFyeSBjb21wb25lbnQuIEN1cnJlbnRseSBub3QgdXNlZD9cclxuICAgKi9cclxuICBASW5wdXQoKSBwYXJlbnRMYWJlbDogc3RyaW5nO1xyXG4gIC8qKlxyXG4gICAqIFRoZSBhbHJlYWR5IHRyYW5zbGF0ZWQgbGFiZWwgb2YgdGhlIHBhcmVudCBvZiBodGUgY29udHJvbCAuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5IGNvbXBvbmVudC4gXHJcbiAgICovXHJcbiAgQElucHV0KCkgdHJhbnNsYXRlZFBhcmVudExhYmVsOiBzdHJpbmc7XHJcbiAgLyoqKlxyXG4gICAqIEluZGV4IG9mIHRoZSBlcnJvci4gVXNlZCB0byBleHBhbmQgdGhlIGV4cGFuZGVyIGZvciB0aGUgZXJyb3Igc3VtbWFyeXRcclxuICAgKi9cclxuICBASW5wdXQoKSBpbmRleDogTnVtYmVyO1xyXG5cclxuICAvKipcclxuICAgKiBGb3IgbWFudWFsbHkgc2hvd2luZyBpbmxpbmUgY29udHJvbCBtZXNzYWdlIGZvciBkaXNhYmxlZCBGb3JtQ29udHJvbC5cclxuICAgKi9cclxuICBASW5wdXQoKSBoYXNFcnJvcnM/OiBib29sZWFuID0gdW5kZWZpbmVkO1xyXG5cclxuICAgLyoqXHJcbiAgICogTnVtYmVyIG9mIGVycm9yIGZyb20gZXJyb3Igc3VtbWFyeVxyXG4gICAqL1xyXG4gICBwdWJsaWMgZXJyb3JOdW1iZXI6IHN0cmluZztcclxuICAvKipcclxuICAgKiBGbGFnIHRvIGluZGljYXRlIGlmIGVycm9yIHN1bW1hcnlcclxuICAgKi9cclxuICBwdWJsaWMgZXJyb3JTdW1tYXJ5RmxhZzogYm9vbGVhbjsgICBcclxuICAvKipcclxuICAgKiBDdXJyZW50IGVycm9yIHR5cGUgZm9yIHRoZSBjb250cm9sXHJcbiAgICogQHR5cGUge3N0cmluZ31cclxuICAgKi9cclxuICBwdWJsaWMgY3VycmVudEVycm9yOiBzdHJpbmcgO1xyXG4gIC8qKlxyXG4gICAqICBBIHJlZmVyZW5jZSB0aGUgdGFic2V0IGNvbnRyb2wgTmdiVGFic2V0IGZyb20gQW5ndWxhciBib290c3RyYXBcclxuICAgKiBAdHlwZSB7bnVsbH1cclxuICAgKi9cclxuICAvLyBwdWJsaWMgdGFiU2V0OiBOZ2JUYWJzZXQ7XHJcbiAgLyoqXHJcbiAgICogVGggaWQgb2YgdGhlIHRhcmdldCB0YWIsIHRoZSB0YWIgY29udGFpbmluZyB0aGUgZXJyb3JcclxuICAgKiBAdHlwZSAoc3RyaW5nKVxyXG4gICAqL1xyXG4gIHB1YmxpYyB0YWJJZDogc3RyaW5nO1xyXG5cclxuICBwdWJsaWMgZXJyb3JQYXJhbXM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH09IHt9O1xyXG4gIC8qKlxyXG4gICAqIGNvbnRyb2xzIHZpc2libGl0eVxyXG4gICAqIEB0eXBlIGJvb2xlYW5cclxuICAgKi9cclxuICBwcml2YXRlIF9lcnJvclZpc2libGU6IGJvb2xlYW47XHJcbiAgXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfZXJyTWVzc2FnZVNlcnZpY2U6IEVyck1lc3NhZ2VTZXJ2aWNlKSB7XHJcbiAgICAvLyB0aGlzLnRhYlNldCA9IG51bGw7XHJcbiAgICB0aGlzLnRhYklkID0gbnVsbDtcclxuICAgIHRoaXMuX2Vycm9yVmlzaWJsZSA9IGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2hhbmdlIGV2ZW50IHByb2Nlc3NpbmcgZnJvbSBpbnB1dHNcclxuICAgKiBAcGFyYW0ge1NpbXBsZUNoYW5nZXN9IGNoYW5nZXNcclxuICAgKi9cclxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcblxyXG4gICAgaWYgKGNoYW5nZXNbJ3Nob3dFcnJvciddKSB7XHJcbiAgICAgIHRoaXMuX2Vycm9yVmlzaWJsZSA9IGNoYW5nZXNbJ3Nob3dFcnJvciddLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgdGhpcy5tYWtlRXJyb3JWaXNpYmxlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXRzIHRoZSBFcnJvciBtZXNzYWdlIGtleSBhbmQgaXRzIHBhcmFtZXRlciB2YWx1ZXMgZm9yIGEgZ2l2ZW4gZXJyb3IgdHlwZS5cclxuICAgKlxyXG4gICAqIEByZXR1cm5zIHthbnl9XHJcbiAgICovXHJcbiAgZ2V0IGVycm9yTWVzc2FnZSgpIHtcclxuICAgIGZvciAobGV0IHByb3BlcnR5TmFtZSBpbiB0aGlzLmNvbnRyb2wuZXJyb3JzKSB7XHJcbiAgICAgIHRoaXMuY3VycmVudEVycm9yID0gcHJvcGVydHlOYW1lOyAgICAgIFxyXG4gICAgICAvLyB2YWx1ZXMgdG8gcmVwbGFjZSBwbGFjZWhvbGRlcnMgaW4gdGhlIGVycm9yIG1lc3NhZ2UgaWYgdGhleSBleGlzdC4gZWcgXCJNaW5pbXVtIGxlbmd0aCB7eyByZXF1aXJlZExlbmd0aCB9fSBudW1iZXJzXCJcclxuICAgICAgdGhpcy5lcnJvclBhcmFtcyA9IHRoaXMuY29udHJvbC5lcnJvcnNbcHJvcGVydHlOYW1lXTsgICBcclxuICAgICAgLy8gY29uc29sZS5sb2cocHJvcGVydHlOYW1lLCBPYmplY3Qua2V5cyh0aGlzLmVycm9yUGFyYW1zKS5sZW5ndGgsIEpTT04uc3RyaW5naWZ5KHRoaXMuZXJyb3JQYXJhbXMpKVxyXG5cclxuICAgICAgcmV0dXJuIHRoaXMuX2Vyck1lc3NhZ2VTZXJ2aWNlLmdldFZhbGlkYXRvckVycm9yTWVzc2FnZUtleShwcm9wZXJ0eU5hbWUpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5jdXJyZW50RXJyb3IgPSAnJztcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ29udHJvbHMgdGhlIHZpc2liaWxpdHkgb2YgYW4gZXJyb3JcclxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICAgKi9cclxuICBtYWtlRXJyb3JWaXNpYmxlKCk6IGJvb2xlYW4ge1xyXG4gICAgLy8gSWYgdGhpcy5oYXNFcnJvcnMgKG1hbnVhbCBlcnJvciBjaGVjayBmb3IgZGlzYWJsZWQgZm9ybSBncm91cCkgaXMgZGVmaW5lZCwgY2hlY2sgZm9yIHRoaXMgZmxhZy5cclxuICAgIGNvbnN0IGhhc01hbnVhbEVycm9yID0gdGhpcy5oYXNFcnJvcnMgPz8gZmFsc2U7XHJcbiAgICBpZiAoaGFzTWFudWFsRXJyb3IpIHtcclxuICAgICAgcmV0dXJuIHRoaXMuaGFzRXJyb3JzICYmIHRoaXMuX2Vycm9yVmlzaWJsZSB8fCAodGhpcy5oYXNFcnJvcnMgJiYgIXRoaXMuY29udHJvbC52YWxpZCk7XHJcbiAgICB9XHJcbiAgXHJcbiAgICByZXR1cm4gKHRoaXMuY29udHJvbC5pbnZhbGlkICYmIHRoaXMuY29udHJvbC50b3VjaGVkICYmIHRoaXMuY29udHJvbC5kaXJ0eSkgfHwgKHRoaXMuY29udHJvbC5pbnZhbGlkICYmIHRoaXMuX2Vycm9yVmlzaWJsZSk7XHJcbiAgICBcclxuICB9XHJcbiAgXHJcblxyXG4gIGlzQ2FuYWRpYW5Qb3N0YWxDb2RlKCk6IGJvb2xlYW4ge1xyXG4gICAgY29uc3QgY29udHJvbE5hbWUgPSB0aGlzLmNvbnRyb2xJZD8udG9Mb3dlckNhc2UoKSB8fCAnJztcclxuICAgIGNvbnN0IGxhYmVsVGV4dCA9IHRoaXMubGFiZWw/LnRvTG93ZXJDYXNlKCkgfHwgJyc7XHJcbiAgICByZXR1cm4gY29udHJvbE5hbWUuaW5jbHVkZXMoJ3Bvc3RhbCcpICYmIGxhYmVsVGV4dC5pbmNsdWRlcygncG9zdGFsJykgJiYgdGhpcy5jb250cm9sPy5lcnJvcnM/LlsncGF0dGVybiddO1xyXG4gIH1cclxuICBcclxuXHJcbn1cclxuXHJcblxyXG5cclxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cIm1ha2VFcnJvclZpc2libGUoKVwiPlxyXG4gIDxzdHJvbmcgY2xhc3M9XCJlcnJvclwiPlxyXG4gICAgPHNwYW4gY2xhc3M9XCJsYWJlbCBsYWJlbC1kYW5nZXJcIj5cclxuICAgICAgQGlmKGVycm9yU3VtbWFyeUZsYWcgJiYgZXJyb3JOdW1iZXIpIHtcclxuICAgICAgICA8c3BhbiBjbGFzcz1cInByZWZpeFwiPnt7J2Vycm9yJyB8IHRyYW5zbGF0ZToge251bWJlcjogZXJyb3JOdW1iZXJ9IH19Jm5ic3A7PC9zcGFuPlxyXG4gICAgICB9IFxyXG4gICAgICB7e2Vycm9yTWVzc2FnZSB8IHRyYW5zbGF0ZTogZXJyb3JQYXJhbXMgfX1cclxuICAgIDwvc3Bhbj5cclxuICA8L3N0cm9uZz5cclxuPC9uZy1jb250YWluZXI+XHJcbiJdfQ==