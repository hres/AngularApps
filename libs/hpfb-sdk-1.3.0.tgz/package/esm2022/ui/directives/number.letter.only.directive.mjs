/* tslint:disable:member-ordering */
import { Directive, HostListener } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
export class NumbersLettersDirective {
    constructor(control, el) {
        this.control = control;
        this.el = el;
    }
    onInput(value) {
        this.filterValue(value);
    }
    onPaste(event) {
        const pastedText = event.clipboardData.getData('text/plain');
        this.filterValue(pastedText);
        event.preventDefault(); // Prevent default paste behavior
    }
    filterValue(value) {
        // Allow only letters and numbers, remove all other characters
        let newValue = value.replace(/[^a-zA-Z0-9]/g, '');
        if (this.el.nativeElement.maxLength != null && this.el.nativeElement.maxLength > 0) {
            const maxLength = this.el.nativeElement.maxLength;
            newValue = newValue.substring(0, maxLength);
        }
        this.control.control.setValue(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NumbersLettersDirective, deps: [{ token: i1.NgControl }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: NumbersLettersDirective, isStandalone: true, selector: "[data-number-letter]", host: { listeners: { "input": "onInput($event.target.value)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NumbersLettersDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[data-number-letter]'
                }]
        }], ctorParameters: () => [{ type: i1.NgControl }, { type: i0.ElementRef }], propDecorators: { onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnVtYmVyLmxldHRlci5vbmx5LmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2RpcmVjdGl2ZXMvbnVtYmVyLmxldHRlci5vbmx5LmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxvQ0FBb0M7QUFDcEMsT0FBTyxFQUFFLFNBQVMsRUFBYyxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUM7OztBQU9wRSxNQUFNLE9BQU8sdUJBQXVCO0lBRWxDLFlBQW9CLE9BQWtCLEVBQVUsRUFBYztRQUExQyxZQUFPLEdBQVAsT0FBTyxDQUFXO1FBQVUsT0FBRSxHQUFGLEVBQUUsQ0FBWTtJQUFJLENBQUM7SUFHbkUsT0FBTyxDQUFDLEtBQWE7UUFDbkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBR0QsT0FBTyxDQUFDLEtBQXFCO1FBQzNCLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdELElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDN0IsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsaUNBQWlDO0lBQzNELENBQUM7SUFFTyxXQUFXLENBQUMsS0FBYTtRQUMvQiw4REFBOEQ7UUFDOUQsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFbEQsSUFBSSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNuRixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7WUFDbEQsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzlDLENBQUM7UUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUMsQ0FBQzsrR0F6QlUsdUJBQXVCO21HQUF2Qix1QkFBdUI7OzRGQUF2Qix1QkFBdUI7a0JBSm5DLFNBQVM7bUJBQUM7b0JBQ1QsVUFBVSxFQUFDLElBQUk7b0JBQ2YsUUFBUSxFQUFFLHNCQUFzQjtpQkFDakM7dUdBTUMsT0FBTztzQkFETixZQUFZO3VCQUFDLE9BQU8sRUFBRSxDQUFDLHFCQUFxQixDQUFDO2dCQU05QyxPQUFPO3NCQUROLFlBQVk7dUJBQUMsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyogdHNsaW50OmRpc2FibGU6bWVtYmVyLW9yZGVyaW5nICovXHJcbmltcG9ydCB7IERpcmVjdGl2ZSwgRWxlbWVudFJlZiwgSG9zdExpc3RlbmVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE5nQ29udHJvbCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gIHN0YW5kYWxvbmU6dHJ1ZSxcclxuICBzZWxlY3RvcjogJ1tkYXRhLW51bWJlci1sZXR0ZXJdJ1xyXG59KVxyXG5leHBvcnQgY2xhc3MgTnVtYmVyc0xldHRlcnNEaXJlY3RpdmUge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGNvbnRyb2w6IE5nQ29udHJvbCwgcHJpdmF0ZSBlbDogRWxlbWVudFJlZikgeyB9XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ2lucHV0JywgWyckZXZlbnQudGFyZ2V0LnZhbHVlJ10pXHJcbiAgb25JbnB1dCh2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICB0aGlzLmZpbHRlclZhbHVlKHZhbHVlKTtcclxuICB9XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ3Bhc3RlJywgWyckZXZlbnQnXSlcclxuICBvblBhc3RlKGV2ZW50OiBDbGlwYm9hcmRFdmVudCkge1xyXG4gICAgY29uc3QgcGFzdGVkVGV4dCA9IGV2ZW50LmNsaXBib2FyZERhdGEuZ2V0RGF0YSgndGV4dC9wbGFpbicpO1xyXG4gICAgdGhpcy5maWx0ZXJWYWx1ZShwYXN0ZWRUZXh0KTtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IC8vIFByZXZlbnQgZGVmYXVsdCBwYXN0ZSBiZWhhdmlvclxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBmaWx0ZXJWYWx1ZSh2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAvLyBBbGxvdyBvbmx5IGxldHRlcnMgYW5kIG51bWJlcnMsIHJlbW92ZSBhbGwgb3RoZXIgY2hhcmFjdGVyc1xyXG4gICAgbGV0IG5ld1ZhbHVlID0gdmFsdWUucmVwbGFjZSgvW15hLXpBLVowLTldL2csICcnKTtcclxuXHJcbiAgICBpZiAodGhpcy5lbC5uYXRpdmVFbGVtZW50Lm1heExlbmd0aCAhPSBudWxsICYmIHRoaXMuZWwubmF0aXZlRWxlbWVudC5tYXhMZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnN0IG1heExlbmd0aCA9IHRoaXMuZWwubmF0aXZlRWxlbWVudC5tYXhMZW5ndGg7XHJcbiAgICAgIG5ld1ZhbHVlID0gbmV3VmFsdWUuc3Vic3RyaW5nKDAsIG1heExlbmd0aCk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNvbnRyb2wuY29udHJvbC5zZXRWYWx1ZShuZXdWYWx1ZSk7XHJcbiAgfVxyXG59XHJcbiJdfQ==