import * as i0 from '@angular/core';
import { ViewEncapsulation, Component, InjectionToken, Inject, Injectable, Input, ViewChildren, Directive, EventEmitter, Output, ContentChild, NgModule, Pipe, HostListener } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule, DatePipe } from '@angular/common';
import * as i1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1$2 from '@angular/forms';
import { ReactiveFormsModule, FormArray, AbstractControl, FormGroup, FormsModule } from '@angular/forms';
import { BehaviorSubject, map, throwError } from 'rxjs';
import * as i1$1 from '@angular/common/http';
import * as FileSaver from 'file-saver';
import * as CryptoJS from 'crypto-js';
import * as i1$3 from '@angular/router';

class LayoutComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LayoutComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: LayoutComponent, isStandalone: true, selector: "lib-layout", ngImport: i0, template: "<div>\r\n    <ng-content select=\"[header]\"></ng-content>\r\n</div>\r\n<div>\r\n    <ng-content select=\"[body]\"></ng-content>\r\n</div>", encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-layout', standalone: true, encapsulation: ViewEncapsulation.None, template: "<div>\r\n    <ng-content select=\"[header]\"></ng-content>\r\n</div>\r\n<div>\r\n    <ng-content select=\"[body]\"></ng-content>\r\n</div>" }]
        }] });

const VALIDATION_SERVICES = new InjectionToken('VALIDATION_SERVICES');

class ErrMessageService {
    constructor(validationServices) {
        this.validationServices = validationServices;
    }
    getValidatorErrorMessageKey(validatorName) {
        for (const service of this.validationServices) {
            // get the error message key in the en/fr.json for this errorz
            const messageKey = service.getValidatorErrorMessage(validatorName);
            if (messageKey)
                return messageKey; // Return the first matching key
        }
        return null; // Default to null if no match is found
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrMessageService, deps: [{ token: VALIDATION_SERVICES }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrMessageService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrMessageService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [VALIDATION_SERVICES]
                }] }] });

class ControlMessagesComponent {
    constructor(_errMessageService) {
        this._errMessageService = _errMessageService;
        this.errorParams = {};
        // this.tabSet = null;
        this.tabId = null;
        this._errorVisible = false;
    }
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['showError']) {
            this._errorVisible = changes['showError'].currentValue;
            this.makeErrorVisible();
        }
    }
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage() {
        for (let propertyName in this.control.errors) {
            this.currentError = propertyName;
            // values to replace placeholders in the error message if they exist. eg "Minimum length {{ requiredLength }} numbers"
            this.errorParams = this.control.errors[propertyName];
            // console.log(propertyName, Object.keys(this.errorParams).length, JSON.stringify(this.errorParams))
            return this._errMessageService.getValidatorErrorMessageKey(propertyName);
        }
        this.currentError = '';
        return null;
    }
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible() {
        const test = ((this.control.invalid && this.control.touched) || (this.control.invalid && this._errorVisible));
        return test;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, deps: [{ token: ErrMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: ControlMessagesComponent, selector: "control-messages", inputs: { control: "control", showError: "showError", label: "label", controlId: "controlId", parentId: "parentId", parentLabel: "parentLabel", translatedParentLabel: "translatedParentLabel", index: "index" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n    <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'control-messages', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n    <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"] }]
        }], ctorParameters: () => [{ type: ErrMessageService }], propDecorators: { control: [{
                type: Input
            }], showError: [{
                type: Input
            }], label: [{
                type: Input
            }], controlId: [{
                type: Input
            }], parentId: [{
                type: Input
            }], parentLabel: [{
                type: Input
            }], translatedParentLabel: [{
                type: Input
            }], index: [{
                type: Input
            }] } });

class BaseComponent {
    constructor() { }
    ngAfterViewInit() {
        this.msgList.changes.subscribe(errorObjs => {
            this._updateAndEmitErrors(errorObjs);
        });
        this.msgList.notifyOnChanges();
    }
    _updateAndEmitErrors(errorObjs) {
        const temp = [];
        if (errorObjs) {
            errorObjs.forEach(error => {
                temp.push(error);
            });
        }
        this.emitErrors(temp);
    }
    // append errors from child component
    _appendErrorsFromChild(errorsFromChild) {
        const parentErrors = this.msgList.toArray();
        const combinedErrors = [...parentErrors, ...errorsFromChild];
        this.emitErrors(combinedErrors); // Call the abstract method
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseComponent, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: BaseComponent, viewQueries: [{ propertyName: "msgList", predicate: ControlMessagesComponent, descendants: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { msgList: [{
                type: ViewChildren,
                args: [ControlMessagesComponent]
            }] } });

const CANADA = 'CA';
const USA = 'US';
const ENGLISH = 'en';
const FRENCH = 'fr';
const YES = 'yes';
const NO = 'no';
// the value needs to match enrollment 'FINAL' status code loaded from the json data file
const FINAL = 'FINAL';
const OTHER_EN = "Other";
const OTHER_FR = "Autre";

class ExpanderComponent {
    constructor() {
        /**
         * Disable expand
         */
        this.disableExpand = false;
        /**
         * Expands a record when it has been added. Default is false
         */
        this.expandOnAdd = false;
        this.expandedRow = new EventEmitter();
        this.tableRowIndexCurrExpanded = -1;
        this.tableRowIndexPreExpanded = -1;
        /**
         * for each table row, stores the state i.e. collapsed or expanded
         * @type {boolean[]}
         * @private
         */
        this._expanderTable = [];
        /**
         * an array of JSON objects to define the column labels, widths and bindings
         * @type {any[]}
         */
        this.columnDefinitions = [];
        /**
         * The number of columns for this expander. Used to determine columnSpan
         * @type {number}
         */
        this.numberColSpan = 1;
        this.dataItems = [];
        this._expanderValid = true;
        this._expandAdd = false;
    }
    ngOnInit() {
    }
    /**
     * Looks for and reacts to changes in the expander component
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['columnDefinitions']) {
            this.numberColSpan = (changes['columnDefinitions'].currentValue).length + 1;
        }
        if (changes['expandOnAdd']) {
            this._expandAdd = changes['expandOnAdd'].currentValue;
        }
        if (changes['itemsList']) {
            this.updateDataRows(changes['itemsList'].currentValue);
            this.dataItems = changes['itemsList'].currentValue;
            if (!Array.isArray(this.dataItems)) {
                this.dataItems = [];
            }
            else if (this.dataItems.length > 0 && this.loadFileIndicator) {
                this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
                this.tableRowIndexCurrExpanded = 0;
            }
        }
        if (changes['isValid']) {
            this._expanderValid = changes['isValid'].currentValue;
        }
        if (changes['addRecord'] && !changes['addRecord'].firstChange) {
            this.collapseTableRows();
            this.updateDataRows(this.itemsList);
            if (this._expandAdd) {
                // expands the table on the additon of a new record
                this.selectTableRowNoCheck(this._expanderTable.length - 1);
            }
            else if (!this.isValid) {
                if (this.tableRowIndexPreExpanded + 1 < this._expanderTable.length) {
                    this.tableRowIndexCurrExpanded = this.tableRowIndexPreExpanded + 1;
                }
                else {
                    this.tableRowIndexCurrExpanded = 0;
                }
                this.selectTableRowNoCheck(this.tableRowIndexCurrExpanded);
            }
        }
        if (changes['deleteRecord']) {
            this.updateDataRows(this.itemsList);
        }
        if (changes['collapseAll']) {
            this.collapseTableRows();
        }
        if (changes['xmlStatus']) {
            if (changes['xmlStatus'].currentValue === FINAL) {
                this.collapseTableRows();
            }
        }
    }
    /**
     * Adds an additional row to the expander UI state tracking array
     */
    updateDataRows(srcList) {
        if (!srcList) {
            return;
        }
        if (srcList.length !== this._expanderTable.length) {
            this._expanderTable = new Array(srcList.length);
        }
    }
    /**
     * For a given row denoted by a zero based index, returns if a row is collapsed or expanded
     * @param {number} index
     * @returns {boolean}
     */
    getExpandedState(index) {
        return (this._expanderTable)[index];
    }
    /**
     *  Checks if a given zero based row denoted by index is expanded
     * @param {number} index
     * @returns {boolean}
     */
    isExpanded(index) {
        if (this.tableRowIndexCurrExpanded < 0)
            return false;
        this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
        return this.tableRowIndexCurrExpanded === index;
    }
    ;
    /**
     *  Checks if a given zero based row denoted by index is collapsed
     * @param {number} index
     * @returns {boolean}
     */
    isCollapsed(index) {
        return !this.isExpanded(index);
    }
    broadcastExpandedRow() {
        // return this.tableRowIndexCurrExpanded;
        this.expandedRow.emit(this.tableRowIndexCurrExpanded);
    }
    getExpandedRow() {
        return this.tableRowIndexCurrExpanded;
    }
    /**
     * Selects the table row to expand or collapse. If disable expand is enabled, will not collapse a row if it is in error
     * @param {number} index
     */
    selectTableRow(index) {
        // if (!this._expanderValid) {
        //    console.warn('select table row did not meet conditions');
        //   return;
        // }
        if (!this.disableExpand) { // && this.isValid
            this.selectTableRowNoCheck(index);
        }
    }
    selectTableRowNoCheck(index) {
        if (this._expanderTable.length > index) {
            const temp = this._expanderTable[index];
            this.collapseTableRows();
            this._expanderTable[index] = !temp;
            this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
            if (this._expanderTable[index]) {
                this.tableRowIndexCurrExpanded = index;
            }
            else {
                this.tableRowIndexCurrExpanded = -1;
            }
        }
        else {
            console.warn('The index is greater than the table length ' + index + ' ' + this._expanderTable.length);
        }
    }
    /**
     * Collapses all the table rows. Ignores any error states in the details.
     */
    collapseTableRows() {
        for (let rec of this._expanderTable) {
            rec = false;
        }
        this.tableRowIndexPreExpanded = this.tableRowIndexCurrExpanded;
        this.tableRowIndexCurrExpanded = -1;
    }
    /**
     * Get the row title dynamic according to the expand/collapse status
     */
    getRowTitle(i) {
        if (this.isCollapsed(i)) {
            return 'Expand Row ' + (i + 1);
        }
        else if (this.isExpanded(i)) {
            return 'Collapse Row ' + (i + 1);
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ExpanderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: ExpanderComponent, selector: "lib-expander", inputs: { accordionHeadingMsgKey: "accordionHeadingMsgKey", disableExpand: "disableExpand", isValid: "isValid", itemsList: ["group", "itemsList"], addRecord: "addRecord", expandOnAdd: "expandOnAdd", deleteRecord: "deleteRecord", collapseAll: "collapseAll", loadFileIndicator: "loadFileIndicator", xmlStatus: "xmlStatus", columnDefinitions: "columnDefinitions" }, outputs: { expandedRow: "expandedRow" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngFor=\"let record of dataItems; index as i;\">\r\n  <div role=\"button\" >\r\n    <h4 id=\"tr-expand-row-{{i}}\" class=\"clickableRow\" [ngClass]=\"{'selected':isExpanded(i)}\"\r\n      [attr.aria-expanded]=\"getExpandedState(i)\" i18n-title=\"@@expander.rowTitle\" [title]=\"getRowTitle(i)\"\r\n      (click)=\"selectTableRow(i)\">\r\n      <span class=\"fa fa-lg fa-fw\" [ngClass]=\"{'fa-caret-right':isCollapsed(i), 'fa-caret-down':isExpanded(i) }\"></span>\r\n      {{accordionHeadingMsgKey | translate}}&nbsp; {{ +record['id']+1 }}\r\n    </h4>\r\n  </div>\r\n\r\n  <div class=\"table-override\" *ngIf=\"isExpanded(i)\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n</ng-container>", dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ExpanderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-expander', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngFor=\"let record of dataItems; index as i;\">\r\n  <div role=\"button\" >\r\n    <h4 id=\"tr-expand-row-{{i}}\" class=\"clickableRow\" [ngClass]=\"{'selected':isExpanded(i)}\"\r\n      [attr.aria-expanded]=\"getExpandedState(i)\" i18n-title=\"@@expander.rowTitle\" [title]=\"getRowTitle(i)\"\r\n      (click)=\"selectTableRow(i)\">\r\n      <span class=\"fa fa-lg fa-fw\" [ngClass]=\"{'fa-caret-right':isCollapsed(i), 'fa-caret-down':isExpanded(i) }\"></span>\r\n      {{accordionHeadingMsgKey | translate}}&nbsp; {{ +record['id']+1 }}\r\n    </h4>\r\n  </div>\r\n\r\n  <div class=\"table-override\" *ngIf=\"isExpanded(i)\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n</ng-container>" }]
        }], ctorParameters: () => [], propDecorators: { accordionHeadingMsgKey: [{
                type: Input
            }], disableExpand: [{
                type: Input
            }], isValid: [{
                type: Input
            }], itemsList: [{
                type: Input,
                args: ['group']
            }], addRecord: [{
                type: Input
            }], expandOnAdd: [{
                type: Input
            }], deleteRecord: [{
                type: Input
            }], collapseAll: [{
                type: Input
            }], loadFileIndicator: [{
                type: Input
            }], xmlStatus: [{
                type: Input
            }], expandedRow: [{
                type: Output
            }], columnDefinitions: [{
                type: Input
            }] } });

class AccordionComponent {
    toggleExpand(index, expanded) {
        this.rowClicked.emit({ index: index, state: expanded });
    }
    constructor() {
        this.rowClicked = new EventEmitter();
    }
    getNestedFormValue(recordRow, keys) {
        return keys.reduce((acc, key) => acc?.get(key), recordRow)?.value ?? null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: AccordionComponent, selector: "lib-accordion", inputs: { rowsFormArray: "rowsFormArray", accordionHeadingMsgKey: "accordionHeadingMsgKey", accordionHeadingSupp: "accordionHeadingSupp" }, outputs: { rowClicked: "rowClicked" }, queries: [{ propertyName: "tmplRef", first: true, predicate: ["tmpl"], descendants: true }], ngImport: i0, template: "<ng-container *ngFor=\"let recordRow of rowsFormArray.controls; let i=index;\">\r\n  <div class=\"panel panel-default\" [attr.data-open]=\"recordRow.get('expandFlag').value? '' : null\">\r\n    <header class=\"panel-heading\">\r\n      @if(recordRow.get('isNew').value){\r\n      <h4 class=\"panel-title\">\r\n        {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }}\r\n      </h4>\r\n      } @else {\r\n      <div role=\"button\" [attr.aria-expanded]=\"recordRow.get('expandFlag').value ? 'true' : 'false'\">\r\n        <h4 class=\"panel-title\" tabindex=\"0\"\r\n          (keydown.enter)=\"toggleExpand(i, recordRow.get('expandFlag').value)\"\r\n          (keydown.space)=\"$event.preventDefault(); toggleExpand(i, recordRow.get('expandFlag').value)\"\r\n          (click)=\"toggleExpand(i, recordRow.get('expandFlag').value)\">\r\n          <i class=\"fa\" [ngClass]=\"recordRow.get('expandFlag').value ? 'fa-caret-down' : 'fa-caret-right'\" aria-hidden=\"true\"></i>\r\n\r\n          @if (accordionHeadingSupp != null) {\r\n            @if (getNestedFormValue(recordRow, accordionHeadingSupp) != null && getNestedFormValue(recordRow, accordionHeadingSupp) != '') {\r\n              {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }} -\r\n              {{ getNestedFormValue(recordRow, accordionHeadingSupp) }}\r\n            }\r\n            @else {\r\n              {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }}\r\n            }\r\n          } \r\n          @else {\r\n            {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }}\r\n          }\r\n        </h4>\r\n      </div>\r\n      }\r\n    </header>\r\n    \r\n    @if(recordRow.get('expandFlag').value){\r\n    <div class=\"panel-body\">\r\n      <ng-container *ngTemplateOutlet=\"tmplRef; context: {$implicit: recordRow, i: i}\"></ng-container>\r\n    </div>\r\n    }\r\n\r\n  </div>\r\n</ng-container>\r\n", styles: [".mydetails:not([data-open])>div{display:none;border:none}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-accordion', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngFor=\"let recordRow of rowsFormArray.controls; let i=index;\">\r\n  <div class=\"panel panel-default\" [attr.data-open]=\"recordRow.get('expandFlag').value? '' : null\">\r\n    <header class=\"panel-heading\">\r\n      @if(recordRow.get('isNew').value){\r\n      <h4 class=\"panel-title\">\r\n        {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }}\r\n      </h4>\r\n      } @else {\r\n      <div role=\"button\" [attr.aria-expanded]=\"recordRow.get('expandFlag').value ? 'true' : 'false'\">\r\n        <h4 class=\"panel-title\" tabindex=\"0\"\r\n          (keydown.enter)=\"toggleExpand(i, recordRow.get('expandFlag').value)\"\r\n          (keydown.space)=\"$event.preventDefault(); toggleExpand(i, recordRow.get('expandFlag').value)\"\r\n          (click)=\"toggleExpand(i, recordRow.get('expandFlag').value)\">\r\n          <i class=\"fa\" [ngClass]=\"recordRow.get('expandFlag').value ? 'fa-caret-down' : 'fa-caret-right'\" aria-hidden=\"true\"></i>\r\n\r\n          @if (accordionHeadingSupp != null) {\r\n            @if (getNestedFormValue(recordRow, accordionHeadingSupp) != null && getNestedFormValue(recordRow, accordionHeadingSupp) != '') {\r\n              {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }} -\r\n              {{ getNestedFormValue(recordRow, accordionHeadingSupp) }}\r\n            }\r\n            @else {\r\n              {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }}\r\n            }\r\n          } \r\n          @else {\r\n            {{ accordionHeadingMsgKey | translate: {seqnumber: recordRow.get('seqNumber') == null ? i + 1 : recordRow.get('seqNumber').value} }}\r\n          }\r\n        </h4>\r\n      </div>\r\n      }\r\n    </header>\r\n    \r\n    @if(recordRow.get('expandFlag').value){\r\n    <div class=\"panel-body\">\r\n      <ng-container *ngTemplateOutlet=\"tmplRef; context: {$implicit: recordRow, i: i}\"></ng-container>\r\n    </div>\r\n    }\r\n\r\n  </div>\r\n</ng-container>\r\n", styles: [".mydetails:not([data-open])>div{display:none;border:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { rowsFormArray: [{
                type: Input
            }], accordionHeadingMsgKey: [{
                type: Input
            }], accordionHeadingSupp: [{
                type: Input
            }], rowClicked: [{
                type: Output
            }], tmplRef: [{
                type: ContentChild,
                args: ['tmpl']
            }] } });

class ExpanderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ExpanderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: ExpanderModule, declarations: [ExpanderComponent,
            AccordionComponent], imports: [CommonModule,
            ReactiveFormsModule,
            TranslateModule], exports: [ExpanderComponent,
            AccordionComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ExpanderModule, imports: [CommonModule,
            ReactiveFormsModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ExpanderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        TranslateModule,
                    ],
                    declarations: [
                        ExpanderComponent,
                        AccordionComponent
                    ],
                    exports: [
                        ExpanderComponent,
                        AccordionComponent
                    ]
                }]
        }] });

const ERR_TYPE_COMPONENT = 'component_error';
const ERR_TYPE_LEAST_ONE_REC = 'least_one_rec_error';
/**
 * Creates a flat json object for the error summary component UI
 * @returns {object}
 */
function getEmptyErrorSummaryObj() {
    return {
        index: -1,
        label: '',
        controlId: '',
        error: '',
        type: '',
        // tabSet: null,
        tabId: -1,
        componentId: '',
        tableId: '',
        expander: null,
        compRef: null,
        errorNumber: ''
    };
}

class JsonKeysPipe {
    /**
     * Transforms a list of json objects into an array
     * Creates key value pairs
     * @param value
     * @param {string[]} args
     * @returns {any}
     */
    transform(value) {
        const keys = [];
        for (const key in value) {
            keys.push({ key: key, value: value[key] });
        }
        return keys;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: JsonKeysPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: JsonKeysPipe, name: "keys" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: JsonKeysPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'keys'
                }]
        }] });

class ErrorSummaryComponent {
    constructor(cdr, _errMessageService) {
        this.cdr = cdr;
        this._errMessageService = _errMessageService;
        this.compId = 'error-summary-';
        this.errors = {};
        this.componentId = '';
        this.tableId = '';
        this.hdingLevel = 'h1';
        this.errorCount = 0;
        this.errorNumberValue = '';
        this.type = ERR_TYPE_COMPONENT;
        this.index = -1;
        this.expander = null;
    }
    ngAfterViewInit() {
        if (this.cdr) {
            this.cdr.detectChanges();
        }
    }
    ngOnChanges(changes) {
        if (changes['errorList']) {
            this.processErrors(changes['errorList'].currentValue);
            // console.log("........process errors in error summary ");
            // console.log(changes['errorList'].currentValue)
        }
        if (changes['compId']) {
            this.componentId = changes['compId'].currentValue;
        }
        if (changes['headingLevel']) {
            this.hdingLevel = changes['headingLevel'].currentValue;
        }
    }
    /**
     * Creates an array of error elements based on the incoming error objects
     * Currently groups the errors by parent. Not doing anything with parent right now.
     * But could display errors groupded by the parent and parent label
     * @param errorList
     */
    processErrors(errorList) {
        this.errors = {};
        if (!errorList) {
            return;
        }
        // console.log(errorList);
        for (let err of errorList) {
            if (!err) {
                continue;
            }
            let controlError = getEmptyErrorSummaryObj();
            controlError.index = 1;
            controlError.label = err.label;
            controlError.controlId = err.controlId;
            controlError.error = err.currentError;
            controlError.type = err.type;
            // controlError.tabSet = err.tabSet;
            controlError.tabId = err.tabId;
            controlError.componentId = err.componentId; // error summary only uses this
            controlError.expander = err.expander; // error summary only uses
            controlError.compRef = err;
            this.errorCount++;
            err.errorNumber = this.errorCount;
            controlError.errorNumber = err.errorNumber;
            err.errorSummaryFlag = this.hiddenSummary;
            // if (err.controlId === 'hasMaterial') {
            //   err.type = ERR_TYPE_LEAST_ONE_REC;
            //   err.tableId = 'materialListTable';
            // }
            // Case 1: an error summary Component
            if (err.hasOwnProperty('type') &&
                (err.type === ERR_TYPE_COMPONENT || err.type === ERR_TYPE_LEAST_ONE_REC)) {
                if (err.tableId) { // replace componentId with table ID
                    controlError.tableId = err.tableId;
                }
                controlError.error = err.error;
                let parentError = { parentLabel: '', index: -1, controls: [] };
                parentError.parentLabel = err.componentId;
                parentError.index = err.index;
                parentError.controls.push(controlError); //TODO needed for eerror summary
                this.errors[err.componentId] = parentError;
            }
            else {
                // Case 2 Not an error summary. If has a parentId gourp the errors
                if (this.errors.hasOwnProperty(err.parentId)) {
                    let id = err.parentId;
                    this.errors[id].controls.push(controlError);
                }
                else {
                    // create a parent tag and put errors under the controls list
                    let parentError = { parentLabel: '', controls: [] };
                    parentError.parentLabel = err.parentLabel;
                    parentError.controls.push(controlError);
                    this.errors[err.parentId] = parentError;
                }
            }
        }
        this.resetErrorCount();
        //console.log(this.errors);
    }
    /**
     * Selects thje tab from an ngbTabset
     * @param error- the error object created by the summary component
     */
    processEvents(error) {
        //process tab Events first. Assunming rhere are no tabs inside an expander
        // if (error && error.tabSet && error.tabId) {
        //   error.tabSet.select(error.tabId);
        // }
        //expander if needed
        if (error && error.expander && error.index > -1) {
            if (!error.expander.getExpandedState(error.index)) {
                error.expander.selectTableRow(error.index);
            }
        }
    }
    resetErrorCount() {
        this.errorCount = 0;
    }
    getValidatorErrorMessageKey(error) {
        return this._errMessageService.getValidatorErrorMessageKey(error);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorSummaryComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: ErrMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: ErrorSummaryComponent, selector: "lib-error-summary", inputs: { headingPreamble: "headingPreamble", headingPreambleParams: "headingPreambleParams", errorList: "errorList", hiddenSummary: "hiddenSummary", compId: "compId", label: "label", headingLevel: "headingLevel" }, usesOnChanges: true, ngImport: i0, template: "<div id=\"{{compId}}\" *ngIf=\"hiddenSummary\">\r\n  <section class=\"alert alert-danger\" tabindex=\"-1\" [ngSwitch]=\"hdingLevel\">\r\n    <h1 *ngSwitchCase=\"'h1'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h1>\r\n    <h2 *ngSwitchCase=\"'h2'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h2>\r\n    <h3 *ngSwitchCase=\"'h3'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h3>\r\n    <h4 *ngSwitchCase=\"'h4'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h4>\r\n    <h5 *ngSwitchCase=\"'h5'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h5>\r\n    <h6 *ngSwitchCase=\"'h6'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h6>\r\n\r\n    <ng-template #sharedHeadingContent>\r\n      <!--<span>For</span>--><span> {{headingPreamble |translate: {seqnumber: headingPreambleParams} }}</span>\r\n      <span>{{'error.found.because'|translate}}</span>\r\n      <span>{{errorList.length}}</span>\r\n      <span *ngIf=\"errorList?.length>1\">{{'error.found.plural'|translate}}</span>\r\n      <span *ngIf=\"errorList?.length<2\">{{'error.found.singular'|translate}}</span>\r\n    </ng-template>\r\n\r\n    <ul *ngFor=\"let parentError of errors | keys\">\r\n      <ng-container *ngFor=\"let controlError of parentError.value.controls\">\r\n        <li *ngIf=\"controlError.type==='component_error'\">\r\n          <a href=\"#{{controlError.componentId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">{{'error' | translate: {number:controlError.errorNumber} }}&nbsp;{{controlError.label|translate}}</a>\r\n        </li>\r\n        <li *ngIf=\"controlError.type==='least_one_rec_error' && !controlError.error\">\r\n          <a href=\"#{{controlError.tableId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">{{'error' | translate: {number:controlError.errorNumber} }}&nbsp;{{controlError.label|translate}}</a>\r\n        </li>\r\n        <li *ngIf=\"controlError.type==='least_one_rec_error' && controlError.error\">\r\n          <a href=\"#{{controlError.tableId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">{{'error' | translate: {number:controlError.errorNumber} }}&nbsp;{{controlError.label|translate}}&nbsp;&#8208;&nbsp;{{ getValidatorErrorMessageKey(controlError.error) | translate: controlError.compRef.errorParams}}</a>\r\n        </li>\r\n        <li *ngIf=\"controlError.type!=='component_error' && controlError.type!='least_one_rec_error'\">\r\n          <a href=\"#{{controlError.controlId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">\r\n            {{'error' | translate: {number:controlError.errorNumber} }}\r\n            \r\n              @if(controlError.compRef.translatedParentLabel) {\r\n                {{controlError.compRef.translatedParentLabel}}&nbsp;&#8208;\r\n              }\r\n            \r\n            {{controlError.compRef.label | translate}}&nbsp;&#8208;&nbsp;{{ getValidatorErrorMessageKey(controlError.compRef.currentError) | translate: controlError.compRef.errorParams}}\r\n          </a>\r\n        </li>\r\n      </ng-container>\r\n    </ul>\r\n  </section>\r\n  <!-- <pre>{{errors|json}}</pre>-->\r\n  <!-- <pre *ngFor=\"let parentError of errors | keys\"></pre>-->\r\n</div>\r\n", styles: [""], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i2.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "pipe", type: JsonKeysPipe, name: "keys" }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorSummaryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-error-summary', encapsulation: ViewEncapsulation.None, template: "<div id=\"{{compId}}\" *ngIf=\"hiddenSummary\">\r\n  <section class=\"alert alert-danger\" tabindex=\"-1\" [ngSwitch]=\"hdingLevel\">\r\n    <h1 *ngSwitchCase=\"'h1'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h1>\r\n    <h2 *ngSwitchCase=\"'h2'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h2>\r\n    <h3 *ngSwitchCase=\"'h3'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h3>\r\n    <h4 *ngSwitchCase=\"'h4'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h4>\r\n    <h5 *ngSwitchCase=\"'h5'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h5>\r\n    <h6 *ngSwitchCase=\"'h6'\">\r\n      <ng-container *ngTemplateOutlet=\"sharedHeadingContent\"></ng-container>\r\n    </h6>\r\n\r\n    <ng-template #sharedHeadingContent>\r\n      <!--<span>For</span>--><span> {{headingPreamble |translate: {seqnumber: headingPreambleParams} }}</span>\r\n      <span>{{'error.found.because'|translate}}</span>\r\n      <span>{{errorList.length}}</span>\r\n      <span *ngIf=\"errorList?.length>1\">{{'error.found.plural'|translate}}</span>\r\n      <span *ngIf=\"errorList?.length<2\">{{'error.found.singular'|translate}}</span>\r\n    </ng-template>\r\n\r\n    <ul *ngFor=\"let parentError of errors | keys\">\r\n      <ng-container *ngFor=\"let controlError of parentError.value.controls\">\r\n        <li *ngIf=\"controlError.type==='component_error'\">\r\n          <a href=\"#{{controlError.componentId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">{{'error' | translate: {number:controlError.errorNumber} }}&nbsp;{{controlError.label|translate}}</a>\r\n        </li>\r\n        <li *ngIf=\"controlError.type==='least_one_rec_error' && !controlError.error\">\r\n          <a href=\"#{{controlError.tableId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">{{'error' | translate: {number:controlError.errorNumber} }}&nbsp;{{controlError.label|translate}}</a>\r\n        </li>\r\n        <li *ngIf=\"controlError.type==='least_one_rec_error' && controlError.error\">\r\n          <a href=\"#{{controlError.tableId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">{{'error' | translate: {number:controlError.errorNumber} }}&nbsp;{{controlError.label|translate}}&nbsp;&#8208;&nbsp;{{ getValidatorErrorMessageKey(controlError.error) | translate: controlError.compRef.errorParams}}</a>\r\n        </li>\r\n        <li *ngIf=\"controlError.type!=='component_error' && controlError.type!='least_one_rec_error'\">\r\n          <a href=\"#{{controlError.controlId}}\" target=\"_self\" (click)=\"processEvents(controlError)\">\r\n            {{'error' | translate: {number:controlError.errorNumber} }}\r\n            \r\n              @if(controlError.compRef.translatedParentLabel) {\r\n                {{controlError.compRef.translatedParentLabel}}&nbsp;&#8208;\r\n              }\r\n            \r\n            {{controlError.compRef.label | translate}}&nbsp;&#8208;&nbsp;{{ getValidatorErrorMessageKey(controlError.compRef.currentError) | translate: controlError.compRef.errorParams}}\r\n          </a>\r\n        </li>\r\n      </ng-container>\r\n    </ul>\r\n  </section>\r\n  <!-- <pre>{{errors|json}}</pre>-->\r\n  <!-- <pre *ngFor=\"let parentError of errors | keys\"></pre>-->\r\n</div>\r\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: ErrMessageService }], propDecorators: { headingPreamble: [{
                type: Input
            }], headingPreambleParams: [{
                type: Input
            }], errorList: [{
                type: Input
            }], hiddenSummary: [{
                type: Input
            }], compId: [{
                type: Input
            }], label: [{
                type: Input
            }], headingLevel: [{
                type: Input
            }] } });

// ref: https://stackoverflow.com/questions/67834802/template-error-type-abstractcontrol-is-not-assignable-to-type-formcontrol
class FormControlPipe {
    transform(value) {
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FormControlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: FormControlPipe, name: "formControl" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FormControlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'formControl',
                }]
        }] });

// todo description of the class
var SortOn;
(function (SortOn) {
    SortOn["ID"] = "id";
    SortOn["ENGLISH"] = "en";
    SortOn["FRENCH"] = "fr";
    SortOn["PRIORITY"] = "sortPriority";
})(SortOn || (SortOn = {}));

class UtilsService {
    constructor() {
        // return true if the value is in the array of valid values
        this.toBoolean = (value) => [true, 'TRUE', 'T', '1', 1].includes(typeof value === 'string' ? value.toUpperCase() : value);
    }
    isCanadaOrUSA(countryValue) {
        return this.isCanada(countryValue) || this.isUsa(countryValue);
    }
    /**
     * Checks of the value is canada or not. Checks for Json object vs single value
     * @param value the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isCanada(countryValue) {
        return countryValue === CANADA;
    }
    /**
     * Checks if the value usa or not. Checks for Json object vs single value
     * @param value - the value to check can be the json object with an id index.
     * @returns {boolean}
     */
    isUsa(countryValue) {
        return countryValue === USA;
    }
    static isFrench(lang) {
        return lang === FRENCH;
    }
    isFrench(lang) {
        return lang === FRENCH;
    }
    getFormattedDate(format) {
        const today = new Date();
        const pipe = new DatePipe('en-US');
        return pipe.transform(today, format);
    }
    /*
    check if the component is first time loaded
    Object.values to retrieve all changes as an array
    Array.some to check whether any of the changes has isFirstChange set
    Beware: If no @Input is set at all, isFirstChange will be false because Array.some stops at the first true value.
    */
    isFirstChange(changes) {
        return Object.values(changes).some(c => c.isFirstChange());
    }
    /**
     * find a code by its id in a code array
     * @param codeArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeById(codeArray, id) {
        return this.isEmpty(id) ? undefined : codeArray.find(obj => obj.id === id);
    }
    /*
    * takes an array of ids,
    * uses the filter method to iterate through the codeArray and includes only those objects whose id is present in the idsToFilter array
    * the filtered array is then returned
    */
    filterCodesByIds(codeArray, idsToFilter) {
        return codeArray.filter((code) => idsToFilter.includes(code.id));
    }
    /**
     * find a codeDefinition by its id in a codeDefinition array
     * @param codeDefinitionArray
     * @param id
     * @returns either a code or undefined
     */
    findCodeDefinitionById(codeDefinitionArray, id) {
        return this.isEmpty(id) ? undefined : codeDefinitionArray.find(obj => obj.id === id);
    }
    /**
     * get the id value from an IdTextLabel object
     * @param idTextLabelObj
     * @returns either id or undefined
     */
    getIdFromIdTextLabel(idTextLabelObj) {
        return !this.isEmpty(idTextLabelObj) ? idTextLabelObj._id : undefined;
    }
    getIdsFromIdTextLabels(idTextLabelObjs) {
        let ids = [];
        if (!this.isEmpty(idTextLabelObjs)) {
            if (Array.isArray(idTextLabelObjs) && this.isArrayOfIIdTextLabel(idTextLabelObjs)) {
                for (const temp of idTextLabelObjs) {
                    ids.push(this.getIdFromIdTextLabel(temp));
                }
            }
            else if (!Array.isArray(idTextLabelObjs) && this.isIIdTextLabel(idTextLabelObjs)) {
                ids.push(this.getIdFromIdTextLabel(idTextLabelObjs));
            }
        }
        return ids;
    }
    getLabelFromIdTextLabelByLang(idTextLabelObj, lang) {
        return !this.isEmpty(idTextLabelObj) ? (this.isFrench(lang) ? idTextLabelObj._label_fr : idTextLabelObj._label_en) : undefined;
    }
    isArrayOfIIdTextLabel(arr) {
        return arr.every(item => this.isIIdTextLabel(item));
    }
    isIIdTextLabel(obj) {
        return obj === null ? false : (typeof obj._id === 'string' &&
            (typeof obj.__text === 'undefined' || typeof obj.__text === 'string') &&
            typeof obj._label_en === 'string' &&
            typeof obj._label_fr === 'string');
    }
    // filter an IParentChildren array by parentId and return its children
    filterParentChildrenArray(arr, pId) {
        if (!pId) {
            return [];
        }
        const filteredArray = arr.filter((x) => x.parentId === pId);
        //    console.log(
        //      'filterParentChildrenArray ~ filteredArray',
        //      filteredArray
        // );
        // Check if filteredArray is not empty and return children
        if (filteredArray.length > 0) {
            return filteredArray[0]['children'];
        }
        // If no match found, return an empty array
        return [];
    }
    // return a concatated string, delimited by a space
    concat(...param) {
        // console.log(param.join(' ')) // [1,2]
        return param.join(' ');
    }
    // reset form controls' values
    resetControlsValues(...controls) {
        controls.forEach(c => {
            if (c instanceof FormArray) {
                // console.log("....FormArray")
                // If it's a FormArray, clear all existing form controls within it
                c.clear();
                c.markAsUntouched();
            }
            else if (c instanceof AbstractControl && 'setValue' in c) {
                // console.log("....FormControl")
                // If it's a FormControl, reset its value
                c.setValue(null);
                c.markAsUntouched();
            }
        });
    }
    getCodeDefinitionByLang(codeDefinition, lang) {
        if (codeDefinition) {
            if (this.isFrench(lang)) {
                return codeDefinition.defFr;
            }
            else {
                return codeDefinition.defEn;
            }
        }
        else {
            return null;
        }
    }
    // Function to find a match by id and return the appropriate definition based on lang
    getCodeDefinitionByIdByLang(id, list, lang) {
        // Find the ICodeDefinition object with the matching id
        const codeDefinition = list.find(item => item.id === id);
        // If no match is found, return undefined
        if (!codeDefinition) {
            return null;
        }
        return this.getCodeDefinitionByLang(codeDefinition, lang);
    }
    isEmpty(value) {
        return value === null || value === undefined || value === "";
    }
    flattenArrays(arrays) {
        return [].concat(...arrays);
    }
    // returns true if any item in array1 is in array2
    isArray1ElementInArray2(array1, array2) {
        for (const item1 of array1) {
            const found = array2.find(x => x === item1);
            if (found) {
                return true;
            }
        }
        return false;
    }
    // Function to copy values from source to destination
    copyFormGroupValues(source, destination) {
        Object.keys(source.controls).forEach(controlName => {
            if (destination.controls[controlName]) {
                destination.controls[controlName].setValue(source.controls[controlName].value);
            }
        });
    }
    getControlName(control) {
        var controlName = null;
        var parent = control["_parent"];
        // only such parent, which is FormGroup, has a dictionary 
        // with control-names as a key and a form-control as a value
        if (parent instanceof FormGroup) {
            // now we will iterate those keys (i.e. names of controls)
            Object.keys(parent.controls).forEach((name) => {
                // and compare the passed control and 
                // a child control of a parent - with provided name (we iterate them all)
                if (control === parent.controls[name]) {
                    // both are same: control passed to Validator
                    //  and this child - are the same references
                    controlName = name;
                }
            });
        }
        // we either found a name or simply return null
        return controlName;
    }
    logFormControlState(form, indent = '\t') {
        if (form) {
            console.log(`${indent}Pristine: ${form.pristine}`);
            console.log(`${indent}Dirty: ${form.dirty}`);
            console.log(`${indent}Touched: ${form.touched}`);
            console.log(`${indent}Untouched: ${form.untouched}`);
            console.log(`${indent}Valid: ${form.valid}`);
            console.log(`${indent}invalid: ${form.invalid}`);
            // ... other properties you might want to log
            if (form instanceof FormGroup) {
                Object.keys(form.controls).forEach((controlName) => {
                    const control = form.get(controlName);
                    if (control) {
                        console.log(`\t\t Control: ${controlName}`);
                        this.logFormControlState(control, '\t\t');
                    }
                });
            }
        }
    }
    checkInputValidity(event, control, errorMsgKey) {
        if (event.target.validity.badInput) {
            if (errorMsgKey == 'invalidDate') {
                control.setErrors({ 'error.msg.invalidDate': true });
            }
            // ...
        }
        else {
            // clear up previous errors
            control.setErrors(null);
            // Recalculates the value and validation status of the control, eg trigger "Validators.required" validation
            control.updateValueAndValidity();
        }
        // logFormControlState(control);
    }
    checkComponentChanges(changes) {
        let changesArray = [];
        for (const prop in changes) {
            if (changes.hasOwnProperty(prop)) {
                const change = changes[prop];
                const isFormGroup = change.currentValue instanceof FormGroup;
                const currentValue = isFormGroup ? change.currentValue.value : JSON.stringify(change.currentValue);
                const isFirstChange = change.isFirstChange();
                changesArray.push({ propertyName: prop, isFirstChange, currentValue });
            }
        }
        return changesArray;
    }
    checkFormInvalidFields(FormGroup) {
        let invalidFields = [];
        Object.keys(FormGroup.controls).forEach(key => {
            const control = FormGroup.get(key);
            if (control.invalid) {
                invalidFields.push(`Field '${key}' is invalid`);
            }
        });
    }
    findAndTranslateCode(codeArray, lang, codeId) {
        const bilingualCode = this.findCodeById(codeArray, codeId);
        if (bilingualCode) {
            return this.translateCode(bilingualCode, lang);
        }
        return null; // Return null if the word is not found
    }
    translateCode(code, lang) {
        // console.log("translateCode", "code", code, "lang", lang)
        return this.isFrench(lang) ? code.fr : code.en;
    }
    createIIdTextLabelObj(id, label_en, label_fr, text) {
        return {
            _id: id,
            __text: text,
            _label_en: label_en,
            _label_fr: label_fr
        };
    }
    //sort a list of ICode objects either by en or fr value based on the language
    sortCodeList(codeArray, lang) {
        return codeArray.sort((a, b) => this.isFrench(lang) ? a.fr.localeCompare(b.fr) : a.en.localeCompare(b.en));
    }
    // to get enum value from string
    getEnumValueFromString(enumType, value) {
        for (const key in enumType) {
            if (enumType[key] === value) {
                return enumType[key];
            }
        }
        return undefined;
    }
    formatAsSixDigitNumber(value) {
        const leadingZeros = '000000';
        return leadingZeros.substring(0, 6 - value.length) + value;
    }
    removeFirstAndLastChars(value) {
        if (value.length <= 2) {
            return '';
        }
        return value.substring(1, value.length - 1);
    }
    // get CompareFields to compare a list of Code objects
    // sort on sortPriority field first if required, and then en or fr field based on the form's language
    getCompareFields(sortOnPriority, lang) {
        let compareFields = [];
        if (sortOnPriority) {
            compareFields.push(SortOn.PRIORITY);
        }
        this.isFrench(lang) ? compareFields.push(SortOn.FRENCH) : compareFields.push(SortOn.ENGLISH);
        return compareFields;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: UtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: UtilsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: UtilsService, decorators: [{
            type: Injectable
        }] });

// take an ICode value and return either en or fr value based on lang
class TextTransformPipe {
    transform(value, lang) {
        return UtilsService.isFrench(lang) ? value.fr : value.en;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: TextTransformPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: TextTransformPipe, name: "textTransform" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: TextTransformPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'textTransform'
                }]
        }] });

// take an ICodeAria value and return either en or fr value based on lang
class AriaTransformPipe {
    transform(value, lang) {
        return UtilsService.isFrench(lang) ? value.ariaFr : value.ariaEn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AriaTransformPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: AriaTransformPipe, name: "ariaTransform" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AriaTransformPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'ariaTransform'
                }]
        }] });

class PipesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PipesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: PipesModule, declarations: [JsonKeysPipe,
            FormControlPipe,
            TextTransformPipe,
            AriaTransformPipe], exports: [JsonKeysPipe,
            FormControlPipe,
            TextTransformPipe,
            AriaTransformPipe] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PipesModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PipesModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        JsonKeysPipe,
                        FormControlPipe,
                        TextTransformPipe,
                        AriaTransformPipe
                    ],
                    exports: [
                        JsonKeysPipe,
                        FormControlPipe,
                        TextTransformPipe,
                        AriaTransformPipe
                    ],
                }]
        }] });

class ErrorNotificationService {
    constructor() {
        // error summaries change notification for all records in a list(eg. contact records) 
        this.errorSummarySubject = new BehaviorSubject([]);
        this.errorSummaryChanged$ = this.errorSummarySubject.asObservable();
    }
    updateErrorSummary(key, errorMessage) {
        const currentErrors = this.errorSummarySubject.value;
        // Check if the error key already exists, 
        // use == not === so comparison of the number 1 and the string "1" returns true 
        const existingErrorIndex = currentErrors.findIndex(error => error.key == key);
        if (existingErrorIndex !== -1) {
            // If the error key exists, update the error errSummaryMessage
            currentErrors[existingErrorIndex].errSummaryMessage = errorMessage;
        }
        else {
            // If the error key does not exist, add the new error
            currentErrors.push({ key, errSummaryMessage: errorMessage });
        }
        // Update the errorSummarySubject with the modified array of errors
        this.errorSummarySubject.next(currentErrors);
    }
    removeErrorSummary(key) {
        const currentErrors = this.errorSummarySubject.value;
        // Filter out the entry with the specified key
        // use == not === so comparison of the number 1 and the string "1" returns true 
        const updatedErrors = currentErrors.filter(error => error.key != key);
        // Update the errorSummarySubject with the filtered array of errors
        this.errorSummarySubject.next(updatedErrors);
    }
    clearErrors() {
        this.errorSummarySubject.next([]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorNotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorNotificationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorNotificationService, decorators: [{
            type: Injectable
        }] });

class ErrorModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: ErrorModule, declarations: [ErrorSummaryComponent,
            ControlMessagesComponent], imports: [CommonModule,
            PipesModule,
            TranslateModule], exports: [ErrorSummaryComponent,
            ControlMessagesComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorModule, providers: [ErrMessageService, ErrorNotificationService], imports: [CommonModule,
            PipesModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ErrorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PipesModule,
                        TranslateModule,
                    ],
                    declarations: [
                        ErrorSummaryComponent,
                        ControlMessagesComponent
                    ],
                    exports: [
                        ErrorSummaryComponent,
                        ControlMessagesComponent
                    ],
                    providers: [ErrMessageService, ErrorNotificationService]
                }]
        }] });

class DataLoaderService {
    constructor(http) {
        this.http = http;
    }
    // public getData<T>(filename: string): Observable<T[]> {
    //   return this.http.get<any>(GlobalsService.DATA_PATH + filename);
    // }
    getData(endpoint) {
        return this.http.get(endpoint).pipe();
    }
    /**
     * @deprecated Will not be used in the future, use getSortedDataAccents() instead
     * @param endpoint
     * @param compareField
     * @returns
     */
    getSortedData(endpoint, compareField) {
        const compareFn = this.getCompareFunction(compareField);
        return this.getData(endpoint).pipe(map(data => data.sort(compareFn)));
    }
    getCompareFunction(compareField) {
        return (a, b) => {
            const valA = this.getFieldValue(a, compareField);
            const valB = this.getFieldValue(b, compareField);
            return valA < valB ? -1 : valA > valB ? 1 : 0;
        };
    }
    getSortedDataAccents(endpoint, compareFields) {
        const compareFn = this.getCompareFunctions(compareFields);
        return this.getData(endpoint).pipe(map(data => data.sort(compareFn)));
    }
    getCompareFunctions(compareFields) {
        return (a, b) => {
            let valA = '';
            let valB = '';
            for (const field of compareFields) {
                valA += this.getFieldValue(a, field);
                valB += this.getFieldValue(b, field);
            }
            return valA.toString().localeCompare(valB.toString());
        };
    }
    getFieldValue(obj, field) {
        if (field === SortOn.PRIORITY && obj.sortPriority !== undefined) {
            // Pad leading 0's, assume the max # of digits in sortPriority is 2 
            const paddedValue = obj.sortPriority.toString().padStart(3, '0');
            return paddedValue;
        }
        return obj[field];
    }
    handleError(err) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        let errorMessage;
        if (err.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            errorMessage = `An error occurred: ${err.error.message}`;
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            errorMessage = `Backend returned code ${err.status}: ${err.message}`;
        }
        console.error(err);
        return throwError(() => errorMessage);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: DataLoaderService, deps: [{ token: i1$1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: DataLoaderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: DataLoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }] });

// output data model

class EntityBaseService {
    getEmptyIdTextLabel() {
        return {
            __text: '',
            _id: '',
            _label_en: '',
            _label_fr: '',
        };
    }
    getEmptyIIdText() {
        return {
            __text: '',
            _id: '',
        };
    }
    getEmptyLabel() {
        return {
            _label_en: '',
            _label_fr: '',
        };
    }
    getEmptyITextLabel() {
        return {
            __text: '',
            _label_en: '',
            _label_fr: ''
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBaseService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBaseService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: EntityBaseService, decorators: [{
            type: Injectable
        }] });

// data model used in Angular forms

/**
 * form data/output data converter/mapper
 */
class ConverterService {
    constructor(_utilsService) {
        this._utilsService = _utilsService;
    }
    convertCodeToIdTextLabel(codeObj, lang) {
        if (codeObj === undefined || codeObj === null) {
            return null;
        }
        else {
            const idTextLabelObj = {};
            idTextLabelObj.__text = this._utilsService.isFrench(lang) ? codeObj.fr : codeObj.en;
            idTextLabelObj._id = codeObj.id;
            idTextLabelObj._label_en = codeObj.en;
            idTextLabelObj._label_fr = codeObj.fr;
            return idTextLabelObj;
        }
    }
    convertCodeToCheckboxOption(codeObj, lang) {
        if (codeObj === undefined || codeObj === null) {
            return null;
        }
        else {
            const checkboxOption = {};
            checkboxOption.value = codeObj.id;
            checkboxOption.label = this._utilsService.isFrench(lang) ? codeObj.fr : codeObj.en;
            checkboxOption.checked = false;
            return checkboxOption;
        }
    }
    // find a ICode in a ICodeList and convert it to an IdTextLabel object
    findAndConverCodeToIdTextLabel(codeList, controlVal, lang) {
        // filter a CodeList by a form control value
        const codeVal = this._utilsService.findCodeById(codeList, controlVal);
        // if found, convert the Code value to an IIdTextLabel object and return it, otherwise return null
        return codeVal ? this.convertCodeToIdTextLabel(codeVal, lang) : null;
    }
    // loop through the controlVals and find it's each and every value in a ICodeList and convert it to an IdTextLabel object 
    // return an IdTextLabel[]
    findAndConverCodesToIdTextLabels(codeList, controlVals, lang) {
        let idTextLabels = [];
        for (const controlVal of controlVals) {
            const temp = this.findAndConverCodeToIdTextLabel(codeList, controlVal, lang);
            if (temp) {
                idTextLabels.push(temp);
            }
            else {
                console.error("ConverterService", "findAndConverCodesToIdTextLabels", `couldn't find '${controlVal}' in codeList`);
                return null;
            }
        }
        return idTextLabels;
    }
    // takes an array of codes and iterates through it, 
    // for each codes, finds the index of the corresponding option in optionList,
    // it the option is found, sets the values of the corresponding checkbox in checkboxFormArray to true
    checkCheckboxes(loadedCodes, optionList, checkboxFormArray) {
        loadedCodes.forEach(id => {
            const index = optionList.findIndex(option => option.value === id);
            if (index !== -1) {
                checkboxFormArray.controls[index].setValue(true);
            }
        });
    }
    getCheckedCheckboxValues(optionList, checkboxFormArray) {
        return optionList
            .filter((item, idx) => checkboxFormArray.controls.some((control, controlIdx) => idx === controlIdx && control.value))
            .map(item => item.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ConverterService, deps: [{ token: UtilsService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ConverterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ConverterService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: UtilsService }] });

class ConvertResults {
    constructor() {
        this.messages = [];
        // public data: Transaction = null;  //todo
        this.data = null;
    }
}

const IMPORT_SUCCESS = 'msg.success.load'; // json key
const PARSE_FAIL = 'msg.err.parse.fail';
// export const JSON_PARSE_FAIL = 'msg.err.jsonparse'; // json key
// export const XML_PARSE_FAIL = 'msg.err.xmlparse';
const FILE_TYPE_ERROR = 'msg.err.file.type';
const FORM_TYPE_ERROR = 'msg.err.form.type';
const CHECK_SUM_ERROR = 'msg.err.checksum';
const DRAFT_FILE_TYPE = 'hcsc';
const FINAL_FILE_TYPE = 'xml';

class FileConversionService {
    constructor() {
    }
    /***
     * Converts an incoming json string to a json object
     * @param data -the json string to convert
     * @param convertResult -the json object to store the data in
     */
    convertToJSONObjects(jsonData, convertResult) {
        convertResult.messages = [];
        try {
            convertResult.data = JSON.parse(jsonData);
            convertResult.messages.push(IMPORT_SUCCESS);
        }
        catch (e) {
            convertResult.data = null;
            convertResult.messages.push(PARSE_FAIL);
        }
    }
    /***
     *  Using xml2js to do the coversion from JSON to XML
     * @param data
     * @param convertResult
     */
    convertXMLToJSONObjects(data, convertResult) {
        let xmlConfig = {
            escapeMode: true,
            emptyNodeForm: 'text',
            useDoubleQuotes: true
        };
        let jsonConverter = new X2JS(xmlConfig);
        convertResult.messages = [];
        // converts XML as a string to a json
        convertResult.data = jsonConverter.xml_str2json(data);
        if (convertResult.data == null) {
            convertResult.messages.push(PARSE_FAIL);
        }
        return (null);
        /* //see https://www.npmjs.com/package/xml2js for list of options
         let config = {
           attrkey: FileIoGlobalsService.attributeKey, //when there are attributes, this is the key, default $
           charkey: FileIoGlobalsService.innerTextKey, //when there are attributes, this what hte text value is of the tag
           trim: true,
           explicitArray: false, //Makes all the values an array
         };
         convertResult.messages = [];
         xml2js.parseString(data, config, function (err, result) {
           convertResult.data = result;
         });
         if (convertResult.data === null) {
           convertResult.messages.push(FileIoGlobalsService.parseFail);
         } else {
           convertResult.messages.push(FileIoGlobalsService.importSuccess);
           // console.log(convertResult);
         }*/
    }
    /***
     * Converts a json object to XML. Assumes root tag is root of JSON object
     * @param jsonObj
     * @returns {any}
     */
    convertJSONObjectsToXML(jsonObj) {
        if (!jsonObj)
            return null;
        /* let builder = new xml2js.Builder({
           headless: true,    //make headless for easier addition of xsl. Add header manualt
           attrkey: FileIoGlobalsService.attributeKey, //when there are attributes, this is the key, default $
           charkey: FileIoGlobalsService.innerTextKey, //when there are attributes, this what hte text value is of the tag
           explicitArray: false,
           explicitChildren: true
         });
         //making headless so easier to add the stylesheet info
         let xmlResult = builder.buildObject(jsonObj);*/
        let xmlConfig = {
            escapeMode: true,
            emptyNodeForm: 'text',
            useDoubleQuotes: true
        };
        let jsonConverter = new X2JS(xmlConfig);
        // converts XML as a string to a json
        let xmlResult = jsonConverter.json2xml_str(jsonObj);
        return xmlResult;
    }
    //let blob = new Blob([makeStrSave], {type: 'text/plain;charset=utf-8'});
    saveJsonToFile(jsonObj, fileName, rootTag) {
        if (!jsonObj)
            return;
        let makeStrSave = JSON.stringify(jsonObj);
        let blob = new Blob([makeStrSave], { type: 'text/plain;charset=utf-8' });
        // if (!fileName) {
        //   fileName = 'REPDraft.' + DRAFT_FILE_TYPE;
        // } else {
        fileName += '.' + DRAFT_FILE_TYPE;
        // }
        FileSaver.saveAs(blob, fileName);
    }
    /**
     * Saves the incoming JSON data as an xml file
     * @param jsonObj -the json object to write as XML
     * @param {string} fileName - the bsse filename to save the file as. the suffix is sdded
     * @param {boolean} addXsl
     * @param {string} xslName
     */
    saveXmlToFile(jsonObj, fileName, addXsl = true, xslName = null) {
        if (!jsonObj)
            return;
        let xmlResult = this.convertJSONObjectsToXML(jsonObj);
        if (addXsl) {
            // if (!xslName) {
            //   xmlResult = '<?xml version="1.0" encoding="UTF-8"?>' + '<?xml-stylesheet  type="text/xsl" href=' + defaultXSLName + '?>' + xmlResult;
            // } else {
            xmlResult = '<?xml version="1.0" encoding="UTF-8"?>' + '<?xml-stylesheet  type="text/xsl" href="' + xslName + '"?>' + xmlResult;
            // }
        }
        let blob = new Blob([xmlResult], { type: 'text/plain;charset=utf-8' });
        // if (!fileName) {
        //   fileName = 'REPFinal.' + FINAL_FILE_TYPE;
        // } else {
        fileName += '.' + FINAL_FILE_TYPE;
        // }
        FileSaver.saveAs(blob, fileName);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FileConversionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FileConversionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FileConversionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

const CHECK_SUM_CONST = "check_sum";

class CheckSumService {
    constructor() { }
    checkHash(convertResultData) {
        for (const key in convertResultData) {
            if (convertResultData.hasOwnProperty(key)) {
                for (const seckey in convertResultData[key]) {
                    if (convertResultData[key].hasOwnProperty(seckey)) {
                        if (seckey === CHECK_SUM_CONST) {
                            let hashFromFile = convertResultData[key][seckey];
                            convertResultData[key][seckey] = "";
                            let hash = CryptoJS.MD5(JSON.stringify(convertResultData));
                            if (hash.toString(CryptoJS.enc.MD5) === hashFromFile) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
    createHash(result) {
        let fileConversion = new FileConversionService();
        let xResult = fileConversion.convertJSONObjectsToXML(result);
        let cr = new ConvertResults();
        fileConversion.convertXMLToJSONObjects(xResult, cr);
        result = cr.data;
        const hash = CryptoJS.MD5(JSON.stringify(result));
        return hash.toString(CryptoJS.enc.MD5);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CheckSumService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CheckSumService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CheckSumService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class FilereaderComponent {
    constructor(translate) {
        this.translate = translate;
        this.complete = new EventEmitter();
        this.rootTag = '';
        this.lang = '';
        this.status = IMPORT_SUCCESS;
        this.importSuccess = false;
        this.importedFileName = "";
        this.displayAlert = false; // reloads the role=alert each message
        this.rootId = '';
        this.fileImported = false;
    }
    ngOnInit() {
        // console.log(this.rootTag);
    }
    ngOnChanges(changes) {
        if (changes['rootTag']) {
            this.rootId = changes['rootTag'].currentValue;
        }
    }
    /**
     * Attaches to the file browser, detecting the file selection change
     * @param $event
     */
    changeListener($event) {
        this.readSelectedFile($event.target);
    }
    /**
     * Determines if a file was selected. Sets a callback to process the file after load (asych)
     * @param inputValue
     */
    readSelectedFile(inputValue) {
        this.fileImported = true;
        let file = inputValue.files[0];
        let myReader = new FileReader();
        let self = this;
        myReader.onloadend = function (e) {
            // you can perform an action with data here callback for asynch load
            let convertResult = new ConvertResults();
            FilereaderComponent._readFile(file.name, myReader.result, self.rootId, convertResult, self.versionTagPath, self.startCheckSumVersion, self.devEnv, self.byPassCheckSum);
            if (convertResult.messages && convertResult.messages.length > 0) {
                self.status = convertResult.messages[0];
            }
            else {
                self.status = IMPORT_SUCCESS;
            }
            if (self.status === IMPORT_SUCCESS) {
                self.importSuccess = true;
            }
            self.importedFileName = file.name;
            self.displayAlert = false;
            setTimeout(() => {
                self.displayAlert = true;
            }, 10);
            setTimeout(() => {
            }, 100);
            self.complete.emit(convertResult);
        };
        if (file && file.name) {
            myReader.readAsText(file);
        }
    }
    /***
     * Processes the file data. Determines the type of file based on the filename suffix
     * @param name - the name of the file. Can include the path
     * @param result - the result of the file read i.e. file contents as text
     * @param rootId - the name of the rootTag. If null is ignored
     * @param {ConvertResults} convertResult -The results of the file read
     * @private
     */
    static _readFile(name, result, rootId, convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass) {
        let splitFile = name.split('.');
        let fileType = splitFile[splitFile.length - 1];
        let conversion = new FileConversionService();
        if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE || fileType.toLowerCase() === FINAL_FILE_TYPE) {
            if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE) {
                conversion.convertToJSONObjects(result, convertResult);
            }
            else {
                conversion.convertXMLToJSONObjects(result, convertResult);
            }
            // console.log(convertResult.data);
            FilereaderComponent.checkRootTagMatch(convertResult, rootId);
            if (fileType.toLowerCase() === FINAL_FILE_TYPE && convertResult.messages.length === 0) {
                if (this.doCheckSumCheck(convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass))
                    if (versionTagPath == null && startCheckSumVersion == null) {
                        this.checkSumCheck(convertResult, rootId);
                    }
                    else {
                        this.strictCheckSumCheck(convertResult, rootId);
                    }
            }
        }
        else {
            convertResult.data = null;
            convertResult.messages = []; //clear msessages
            convertResult.messages.push(FILE_TYPE_ERROR);
        }
    }
    static checkRootTagMatch(convertResult, rootName) {
        if (!rootName || !convertResult || !convertResult.data)
            return;
        if (!convertResult.data[rootName]) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(FORM_TYPE_ERROR);
        }
    }
    refreshPage() {
        location.reload();
    }
    static checkSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!convertResult.data[rootName][CHECK_SUM_CONST]) {
            return;
        }
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static strictCheckSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static doCheckSumCheck(convertResult, versionPath, startCheckSumVersion, devEnv, byPass) {
        if (versionPath != null && startCheckSumVersion != null) {
            var version = convertResult.data;
            versionPath.split(".").forEach(function (key) {
                version = version[key];
            });
            version = parseInt(version.split('.')[0], 10);
            if (version < startCheckSumVersion) {
                return false;
            }
        }
        if (devEnv && byPass) {
            console.warn("Bypassing Checksum Verification in Dev Mode!");
            return false;
        }
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FilereaderComponent, deps: [{ token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: FilereaderComponent, selector: "lib-file-reader", inputs: { rootTag: "rootTag", lang: "lang", versionTagPath: "versionTagPath", startCheckSumVersion: "startCheckSumVersion", devEnv: "devEnv", byPassCheckSum: "byPassCheckSum" }, outputs: { complete: "complete" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <div *ngIf=\"!importSuccess\">\r\n      <button id=\"fileLoadButton\" [attr.aria-labelledby]=\"fileImported ? 'fileName' : 'noFileChosen'\" onclick=\"document.getElementById('fileLoad').click()\" > {{ 'choose.file' | translate }} </button>\r\n      <input style=\"display:none\" type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n      <!-- FOR SCREEN READER : To read \"Select a file to load, no file chosen / (file name) button\" -->\r\n      <span hidden class=\"field-name\" *ngIf=\"!fileImported\" id=\"noFileChosen\"> {{ 'select.file'|translate }} {{ 'no.file.chosen' | translate }} </span>\r\n      <span hidden class=\"field-name\" *ngIf=\"fileImported\" id=\"fileName\"> {{ 'select.file'|translate }} {{importedFileName}} </span>\r\n      <!-- -->\r\n      <span class=\"field-name\" *ngIf=\"!fileImported\"> {{ 'no.file.chosen' | translate }} </span>\r\n      <span class=\"field-name\" *ngIf=\"fileImported\"> {{importedFileName}} </span>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"displayAlert\">\r\n  <span role=\"alert\">{{status | translate}}</span>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>", styles: [""], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FilereaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-file-reader', encapsulation: ViewEncapsulation.None, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <div *ngIf=\"!importSuccess\">\r\n      <button id=\"fileLoadButton\" [attr.aria-labelledby]=\"fileImported ? 'fileName' : 'noFileChosen'\" onclick=\"document.getElementById('fileLoad').click()\" > {{ 'choose.file' | translate }} </button>\r\n      <input style=\"display:none\" type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n      <!-- FOR SCREEN READER : To read \"Select a file to load, no file chosen / (file name) button\" -->\r\n      <span hidden class=\"field-name\" *ngIf=\"!fileImported\" id=\"noFileChosen\"> {{ 'select.file'|translate }} {{ 'no.file.chosen' | translate }} </span>\r\n      <span hidden class=\"field-name\" *ngIf=\"fileImported\" id=\"fileName\"> {{ 'select.file'|translate }} {{importedFileName}} </span>\r\n      <!-- -->\r\n      <span class=\"field-name\" *ngIf=\"!fileImported\"> {{ 'no.file.chosen' | translate }} </span>\r\n      <span class=\"field-name\" *ngIf=\"fileImported\"> {{importedFileName}} </span>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"displayAlert\">\r\n  <span role=\"alert\">{{status | translate}}</span>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>" }]
        }], ctorParameters: () => [{ type: i1.TranslateService }], propDecorators: { complete: [{
                type: Output
            }], rootTag: [{
                type: Input
            }], lang: [{
                type: Input
            }], versionTagPath: [{
                type: Input
            }], startCheckSumVersion: [{
                type: Input
            }], devEnv: [{
                type: Input
            }], byPassCheckSum: [{
                type: Input
            }] } });

class FileIoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FileIoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: FileIoModule, declarations: [FilereaderComponent], imports: [CommonModule,
            TranslateModule], exports: [FilereaderComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FileIoModule, providers: [
            FileConversionService
        ], imports: [CommonModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FileIoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        TranslateModule
                    ],
                    declarations: [
                        FilereaderComponent
                    ],
                    exports: [
                        FilereaderComponent
                    ],
                    providers: [
                        FileConversionService
                    ]
                }]
        }] });

class ValidationService {
    constructor() {
        // private translate: TranslateService
        // this.translate.get('error.msg.required').subscribe(res => { console.log(res); });
    }
    getValidatorErrorMessage(validatorName) {
        // TODO sucky need to make the keys the same as the translation for the error summary
        const config = {
            'required': 'required',
            'error.msg.number': 'error.msg.number',
            'error.msg.phone': 'error.msg.phone',
            'error.msg.fax': 'error.msg.fax',
            'error.msg.email': 'error.msg.email',
            'minlength': 'error.msg.minlength',
            'error.msg.postal': 'error.msg.postal',
            'error.mgs.zip': 'error.mgs.zip',
            'error.mgs.company.id': 'error.mgs.company.id',
            'error.mgs.contact.id': 'error.mgs.contact.id',
            'error.mgs.primary.company.id': 'error.mgs.primary.company.id',
            'error.mgs.primary.contact.id': 'error.mgs.primary.contact.id',
            'error.mgs.5.numeric': 'error.mgs.5.numeric',
            'error.mgs.6.numeric': 'error.mgs.6.numeric',
            'error.mgs.8.numeric': 'error.mgs.8.numeric',
            'error.mgs.regu.contact.id': 'error.mgs.regu.contact.id',
            'error.mgs.dossier.id': 'error.mgs.dossier.id',
            'error.mgs.licence.number': 'error.mgs.licence.number',
            'error.mgs.application.number': 'error.mgs.application.number',
            'error.mgs.din': 'error.mgs.din',
            'error.mgs.npn': 'error.mgs.npn',
            'error.msg.remove.contact': 'error.msg.remove.contact',
            'error.msg.revise.contact': 'error.msg.revise.contact',
            'error.mgs.incorrectFormat': 'error.mgs.incorrectFormat',
            'error.msg.invalidDate': 'error.msg.invalidDate',
            'error.msg.endDate': 'error.msg.endDate',
            'error.msg.amount.limit': 'error.msg.amount.limit',
        };
        return config[validatorName];
    }
    static emailValidator(control) {
        if (!control.value) {
            return null;
        }
        // RFC 2822 compliant regex
        if (control.value.match(/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/)) {
            return null;
        }
        else {
            return { 'error.msg.email': true };
        }
    }
    /*static passwordValidator(control) {
      // {6,100}           - Assert password is between 6 and 100 characters
      // (?=.*[0-9])       - Assert a string has at least one number
      if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
        return null;
      } else {
        return {'invalidPassword': true};
      }
    }*/
    static canadaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^(?!.*[DFIOQU])[A-VXYa-vxy][0-9][A-Za-z] ?[0-9][A-Za-z][0-9]$/)) {
            return null;
        }
        else {
            return { 'error.msg.postal': true };
        }
    }
    static usaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}(?:-[0-9]{4})?$/)) {
            return null;
        }
        else {
            return { 'error.mgs.zip': true };
        }
    }
    static countryValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value[0].id !== '') {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static phoneNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.phone': true };
        }
    }
    static faxNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.fax': true };
        }
    }
    static numberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.number': true };
        }
    }
    static companyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static numeric5Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.5.numeric': true };
        }
    }
    static numeric6Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.6.numeric': true };
        }
    }
    static numeric8Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.8.numeric': true };
        }
    }
    static dossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[m]{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static dossierContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static regulatoryContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.regu.contact.id': true };
        }
    }
    static licenceNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.licence.number': true };
        }
    }
    static appNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.application.number': true };
        }
    }
    static dinValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.din': true };
        }
    }
    static npnValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.npn': true };
        }
    }
    static checkboxRequiredValidator(control) {
        if (control.value) {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static contactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static primaryCompanyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static atLeastOneCheckboxSelected(formArray) {
        // return (): { [key: string]: boolean } | null => {
        const controls = formArray.controls;
        // Check if at least one checkbox is selected
        const isAtLeastOneSelected = controls.some((control) => control.value === true);
        // Return validation error if none are selected
        return isAtLeastOneSelected ? null : { 'required': true };
        // };
    }
    static masterFileNumberValidator(control) {
        // todo
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{4}-[0-9]{3}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.incorrectFormat': true };
        }
    }
    // if first letter is e, then followed by 6 numbers
    // if first letter is f, then followed by 7 numbers
    static masterFileDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[e]{1}[0-9]{6}$/) ||
            control.value.match(/^[f]{1}[0-9]{7}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static accountNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.account': true };
        }
    }
    static businessNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.business': true };
        }
    }
    static limitValidation(control) {
        if (!control.value) {
            return null;
        }
        if (control.value > 10000000) {
            return { 'error.msg.amount.limit': true };
        }
        else {
            return null;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

/* tslint:disable:member-ordering */
class NumbersOnlyDirective {
    constructor(control, el) {
        this.control = control;
        this.el = el;
    }
    onInput(value) {
        this.filterValue(value);
    }
    onPaste(event) {
        const pastedText = event.clipboardData.getData('text/plain');
        this.filterValue(pastedText);
        event.preventDefault(); // Prevent default paste behavior
    }
    filterValue(value) {
        // Replace any non-numeric characters with an empty string
        var newValue = value.replace(/[^\d]/g, '');
        // Update the form control value with the cleaned value
        if (this.el.nativeElement.maxLength != null) {
            const pos = this.el.nativeElement.maxLength;
            newValue = newValue.substring(0, pos);
        }
        this.control.control.setValue(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NumbersOnlyDirective, deps: [{ token: i1$2.NgControl }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: NumbersOnlyDirective, isStandalone: true, selector: "[data-only-digits]", host: { listeners: { "input": "onInput($event.target.value)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NumbersOnlyDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[data-only-digits]'
                }]
        }], ctorParameters: () => [{ type: i1$2.NgControl }, { type: i0.ElementRef }], propDecorators: { onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

/* tslint:disable:member-ordering */
class NumbersLettersDirective {
    constructor(control, el) {
        this.control = control;
        this.el = el;
    }
    onInput(value) {
        this.filterValue(value);
    }
    onPaste(event) {
        const pastedText = event.clipboardData.getData('text/plain');
        this.filterValue(pastedText);
        event.preventDefault(); // Prevent default paste behavior
    }
    filterValue(value) {
        // Allow only letters and numbers, remove all other characters
        let newValue = value.replace(/[^a-zA-Z0-9]/g, '');
        if (this.el.nativeElement.maxLength != null && this.el.nativeElement.maxLength > 0) {
            const maxLength = this.el.nativeElement.maxLength;
            newValue = newValue.substring(0, maxLength);
        }
        this.control.control.setValue(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NumbersLettersDirective, deps: [{ token: i1$2.NgControl }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: NumbersLettersDirective, isStandalone: true, selector: "[data-number-letter]", host: { listeners: { "input": "onInput($event.target.value)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NumbersLettersDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[data-number-letter]'
                }]
        }], ctorParameters: () => [{ type: i1$2.NgControl }, { type: i0.ElementRef }], propDecorators: { onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class CommonFormDendencyModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CommonFormDendencyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: CommonFormDendencyModule, exports: [FormsModule, ReactiveFormsModule, TranslateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CommonFormDendencyModule, imports: [FormsModule, ReactiveFormsModule, TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CommonFormDendencyModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    exports: [FormsModule, ReactiveFormsModule, TranslateModule],
                }]
        }] });

class VersionService {
    getApplicationVersion(appEnvironment) {
        return appEnvironment.appVersion;
    }
    /**
     * get the major and minor version of the application concatenated with '.'
     * @param appVersion format is 1.0.0
     * @returns string
     */
    getApplicationMajorVersion(appVersion) {
        const majorVersion = appVersion.split('.', 2).join('.');
        return majorVersion;
    }
    /**
    * get the major and minor version of the application concatenated with '_'
    * @param appVersion format is 1.0.0
    * @returns string
    */
    getApplicationMajorVersionWithUnderscore(appVersion) {
        const majorVersion = appVersion.split('.', 2).join('_');
        return majorVersion;
    }
    /**
     * Extracts the major version number from a version string.
     *
     * @param versionStr - The version string in the format "major.minor.patch", e.g., "1.0.0".
     * @returns The major version number as an integer.
     */
    getMajorVersion(versionStr) {
        return parseInt(versionStr.split('.')[0], 10);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: VersionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: VersionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: VersionService, decorators: [{
            type: Injectable
        }] });

class LoggerService {
    log(debugEnabled, className, methodName, ...messages) {
        if (debugEnabled) {
            console.log(`${className} -> ${methodName} ->`, ...this.formatMessages(messages));
        }
    }
    error(debugEnabled, className, methodName, ...messages) {
        if (debugEnabled) {
            console.error(`${className} -> ${methodName} ->`, ...this.formatMessages(messages));
        }
    }
    warn(debugEnabled, className, methodName, ...messages) {
        if (debugEnabled) {
            console.warn(`${className} -> ${methodName} ->`, ...this.formatMessages(messages));
        }
    }
    formatMessages(messages) {
        return messages.map(msg => typeof msg === 'object' ? JSON.stringify(msg, null, 2) : msg);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LoggerService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable
        }] });

// import { BrowserModule } from '@angular/platform-browser';
class CommonUiFeatureModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CommonUiFeatureModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: CommonUiFeatureModule, imports: [CommonModule,
            // BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            TranslateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CommonUiFeatureModule, providers: [
            UtilsService,
            VersionService,
            LoggerService,
            ConverterService,
            EntityBaseService,
        ], imports: [CommonModule,
            // BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            TranslateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CommonUiFeatureModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule,
                        // BrowserModule,
                        FormsModule,
                        ReactiveFormsModule,
                        TranslateModule,
                    ],
                    providers: [
                        UtilsService,
                        VersionService,
                        LoggerService,
                        ConverterService,
                        EntityBaseService,
                    ],
                    exports: [],
                }]
        }] });

class NoCacheHeadersInterceptor {
    intercept(req, next) {
        const httpRequest = req.clone({
            headers: req.headers
                .set('Cache-Control', 'no-cache')
                .set('Pragma', 'no-cache')
                .set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT')
        });
        // console.log(httpRequest.headers);
        return next.handle(httpRequest);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NoCacheHeadersInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NoCacheHeadersInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: NoCacheHeadersInterceptor, decorators: [{
            type: Injectable
        }] });

class PrivacyStatementComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PrivacyStatementComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: PrivacyStatementComponent, isStandalone: true, selector: "lib-privacy-statement", inputs: { lang: "lang", purposeOfCollection: "purposeOfCollection" }, ngImport: i0, template: "<div *ngIf=\"lang === 'en'\">\r\n    <p>\r\n        The personal information that you provide is protected and governed in accordance with the Privacy Act. We\r\n        only collect\r\n        personal information required to administer the Canadian drug registration process. The personal information\r\n        is\r\n        collected under the authority of the Food and Drugs Act and the Food and Drug Regulations.\r\n    </p>\r\n    <p>\r\n        <b>Purpose of collection</b>: <ng-container *ngIf=\"purposeOfCollection; else defaultPurpose\">{{purposeOfCollection}}</ng-container>\r\n        <ng-template #defaultPurpose>Health Canada requires the personal information to process regulatory\r\n        application forms related to medical devices under the Regulatory Enrolment Process (REP) within the Canadian drug registration framework. The information you provide may\r\n        be used to contact you to verify provided information, to assess the feasibility of enrolling companies,\r\n        dossiers, and\r\n        track regulatory activities and transactions.</ng-template>\r\n    </p>\r\n    <p>\r\n        <b>For more information</b>: The class of records are described under HC HP 005 on <a\r\n            href=\"https://www.canada.ca/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html\">Info\r\n            Source website</a>.\r\n        The personal information bank for this collection is currently under development.\r\n    </p>\r\n    <p>\r\n        <b>Your rights under the Privacy Act</b>: In addition to protecting your personal information, the Privacy Act\r\n        gives you the right to request access to and\r\n        correct your personal information. You also have the right to file a complaint to the Office of the Privacy\r\n        Commissioner\r\n        if you think your personal information has been handled improperly.\r\n    </p>\r\n    <p>\r\n        For more information about the program, please contact <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>\r\n<div *ngIf=\"lang === 'fr'\">\r\n    <p>\r\n        Les renseignements que vous fournissez \u00E0 Sant\u00E9 Canada sont prot\u00E9g\u00E9s et r\u00E9gis par la Loi sur la protection des\r\n        renseignements personnels. Sant\u00E9 Canada ne recueille que les renseignements personnels n\u00E9cessaires \u00E0\r\n        l'administration du\r\n        processus d'homologation des m\u00E9dicaments. Ces renseignements sont recueillis en vertu de la Loi sur les aliments\r\n        et\r\n        drogues et du R\u00E8glement sur les aliments et drogues.\r\n    </p>\r\n    <p>\r\n        <b>But de la collecte </b>: <ng-container *ngIf=\"purposeOfCollection; else defaultPurpose\">{{purposeOfCollection}}</ng-container>\r\n        <ng-template #defaultPurpose>Sant\u00E9 Canada a besoin des renseignements personnels pour traiter les formulaires de\r\n        demande r\u00E9glementaire li\u00E9s aux instruments m\u00E9dicaux au sein du processus d'inscription r\u00E9glementaire (PIR) dans le cadre canadien d'enregistrement des m\u00E9dicaments. Les informations que vous fournissez peuvent \u00EAtre utilis\u00E9es pour vous\r\n        contacter afin de v\u00E9rifier les informations fournies, d'\u00E9valuer la faisabilit\u00E9 de l'inscription d'entreprises,\r\n        de\r\n        dossiers et de suivre les activit\u00E9s et transactions r\u00E9glementaires.</ng-template>\r\n    </p>\r\n    <p>\r\n        <b>Pour de plus amples renseignements </b>: La cat\u00E9gorie de documents est d\u00E9crite sous HC HP 005 sur le site web\r\n        d'<a\r\n            href=\"https://www.canada.ca/fr/sante-canada/organisation/a-propos-sante-canada/activites-responsabilites/acces-information-protection-renseignements-personnels/info-source-renseignements-gouvernement-federal-fonctionnaires-federaux.html\">\r\n            Info Source</a>.\r\n        La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n    </p>\r\n    <p>\r\n        <b>Vos droits en vertu de la Loi sur la protection des renseignements personnels </b>: En plus de prot\u00E9ger vos\r\n        renseignements personnels, la Loi sur la protection des renseignements personnels vous donne le\r\n        droit de demander l'acc\u00E8s \u00E0 vos renseignements personnels et de les faire corriger. Vous avez \u00E9galement le droit\r\n        de\r\n        d\u00E9poser une plainte aupr\u00E8s du Commissariat \u00E0 la protection de la vie priv\u00E9e si vous estimez que vos\r\n        renseignements\r\n        personnels ont \u00E9t\u00E9 trait\u00E9s de fa\u00E7on inappropri\u00E9e.\r\n    </p>\r\n    <p>\r\n        Pour obtenir de plus amples renseignements sur le programme, veuillez nous \u00E9crire \u00E0 <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>\r\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PrivacyStatementComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-privacy-statement', standalone: true, imports: [CommonModule], template: "<div *ngIf=\"lang === 'en'\">\r\n    <p>\r\n        The personal information that you provide is protected and governed in accordance with the Privacy Act. We\r\n        only collect\r\n        personal information required to administer the Canadian drug registration process. The personal information\r\n        is\r\n        collected under the authority of the Food and Drugs Act and the Food and Drug Regulations.\r\n    </p>\r\n    <p>\r\n        <b>Purpose of collection</b>: <ng-container *ngIf=\"purposeOfCollection; else defaultPurpose\">{{purposeOfCollection}}</ng-container>\r\n        <ng-template #defaultPurpose>Health Canada requires the personal information to process regulatory\r\n        application forms related to medical devices under the Regulatory Enrolment Process (REP) within the Canadian drug registration framework. The information you provide may\r\n        be used to contact you to verify provided information, to assess the feasibility of enrolling companies,\r\n        dossiers, and\r\n        track regulatory activities and transactions.</ng-template>\r\n    </p>\r\n    <p>\r\n        <b>For more information</b>: The class of records are described under HC HP 005 on <a\r\n            href=\"https://www.canada.ca/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html\">Info\r\n            Source website</a>.\r\n        The personal information bank for this collection is currently under development.\r\n    </p>\r\n    <p>\r\n        <b>Your rights under the Privacy Act</b>: In addition to protecting your personal information, the Privacy Act\r\n        gives you the right to request access to and\r\n        correct your personal information. You also have the right to file a complaint to the Office of the Privacy\r\n        Commissioner\r\n        if you think your personal information has been handled improperly.\r\n    </p>\r\n    <p>\r\n        For more information about the program, please contact <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>\r\n<div *ngIf=\"lang === 'fr'\">\r\n    <p>\r\n        Les renseignements que vous fournissez \u00E0 Sant\u00E9 Canada sont prot\u00E9g\u00E9s et r\u00E9gis par la Loi sur la protection des\r\n        renseignements personnels. Sant\u00E9 Canada ne recueille que les renseignements personnels n\u00E9cessaires \u00E0\r\n        l'administration du\r\n        processus d'homologation des m\u00E9dicaments. Ces renseignements sont recueillis en vertu de la Loi sur les aliments\r\n        et\r\n        drogues et du R\u00E8glement sur les aliments et drogues.\r\n    </p>\r\n    <p>\r\n        <b>But de la collecte </b>: <ng-container *ngIf=\"purposeOfCollection; else defaultPurpose\">{{purposeOfCollection}}</ng-container>\r\n        <ng-template #defaultPurpose>Sant\u00E9 Canada a besoin des renseignements personnels pour traiter les formulaires de\r\n        demande r\u00E9glementaire li\u00E9s aux instruments m\u00E9dicaux au sein du processus d'inscription r\u00E9glementaire (PIR) dans le cadre canadien d'enregistrement des m\u00E9dicaments. Les informations que vous fournissez peuvent \u00EAtre utilis\u00E9es pour vous\r\n        contacter afin de v\u00E9rifier les informations fournies, d'\u00E9valuer la faisabilit\u00E9 de l'inscription d'entreprises,\r\n        de\r\n        dossiers et de suivre les activit\u00E9s et transactions r\u00E9glementaires.</ng-template>\r\n    </p>\r\n    <p>\r\n        <b>Pour de plus amples renseignements </b>: La cat\u00E9gorie de documents est d\u00E9crite sous HC HP 005 sur le site web\r\n        d'<a\r\n            href=\"https://www.canada.ca/fr/sante-canada/organisation/a-propos-sante-canada/activites-responsabilites/acces-information-protection-renseignements-personnels/info-source-renseignements-gouvernement-federal-fonctionnaires-federaux.html\">\r\n            Info Source</a>.\r\n        La banque de renseignements personnels pour cette collecte est en cours d'\u00E9laboration.\r\n    </p>\r\n    <p>\r\n        <b>Vos droits en vertu de la Loi sur la protection des renseignements personnels </b>: En plus de prot\u00E9ger vos\r\n        renseignements personnels, la Loi sur la protection des renseignements personnels vous donne le\r\n        droit de demander l'acc\u00E8s \u00E0 vos renseignements personnels et de les faire corriger. Vous avez \u00E9galement le droit\r\n        de\r\n        d\u00E9poser une plainte aupr\u00E8s du Commissariat \u00E0 la protection de la vie priv\u00E9e si vous estimez que vos\r\n        renseignements\r\n        personnels ont \u00E9t\u00E9 trait\u00E9s de fa\u00E7on inappropri\u00E9e.\r\n    </p>\r\n    <p>\r\n        Pour obtenir de plus amples renseignements sur le programme, veuillez nous \u00E9crire \u00E0 <a\r\n            href=\"mailto:ereview&#64;hc-sc.gc.ca\">ereview&#64;hc-sc.gc.ca</a>.\r\n    </p>\r\n</div>\r\n" }]
        }], propDecorators: { lang: [{
                type: Input
            }], purposeOfCollection: [{
                type: Input
            }] } });

class SecurityDisclaimerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SecurityDisclaimerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SecurityDisclaimerComponent, isStandalone: true, selector: "lib-security-disclaimer", inputs: { lang: "lang" }, ngImport: i0, template: "<div>\r\n    <p *ngIf=\"lang === 'en'\">\r\n        The security of any sensitive or confidential data or information that you enter on this form will be entirely\r\n        your\r\n        responsibility and at your own risk. You acknowledge that during the form completion process, your data or\r\n        information\r\n        may be held in cache on your web browser, and in certain events such as a loss of connection, your data and\r\n        information\r\n        may be retained in your local cache. You are responsible for the security of all data and information entered on\r\n        your\r\n        workstation or anywhere on your system, and for marking, handling, storing, and destroying your data and\r\n        information in\r\n        a secure manner.\r\n    </p>\r\n    <p *ngIf=\"lang === 'fr'\">\r\n        Vous \u00EAtes enti\u00E8rement responsable de la s\u00E9curit\u00E9 de toutes les donn\u00E9es et tous les renseignements sensibles ou\r\n        confidentiels que vous indiquez \u00E0 vos propres risques sur ce formulaire. Vous reconnaissez que pendant que vous\r\n        remplissez ce formulaire, vos donn\u00E9es et renseignements peuvent \u00EAtre conserv\u00E9s dans la m\u00E9moire cache de votre\r\n        fureteur\r\n        Web, et que dans certains cas, tels que la perte de connexion, vos donn\u00E9es et renseignements peuvent \u00EAtre\r\n        conserv\u00E9s dans\r\n        votre m\u00E9moire cache locale. Vous \u00EAtes responsable de la s\u00E9curit\u00E9 de toutes les donn\u00E9es et tous les\r\n        renseignements saisis\r\n        dans votre poste de travail ou ailleurs dans votre syst\u00E8me, ainsi que du marquage, du traitement, du stockage et\r\n        de la\r\n        destruction s\u00E9curis\u00E9s de vos donn\u00E9es et renseignements.\r\n    </p>\r\n</div>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SecurityDisclaimerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-security-disclaimer', standalone: true, imports: [CommonModule], template: "<div>\r\n    <p *ngIf=\"lang === 'en'\">\r\n        The security of any sensitive or confidential data or information that you enter on this form will be entirely\r\n        your\r\n        responsibility and at your own risk. You acknowledge that during the form completion process, your data or\r\n        information\r\n        may be held in cache on your web browser, and in certain events such as a loss of connection, your data and\r\n        information\r\n        may be retained in your local cache. You are responsible for the security of all data and information entered on\r\n        your\r\n        workstation or anywhere on your system, and for marking, handling, storing, and destroying your data and\r\n        information in\r\n        a secure manner.\r\n    </p>\r\n    <p *ngIf=\"lang === 'fr'\">\r\n        Vous \u00EAtes enti\u00E8rement responsable de la s\u00E9curit\u00E9 de toutes les donn\u00E9es et tous les renseignements sensibles ou\r\n        confidentiels que vous indiquez \u00E0 vos propres risques sur ce formulaire. Vous reconnaissez que pendant que vous\r\n        remplissez ce formulaire, vos donn\u00E9es et renseignements peuvent \u00EAtre conserv\u00E9s dans la m\u00E9moire cache de votre\r\n        fureteur\r\n        Web, et que dans certains cas, tels que la perte de connexion, vos donn\u00E9es et renseignements peuvent \u00EAtre\r\n        conserv\u00E9s dans\r\n        votre m\u00E9moire cache locale. Vous \u00EAtes responsable de la s\u00E9curit\u00E9 de toutes les donn\u00E9es et tous les\r\n        renseignements saisis\r\n        dans votre poste de travail ou ailleurs dans votre syst\u00E8me, ainsi que du marquage, du traitement, du stockage et\r\n        de la\r\n        destruction s\u00E9curis\u00E9s de vos donn\u00E9es et renseignements.\r\n    </p>\r\n</div>" }]
        }], propDecorators: { lang: [{
                type: Input
            }] } });

class InstructionService {
    constructor() {
        this.helpTextIndx = {};
    }
    /**
     * Sets the Help Text Index
     *
     * instructionHeadings should be a list
     * @deprecated Use `createtHelpTextIndex` instead
     */
    getHelpTextIndex(instructionHeadings) {
        for (let i = 0; i < instructionHeadings.length; i++) {
            this.helpTextIndx[instructionHeadings[i]] = i + 1;
        }
        // console.log(this.helpTextIndx);
        return this.helpTextIndx;
    }
    createHelpSequence(prefix, suffix, instructionHeadings) {
        return instructionHeadings.reduce((acc, heading, index) => {
            const sequence = index + 1;
            acc[heading] = [
                sequence, // Help text sequence
                `${prefix}${sequence}`, // Definition description (dd) id, eg tr1
                `${prefix}${sequence}${suffix}` // Superscript (sup) id, eg tr1-rf
            ];
            return acc;
        }, {});
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: InstructionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: InstructionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: InstructionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

class RoutingService {
    constructor(router) {
        this.router = router;
    }
    navigateTo(path) {
        this.router.navigate([path]);
    }
    navigateToWithExtra(path, stateData) {
        this.router.navigate([path], { state: stateData });
    }
    getStateData(propertyKey) {
        const currentNavigation = this.router.getCurrentNavigation();
        if (currentNavigation && currentNavigation.extras.state) {
            return currentNavigation.extras.state[propertyKey];
        }
        console.info(`Property '${propertyKey}' not found in state.`);
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RoutingService, deps: [{ token: i1$3.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RoutingService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RoutingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$3.Router }] });

class BaseListService {
    constructor() {
        this.idCount = 0;
    }
    setList(list) {
        this.list = list;
    }
    getNextId() {
        let maxId = 0;
        // Iterate over the form groups
        this.list.forEach(control => {
            const id = control.get('id').value;
            // Parse the ID as a number and update maxId if necessary
            const numericId = parseInt(id, 10);
            if (!isNaN(numericId) && numericId > maxId) {
                maxId = numericId;
            }
        });
        // Increment the maximum ID to get the next available ID
        return maxId + 1;
    }
    // These are id's are used for keeping track of recordId - used for prefixes on global variables accross records
    setMaxId(value) {
        this.idCount = value;
    }
    getId() {
        this.idCount += 1;
        return this.idCount;
    }
}

class BaseListComponent extends BaseComponent {
    constructor(_fb, listService) {
        super();
        this._fb = _fb;
        this.listService = listService;
    }
    ngOnChanges(changes) {
        if (changes['recordList']) {
            this._init(changes['recordList'].currentValue);
        }
    }
    _init(recordData) {
        // Clear existing controls
        this.recordFormArray.clear();
        if (recordData && recordData.length !== 0) {
            if (recordData.length > 0) {
                let maxId = -1;
                recordData.forEach((record, index) => {
                    const group = this.recordService.createRecordFormGroup(this._fb);
                    // Set values after defining the form controls
                    group.patchValue({
                        id: record.id,
                        recordId: index + 1,
                        isNew: false,
                        expandFlag: false,
                    });
                    this._patchRecordInfoValue(group, record);
                    this._patchLastSavedStateValue(group.controls['lastSavedState'], record);
                    this.recordFormArray.push(group);
                    // Parse the ID as a number and update maxId if necessary
                    maxId = Math.max(Number(record.id), maxId);
                });
                this.listService.setMaxId(maxId);
            }
        }
        else {
            if (!this.isInternal) {
                const group = this.recordService.createRecordFormGroup(this._fb);
                group.patchValue({
                    recordId: this.listService.getId()
                });
                this.recordFormArray.push(group);
                const firstFormRecord = this.recordFormArray.at(0);
                firstFormRecord.controls['expandFlag'].setValue(true);
            }
        }
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
        // Set the list of form groups
        this.listService.setList(this.recordFormArray.controls);
    }
    addRecord() {
        const group = this.recordService.createRecordFormGroup(this._fb);
        group.patchValue({
            recordId: this.listService.getId()
        });
        this.recordFormArray.push(group);
    }
    saveRecord(event) {
        const index = event.index;
        const group = this.recordFormArray.at(index);
        // if this is a new record, assign next available id, otherwise, use it's existing id
        const id = group.get('isNew').value ? this.listService.getNextId() : group.get('id').value;
        group.patchValue({
            id: id,
            isNew: false,
            expandFlag: false, // collapse this record
        });
        const recordInfo = this.getRecordInfo(group);
        // Update lastSavedState with the current value of contactInfo
        group.get('lastSavedState').setValue(recordInfo.value);
        this._expandNextInvalidRecord();
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    _expandNextInvalidRecord() {
        // expand next invalid record
        for (let index = 0; index < this.recordFormArray.controls.length; index++) {
            const group = this.recordFormArray.controls[index];
            if (group.invalid) {
                group.controls['expandFlag'].setValue(true);
                this.recordFormGroup.markAsDirty();
                break;
            }
        }
    }
    deleteRecord(index) {
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        recordInfo.reset();
        this.recordFormArray.removeAt(index);
        this.recordService.setRecordsFormArrValue(this.getRecordFormArrValues());
    }
    revertRecord(event) {
        const index = event.index;
        const id = event.id;
        const group = this.recordFormArray.at(index);
        const recordInfo = this.getRecordInfo(group);
        // Revert to the last saved state
        const lastSavedState = group.get('lastSavedState').value;
        recordInfo.patchValue(lastSavedState);
    }
    handleRowClick(event) {
        const clickedIndex = event.index;
        const clickedRecordState = event.state;
        if (this.recordFormGroup.pristine) {
            this.recordFormArray.controls.forEach((element, index) => {
                if (clickedIndex === index) {
                    element.controls['expandFlag'].setValue(!clickedRecordState);
                }
            });
        }
        else {
            this.openPopup();
        }
    }
    showError(errs) {
        if (errs.length > 0) {
            this.showErrors = true;
        }
        else {
            this.showErrors = false;
        }
    }
    disableAddButton() {
        return (this.recordFormGroup.dirty || !this.recordFormGroup.valid || this.errorList?.length > 0);
    }
    openPopup() {
        jQuery("#" + this.popupId).trigger("open.wb-overlay");
    }
    get recordFormArray() {
        return this.recordFormGroup.get(this.records);
    }
    getRecordInfo(recordFormGroup) {
        return recordFormGroup.get(this.recordInfo);
    }
    getRecordFormArrValues() {
        return this.recordFormArray.value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, deps: [{ token: i1$2.FormBuilder }, { token: BaseListService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: BaseListComponent, selector: "ng-component", inputs: { recordList: "recordList", showErrors: "showErrors", isInternal: "isInternal" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: BaseListComponent, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }], ctorParameters: () => [{ type: i1$2.FormBuilder }, { type: BaseListService, decorators: [{
                    type: Inject,
                    args: [BaseListService]
                }] }], propDecorators: { recordList: [{
                type: Input
            }], showErrors: [{
                type: Input
            }], isInternal: [{
                type: Input
            }] } });

class PopupComponent {
    closePopup() {
        jQuery(".wb-overlay").trigger("close.wb-overlay");
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PopupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: PopupComponent, isStandalone: true, selector: "lib-popup", inputs: { message: "message", title: "title", id: "id", close: "close" }, ngImport: i0, template: "<section id={{id}} class=\"wb-overlay modal-dialog modal-content overlay-def wb-popup-mid overlay-bg\">\r\n\t<header class=\"modal-header\">\r\n\t  <h2 class=\"modal-title\">{{title}}</h2>\r\n\t</header>\r\n\t<div class=\"modal-body\">\r\n\t  {{message}}\r\n\t</div>\r\n\t<div class=\"modal-footer\">\r\n\t\t<button class=\"btn btn-primary overlay-close\" type=\"button\" (click)=\"closePopup()\">{{close}}</button>\r\n\t</div>\r\n</section>", styles: [".wb-popup-mid{width:30%;height:fit-content}\n"], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: PopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-popup', standalone: true, imports: [], encapsulation: ViewEncapsulation.None, template: "<section id={{id}} class=\"wb-overlay modal-dialog modal-content overlay-def wb-popup-mid overlay-bg\">\r\n\t<header class=\"modal-header\">\r\n\t  <h2 class=\"modal-title\">{{title}}</h2>\r\n\t</header>\r\n\t<div class=\"modal-body\">\r\n\t  {{message}}\r\n\t</div>\r\n\t<div class=\"modal-footer\">\r\n\t\t<button class=\"btn btn-primary overlay-close\" type=\"button\" (click)=\"closePopup()\">{{close}}</button>\r\n\t</div>\r\n</section>", styles: [".wb-popup-mid{width:30%;height:fit-content}\n"] }]
        }], propDecorators: { message: [{
                type: Input
            }], title: [{
                type: Input
            }], id: [{
                type: Input
            }], close: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { AccordionComponent, AriaTransformPipe, BaseComponent, BaseListComponent, BaseListService, CANADA, CHECK_SUM_CONST, CheckSumService, CommonFormDendencyModule, CommonUiFeatureModule, ControlMessagesComponent, ConvertResults, ConverterService, DataLoaderService, ENGLISH, ERR_TYPE_COMPONENT, ERR_TYPE_LEAST_ONE_REC, EntityBaseService, ErrorModule, ErrorNotificationService, ErrorSummaryComponent, ExpanderComponent, ExpanderModule, FINAL, FRENCH, FileConversionService, FileIoModule, FilereaderComponent, FormControlPipe, InstructionService, JsonKeysPipe, LayoutComponent, LoggerService, NO, NoCacheHeadersInterceptor, NumbersLettersDirective, NumbersOnlyDirective, OTHER_EN, OTHER_FR, PipesModule, PopupComponent, PrivacyStatementComponent, RoutingService, SecurityDisclaimerComponent, SortOn, TextTransformPipe, USA, UtilsService, VALIDATION_SERVICES, ValidationService, VersionService, YES, getEmptyErrorSummaryObj };
//# sourceMappingURL=hpfb-sdk-ui.mjs.map
