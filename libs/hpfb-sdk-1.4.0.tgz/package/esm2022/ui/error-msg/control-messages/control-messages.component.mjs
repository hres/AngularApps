import { Component, Input, ViewEncapsulation } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../err.message.service";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
export class ControlMessagesComponent {
    constructor(_errMessageService) {
        this._errMessageService = _errMessageService;
        /**
         * For manually showing inline control message for disabled FormControl.
         */
        this.disabledError = undefined;
        this.errorParams = {};
        // this.tabSet = null;
        this.tabId = null;
        this._errorVisible = false;
    }
    /**
     * Change event processing from inputs
     * @param {SimpleChanges} changes
     */
    ngOnChanges(changes) {
        if (changes['showError']) {
            this._errorVisible = changes['showError'].currentValue;
            this.makeErrorVisible();
        }
    }
    /**
     * Gets the Error message key and its parameter values for a given error type.
     *
     * @returns {any}
     */
    get errorMessage() {
        for (let propertyName in this.control.errors) {
            this.currentError = propertyName;
            // values to replace placeholders in the error message if they exist. eg "Minimum length {{ requiredLength }} numbers"
            this.errorParams = this.control.errors[propertyName];
            // console.log(propertyName, Object.keys(this.errorParams).length, JSON.stringify(this.errorParams))
            return this._errMessageService.getValidatorErrorMessageKey(propertyName);
        }
        this.currentError = '';
        return null;
    }
    /**
     * Controls the visibility of an error
     * @returns {boolean}
     */
    makeErrorVisible() {
        // If this.hasErrors (manual error check for disabled form group) is defined, check for this flag.
        const hasManualError = this.disabledError ?? false;
        if (hasManualError) {
            return this.disabledError && this._errorVisible;
        }
        // More defensive
        // if (this.hasErrors !== undefined) {
        //   return !!this.hasErrors && this._errorVisible;
        // }
        return (this.control.invalid && this.control.touched && this.control.dirty) || (this.control.invalid && this._errorVisible);
    }
    isCanadianPostalCode() {
        const controlName = this.controlId?.toLowerCase() || '';
        const labelText = this.label?.toLowerCase() || '';
        return controlName.includes('postal') && labelText.includes('postal') && this.control?.errors?.['pattern'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, deps: [{ token: i1.ErrMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: ControlMessagesComponent, selector: "control-messages", inputs: { control: "control", showError: "showError", label: "label", controlId: "controlId", parentId: "parentId", parentLabel: "parentLabel", translatedParentLabel: "translatedParentLabel", index: "index", disabledError: "disabledError" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ControlMessagesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'control-messages', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngIf=\"makeErrorVisible()\">\r\n  <strong class=\"error\">\r\n    <span class=\"label label-danger\">\r\n      @if(errorSummaryFlag && errorNumber) {\r\n        <span class=\"prefix\">{{'error' | translate: {number: errorNumber} }}&nbsp;</span>\r\n      } \r\n      {{errorMessage | translate: errorParams }}\r\n    </span>\r\n  </strong>\r\n</ng-container>\r\n", styles: [".rep{display:inline!important;font-size:100%!important;font-weight:700!important;vertical-align:baseline;text-align:center;white-space:normal!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.ErrMessageService }], propDecorators: { control: [{
                type: Input
            }], showError: [{
                type: Input
            }], label: [{
                type: Input
            }], controlId: [{
                type: Input
            }], parentId: [{
                type: Input
            }], parentLabel: [{
                type: Input
            }], translatedParentLabel: [{
                type: Input
            }], index: [{
                type: Input
            }], disabledError: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udHJvbC1tZXNzYWdlcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9lcnJvci1tc2cvY29udHJvbC1tZXNzYWdlcy9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL2Vycm9yLW1zZy9jb250cm9sLW1lc3NhZ2VzL2NvbnRyb2wtbWVzc2FnZXMuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBRSxLQUFLLEVBQTJCLGlCQUFpQixFQUFTLE1BQU0sZUFBZSxDQUFDOzs7OztBQWFuRyxNQUFNLE9BQU8sd0JBQXdCO0lBd0VuQyxZQUFvQixrQkFBcUM7UUFBckMsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFtQjtRQXBDekQ7O1dBRUc7UUFDTSxrQkFBYSxHQUFhLFNBQVMsQ0FBQztRQTBCdEMsZ0JBQVcsR0FBNkIsRUFBRSxDQUFDO1FBUWhELHNCQUFzQjtRQUN0QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsV0FBVyxDQUFDLE9BQXNCO1FBRWhDLElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQ3ZELElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFCLENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILElBQUksWUFBWTtRQUNkLEtBQUssSUFBSSxZQUFZLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM3QyxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztZQUNqQyxzSEFBc0g7WUFDdEgsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNyRCxvR0FBb0c7WUFFcEcsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDM0UsQ0FBQztRQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7T0FHRztJQUNILGdCQUFnQjtRQUNkLGtHQUFrRztRQUNsRyxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssQ0FBQztRQUNuRCxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ2xELENBQUM7UUFFRCxpQkFBaUI7UUFDakIsc0NBQXNDO1FBQ3RDLG1EQUFtRDtRQUNuRCxJQUFJO1FBRUosT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFFOUgsQ0FBQztJQUdELG9CQUFvQjtRQUNsQixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUN4RCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUNsRCxPQUFPLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzdHLENBQUM7K0dBcklVLHdCQUF3QjttR0FBeEIsd0JBQXdCLCtUQ2JyQywwWEFVQTs7NEZER2Esd0JBQXdCO2tCQVBwQyxTQUFTOytCQUNFLGtCQUFrQixpQkFHYixpQkFBaUIsQ0FBQyxJQUFJO3NGQVE1QixPQUFPO3NCQUFmLEtBQUs7Z0JBS0csU0FBUztzQkFBakIsS0FBSztnQkFJRyxLQUFLO3NCQUFiLEtBQUs7Z0JBSUcsU0FBUztzQkFBakIsS0FBSztnQkFJRyxRQUFRO3NCQUFoQixLQUFLO2dCQUlHLFdBQVc7c0JBQW5CLEtBQUs7Z0JBSUcscUJBQXFCO3NCQUE3QixLQUFLO2dCQUlHLEtBQUs7c0JBQWIsS0FBSztnQkFLRyxhQUFhO3NCQUFyQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIElucHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMsVmlld0VuY2Fwc3VsYXRpb24sIGluamVjdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7Rm9ybUNvbnRyb2x9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgVmFsaWRhdGlvblNlcnZpY2UgfSBmcm9tICcuLi8uLi92YWxpZGF0aW9uL3ZhbGlkYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7VHJhbnNsYXRlU2VydmljZX0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XHJcbmltcG9ydCB7IEVyck1lc3NhZ2VTZXJ2aWNlIH0gZnJvbSAnLi4vZXJyLm1lc3NhZ2Uuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2NvbnRyb2wtbWVzc2FnZXMnLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9jb250cm9sLW1lc3NhZ2VzLmNvbXBvbmVudC5jc3MnXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIENvbnRyb2xNZXNzYWdlc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XHJcblxyXG4gIC8qKlxyXG4gICAqICBUaGUgcmVhY3RpdmUgZm9ybSBjb250cm9sIHRoYXQgdGhpcyBtZXNzYWdlIHJlbGF0ZXNcclxuICAgKi9cclxuICBASW5wdXQoKSBjb250cm9sOiBGb3JtQ29udHJvbDtcclxuICAvKipcclxuICAgKiBXaGVuIHRydWUsIGluZGljYXRlcyB0byBzaG93IHRoZSBlcnJvciwgZXZlbiBpZiBjb250cm9sIHdhcyBub3QgdG91Y2hlZFxyXG4gICAqIEB0eXBlIHtib29sZWFufVxyXG4gICAqL1xyXG4gIEBJbnB1dCgpIHNob3dFcnJvcjogYm9vbGVhbjtcclxuICAvKipcclxuICAgKiBMYWJlbCBtZXNzYWdlIGtleSB0aGF0IGlzIGFzc29jaWF0ZWQgdG8gdGhlIGNvbnRyb2wuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5XHJcbiAgICovXHJcbiAgQElucHV0KCkgbGFiZWw6IHN0cmluZztcclxuICAvKipcclxuICAgKiBUaGUgaWQgb2YgdGhlIGNvbnRyb2wuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5IHRvIGNyZWF0ZSB0aGUgYW5jaG9yIGxpbmtcclxuICAgKi9cclxuICBASW5wdXQoKSBjb250cm9sSWQ6IHN0cmluZztcclxuICAvKipcclxuICAgKiBUaGUgaWQgb2YgdGhlIHBhcmVudCBvZiB0aGUgY29udHJvbC4gRm9yIHRoZSBlcnJvciBzdW1tYXJ5IGNvbXBvbm5ldCwgY3VycmVudGx5IG5vdCB1c2VkP1xyXG4gICAqL1xyXG4gIEBJbnB1dCgpIHBhcmVudElkOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogVGhlIGxhYmVsIG1lc3NhZ2Uga2V5IG9mIHRoZSBwYXJlbnQgb2YgaHRlIGNvbnRyb2wgLiBVc2VkIGZvciB0aGUgZXJyb3Igc3VtbWFyeSBjb21wb25lbnQuIEN1cnJlbnRseSBub3QgdXNlZD9cclxuICAgKi9cclxuICBASW5wdXQoKSBwYXJlbnRMYWJlbDogc3RyaW5nO1xyXG4gIC8qKlxyXG4gICAqIFRoZSBhbHJlYWR5IHRyYW5zbGF0ZWQgbGFiZWwgb2YgdGhlIHBhcmVudCBvZiBodGUgY29udHJvbCAuIFVzZWQgZm9yIHRoZSBlcnJvciBzdW1tYXJ5IGNvbXBvbmVudC4gXHJcbiAgICovXHJcbiAgQElucHV0KCkgdHJhbnNsYXRlZFBhcmVudExhYmVsOiBzdHJpbmc7XHJcbiAgLyoqKlxyXG4gICAqIEluZGV4IG9mIHRoZSBlcnJvci4gVXNlZCB0byBleHBhbmQgdGhlIGV4cGFuZGVyIGZvciB0aGUgZXJyb3Igc3VtbWFyeXRcclxuICAgKi9cclxuICBASW5wdXQoKSBpbmRleDogTnVtYmVyO1xyXG5cclxuICAvKipcclxuICAgKiBGb3IgbWFudWFsbHkgc2hvd2luZyBpbmxpbmUgY29udHJvbCBtZXNzYWdlIGZvciBkaXNhYmxlZCBGb3JtQ29udHJvbC5cclxuICAgKi9cclxuICBASW5wdXQoKSBkaXNhYmxlZEVycm9yPzogYm9vbGVhbiA9IHVuZGVmaW5lZDtcclxuXHJcbiAgIC8qKlxyXG4gICAqIE51bWJlciBvZiBlcnJvciBmcm9tIGVycm9yIHN1bW1hcnlcclxuICAgKi9cclxuICAgcHVibGljIGVycm9yTnVtYmVyOiBzdHJpbmc7XHJcbiAgLyoqXHJcbiAgICogRmxhZyB0byBpbmRpY2F0ZSBpZiBlcnJvciBzdW1tYXJ5XHJcbiAgICovXHJcbiAgcHVibGljIGVycm9yU3VtbWFyeUZsYWc6IGJvb2xlYW47ICAgXHJcbiAgLyoqXHJcbiAgICogQ3VycmVudCBlcnJvciB0eXBlIGZvciB0aGUgY29udHJvbFxyXG4gICAqIEB0eXBlIHtzdHJpbmd9XHJcbiAgICovXHJcbiAgcHVibGljIGN1cnJlbnRFcnJvcjogc3RyaW5nIDtcclxuICAvKipcclxuICAgKiAgQSByZWZlcmVuY2UgdGhlIHRhYnNldCBjb250cm9sIE5nYlRhYnNldCBmcm9tIEFuZ3VsYXIgYm9vdHN0cmFwXHJcbiAgICogQHR5cGUge251bGx9XHJcbiAgICovXHJcbiAgLy8gcHVibGljIHRhYlNldDogTmdiVGFic2V0O1xyXG4gIC8qKlxyXG4gICAqIFRoIGlkIG9mIHRoZSB0YXJnZXQgdGFiLCB0aGUgdGFiIGNvbnRhaW5pbmcgdGhlIGVycm9yXHJcbiAgICogQHR5cGUgKHN0cmluZylcclxuICAgKi9cclxuICBwdWJsaWMgdGFiSWQ6IHN0cmluZztcclxuXHJcbiAgcHVibGljIGVycm9yUGFyYW1zOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9PSB7fTtcclxuICAvKipcclxuICAgKiBjb250cm9scyB2aXNpYmxpdHlcclxuICAgKiBAdHlwZSBib29sZWFuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBfZXJyb3JWaXNpYmxlOiBib29sZWFuO1xyXG4gIFxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Vyck1lc3NhZ2VTZXJ2aWNlOiBFcnJNZXNzYWdlU2VydmljZSkge1xyXG4gICAgLy8gdGhpcy50YWJTZXQgPSBudWxsO1xyXG4gICAgdGhpcy50YWJJZCA9IG51bGw7XHJcbiAgICB0aGlzLl9lcnJvclZpc2libGUgPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoYW5nZSBldmVudCBwcm9jZXNzaW5nIGZyb20gaW5wdXRzXHJcbiAgICogQHBhcmFtIHtTaW1wbGVDaGFuZ2VzfSBjaGFuZ2VzXHJcbiAgICovXHJcbiAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG5cclxuICAgIGlmIChjaGFuZ2VzWydzaG93RXJyb3InXSkge1xyXG4gICAgICB0aGlzLl9lcnJvclZpc2libGUgPSBjaGFuZ2VzWydzaG93RXJyb3InXS5jdXJyZW50VmFsdWU7XHJcbiAgICAgIHRoaXMubWFrZUVycm9yVmlzaWJsZSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2V0cyB0aGUgRXJyb3IgbWVzc2FnZSBrZXkgYW5kIGl0cyBwYXJhbWV0ZXIgdmFsdWVzIGZvciBhIGdpdmVuIGVycm9yIHR5cGUuXHJcbiAgICpcclxuICAgKiBAcmV0dXJucyB7YW55fVxyXG4gICAqL1xyXG4gIGdldCBlcnJvck1lc3NhZ2UoKSB7XHJcbiAgICBmb3IgKGxldCBwcm9wZXJ0eU5hbWUgaW4gdGhpcy5jb250cm9sLmVycm9ycykge1xyXG4gICAgICB0aGlzLmN1cnJlbnRFcnJvciA9IHByb3BlcnR5TmFtZTsgICAgICBcclxuICAgICAgLy8gdmFsdWVzIHRvIHJlcGxhY2UgcGxhY2Vob2xkZXJzIGluIHRoZSBlcnJvciBtZXNzYWdlIGlmIHRoZXkgZXhpc3QuIGVnIFwiTWluaW11bSBsZW5ndGgge3sgcmVxdWlyZWRMZW5ndGggfX0gbnVtYmVyc1wiXHJcbiAgICAgIHRoaXMuZXJyb3JQYXJhbXMgPSB0aGlzLmNvbnRyb2wuZXJyb3JzW3Byb3BlcnR5TmFtZV07ICAgXHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKHByb3BlcnR5TmFtZSwgT2JqZWN0LmtleXModGhpcy5lcnJvclBhcmFtcykubGVuZ3RoLCBKU09OLnN0cmluZ2lmeSh0aGlzLmVycm9yUGFyYW1zKSlcclxuXHJcbiAgICAgIHJldHVybiB0aGlzLl9lcnJNZXNzYWdlU2VydmljZS5nZXRWYWxpZGF0b3JFcnJvck1lc3NhZ2VLZXkocHJvcGVydHlOYW1lKTtcclxuICAgIH1cclxuICAgIHRoaXMuY3VycmVudEVycm9yID0gJyc7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnRyb2xzIHRoZSB2aXNpYmlsaXR5IG9mIGFuIGVycm9yXHJcbiAgICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAgICovXHJcbiAgbWFrZUVycm9yVmlzaWJsZSgpOiBib29sZWFuIHtcclxuICAgIC8vIElmIHRoaXMuaGFzRXJyb3JzIChtYW51YWwgZXJyb3IgY2hlY2sgZm9yIGRpc2FibGVkIGZvcm0gZ3JvdXApIGlzIGRlZmluZWQsIGNoZWNrIGZvciB0aGlzIGZsYWcuXHJcbiAgICBjb25zdCBoYXNNYW51YWxFcnJvciA9IHRoaXMuZGlzYWJsZWRFcnJvciA/PyBmYWxzZTtcclxuICAgIGlmIChoYXNNYW51YWxFcnJvcikge1xyXG4gICAgICByZXR1cm4gdGhpcy5kaXNhYmxlZEVycm9yICYmIHRoaXMuX2Vycm9yVmlzaWJsZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBNb3JlIGRlZmVuc2l2ZVxyXG4gICAgLy8gaWYgKHRoaXMuaGFzRXJyb3JzICE9PSB1bmRlZmluZWQpIHtcclxuICAgIC8vICAgcmV0dXJuICEhdGhpcy5oYXNFcnJvcnMgJiYgdGhpcy5fZXJyb3JWaXNpYmxlO1xyXG4gICAgLy8gfVxyXG4gIFxyXG4gICAgcmV0dXJuICh0aGlzLmNvbnRyb2wuaW52YWxpZCAmJiB0aGlzLmNvbnRyb2wudG91Y2hlZCAmJiB0aGlzLmNvbnRyb2wuZGlydHkpIHx8ICh0aGlzLmNvbnRyb2wuaW52YWxpZCAmJiB0aGlzLl9lcnJvclZpc2libGUpO1xyXG4gICAgXHJcbiAgfVxyXG4gIFxyXG5cclxuICBpc0NhbmFkaWFuUG9zdGFsQ29kZSgpOiBib29sZWFuIHtcclxuICAgIGNvbnN0IGNvbnRyb2xOYW1lID0gdGhpcy5jb250cm9sSWQ/LnRvTG93ZXJDYXNlKCkgfHwgJyc7XHJcbiAgICBjb25zdCBsYWJlbFRleHQgPSB0aGlzLmxhYmVsPy50b0xvd2VyQ2FzZSgpIHx8ICcnO1xyXG4gICAgcmV0dXJuIGNvbnRyb2xOYW1lLmluY2x1ZGVzKCdwb3N0YWwnKSAmJiBsYWJlbFRleHQuaW5jbHVkZXMoJ3Bvc3RhbCcpICYmIHRoaXMuY29udHJvbD8uZXJyb3JzPy5bJ3BhdHRlcm4nXTtcclxuICB9XHJcbiAgXHJcblxyXG59XHJcblxyXG5cclxuXHJcbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJtYWtlRXJyb3JWaXNpYmxlKClcIj5cclxuICA8c3Ryb25nIGNsYXNzPVwiZXJyb3JcIj5cclxuICAgIDxzcGFuIGNsYXNzPVwibGFiZWwgbGFiZWwtZGFuZ2VyXCI+XHJcbiAgICAgIEBpZihlcnJvclN1bW1hcnlGbGFnICYmIGVycm9yTnVtYmVyKSB7XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJwcmVmaXhcIj57eydlcnJvcicgfCB0cmFuc2xhdGU6IHtudW1iZXI6IGVycm9yTnVtYmVyfSB9fSZuYnNwOzwvc3Bhbj5cclxuICAgICAgfSBcclxuICAgICAge3tlcnJvck1lc3NhZ2UgfCB0cmFuc2xhdGU6IGVycm9yUGFyYW1zIH19XHJcbiAgICA8L3NwYW4+XHJcbiAgPC9zdHJvbmc+XHJcbjwvbmctY29udGFpbmVyPlxyXG4iXX0=