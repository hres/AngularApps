import { Component, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { DRAFT_FILE_TYPE, FILE_TYPE_ERROR, FINAL_FILE_TYPE, FORM_TYPE_ERROR, IMPORT_SUCCESS, CHECK_SUM_ERROR } from '../file-io-constants';
import { ConvertResults } from '../convert-results';
import { FileConversionService } from '../file-conversion.service';
import { CheckSumService } from '../../check-sum/check-sum.service';
import { CHECK_SUM_CONST } from '../../check-sum/check-sum-constants';
import * as i0 from "@angular/core";
import * as i1 from "@ngx-translate/core";
import * as i2 from "@angular/common";
export class FilereaderComponent {
    constructor(translate) {
        this.translate = translate;
        this.complete = new EventEmitter();
        this.rootTag = '';
        this.lang = '';
        this.status = IMPORT_SUCCESS;
        this.importSuccess = false;
        this.importedFileName = "";
        this.displayAlert = false; // reloads the role=alert each message
        this.rootId = '';
    }
    ngOnInit() {
        // console.log(this.rootTag);
    }
    ngOnChanges(changes) {
        if (changes['rootTag']) {
            this.rootId = changes['rootTag'].currentValue;
        }
    }
    /**
     * Attaches to the file browser, detecting the file selection change
     * @param $event
     */
    changeListener($event) {
        this.readSelectedFile($event.target);
    }
    /**
     * Determines if a file was selected. Sets a callback to process the file after load (asych)
     * @param inputValue
     */
    readSelectedFile(inputValue) {
        let file = inputValue.files[0];
        let myReader = new FileReader();
        let self = this;
        myReader.onloadend = function (e) {
            // you can perform an action with data here callback for asynch load
            let convertResult = new ConvertResults();
            FilereaderComponent._readFile(file.name, myReader.result, self.rootId, convertResult, self.versionTagPath, self.startCheckSumVersion, self.devEnv, self.byPassCheckSum);
            if (convertResult.messages && convertResult.messages.length > 0) {
                self.status = convertResult.messages[0];
            }
            else {
                self.status = IMPORT_SUCCESS;
            }
            if (self.status === IMPORT_SUCCESS) {
                self.importSuccess = true;
            }
            self.importedFileName = file.name;
            self.displayAlert = false;
            setTimeout(() => {
                self.displayAlert = true;
            }, 10);
            setTimeout(() => {
            }, 100);
            self.complete.emit(convertResult);
        };
        if (file && file.name) {
            myReader.readAsText(file);
        }
    }
    /***
     * Processes the file data. Determines the type of file based on the filename suffix
     * @param name - the name of the file. Can include the path
     * @param result - the result of the file read i.e. file contents as text
     * @param rootId - the name of the rootTag. If null is ignored
     * @param {ConvertResults} convertResult -The results of the file read
     * @private
     */
    static _readFile(name, result, rootId, convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass) {
        let splitFile = name.split('.');
        let fileType = splitFile[splitFile.length - 1];
        let conversion = new FileConversionService();
        if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE || fileType.toLowerCase() === FINAL_FILE_TYPE) {
            if ((fileType.toLowerCase()) === DRAFT_FILE_TYPE) {
                conversion.convertToJSONObjects(result, convertResult);
            }
            else {
                conversion.convertXMLToJSONObjects(result, convertResult);
            }
            // console.log(convertResult.data);
            FilereaderComponent.checkRootTagMatch(convertResult, rootId);
            if (fileType.toLowerCase() === FINAL_FILE_TYPE && convertResult.messages.length === 0) {
                if (this.doCheckSumCheck(convertResult, versionTagPath, startCheckSumVersion, devEnv, byPass))
                    if (versionTagPath == null && startCheckSumVersion == null) {
                        this.checkSumCheck(convertResult, rootId);
                    }
                    else {
                        this.strictCheckSumCheck(convertResult, rootId);
                    }
            }
        }
        else {
            convertResult.data = null;
            convertResult.messages = []; //clear msessages
            convertResult.messages.push(FILE_TYPE_ERROR);
        }
    }
    static checkRootTagMatch(convertResult, rootName) {
        if (!rootName || !convertResult || !convertResult.data)
            return;
        if (!convertResult.data[rootName]) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(FORM_TYPE_ERROR);
        }
    }
    refreshPage() {
        location.reload();
    }
    static checkSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!convertResult.data[rootName][CHECK_SUM_CONST]) {
            return;
        }
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static strictCheckSumCheck(convertResult, rootName) {
        const checkSum = new CheckSumService();
        if (!checkSum.checkHash(convertResult.data)) {
            convertResult.data = null;
            convertResult.messages = [];
            convertResult.messages.push(CHECK_SUM_ERROR);
        }
    }
    static doCheckSumCheck(convertResult, versionPath, startCheckSumVersion, devEnv, byPass) {
        if (versionPath != null && startCheckSumVersion != null) {
            var version = convertResult.data;
            versionPath.split(".").forEach(function (key) {
                version = version[key];
            });
            version = parseInt(version.split('.')[0], 10);
            if (version < startCheckSumVersion) {
                return false;
            }
        }
        if (devEnv && byPass) {
            console.warn("Bypassing Checksum Verification in Dev Mode!");
            return false;
        }
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FilereaderComponent, deps: [{ token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: FilereaderComponent, selector: "lib-file-reader", inputs: { rootTag: "rootTag", lang: "lang", versionTagPath: "versionTagPath", startCheckSumVersion: "startCheckSumVersion", devEnv: "devEnv", byPassCheckSum: "byPassCheckSum" }, outputs: { complete: "complete" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <input type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"displayAlert\">\r\n  <span role=\"alert\">{{status | translate}}</span>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>", styles: [""], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: FilereaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-file-reader', encapsulation: ViewEncapsulation.None, template: "<div class=\"row\">\r\n  <div *ngIf=\"!importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <label for=\"fileLoad\">\r\n      <span class=\"field-name\">{{ 'select.file'|translate }}</span>\r\n    </label>\r\n    <input type=\"file\" id=\"fileLoad\" name=\"fileLoad\" accept=\".xml, .hcsc\" (change)=\"changeListener($event)\" />\r\n  </div>\r\n  <div *ngIf=\"importSuccess\" class=\"form-group col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n    <button (click)=\"refreshPage()\">{{ 'refresh.file.input'|translate }}</button>\r\n    <Strong> {{importedFileName}}</Strong>\r\n  </div>\r\n</div>\r\n<div [ngClass]=\"status == 'msg.success.load' ? 'alert alert-success' : 'alert alert-danger'\" *ngIf=\"displayAlert\">\r\n  <span role=\"alert\">{{status | translate}}</span>\r\n</div>\r\n\r\n<ng-content select=\"[fileUploadInstruction]\"></ng-content>" }]
        }], ctorParameters: () => [{ type: i1.TranslateService }], propDecorators: { complete: [{
                type: Output
            }], rootTag: [{
                type: Input
            }], lang: [{
                type: Input
            }], versionTagPath: [{
                type: Input
            }], startCheckSumVersion: [{
                type: Input
            }], devEnv: [{
                type: Input
            }], byPassCheckSum: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZXJlYWRlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGVyZWFkZXIvZmlsZXJlYWRlci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9ocGZiL3Nkay91aS9maWxlLWlvL2ZpbGVyZWFkZXIvZmlsZXJlYWRlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsU0FBUyxFQUFVLFlBQVksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFpQixpQkFBaUIsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUMvRyxPQUFPLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFFLGNBQWMsRUFBRSxlQUFlLEVBQUMsTUFBTSxzQkFBc0IsQ0FBQztBQUUxSSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDcEQsT0FBTyxFQUFDLHFCQUFxQixFQUFDLE1BQU0sNEJBQTRCLENBQUM7QUFDakUsT0FBTyxFQUFDLGVBQWUsRUFBQyxNQUFNLG1DQUFtQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQzs7OztBQVN0RSxNQUFNLE9BQU8sbUJBQW1CO0lBZ0I5QixZQUFvQixTQUEyQjtRQUEzQixjQUFTLEdBQVQsU0FBUyxDQUFrQjtRQWZyQyxhQUFRLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUMvQixZQUFPLEdBQVksRUFBRSxDQUFDO1FBQ3RCLFNBQUksR0FBWSxFQUFFLENBQUM7UUFPckIsV0FBTSxHQUFHLGNBQWMsQ0FBQztRQUN4QixrQkFBYSxHQUFHLEtBQUssQ0FBQztRQUN0QixxQkFBZ0IsR0FBRyxFQUFFLENBQUM7UUFDdEIsaUJBQVksR0FBRyxLQUFLLENBQUMsQ0FBRyxzQ0FBc0M7UUFDN0QsV0FBTSxHQUFHLEVBQUUsQ0FBQztJQUdwQixDQUFDO0lBRUQsUUFBUTtRQUNOLDZCQUE2QjtJQUMvQixDQUFDO0lBR0QsV0FBVyxDQUFDLE9BQXNCO1FBQ2hDLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ2hELENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsY0FBYyxDQUFDLE1BQVc7UUFFeEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUV2QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZ0JBQWdCLENBQUMsVUFBZTtRQUM5QixJQUFJLElBQUksR0FBUyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLElBQUksUUFBUSxHQUFlLElBQUksVUFBVSxFQUFFLENBQUM7UUFDNUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLFFBQVEsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO1lBQzlCLG9FQUFvRTtZQUNwRSxJQUFJLGFBQWEsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ3pDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDeEssSUFBSSxhQUFhLENBQUMsUUFBUSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNoRSxJQUFJLENBQUMsTUFBTSxHQUFHLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUMsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDO1lBQy9CLENBQUM7WUFFRCxJQUFHLElBQUksQ0FBQyxNQUFNLEtBQUssY0FBYyxFQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzVCLENBQUM7WUFDRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUVsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztZQUMxQixVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUVQLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFFaEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBR1IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3RCLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFXLEVBQUUsTUFBTSxFQUFFLE1BQWEsRUFBRSxhQUE0QixFQUFFLGNBQXFCLEVBQUUsb0JBQTRCLEVBQUUsTUFBYyxFQUFFLE1BQWM7UUFDNUssSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoQyxJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLFVBQVUsR0FBd0IsSUFBSSxxQkFBcUIsRUFBRSxDQUFDO1FBRWxFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxlQUFlLElBQUksUUFBUSxDQUFDLFdBQVcsRUFBRSxLQUFLLGVBQWUsRUFBRSxDQUFDO1lBQy9GLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxlQUFlLEVBQUUsQ0FBQztnQkFDakQsVUFBVSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztZQUN6RCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztZQUM1RCxDQUFDO1lBQ0QsbUNBQW1DO1lBQ25DLG1CQUFtQixDQUFDLGlCQUFpQixDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUU3RCxJQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUUsS0FBSyxlQUFlLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFDLENBQUM7Z0JBQ3BGLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsY0FBYyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7b0JBQzNGLElBQUksY0FBYyxJQUFHLElBQUksSUFBSSxvQkFBb0IsSUFBSSxJQUFJLEVBQUUsQ0FBQzt3QkFDMUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBQzVDLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUNsRCxDQUFDO1lBQ0wsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDMUIsYUFBYSxDQUFDLFFBQVEsR0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUI7WUFDNUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFDTyxNQUFNLENBQUMsaUJBQWlCLENBQUMsYUFBNEIsRUFBRSxRQUFlO1FBQzVFLElBQUksQ0FBQyxRQUFRLElBQUcsQ0FBQyxhQUFhLElBQUcsQ0FBQyxhQUFhLENBQUMsSUFBSTtZQUFFLE9BQU87UUFFN0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztZQUNsQyxhQUFhLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUMxQixhQUFhLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUM1QixhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUMvQyxDQUFDO0lBQ0gsQ0FBQztJQUNNLFdBQVc7UUFDaEIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxNQUFNLENBQUMsYUFBYSxDQUFDLGFBQTRCLEVBQUUsUUFBZTtRQUN4RSxNQUFNLFFBQVEsR0FBb0IsSUFBSSxlQUFlLEVBQUUsQ0FBQztRQUV4RCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDO1lBQUEsT0FBTztRQUFBLENBQUM7UUFFN0QsSUFBRyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUM7WUFDMUMsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDMUIsYUFBYSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7WUFDNUIsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFFTyxNQUFNLENBQUMsbUJBQW1CLENBQUMsYUFBNEIsRUFBRSxRQUFlO1FBQzlFLE1BQU0sUUFBUSxHQUFvQixJQUFJLGVBQWUsRUFBRSxDQUFDO1FBRXhELElBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDO1lBQzFDLGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQzFCLGFBQWEsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQzVCLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQy9DLENBQUM7SUFDSCxDQUFDO0lBRU8sTUFBTSxDQUFDLGVBQWUsQ0FBQyxhQUE0QixFQUFFLFdBQW1CLEVBQUUsb0JBQTRCLEVBQUUsTUFBZSxFQUFFLE1BQWU7UUFDOUksSUFBSSxXQUFXLElBQUcsSUFBSSxJQUFJLG9CQUFvQixJQUFJLElBQUksRUFBRSxDQUFDO1lBQ3ZELElBQUksT0FBTyxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUM7WUFDakMsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBUyxHQUFHO2dCQUN6QyxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3pCLENBQUMsQ0FBQyxDQUFBO1lBQ0YsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLElBQUksT0FBTyxHQUFHLG9CQUFvQixFQUFFLENBQUM7Z0JBQ25DLE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQztRQUNILENBQUM7UUFDRCxJQUFJLE1BQU0sSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNyQixPQUFPLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxDQUFDLENBQUE7WUFDNUQsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDOytHQXZLVSxtQkFBbUI7bUdBQW5CLG1CQUFtQixpU0NmaEMsazNCQWdCMEQ7OzRGREQ3QyxtQkFBbUI7a0JBUC9CLFNBQVM7K0JBQ0UsaUJBQWlCLGlCQUdaLGlCQUFpQixDQUFDLElBQUk7cUZBSTNCLFFBQVE7c0JBQWpCLE1BQU07Z0JBQ0UsT0FBTztzQkFBZixLQUFLO2dCQUNHLElBQUk7c0JBQVosS0FBSztnQkFDRyxjQUFjO3NCQUF0QixLQUFLO2dCQUNHLG9CQUFvQjtzQkFBNUIsS0FBSztnQkFDRyxNQUFNO3NCQUFkLEtBQUs7Z0JBQ0csY0FBYztzQkFBdEIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXQsIEV2ZW50RW1pdHRlciwgT3V0cHV0LCBJbnB1dCwgU2ltcGxlQ2hhbmdlcywgVmlld0VuY2Fwc3VsYXRpb259IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBEUkFGVF9GSUxFX1RZUEUsIEZJTEVfVFlQRV9FUlJPUiwgRklOQUxfRklMRV9UWVBFLCBGT1JNX1RZUEVfRVJST1IsIElNUE9SVF9TVUNDRVNTLCBDSEVDS19TVU1fRVJST1J9IGZyb20gJy4uL2ZpbGUtaW8tY29uc3RhbnRzJztcclxuaW1wb3J0IHtUcmFuc2xhdGVTZXJ2aWNlfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcclxuaW1wb3J0IHsgQ29udmVydFJlc3VsdHMgfSBmcm9tICcuLi9jb252ZXJ0LXJlc3VsdHMnO1xyXG5pbXBvcnQge0ZpbGVDb252ZXJzaW9uU2VydmljZX0gZnJvbSAnLi4vZmlsZS1jb252ZXJzaW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQge0NoZWNrU3VtU2VydmljZX0gZnJvbSAnLi4vLi4vY2hlY2stc3VtL2NoZWNrLXN1bS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ0hFQ0tfU1VNX0NPTlNUIH0gZnJvbSAnLi4vLi4vY2hlY2stc3VtL2NoZWNrLXN1bS1jb25zdGFudHMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItZmlsZS1yZWFkZXInLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9maWxlcmVhZGVyLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9maWxlcmVhZGVyLmNvbXBvbmVudC5jc3MnXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEZpbGVyZWFkZXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIEBPdXRwdXQoKSBjb21wbGV0ZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICBASW5wdXQoKSByb290VGFnIDogc3RyaW5nID0gJyc7XHJcbiAgQElucHV0KCkgbGFuZyA6IHN0cmluZyA9ICcnO1xyXG4gIEBJbnB1dCgpIHZlcnNpb25UYWdQYXRoPyA6IHN0cmluZzsgLy9UaGUgeG1sIHBhdGggb2YgdGhlIHZlcnNpb24gdGFnIGluIFhNTCBzZXBlcmF0ZWQgYnkgXCIuXCIgZXguIFwiVFJBTlNBQ1RJT05fRU5ST0wuc29mdHdhcmVfdmVyc2lvblwiXHJcbiAgQElucHV0KCkgc3RhcnRDaGVja1N1bVZlcnNpb24/IDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIGRldkVudj8gOiBib29sZWFuO1xyXG4gIEBJbnB1dCgpIGJ5UGFzc0NoZWNrU3VtPyA6IGJvb2xlYW47XHJcblxyXG5cclxuICBwdWJsaWMgc3RhdHVzID0gSU1QT1JUX1NVQ0NFU1M7XHJcbiAgcHVibGljIGltcG9ydFN1Y2Nlc3MgPSBmYWxzZTtcclxuICBwdWJsaWMgaW1wb3J0ZWRGaWxlTmFtZSA9IFwiXCI7XHJcbiAgcHVibGljIGRpc3BsYXlBbGVydCA9IGZhbHNlOyAgIC8vIHJlbG9hZHMgdGhlIHJvbGU9YWxlcnQgZWFjaCBtZXNzYWdlXHJcbiAgcHJpdmF0ZSByb290SWQgPSAnJztcclxuICBcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHRyYW5zbGF0ZTogVHJhbnNsYXRlU2VydmljZSkge1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnJvb3RUYWcpO1xyXG4gIH1cclxuXHJcblxyXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuICAgIGlmIChjaGFuZ2VzWydyb290VGFnJ10pIHtcclxuICAgICAgdGhpcy5yb290SWQgPSBjaGFuZ2VzWydyb290VGFnJ10uY3VycmVudFZhbHVlO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQXR0YWNoZXMgdG8gdGhlIGZpbGUgYnJvd3NlciwgZGV0ZWN0aW5nIHRoZSBmaWxlIHNlbGVjdGlvbiBjaGFuZ2VcclxuICAgKiBAcGFyYW0gJGV2ZW50XHJcbiAgICovXHJcbiAgY2hhbmdlTGlzdGVuZXIoJGV2ZW50OiBhbnkpIHtcclxuXHJcbiAgICB0aGlzLnJlYWRTZWxlY3RlZEZpbGUoJGV2ZW50LnRhcmdldCk7XHJcblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGV0ZXJtaW5lcyBpZiBhIGZpbGUgd2FzIHNlbGVjdGVkLiBTZXRzIGEgY2FsbGJhY2sgdG8gcHJvY2VzcyB0aGUgZmlsZSBhZnRlciBsb2FkIChhc3ljaClcclxuICAgKiBAcGFyYW0gaW5wdXRWYWx1ZVxyXG4gICAqL1xyXG4gIHJlYWRTZWxlY3RlZEZpbGUoaW5wdXRWYWx1ZTogYW55KTogdm9pZCB7XHJcbiAgICBsZXQgZmlsZTogRmlsZSA9IGlucHV0VmFsdWUuZmlsZXNbMF07XHJcbiAgICBsZXQgbXlSZWFkZXI6IEZpbGVSZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgbGV0IHNlbGYgPSB0aGlzO1xyXG4gICAgbXlSZWFkZXIub25sb2FkZW5kID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgLy8geW91IGNhbiBwZXJmb3JtIGFuIGFjdGlvbiB3aXRoIGRhdGEgaGVyZSBjYWxsYmFjayBmb3IgYXN5bmNoIGxvYWRcclxuICAgICAgbGV0IGNvbnZlcnRSZXN1bHQgPSBuZXcgQ29udmVydFJlc3VsdHMoKTtcclxuICAgICAgRmlsZXJlYWRlckNvbXBvbmVudC5fcmVhZEZpbGUoZmlsZS5uYW1lLCBteVJlYWRlci5yZXN1bHQsIHNlbGYucm9vdElkLCBjb252ZXJ0UmVzdWx0LCBzZWxmLnZlcnNpb25UYWdQYXRoLCBzZWxmLnN0YXJ0Q2hlY2tTdW1WZXJzaW9uLCBzZWxmLmRldkVudiwgc2VsZi5ieVBhc3NDaGVja1N1bSk7XHJcbiAgICAgIGlmIChjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzICYmIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNlbGYuc3RhdHVzID0gY29udmVydFJlc3VsdC5tZXNzYWdlc1swXTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZWxmLnN0YXR1cyA9IElNUE9SVF9TVUNDRVNTO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZihzZWxmLnN0YXR1cyA9PT0gSU1QT1JUX1NVQ0NFU1Mpe1xyXG4gICAgICAgIHNlbGYuaW1wb3J0U3VjY2VzcyA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgICAgc2VsZi5pbXBvcnRlZEZpbGVOYW1lID0gZmlsZS5uYW1lO1xyXG5cclxuICAgICAgc2VsZi5kaXNwbGF5QWxlcnQgPSBmYWxzZTtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7IC8vIHRoaXMgcmVsb2FkcyB0aGUgbWVzc2FnZVxyXG4gICAgICAgIHNlbGYuZGlzcGxheUFsZXJ0ID0gdHJ1ZTtcclxuICAgICAgfSwgMTApO1xyXG5cclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcblxyXG4gICAgICB9LCAxMDApO1xyXG5cclxuXHJcbiAgICAgIHNlbGYuY29tcGxldGUuZW1pdChjb252ZXJ0UmVzdWx0KTtcclxuICAgIH07XHJcbiAgICBpZiAoZmlsZSAmJiBmaWxlLm5hbWUpIHtcclxuICAgICAgbXlSZWFkZXIucmVhZEFzVGV4dChmaWxlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKipcclxuICAgKiBQcm9jZXNzZXMgdGhlIGZpbGUgZGF0YS4gRGV0ZXJtaW5lcyB0aGUgdHlwZSBvZiBmaWxlIGJhc2VkIG9uIHRoZSBmaWxlbmFtZSBzdWZmaXhcclxuICAgKiBAcGFyYW0gbmFtZSAtIHRoZSBuYW1lIG9mIHRoZSBmaWxlLiBDYW4gaW5jbHVkZSB0aGUgcGF0aFxyXG4gICAqIEBwYXJhbSByZXN1bHQgLSB0aGUgcmVzdWx0IG9mIHRoZSBmaWxlIHJlYWQgaS5lLiBmaWxlIGNvbnRlbnRzIGFzIHRleHRcclxuICAgKiBAcGFyYW0gcm9vdElkIC0gdGhlIG5hbWUgb2YgdGhlIHJvb3RUYWcuIElmIG51bGwgaXMgaWdub3JlZFxyXG4gICAqIEBwYXJhbSB7Q29udmVydFJlc3VsdHN9IGNvbnZlcnRSZXN1bHQgLVRoZSByZXN1bHRzIG9mIHRoZSBmaWxlIHJlYWRcclxuICAgKiBAcHJpdmF0ZVxyXG4gICAqL1xyXG4gIHByaXZhdGUgc3RhdGljIF9yZWFkRmlsZShuYW1lOnN0cmluZywgcmVzdWx0LCByb290SWQ6c3RyaW5nLCBjb252ZXJ0UmVzdWx0OkNvbnZlcnRSZXN1bHRzLCB2ZXJzaW9uVGFnUGF0aDpzdHJpbmcsIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uOiBudW1iZXIsIGRldkVudjpib29sZWFuLCBieVBhc3M6Ym9vbGVhbikge1xyXG4gICAgbGV0IHNwbGl0RmlsZSA9IG5hbWUuc3BsaXQoJy4nKTtcclxuICAgIGxldCBmaWxlVHlwZSA9IHNwbGl0RmlsZVtzcGxpdEZpbGUubGVuZ3RoIC0gMV07XHJcbiAgICBsZXQgY29udmVyc2lvbjpGaWxlQ29udmVyc2lvblNlcnZpY2UgPW5ldyBGaWxlQ29udmVyc2lvblNlcnZpY2UoKTtcclxuXHJcbiAgICBpZiAoKGZpbGVUeXBlLnRvTG93ZXJDYXNlKCkpID09PSBEUkFGVF9GSUxFX1RZUEUgfHwgZmlsZVR5cGUudG9Mb3dlckNhc2UoKSA9PT0gRklOQUxfRklMRV9UWVBFKSB7XHJcbiAgICAgIGlmICgoZmlsZVR5cGUudG9Mb3dlckNhc2UoKSkgPT09IERSQUZUX0ZJTEVfVFlQRSkge1xyXG4gICAgICAgIGNvbnZlcnNpb24uY29udmVydFRvSlNPTk9iamVjdHMocmVzdWx0LCBjb252ZXJ0UmVzdWx0KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb252ZXJzaW9uLmNvbnZlcnRYTUxUb0pTT05PYmplY3RzKHJlc3VsdCwgY29udmVydFJlc3VsdCk7XHJcbiAgICAgIH1cclxuICAgICAgLy8gY29uc29sZS5sb2coY29udmVydFJlc3VsdC5kYXRhKTtcclxuICAgICAgRmlsZXJlYWRlckNvbXBvbmVudC5jaGVja1Jvb3RUYWdNYXRjaChjb252ZXJ0UmVzdWx0LCByb290SWQpO1xyXG4gICAgICBcclxuICAgICAgaWYoZmlsZVR5cGUudG9Mb3dlckNhc2UoKSA9PT0gRklOQUxfRklMRV9UWVBFICYmIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMubGVuZ3RoID09PSAwKXtcclxuICAgICAgICBpZiAodGhpcy5kb0NoZWNrU3VtQ2hlY2soY29udmVydFJlc3VsdCwgdmVyc2lvblRhZ1BhdGgsIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uLCBkZXZFbnYsIGJ5UGFzcykpXHJcbiAgICAgICAgICBpZiAodmVyc2lvblRhZ1BhdGggPT1udWxsICYmIHN0YXJ0Q2hlY2tTdW1WZXJzaW9uID09IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5jaGVja1N1bUNoZWNrKGNvbnZlcnRSZXN1bHQsIHJvb3RJZCk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnN0cmljdENoZWNrU3VtQ2hlY2soY29udmVydFJlc3VsdCwgcm9vdElkKTtcclxuICAgICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29udmVydFJlc3VsdC5kYXRhID0gbnVsbDtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcz1bXTsgLy9jbGVhciBtc2Vzc2FnZXNcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKEZJTEVfVFlQRV9FUlJPUik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHByaXZhdGUgc3RhdGljIGNoZWNrUm9vdFRhZ01hdGNoKGNvbnZlcnRSZXN1bHQ6Q29udmVydFJlc3VsdHMsIHJvb3ROYW1lOnN0cmluZykge1xyXG4gICAgaWYgKCFyb290TmFtZXx8ICFjb252ZXJ0UmVzdWx0IHx8IWNvbnZlcnRSZXN1bHQuZGF0YSkgcmV0dXJuO1xyXG5cclxuICAgIGlmICghY29udmVydFJlc3VsdC5kYXRhW3Jvb3ROYW1lXSkge1xyXG4gICAgICBjb252ZXJ0UmVzdWx0LmRhdGEgPSBudWxsO1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzID0gW107XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMucHVzaChGT1JNX1RZUEVfRVJST1IpO1xyXG4gICAgfVxyXG4gIH1cclxuICBwdWJsaWMgcmVmcmVzaFBhZ2UoKXtcclxuICAgIGxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzdGF0aWMgY2hlY2tTdW1DaGVjayhjb252ZXJ0UmVzdWx0OkNvbnZlcnRSZXN1bHRzLCByb290TmFtZTpzdHJpbmcpIHsgIFxyXG4gICAgY29uc3QgY2hlY2tTdW06IENoZWNrU3VtU2VydmljZSA9IG5ldyBDaGVja1N1bVNlcnZpY2UoKTtcclxuXHJcbiAgICBpZiAoIWNvbnZlcnRSZXN1bHQuZGF0YVtyb290TmFtZV1bQ0hFQ0tfU1VNX0NPTlNUXSkge3JldHVybjt9XHJcblxyXG4gICAgaWYoIWNoZWNrU3VtLmNoZWNrSGFzaChjb252ZXJ0UmVzdWx0LmRhdGEpKXtcclxuICAgICAgY29udmVydFJlc3VsdC5kYXRhID0gbnVsbDtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcyA9IFtdO1xyXG4gICAgICBjb252ZXJ0UmVzdWx0Lm1lc3NhZ2VzLnB1c2goQ0hFQ0tfU1VNX0VSUk9SKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgc3RhdGljIHN0cmljdENoZWNrU3VtQ2hlY2soY29udmVydFJlc3VsdDpDb252ZXJ0UmVzdWx0cywgcm9vdE5hbWU6c3RyaW5nKSB7XHJcbiAgICBjb25zdCBjaGVja1N1bTogQ2hlY2tTdW1TZXJ2aWNlID0gbmV3IENoZWNrU3VtU2VydmljZSgpO1xyXG5cclxuICAgIGlmKCFjaGVja1N1bS5jaGVja0hhc2goY29udmVydFJlc3VsdC5kYXRhKSl7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQuZGF0YSA9IG51bGw7XHJcbiAgICAgIGNvbnZlcnRSZXN1bHQubWVzc2FnZXMgPSBbXTtcclxuICAgICAgY29udmVydFJlc3VsdC5tZXNzYWdlcy5wdXNoKENIRUNLX1NVTV9FUlJPUik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHN0YXRpYyBkb0NoZWNrU3VtQ2hlY2soY29udmVydFJlc3VsdDpDb252ZXJ0UmVzdWx0cywgdmVyc2lvblBhdGg6IHN0cmluZywgc3RhcnRDaGVja1N1bVZlcnNpb246IG51bWJlciwgZGV2RW52OiBib29sZWFuLCBieVBhc3M6IGJvb2xlYW4pe1xyXG4gICAgaWYgKHZlcnNpb25QYXRoICE9bnVsbCAmJiBzdGFydENoZWNrU3VtVmVyc2lvbiAhPSBudWxsKSB7XHJcbiAgICAgIHZhciB2ZXJzaW9uID0gY29udmVydFJlc3VsdC5kYXRhO1xyXG4gICAgICB2ZXJzaW9uUGF0aC5zcGxpdChcIi5cIikuZm9yRWFjaChmdW5jdGlvbihrZXkpe1xyXG4gICAgICAgIHZlcnNpb24gPSB2ZXJzaW9uW2tleV07XHJcbiAgICAgIH0pXHJcbiAgICAgIHZlcnNpb24gPSBwYXJzZUludCh2ZXJzaW9uLnNwbGl0KCcuJylbMF0sIDEwKTtcclxuICAgICAgaWYgKHZlcnNpb24gPCBzdGFydENoZWNrU3VtVmVyc2lvbikge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSBcclxuICAgIGlmIChkZXZFbnYgJiYgYnlQYXNzKSB7XHJcbiAgICAgIGNvbnNvbGUud2FybihcIkJ5cGFzc2luZyBDaGVja3N1bSBWZXJpZmljYXRpb24gaW4gRGV2IE1vZGUhXCIpXHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxufVxyXG5cclxuIiwiPGRpdiBjbGFzcz1cInJvd1wiPlxyXG4gIDxkaXYgKm5nSWY9XCIhaW1wb3J0U3VjY2Vzc1wiIGNsYXNzPVwiZm9ybS1ncm91cCBjb2wtbGctMTIgY29sLW1kLTEyIGNvbC1zbS0xMiBjb2wteHMtMTJcIj5cclxuICAgIDxsYWJlbCBmb3I9XCJmaWxlTG9hZFwiPlxyXG4gICAgICA8c3BhbiBjbGFzcz1cImZpZWxkLW5hbWVcIj57eyAnc2VsZWN0LmZpbGUnfHRyYW5zbGF0ZSB9fTwvc3Bhbj5cclxuICAgIDwvbGFiZWw+XHJcbiAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBpZD1cImZpbGVMb2FkXCIgbmFtZT1cImZpbGVMb2FkXCIgYWNjZXB0PVwiLnhtbCwgLmhjc2NcIiAoY2hhbmdlKT1cImNoYW5nZUxpc3RlbmVyKCRldmVudClcIiAvPlxyXG4gIDwvZGl2PlxyXG4gIDxkaXYgKm5nSWY9XCJpbXBvcnRTdWNjZXNzXCIgY2xhc3M9XCJmb3JtLWdyb3VwIGNvbC1sZy0xMiBjb2wtbWQtMTIgY29sLXNtLTEyIGNvbC14cy0xMlwiPlxyXG4gICAgPGJ1dHRvbiAoY2xpY2spPVwicmVmcmVzaFBhZ2UoKVwiPnt7ICdyZWZyZXNoLmZpbGUuaW5wdXQnfHRyYW5zbGF0ZSB9fTwvYnV0dG9uPlxyXG4gICAgPFN0cm9uZz4ge3tpbXBvcnRlZEZpbGVOYW1lfX08L1N0cm9uZz5cclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcbjxkaXYgW25nQ2xhc3NdPVwic3RhdHVzID09ICdtc2cuc3VjY2Vzcy5sb2FkJyA/ICdhbGVydCBhbGVydC1zdWNjZXNzJyA6ICdhbGVydCBhbGVydC1kYW5nZXInXCIgKm5nSWY9XCJkaXNwbGF5QWxlcnRcIj5cclxuICA8c3BhbiByb2xlPVwiYWxlcnRcIj57e3N0YXR1cyB8IHRyYW5zbGF0ZX19PC9zcGFuPlxyXG48L2Rpdj5cclxuXHJcbjxuZy1jb250ZW50IHNlbGVjdD1cIltmaWxlVXBsb2FkSW5zdHJ1Y3Rpb25dXCI+PC9uZy1jb250ZW50PiJdfQ==