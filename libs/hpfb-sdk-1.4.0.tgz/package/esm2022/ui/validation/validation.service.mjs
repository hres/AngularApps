import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class ValidationService {
    constructor() {
        // private translate: TranslateService
        // this.translate.get('error.msg.required').subscribe(res => { console.log(res); });
    }
    getValidatorErrorMessage(validatorName) {
        // TODO sucky need to make the keys the same as the translation for the error summary
        const config = {
            'required': 'required',
            'error.msg.number': 'error.msg.number',
            'error.msg.phone': 'error.msg.phone',
            'error.msg.fax': 'error.msg.fax',
            'error.msg.email': 'error.msg.email',
            'minlength': 'error.msg.minlength',
            'error.msg.postal': 'error.msg.postal',
            'error.mgs.zip': 'error.mgs.zip',
            'error.mgs.company.id': 'error.mgs.company.id',
            'error.mgs.contact.id': 'error.mgs.contact.id',
            'error.mgs.primary.company.id': 'error.mgs.primary.company.id',
            'error.mgs.primary.contact.id': 'error.mgs.primary.contact.id',
            'error.mgs.4.numeric': 'error.mgs.4.numeric',
            'error.mgs.5.numeric': 'error.mgs.5.numeric',
            'error.mgs.6.numeric': 'error.mgs.6.numeric',
            'error.mgs.8.numeric': 'error.mgs.8.numeric',
            'error.mgs.regu.contact.id': 'error.mgs.regu.contact.id',
            'error.mgs.dossier.id': 'error.mgs.dossier.id',
            'error.mgs.licence.number': 'error.mgs.licence.number',
            'error.mgs.application.number': 'error.mgs.application.number',
            'error.mgs.din': 'error.mgs.din',
            'error.mgs.npn': 'error.mgs.npn',
            'error.msg.remove.contact': 'error.msg.remove.contact',
            'error.msg.revise.contact': 'error.msg.revise.contact',
            'error.mgs.incorrectFormat': 'error.mgs.incorrectFormat',
            'error.msg.invalidDate': 'error.msg.invalidDate',
            'error.msg.endDate': 'error.msg.endDate',
            'error.msg.amount.limit': 'error.msg.amount.limit',
        };
        return config[validatorName];
    }
    static emailValidator(control) {
        if (!control.value) {
            return null;
        }
        // RFC 2822 compliant regex
        if (control.value.match(/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/)) {
            return null;
        }
        else {
            return { 'error.msg.email': true };
        }
    }
    /*static passwordValidator(control) {
      // {6,100}           - Assert password is between 6 and 100 characters
      // (?=.*[0-9])       - Assert a string has at least one number
      if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
        return null;
      } else {
        return {'invalidPassword': true};
      }
    }*/
    static canadaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^(?!.*[DFIOQU])[A-VXYa-vxy][0-9][A-Za-z] ?[0-9][A-Za-z][0-9]$/)) {
            return null;
        }
        else {
            return { 'error.msg.postal': true };
        }
    }
    static usaPostalValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}(?:-[0-9]{4})?$/)) {
            return null;
        }
        else {
            return { 'error.mgs.zip': true };
        }
    }
    static countryValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value[0].id !== '') {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static phoneNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.phone': true };
        }
    }
    static faxNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.fax': true };
        }
    }
    static numberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.number': true };
        }
    }
    static companyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static numeric4Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{4}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.4.numeric': true };
        }
    }
    static numeric5Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.5.numeric': true };
        }
    }
    static numeric6Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.6.numeric': true };
        }
    }
    static numeric8Validator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.8.numeric': true };
        }
    }
    static dossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[m]{1}[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static dossierContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static regulatoryContactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.regu.contact.id': true };
        }
    }
    static licenceNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.licence.number': true };
        }
    }
    static appNumValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.application.number': true };
        }
    }
    static dinValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.din': true };
        }
    }
    static npnValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{8}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.npn': true };
        }
    }
    static checkboxRequiredValidator(control) {
        if (control.value) {
            return null;
        }
        else {
            return { 'required': true };
        }
    }
    static contactIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{5}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.contact.id': true };
        }
    }
    static primaryCompanyIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{6}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.company.id': true };
        }
    }
    static atLeastOneCheckboxSelected(formArray) {
        // return (): { [key: string]: boolean } | null => {
        const controls = formArray.controls;
        // Check if at least one checkbox is selected
        const isAtLeastOneSelected = controls.some((control) => control.value === true);
        // Return validation error if none are selected
        return isAtLeastOneSelected ? null : { 'required': true };
        // };
    }
    static masterFileNumberValidator(control) {
        // todo
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]{4}-[0-9]{3}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.incorrectFormat': true };
        }
    }
    // if first letter is e, then followed by 6 numbers
    // if first letter is f, then followed by 7 numbers
    static masterFileDossierIdValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[e]{1}[0-9]{6}$/) ||
            control.value.match(/^[f]{1}[0-9]{7}$/)) {
            return null;
        }
        else {
            return { 'error.mgs.dossier.id': true };
        }
    }
    static accountNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.account': true };
        }
    }
    static businessNumberValidator(control) {
        if (!control.value) {
            return null;
        }
        if (control.value.match(/^[0-9]*$/)) {
            return null;
        }
        else {
            return { 'error.msg.business': true };
        }
    }
    static limitValidation(control) {
        if (!control.value) {
            return null;
        }
        if (control.value > 10000000) {
            return { 'error.msg.amount.limit': true };
        }
        else {
            return null;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: ValidationService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGlvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvaHBmYi9zZGsvdWkvdmFsaWRhdGlvbi92YWxpZGF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLGlCQUFpQjtJQUU1QjtRQUNFLHNDQUFzQztRQUN0QyxvRkFBb0Y7SUFFdEYsQ0FBQztJQUVELHdCQUF3QixDQUFDLGFBQXFCO1FBQzVDLHFGQUFxRjtRQUNyRixNQUFNLE1BQU0sR0FBRztZQUNiLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxpQkFBaUIsRUFBRSxpQkFBaUI7WUFDcEMsZUFBZSxFQUFFLGVBQWU7WUFDaEMsaUJBQWlCLEVBQUUsaUJBQWlCO1lBQ3BDLFdBQVcsRUFBRSxxQkFBcUI7WUFDbEMsa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLGVBQWUsRUFBRSxlQUFlO1lBQ2hDLHNCQUFzQixFQUFFLHNCQUFzQjtZQUM5QyxzQkFBc0IsRUFBRSxzQkFBc0I7WUFDOUMsOEJBQThCLEVBQUUsOEJBQThCO1lBQzlELDhCQUE4QixFQUFFLDhCQUE4QjtZQUM5RCxxQkFBcUIsRUFBQyxxQkFBcUI7WUFDM0MscUJBQXFCLEVBQUUscUJBQXFCO1lBQzVDLHFCQUFxQixFQUFFLHFCQUFxQjtZQUM1QyxxQkFBcUIsRUFBQyxxQkFBcUI7WUFDM0MsMkJBQTJCLEVBQUUsMkJBQTJCO1lBQ3hELHNCQUFzQixFQUFFLHNCQUFzQjtZQUM5QywwQkFBMEIsRUFBRSwwQkFBMEI7WUFDdEQsOEJBQThCLEVBQUUsOEJBQThCO1lBQzlELGVBQWUsRUFBRSxlQUFlO1lBQ2hDLGVBQWUsRUFBRSxlQUFlO1lBQ2hDLDBCQUEwQixFQUFHLDBCQUEwQjtZQUN2RCwwQkFBMEIsRUFBRywwQkFBMEI7WUFDdkQsMkJBQTJCLEVBQUUsMkJBQTJCO1lBQ3hELHVCQUF1QixFQUFFLHVCQUF1QjtZQUNoRCxtQkFBbUIsRUFBQyxtQkFBbUI7WUFDdkMsd0JBQXdCLEVBQUMsd0JBQXdCO1NBQ2xELENBQUM7UUFFRixPQUFPLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPO1FBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsMkJBQTJCO1FBQzNCLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsa0RBQWtELENBQUMsRUFBRSxDQUFDO1lBQzVFLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsaUJBQWlCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDbkMsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPO1FBQ2xDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQywrREFBK0QsQ0FBQyxFQUFFLENBQUM7WUFDekYsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxrQkFBa0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNwQyxDQUFDO0lBRUgsQ0FBQztJQUVELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxFQUFFLENBQUM7WUFDcEQsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTztRQUM3QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7WUFDL0IsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxVQUFVLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsb0JBQW9CLENBQUMsT0FBTztRQUNqQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLGlCQUFpQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ25DLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU87UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU87UUFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxrQkFBa0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNwQyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsc0JBQXNCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTztRQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHFCQUFxQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU87UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxxQkFBcUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMscUJBQXFCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDdkMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTztRQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHFCQUFxQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBR0QsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU87UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQztZQUM1QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHlCQUF5QixDQUFDLE9BQU87UUFDdEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxzQkFBc0IsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPO1FBQ3pDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsMkJBQTJCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsT0FBTztRQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLDBCQUEwQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzVDLENBQUM7SUFDSCxDQUFDO0lBSUQsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPO1FBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsOEJBQThCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDaEQsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU87UUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU87UUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMseUJBQXlCLENBQUMsT0FBTztRQUN0QyxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNsQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsc0JBQXNCLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLENBQUMseUJBQXlCLENBQUMsT0FBTztRQUN0QyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLDBCQUEwQixDQUFDLFNBQW9CO1FBQ3BELG9EQUFvRDtRQUNsRCxNQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBRXBDLDZDQUE2QztRQUM3QyxNQUFNLG9CQUFvQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUF3QixFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDO1FBRWpHLCtDQUErQztRQUMvQyxPQUFPLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxDQUFDO1FBQzVELEtBQUs7SUFDUCxDQUFDO0lBRUQsTUFBTSxDQUFDLHlCQUF5QixDQUFDLE9BQU87UUFDdEMsT0FBTztRQUNQLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUM7WUFDL0MsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBRSwyQkFBMkIsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUMvQyxDQUFDO0lBQ0gsQ0FBQztJQUVELG1EQUFtRDtJQUNuRCxtREFBbUQ7SUFDbkQsTUFBTSxDQUFDLDRCQUE0QixDQUFDLE9BQU87UUFDekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUNFLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDO1lBQ3ZDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQ3ZDLENBQUM7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLHNCQUFzQixDQUFDLE9BQU87UUFDbkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDcEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sRUFBQyxtQkFBbUIsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUNyQyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPO1FBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFDLENBQUM7UUFDdEMsQ0FBQztJQUNILENBQUM7SUFHRCxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU87UUFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7WUFDN0IsT0FBTyxFQUFDLHdCQUF3QixFQUFFLElBQUksRUFBQyxDQUFDO1FBQzFDLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO0lBQ0gsQ0FBQzsrR0FqWFUsaUJBQWlCO21IQUFqQixpQkFBaUI7OzRGQUFqQixpQkFBaUI7a0JBRDdCLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEFic3RyYWN0Q29udHJvbCwgRm9ybUFycmF5LCBGb3JtR3JvdXAgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IElWYWxpZGF0aW9uU2VydmljZSB9IGZyb20gJy4vdmFsaWRhdGlvbi1zZXJ2aWNlLmludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBWYWxpZGF0aW9uU2VydmljZSBpbXBsZW1lbnRzIElWYWxpZGF0aW9uU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgLy8gcHJpdmF0ZSB0cmFuc2xhdGU6IFRyYW5zbGF0ZVNlcnZpY2VcclxuICAgIC8vIHRoaXMudHJhbnNsYXRlLmdldCgnZXJyb3IubXNnLnJlcXVpcmVkJykuc3Vic2NyaWJlKHJlcyA9PiB7IGNvbnNvbGUubG9nKHJlcyk7IH0pO1xyXG5cclxuICB9XHJcblxyXG4gIGdldFZhbGlkYXRvckVycm9yTWVzc2FnZSh2YWxpZGF0b3JOYW1lOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICAgIC8vIFRPRE8gc3Vja3kgbmVlZCB0byBtYWtlIHRoZSBrZXlzIHRoZSBzYW1lIGFzIHRoZSB0cmFuc2xhdGlvbiBmb3IgdGhlIGVycm9yIHN1bW1hcnlcclxuICAgIGNvbnN0IGNvbmZpZyA9IHtcclxuICAgICAgJ3JlcXVpcmVkJzogJ3JlcXVpcmVkJyxcclxuICAgICAgJ2Vycm9yLm1zZy5udW1iZXInOiAnZXJyb3IubXNnLm51bWJlcicsXHJcbiAgICAgICdlcnJvci5tc2cucGhvbmUnOiAnZXJyb3IubXNnLnBob25lJyxcclxuICAgICAgJ2Vycm9yLm1zZy5mYXgnOiAnZXJyb3IubXNnLmZheCcsXHJcbiAgICAgICdlcnJvci5tc2cuZW1haWwnOiAnZXJyb3IubXNnLmVtYWlsJyxcclxuICAgICAgJ21pbmxlbmd0aCc6ICdlcnJvci5tc2cubWlubGVuZ3RoJyxcclxuICAgICAgJ2Vycm9yLm1zZy5wb3N0YWwnOiAnZXJyb3IubXNnLnBvc3RhbCcsXHJcbiAgICAgICdlcnJvci5tZ3MuemlwJzogJ2Vycm9yLm1ncy56aXAnLFxyXG4gICAgICAnZXJyb3IubWdzLmNvbXBhbnkuaWQnOiAnZXJyb3IubWdzLmNvbXBhbnkuaWQnLFxyXG4gICAgICAnZXJyb3IubWdzLmNvbnRhY3QuaWQnOiAnZXJyb3IubWdzLmNvbnRhY3QuaWQnLFxyXG4gICAgICAnZXJyb3IubWdzLnByaW1hcnkuY29tcGFueS5pZCc6ICdlcnJvci5tZ3MucHJpbWFyeS5jb21wYW55LmlkJyxcclxuICAgICAgJ2Vycm9yLm1ncy5wcmltYXJ5LmNvbnRhY3QuaWQnOiAnZXJyb3IubWdzLnByaW1hcnkuY29udGFjdC5pZCcsXHJcbiAgICAgICdlcnJvci5tZ3MuNC5udW1lcmljJzonZXJyb3IubWdzLjQubnVtZXJpYycsXHJcbiAgICAgICdlcnJvci5tZ3MuNS5udW1lcmljJzogJ2Vycm9yLm1ncy41Lm51bWVyaWMnLFxyXG4gICAgICAnZXJyb3IubWdzLjYubnVtZXJpYyc6ICdlcnJvci5tZ3MuNi5udW1lcmljJyxcclxuICAgICAgJ2Vycm9yLm1ncy44Lm51bWVyaWMnOidlcnJvci5tZ3MuOC5udW1lcmljJyxcclxuICAgICAgJ2Vycm9yLm1ncy5yZWd1LmNvbnRhY3QuaWQnOiAnZXJyb3IubWdzLnJlZ3UuY29udGFjdC5pZCcsXHJcbiAgICAgICdlcnJvci5tZ3MuZG9zc2llci5pZCc6ICdlcnJvci5tZ3MuZG9zc2llci5pZCcsXHJcbiAgICAgICdlcnJvci5tZ3MubGljZW5jZS5udW1iZXInOiAnZXJyb3IubWdzLmxpY2VuY2UubnVtYmVyJyxcclxuICAgICAgJ2Vycm9yLm1ncy5hcHBsaWNhdGlvbi5udW1iZXInOiAnZXJyb3IubWdzLmFwcGxpY2F0aW9uLm51bWJlcicsXHJcbiAgICAgICdlcnJvci5tZ3MuZGluJzogJ2Vycm9yLm1ncy5kaW4nLFxyXG4gICAgICAnZXJyb3IubWdzLm5wbic6ICdlcnJvci5tZ3MubnBuJyxcclxuICAgICAgJ2Vycm9yLm1zZy5yZW1vdmUuY29udGFjdCcgOiAnZXJyb3IubXNnLnJlbW92ZS5jb250YWN0JyxcclxuICAgICAgJ2Vycm9yLm1zZy5yZXZpc2UuY29udGFjdCcgOiAnZXJyb3IubXNnLnJldmlzZS5jb250YWN0JyxcclxuICAgICAgJ2Vycm9yLm1ncy5pbmNvcnJlY3RGb3JtYXQnOiAnZXJyb3IubWdzLmluY29ycmVjdEZvcm1hdCcsXHJcbiAgICAgICdlcnJvci5tc2cuaW52YWxpZERhdGUnOiAnZXJyb3IubXNnLmludmFsaWREYXRlJyxcclxuICAgICAgJ2Vycm9yLm1zZy5lbmREYXRlJzonZXJyb3IubXNnLmVuZERhdGUnLFxyXG4gICAgICAnZXJyb3IubXNnLmFtb3VudC5saW1pdCc6J2Vycm9yLm1zZy5hbW91bnQubGltaXQnLFxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gY29uZmlnW3ZhbGlkYXRvck5hbWVdO1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIGVtYWlsVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIC8vIFJGQyAyODIyIGNvbXBsaWFudCByZWdleFxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bYS16QS1aMC05Xy4rLV0rQFthLXpBLVowLTktXStcXC5bYS16QS1aMC05LS5dKyQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5lbWFpbCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLypzdGF0aWMgcGFzc3dvcmRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgLy8gezYsMTAwfSAgICAgICAgICAgLSBBc3NlcnQgcGFzc3dvcmQgaXMgYmV0d2VlbiA2IGFuZCAxMDAgY2hhcmFjdGVyc1xyXG4gICAgLy8gKD89LipbMC05XSkgICAgICAgLSBBc3NlcnQgYSBzdHJpbmcgaGFzIGF0IGxlYXN0IG9uZSBudW1iZXJcclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eKD89LipbMC05XSlbYS16QS1aMC05IUAjJCVeJipdezYsMTAwfSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2ludmFsaWRQYXNzd29yZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH0qL1xyXG4gIHN0YXRpYyBjYW5hZGFQb3N0YWxWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL14oPyEuKltERklPUVVdKVtBLVZYWWEtdnh5XVswLTldW0EtWmEtel0gP1swLTldW0EtWmEtel1bMC05XSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5wb3N0YWwnOiB0cnVlfTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgdXNhUG9zdGFsVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17NX0oPzotWzAtOV17NH0pPyQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy56aXAnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBjb3VudHJ5VmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlWzBdLmlkICE9PSAnJykge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J3JlcXVpcmVkJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgcGhvbmVOdW1iZXJWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XSokLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cucGhvbmUnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBmYXhOdW1iZXJWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XSokLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cuZmF4JzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgbnVtYmVyVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV0qJC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLm51bWJlcic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNvbXBhbnlJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmNvbXBhbnkuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gICAgc3RhdGljIG51bWVyaWM0VmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17NH0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuNC5udW1lcmljJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgbnVtZXJpYzVWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs1fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy41Lm51bWVyaWMnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBudW1lcmljNlZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLjYubnVtZXJpYyc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG51bWVyaWM4VmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17OH0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuOC5udW1lcmljJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbiAgc3RhdGljIGRvc3NpZXJJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlttXXsxfVswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRvc3NpZXIuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBkb3NzaWVyQ29udGFjdElkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17NX0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuY29udGFjdC5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHJlZ3VsYXRvcnlDb250YWN0SWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XXs1fSQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5yZWd1LmNvbnRhY3QuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBsaWNlbmNlTnVtVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MubGljZW5jZS5udW1iZXInOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuXHJcbiAgc3RhdGljIGFwcE51bVZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezZ9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmFwcGxpY2F0aW9uLm51bWJlcic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGRpblZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezh9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmRpbic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIG5wblZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezh9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLm5wbic6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydyZXF1aXJlZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGNvbnRhY3RJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezV9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubWdzLmNvbnRhY3QuaWQnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyBwcmltYXJ5Q29tcGFueUlkVmFsaWRhdG9yKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlLm1hdGNoKC9eWzAtOV17Nn0kLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tZ3MuY29tcGFueS5pZCc6IHRydWV9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGF0TGVhc3RPbmVDaGVja2JveFNlbGVjdGVkKGZvcm1BcnJheTogRm9ybUFycmF5KSB7XHJcbiAgICAvLyByZXR1cm4gKCk6IHsgW2tleTogc3RyaW5nXTogYm9vbGVhbiB9IHwgbnVsbCA9PiB7XHJcbiAgICAgIGNvbnN0IGNvbnRyb2xzID0gZm9ybUFycmF5LmNvbnRyb2xzO1xyXG5cclxuICAgICAgLy8gQ2hlY2sgaWYgYXQgbGVhc3Qgb25lIGNoZWNrYm94IGlzIHNlbGVjdGVkXHJcbiAgICAgIGNvbnN0IGlzQXRMZWFzdE9uZVNlbGVjdGVkID0gY29udHJvbHMuc29tZSgoY29udHJvbDogQWJzdHJhY3RDb250cm9sKSA9PiBjb250cm9sLnZhbHVlID09PSB0cnVlKTtcclxuXHJcbiAgICAgIC8vIFJldHVybiB2YWxpZGF0aW9uIGVycm9yIGlmIG5vbmUgYXJlIHNlbGVjdGVkXHJcbiAgICAgIHJldHVybiBpc0F0TGVhc3RPbmVTZWxlY3RlZCA/IG51bGwgOiB7ICdyZXF1aXJlZCc6IHRydWUgfTtcclxuICAgIC8vIH07XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgbWFzdGVyRmlsZU51bWJlclZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICAvLyB0b2RvXHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldezR9LVswLTldezN9JC8pKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHsgJ2Vycm9yLm1ncy5pbmNvcnJlY3RGb3JtYXQnOiB0cnVlIH07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyBpZiBmaXJzdCBsZXR0ZXIgaXMgZSwgdGhlbiBmb2xsb3dlZCBieSA2IG51bWJlcnNcclxuICAvLyBpZiBmaXJzdCBsZXR0ZXIgaXMgZiwgdGhlbiBmb2xsb3dlZCBieSA3IG51bWJlcnNcclxuICBzdGF0aWMgbWFzdGVyRmlsZURvc3NpZXJJZFZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoXHJcbiAgICAgIGNvbnRyb2wudmFsdWUubWF0Y2goL15bZV17MX1bMC05XXs2fSQvKSB8fFxyXG4gICAgICBjb250cm9sLnZhbHVlLm1hdGNoKC9eW2ZdezF9WzAtOV17N30kLylcclxuICAgICkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1ncy5kb3NzaWVyLmlkJzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgYWNjb3VudE51bWJlclZhbGlkYXRvcihjb250cm9sKSB7XHJcbiAgICBpZiAoIWNvbnRyb2wudmFsdWUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBpZiAoY29udHJvbC52YWx1ZS5tYXRjaCgvXlswLTldKiQvKSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB7J2Vycm9yLm1zZy5hY2NvdW50JzogdHJ1ZX07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgYnVzaW5lc3NOdW1iZXJWYWxpZGF0b3IoY29udHJvbCkge1xyXG4gICAgaWYgKCFjb250cm9sLnZhbHVlKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgaWYgKGNvbnRyb2wudmFsdWUubWF0Y2goL15bMC05XSokLykpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geydlcnJvci5tc2cuYnVzaW5lc3MnOiB0cnVlfTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICBzdGF0aWMgbGltaXRWYWxpZGF0aW9uKGNvbnRyb2wpIHtcclxuICAgIGlmICghY29udHJvbC52YWx1ZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGlmIChjb250cm9sLnZhbHVlID4gMTAwMDAwMDApIHtcclxuICAgICAgcmV0dXJuIHsnZXJyb3IubXNnLmFtb3VudC5saW1pdCc6IHRydWV9O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ==