import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export class RecordDiscardService {
    constructor() {
        this.discardConfirmedSubject = new Subject();
        this.discardConfirmed$ = this.discardConfirmedSubject.asObservable();
    }
    confirmDiscard(index) {
        this.discardConfirmedSubject.next(index);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RecordDiscardService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RecordDiscardService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RecordDiscardService, decorators: [{
            type: Injectable
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb3JkLWRpc2NhcmQuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2hwZmIvc2RrL3VpL3JlY29yZC9yZWNvcmQtYWN0aW9uLXNlcnZpY2UvcmVjb3JkLWRpc2NhcmQuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxNQUFNLENBQUM7O0FBRy9CLE1BQU0sT0FBTyxvQkFBb0I7SUFEakM7UUFFVSw0QkFBdUIsR0FBRyxJQUFJLE9BQU8sRUFBVSxDQUFDO1FBQ3hELHNCQUFpQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxZQUFZLEVBQUUsQ0FBQztLQUtqRTtJQUhDLGNBQWMsQ0FBQyxLQUFhO1FBQzFCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQzsrR0FOVSxvQkFBb0I7bUhBQXBCLG9CQUFvQjs7NEZBQXBCLG9CQUFvQjtrQkFEaEMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgUmVjb3JkRGlzY2FyZFNlcnZpY2Uge1xyXG4gIHByaXZhdGUgZGlzY2FyZENvbmZpcm1lZFN1YmplY3QgPSBuZXcgU3ViamVjdDxudW1iZXI+KCk7XHJcbiAgZGlzY2FyZENvbmZpcm1lZCQgPSB0aGlzLmRpc2NhcmRDb25maXJtZWRTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG5cclxuICBjb25maXJtRGlzY2FyZChpbmRleDogbnVtYmVyKSB7XHJcbiAgICB0aGlzLmRpc2NhcmRDb25maXJtZWRTdWJqZWN0Lm5leHQoaW5kZXgpO1xyXG4gIH1cclxufVxyXG4iXX0=