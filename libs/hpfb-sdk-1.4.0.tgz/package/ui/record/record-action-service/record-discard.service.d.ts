import * as i0 from "@angular/core";
export declare class RecordDiscardService {
    private discardConfirmedSubject;
    discardConfirmed$: import("rxjs").Observable<number>;
    confirmDiscard(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordDiscardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RecordDiscardService>;
}
