import * as i0 from "@angular/core";
export declare class RecordDeleteService {
    private deleteConfirmedSubject;
    deleteConfirmed$: import("rxjs").Observable<number>;
    confirmDelete(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordDeleteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RecordDeleteService>;
}
