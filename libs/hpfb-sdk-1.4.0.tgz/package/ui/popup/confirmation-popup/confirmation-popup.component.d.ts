import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ConfirmationPopupComponent {
    message: string;
    title: string;
    id: string;
    cancel: string;
    confirm: string;
    heading: string;
    confirmed: EventEmitter<any>;
    closePopup(): void;
    onConfirm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationPopupComponent, "lib-confirmation-popup", never, { "message": { "alias": "message"; "required": false; }; "title": { "alias": "title"; "required": false; }; "id": { "alias": "id"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "confirm": { "alias": "confirm"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; }, { "confirmed": "confirmed"; }, never, never, true, never>;
}
